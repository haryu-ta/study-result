/**
 * C000_GAIKOKUKAWASEINFO__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C000_GAIKOKUKAWASEINFO__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult activityHistories;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String CCYKBN_KIJUNBI__c;

    private java.lang.String CCYKBN__c;

    private java.lang.String CCYUNITKBN_SHOUREIRATE__c;

    private java.lang.String CCYUNITKBN_TTM__c;

    private java.lang.String CCY_CCYRYAKUNM3__c;

    private java.lang.String CCY_CCYRYAKUNM6__c;

    private java.lang.String CCY_HOJOKETASUU__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Boolean DELFLG__c;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult events;

    private java.lang.String GETSUMATSUEIGYOBIKBN__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private java.lang.Double KATEIKANSANRATE__c;

    private java.util.Date KATEIRATEJISSHIBI_ZENKAI__c;

    private java.util.Date KATEIRATEJISSHIBI__c;

    private java.lang.Double KATEIRATE_ZENKAI__c;

    private java.util.Date KIJUNBI__c;

    private java.util.Date lastActivityDate;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String MULTI_DIVKBN_SHOUREIRATE__c;

    private java.lang.String MULTI_DIVKBN_TTM__c;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.QueryResult openActivities;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.Double SHOUREIRATE__c;

    private com.sforce.soap.enterprise.QueryResult shares;

    private java.util.Calendar systemModstamp;

    private java.lang.String TEKIYOUKBN_SHOUREIRATE__c;

    private java.lang.String TEKIYOUKBN_TTM__c;

    private java.lang.Double TTB__c;

    private java.lang.Double TTM_ICHIJI__c;

    private java.lang.Double TTM__c;

    private java.lang.Double TTS__c;

    private com.sforce.soap.enterprise.QueryResult tasks;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    public C000_GAIKOKUKAWASEINFO__c() {
    }

    public C000_GAIKOKUKAWASEINFO__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult activityHistories,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String CCYKBN_KIJUNBI__c,
           java.lang.String CCYKBN__c,
           java.lang.String CCYUNITKBN_SHOUREIRATE__c,
           java.lang.String CCYUNITKBN_TTM__c,
           java.lang.String CCY_CCYRYAKUNM3__c,
           java.lang.String CCY_CCYRYAKUNM6__c,
           java.lang.String CCY_HOJOKETASUU__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Boolean DELFLG__c,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult events,
           java.lang.String GETSUMATSUEIGYOBIKBN__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           java.lang.Double KATEIKANSANRATE__c,
           java.util.Date KATEIRATEJISSHIBI_ZENKAI__c,
           java.util.Date KATEIRATEJISSHIBI__c,
           java.lang.Double KATEIRATE_ZENKAI__c,
           java.util.Date KIJUNBI__c,
           java.util.Date lastActivityDate,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String MULTI_DIVKBN_SHOUREIRATE__c,
           java.lang.String MULTI_DIVKBN_TTM__c,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.QueryResult openActivities,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.Double SHOUREIRATE__c,
           com.sforce.soap.enterprise.QueryResult shares,
           java.util.Calendar systemModstamp,
           java.lang.String TEKIYOUKBN_SHOUREIRATE__c,
           java.lang.String TEKIYOUKBN_TTM__c,
           java.lang.Double TTB__c,
           java.lang.Double TTM_ICHIJI__c,
           java.lang.Double TTM__c,
           java.lang.Double TTS__c,
           com.sforce.soap.enterprise.QueryResult tasks,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        super(
            fieldsToNull,
            id);
        this.activityHistories = activityHistories;
        this.attachments = attachments;
        this.CCYKBN_KIJUNBI__c = CCYKBN_KIJUNBI__c;
        this.CCYKBN__c = CCYKBN__c;
        this.CCYUNITKBN_SHOUREIRATE__c = CCYUNITKBN_SHOUREIRATE__c;
        this.CCYUNITKBN_TTM__c = CCYUNITKBN_TTM__c;
        this.CCY_CCYRYAKUNM3__c = CCY_CCYRYAKUNM3__c;
        this.CCY_CCYRYAKUNM6__c = CCY_CCYRYAKUNM6__c;
        this.CCY_HOJOKETASUU__c = CCY_HOJOKETASUU__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.DELFLG__c = DELFLG__c;
        this.duplicateRecordItems = duplicateRecordItems;
        this.events = events;
        this.GETSUMATSUEIGYOBIKBN__c = GETSUMATSUEIGYOBIKBN__c;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.KATEIKANSANRATE__c = KATEIKANSANRATE__c;
        this.KATEIRATEJISSHIBI_ZENKAI__c = KATEIRATEJISSHIBI_ZENKAI__c;
        this.KATEIRATEJISSHIBI__c = KATEIRATEJISSHIBI__c;
        this.KATEIRATE_ZENKAI__c = KATEIRATE_ZENKAI__c;
        this.KIJUNBI__c = KIJUNBI__c;
        this.lastActivityDate = lastActivityDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.MULTI_DIVKBN_SHOUREIRATE__c = MULTI_DIVKBN_SHOUREIRATE__c;
        this.MULTI_DIVKBN_TTM__c = MULTI_DIVKBN_TTM__c;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.openActivities = openActivities;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.SHOUREIRATE__c = SHOUREIRATE__c;
        this.shares = shares;
        this.systemModstamp = systemModstamp;
        this.TEKIYOUKBN_SHOUREIRATE__c = TEKIYOUKBN_SHOUREIRATE__c;
        this.TEKIYOUKBN_TTM__c = TEKIYOUKBN_TTM__c;
        this.TTB__c = TTB__c;
        this.TTM_ICHIJI__c = TTM_ICHIJI__c;
        this.TTM__c = TTM__c;
        this.TTS__c = TTS__c;
        this.tasks = tasks;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the activityHistories value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return activityHistories
     */
    public com.sforce.soap.enterprise.QueryResult getActivityHistories() {
        return activityHistories;
    }


    /**
     * Sets the activityHistories value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param activityHistories
     */
    public void setActivityHistories(com.sforce.soap.enterprise.QueryResult activityHistories) {
        this.activityHistories = activityHistories;
    }


    /**
     * Gets the attachments value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the CCYKBN_KIJUNBI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return CCYKBN_KIJUNBI__c
     */
    public java.lang.String getCCYKBN_KIJUNBI__c() {
        return CCYKBN_KIJUNBI__c;
    }


    /**
     * Sets the CCYKBN_KIJUNBI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param CCYKBN_KIJUNBI__c
     */
    public void setCCYKBN_KIJUNBI__c(java.lang.String CCYKBN_KIJUNBI__c) {
        this.CCYKBN_KIJUNBI__c = CCYKBN_KIJUNBI__c;
    }


    /**
     * Gets the CCYKBN__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return CCYKBN__c
     */
    public java.lang.String getCCYKBN__c() {
        return CCYKBN__c;
    }


    /**
     * Sets the CCYKBN__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param CCYKBN__c
     */
    public void setCCYKBN__c(java.lang.String CCYKBN__c) {
        this.CCYKBN__c = CCYKBN__c;
    }


    /**
     * Gets the CCYUNITKBN_SHOUREIRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return CCYUNITKBN_SHOUREIRATE__c
     */
    public java.lang.String getCCYUNITKBN_SHOUREIRATE__c() {
        return CCYUNITKBN_SHOUREIRATE__c;
    }


    /**
     * Sets the CCYUNITKBN_SHOUREIRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param CCYUNITKBN_SHOUREIRATE__c
     */
    public void setCCYUNITKBN_SHOUREIRATE__c(java.lang.String CCYUNITKBN_SHOUREIRATE__c) {
        this.CCYUNITKBN_SHOUREIRATE__c = CCYUNITKBN_SHOUREIRATE__c;
    }


    /**
     * Gets the CCYUNITKBN_TTM__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return CCYUNITKBN_TTM__c
     */
    public java.lang.String getCCYUNITKBN_TTM__c() {
        return CCYUNITKBN_TTM__c;
    }


    /**
     * Sets the CCYUNITKBN_TTM__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param CCYUNITKBN_TTM__c
     */
    public void setCCYUNITKBN_TTM__c(java.lang.String CCYUNITKBN_TTM__c) {
        this.CCYUNITKBN_TTM__c = CCYUNITKBN_TTM__c;
    }


    /**
     * Gets the CCY_CCYRYAKUNM3__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return CCY_CCYRYAKUNM3__c
     */
    public java.lang.String getCCY_CCYRYAKUNM3__c() {
        return CCY_CCYRYAKUNM3__c;
    }


    /**
     * Sets the CCY_CCYRYAKUNM3__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param CCY_CCYRYAKUNM3__c
     */
    public void setCCY_CCYRYAKUNM3__c(java.lang.String CCY_CCYRYAKUNM3__c) {
        this.CCY_CCYRYAKUNM3__c = CCY_CCYRYAKUNM3__c;
    }


    /**
     * Gets the CCY_CCYRYAKUNM6__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return CCY_CCYRYAKUNM6__c
     */
    public java.lang.String getCCY_CCYRYAKUNM6__c() {
        return CCY_CCYRYAKUNM6__c;
    }


    /**
     * Sets the CCY_CCYRYAKUNM6__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param CCY_CCYRYAKUNM6__c
     */
    public void setCCY_CCYRYAKUNM6__c(java.lang.String CCY_CCYRYAKUNM6__c) {
        this.CCY_CCYRYAKUNM6__c = CCY_CCYRYAKUNM6__c;
    }


    /**
     * Gets the CCY_HOJOKETASUU__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return CCY_HOJOKETASUU__c
     */
    public java.lang.String getCCY_HOJOKETASUU__c() {
        return CCY_HOJOKETASUU__c;
    }


    /**
     * Sets the CCY_HOJOKETASUU__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param CCY_HOJOKETASUU__c
     */
    public void setCCY_HOJOKETASUU__c(java.lang.String CCY_HOJOKETASUU__c) {
        this.CCY_HOJOKETASUU__c = CCY_HOJOKETASUU__c;
    }


    /**
     * Gets the combinedAttachments value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the DELFLG__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return DELFLG__c
     */
    public java.lang.Boolean getDELFLG__c() {
        return DELFLG__c;
    }


    /**
     * Sets the DELFLG__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param DELFLG__c
     */
    public void setDELFLG__c(java.lang.Boolean DELFLG__c) {
        this.DELFLG__c = DELFLG__c;
    }


    /**
     * Gets the duplicateRecordItems value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the events value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return events
     */
    public com.sforce.soap.enterprise.QueryResult getEvents() {
        return events;
    }


    /**
     * Sets the events value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param events
     */
    public void setEvents(com.sforce.soap.enterprise.QueryResult events) {
        this.events = events;
    }


    /**
     * Gets the GETSUMATSUEIGYOBIKBN__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return GETSUMATSUEIGYOBIKBN__c
     */
    public java.lang.String getGETSUMATSUEIGYOBIKBN__c() {
        return GETSUMATSUEIGYOBIKBN__c;
    }


    /**
     * Sets the GETSUMATSUEIGYOBIKBN__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param GETSUMATSUEIGYOBIKBN__c
     */
    public void setGETSUMATSUEIGYOBIKBN__c(java.lang.String GETSUMATSUEIGYOBIKBN__c) {
        this.GETSUMATSUEIGYOBIKBN__c = GETSUMATSUEIGYOBIKBN__c;
    }


    /**
     * Gets the histories value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the KATEIKANSANRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return KATEIKANSANRATE__c
     */
    public java.lang.Double getKATEIKANSANRATE__c() {
        return KATEIKANSANRATE__c;
    }


    /**
     * Sets the KATEIKANSANRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param KATEIKANSANRATE__c
     */
    public void setKATEIKANSANRATE__c(java.lang.Double KATEIKANSANRATE__c) {
        this.KATEIKANSANRATE__c = KATEIKANSANRATE__c;
    }


    /**
     * Gets the KATEIRATEJISSHIBI_ZENKAI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return KATEIRATEJISSHIBI_ZENKAI__c
     */
    public java.util.Date getKATEIRATEJISSHIBI_ZENKAI__c() {
        return KATEIRATEJISSHIBI_ZENKAI__c;
    }


    /**
     * Sets the KATEIRATEJISSHIBI_ZENKAI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param KATEIRATEJISSHIBI_ZENKAI__c
     */
    public void setKATEIRATEJISSHIBI_ZENKAI__c(java.util.Date KATEIRATEJISSHIBI_ZENKAI__c) {
        this.KATEIRATEJISSHIBI_ZENKAI__c = KATEIRATEJISSHIBI_ZENKAI__c;
    }


    /**
     * Gets the KATEIRATEJISSHIBI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return KATEIRATEJISSHIBI__c
     */
    public java.util.Date getKATEIRATEJISSHIBI__c() {
        return KATEIRATEJISSHIBI__c;
    }


    /**
     * Sets the KATEIRATEJISSHIBI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param KATEIRATEJISSHIBI__c
     */
    public void setKATEIRATEJISSHIBI__c(java.util.Date KATEIRATEJISSHIBI__c) {
        this.KATEIRATEJISSHIBI__c = KATEIRATEJISSHIBI__c;
    }


    /**
     * Gets the KATEIRATE_ZENKAI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return KATEIRATE_ZENKAI__c
     */
    public java.lang.Double getKATEIRATE_ZENKAI__c() {
        return KATEIRATE_ZENKAI__c;
    }


    /**
     * Sets the KATEIRATE_ZENKAI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param KATEIRATE_ZENKAI__c
     */
    public void setKATEIRATE_ZENKAI__c(java.lang.Double KATEIRATE_ZENKAI__c) {
        this.KATEIRATE_ZENKAI__c = KATEIRATE_ZENKAI__c;
    }


    /**
     * Gets the KIJUNBI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return KIJUNBI__c
     */
    public java.util.Date getKIJUNBI__c() {
        return KIJUNBI__c;
    }


    /**
     * Sets the KIJUNBI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param KIJUNBI__c
     */
    public void setKIJUNBI__c(java.util.Date KIJUNBI__c) {
        this.KIJUNBI__c = KIJUNBI__c;
    }


    /**
     * Gets the lastActivityDate value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return lastActivityDate
     */
    public java.util.Date getLastActivityDate() {
        return lastActivityDate;
    }


    /**
     * Sets the lastActivityDate value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param lastActivityDate
     */
    public void setLastActivityDate(java.util.Date lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }


    /**
     * Gets the lastModifiedBy value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the MULTI_DIVKBN_SHOUREIRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return MULTI_DIVKBN_SHOUREIRATE__c
     */
    public java.lang.String getMULTI_DIVKBN_SHOUREIRATE__c() {
        return MULTI_DIVKBN_SHOUREIRATE__c;
    }


    /**
     * Sets the MULTI_DIVKBN_SHOUREIRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param MULTI_DIVKBN_SHOUREIRATE__c
     */
    public void setMULTI_DIVKBN_SHOUREIRATE__c(java.lang.String MULTI_DIVKBN_SHOUREIRATE__c) {
        this.MULTI_DIVKBN_SHOUREIRATE__c = MULTI_DIVKBN_SHOUREIRATE__c;
    }


    /**
     * Gets the MULTI_DIVKBN_TTM__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return MULTI_DIVKBN_TTM__c
     */
    public java.lang.String getMULTI_DIVKBN_TTM__c() {
        return MULTI_DIVKBN_TTM__c;
    }


    /**
     * Sets the MULTI_DIVKBN_TTM__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param MULTI_DIVKBN_TTM__c
     */
    public void setMULTI_DIVKBN_TTM__c(java.lang.String MULTI_DIVKBN_TTM__c) {
        this.MULTI_DIVKBN_TTM__c = MULTI_DIVKBN_TTM__c;
    }


    /**
     * Gets the name value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the openActivities value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return openActivities
     */
    public com.sforce.soap.enterprise.QueryResult getOpenActivities() {
        return openActivities;
    }


    /**
     * Sets the openActivities value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param openActivities
     */
    public void setOpenActivities(com.sforce.soap.enterprise.QueryResult openActivities) {
        this.openActivities = openActivities;
    }


    /**
     * Gets the owner value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the SHOUREIRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return SHOUREIRATE__c
     */
    public java.lang.Double getSHOUREIRATE__c() {
        return SHOUREIRATE__c;
    }


    /**
     * Sets the SHOUREIRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param SHOUREIRATE__c
     */
    public void setSHOUREIRATE__c(java.lang.Double SHOUREIRATE__c) {
        this.SHOUREIRATE__c = SHOUREIRATE__c;
    }


    /**
     * Gets the shares value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return shares
     */
    public com.sforce.soap.enterprise.QueryResult getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param shares
     */
    public void setShares(com.sforce.soap.enterprise.QueryResult shares) {
        this.shares = shares;
    }


    /**
     * Gets the systemModstamp value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the TEKIYOUKBN_SHOUREIRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return TEKIYOUKBN_SHOUREIRATE__c
     */
    public java.lang.String getTEKIYOUKBN_SHOUREIRATE__c() {
        return TEKIYOUKBN_SHOUREIRATE__c;
    }


    /**
     * Sets the TEKIYOUKBN_SHOUREIRATE__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param TEKIYOUKBN_SHOUREIRATE__c
     */
    public void setTEKIYOUKBN_SHOUREIRATE__c(java.lang.String TEKIYOUKBN_SHOUREIRATE__c) {
        this.TEKIYOUKBN_SHOUREIRATE__c = TEKIYOUKBN_SHOUREIRATE__c;
    }


    /**
     * Gets the TEKIYOUKBN_TTM__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return TEKIYOUKBN_TTM__c
     */
    public java.lang.String getTEKIYOUKBN_TTM__c() {
        return TEKIYOUKBN_TTM__c;
    }


    /**
     * Sets the TEKIYOUKBN_TTM__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param TEKIYOUKBN_TTM__c
     */
    public void setTEKIYOUKBN_TTM__c(java.lang.String TEKIYOUKBN_TTM__c) {
        this.TEKIYOUKBN_TTM__c = TEKIYOUKBN_TTM__c;
    }


    /**
     * Gets the TTB__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return TTB__c
     */
    public java.lang.Double getTTB__c() {
        return TTB__c;
    }


    /**
     * Sets the TTB__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param TTB__c
     */
    public void setTTB__c(java.lang.Double TTB__c) {
        this.TTB__c = TTB__c;
    }


    /**
     * Gets the TTM_ICHIJI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return TTM_ICHIJI__c
     */
    public java.lang.Double getTTM_ICHIJI__c() {
        return TTM_ICHIJI__c;
    }


    /**
     * Sets the TTM_ICHIJI__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param TTM_ICHIJI__c
     */
    public void setTTM_ICHIJI__c(java.lang.Double TTM_ICHIJI__c) {
        this.TTM_ICHIJI__c = TTM_ICHIJI__c;
    }


    /**
     * Gets the TTM__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return TTM__c
     */
    public java.lang.Double getTTM__c() {
        return TTM__c;
    }


    /**
     * Sets the TTM__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param TTM__c
     */
    public void setTTM__c(java.lang.Double TTM__c) {
        this.TTM__c = TTM__c;
    }


    /**
     * Gets the TTS__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return TTS__c
     */
    public java.lang.Double getTTS__c() {
        return TTS__c;
    }


    /**
     * Sets the TTS__c value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param TTS__c
     */
    public void setTTS__c(java.lang.Double TTS__c) {
        this.TTS__c = TTS__c;
    }


    /**
     * Gets the tasks value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return tasks
     */
    public com.sforce.soap.enterprise.QueryResult getTasks() {
        return tasks;
    }


    /**
     * Sets the tasks value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param tasks
     */
    public void setTasks(com.sforce.soap.enterprise.QueryResult tasks) {
        this.tasks = tasks;
    }


    /**
     * Gets the topicAssignments value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C000_GAIKOKUKAWASEINFO__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C000_GAIKOKUKAWASEINFO__c)) return false;
        C000_GAIKOKUKAWASEINFO__c other = (C000_GAIKOKUKAWASEINFO__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.activityHistories==null && other.getActivityHistories()==null) || 
             (this.activityHistories!=null &&
              this.activityHistories.equals(other.getActivityHistories()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.CCYKBN_KIJUNBI__c==null && other.getCCYKBN_KIJUNBI__c()==null) || 
             (this.CCYKBN_KIJUNBI__c!=null &&
              this.CCYKBN_KIJUNBI__c.equals(other.getCCYKBN_KIJUNBI__c()))) &&
            ((this.CCYKBN__c==null && other.getCCYKBN__c()==null) || 
             (this.CCYKBN__c!=null &&
              this.CCYKBN__c.equals(other.getCCYKBN__c()))) &&
            ((this.CCYUNITKBN_SHOUREIRATE__c==null && other.getCCYUNITKBN_SHOUREIRATE__c()==null) || 
             (this.CCYUNITKBN_SHOUREIRATE__c!=null &&
              this.CCYUNITKBN_SHOUREIRATE__c.equals(other.getCCYUNITKBN_SHOUREIRATE__c()))) &&
            ((this.CCYUNITKBN_TTM__c==null && other.getCCYUNITKBN_TTM__c()==null) || 
             (this.CCYUNITKBN_TTM__c!=null &&
              this.CCYUNITKBN_TTM__c.equals(other.getCCYUNITKBN_TTM__c()))) &&
            ((this.CCY_CCYRYAKUNM3__c==null && other.getCCY_CCYRYAKUNM3__c()==null) || 
             (this.CCY_CCYRYAKUNM3__c!=null &&
              this.CCY_CCYRYAKUNM3__c.equals(other.getCCY_CCYRYAKUNM3__c()))) &&
            ((this.CCY_CCYRYAKUNM6__c==null && other.getCCY_CCYRYAKUNM6__c()==null) || 
             (this.CCY_CCYRYAKUNM6__c!=null &&
              this.CCY_CCYRYAKUNM6__c.equals(other.getCCY_CCYRYAKUNM6__c()))) &&
            ((this.CCY_HOJOKETASUU__c==null && other.getCCY_HOJOKETASUU__c()==null) || 
             (this.CCY_HOJOKETASUU__c!=null &&
              this.CCY_HOJOKETASUU__c.equals(other.getCCY_HOJOKETASUU__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.DELFLG__c==null && other.getDELFLG__c()==null) || 
             (this.DELFLG__c!=null &&
              this.DELFLG__c.equals(other.getDELFLG__c()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.events==null && other.getEvents()==null) || 
             (this.events!=null &&
              this.events.equals(other.getEvents()))) &&
            ((this.GETSUMATSUEIGYOBIKBN__c==null && other.getGETSUMATSUEIGYOBIKBN__c()==null) || 
             (this.GETSUMATSUEIGYOBIKBN__c!=null &&
              this.GETSUMATSUEIGYOBIKBN__c.equals(other.getGETSUMATSUEIGYOBIKBN__c()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.KATEIKANSANRATE__c==null && other.getKATEIKANSANRATE__c()==null) || 
             (this.KATEIKANSANRATE__c!=null &&
              this.KATEIKANSANRATE__c.equals(other.getKATEIKANSANRATE__c()))) &&
            ((this.KATEIRATEJISSHIBI_ZENKAI__c==null && other.getKATEIRATEJISSHIBI_ZENKAI__c()==null) || 
             (this.KATEIRATEJISSHIBI_ZENKAI__c!=null &&
              this.KATEIRATEJISSHIBI_ZENKAI__c.equals(other.getKATEIRATEJISSHIBI_ZENKAI__c()))) &&
            ((this.KATEIRATEJISSHIBI__c==null && other.getKATEIRATEJISSHIBI__c()==null) || 
             (this.KATEIRATEJISSHIBI__c!=null &&
              this.KATEIRATEJISSHIBI__c.equals(other.getKATEIRATEJISSHIBI__c()))) &&
            ((this.KATEIRATE_ZENKAI__c==null && other.getKATEIRATE_ZENKAI__c()==null) || 
             (this.KATEIRATE_ZENKAI__c!=null &&
              this.KATEIRATE_ZENKAI__c.equals(other.getKATEIRATE_ZENKAI__c()))) &&
            ((this.KIJUNBI__c==null && other.getKIJUNBI__c()==null) || 
             (this.KIJUNBI__c!=null &&
              this.KIJUNBI__c.equals(other.getKIJUNBI__c()))) &&
            ((this.lastActivityDate==null && other.getLastActivityDate()==null) || 
             (this.lastActivityDate!=null &&
              this.lastActivityDate.equals(other.getLastActivityDate()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.MULTI_DIVKBN_SHOUREIRATE__c==null && other.getMULTI_DIVKBN_SHOUREIRATE__c()==null) || 
             (this.MULTI_DIVKBN_SHOUREIRATE__c!=null &&
              this.MULTI_DIVKBN_SHOUREIRATE__c.equals(other.getMULTI_DIVKBN_SHOUREIRATE__c()))) &&
            ((this.MULTI_DIVKBN_TTM__c==null && other.getMULTI_DIVKBN_TTM__c()==null) || 
             (this.MULTI_DIVKBN_TTM__c!=null &&
              this.MULTI_DIVKBN_TTM__c.equals(other.getMULTI_DIVKBN_TTM__c()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.openActivities==null && other.getOpenActivities()==null) || 
             (this.openActivities!=null &&
              this.openActivities.equals(other.getOpenActivities()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.SHOUREIRATE__c==null && other.getSHOUREIRATE__c()==null) || 
             (this.SHOUREIRATE__c!=null &&
              this.SHOUREIRATE__c.equals(other.getSHOUREIRATE__c()))) &&
            ((this.shares==null && other.getShares()==null) || 
             (this.shares!=null &&
              this.shares.equals(other.getShares()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.TEKIYOUKBN_SHOUREIRATE__c==null && other.getTEKIYOUKBN_SHOUREIRATE__c()==null) || 
             (this.TEKIYOUKBN_SHOUREIRATE__c!=null &&
              this.TEKIYOUKBN_SHOUREIRATE__c.equals(other.getTEKIYOUKBN_SHOUREIRATE__c()))) &&
            ((this.TEKIYOUKBN_TTM__c==null && other.getTEKIYOUKBN_TTM__c()==null) || 
             (this.TEKIYOUKBN_TTM__c!=null &&
              this.TEKIYOUKBN_TTM__c.equals(other.getTEKIYOUKBN_TTM__c()))) &&
            ((this.TTB__c==null && other.getTTB__c()==null) || 
             (this.TTB__c!=null &&
              this.TTB__c.equals(other.getTTB__c()))) &&
            ((this.TTM_ICHIJI__c==null && other.getTTM_ICHIJI__c()==null) || 
             (this.TTM_ICHIJI__c!=null &&
              this.TTM_ICHIJI__c.equals(other.getTTM_ICHIJI__c()))) &&
            ((this.TTM__c==null && other.getTTM__c()==null) || 
             (this.TTM__c!=null &&
              this.TTM__c.equals(other.getTTM__c()))) &&
            ((this.TTS__c==null && other.getTTS__c()==null) || 
             (this.TTS__c!=null &&
              this.TTS__c.equals(other.getTTS__c()))) &&
            ((this.tasks==null && other.getTasks()==null) || 
             (this.tasks!=null &&
              this.tasks.equals(other.getTasks()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getActivityHistories() != null) {
            _hashCode += getActivityHistories().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getCCYKBN_KIJUNBI__c() != null) {
            _hashCode += getCCYKBN_KIJUNBI__c().hashCode();
        }
        if (getCCYKBN__c() != null) {
            _hashCode += getCCYKBN__c().hashCode();
        }
        if (getCCYUNITKBN_SHOUREIRATE__c() != null) {
            _hashCode += getCCYUNITKBN_SHOUREIRATE__c().hashCode();
        }
        if (getCCYUNITKBN_TTM__c() != null) {
            _hashCode += getCCYUNITKBN_TTM__c().hashCode();
        }
        if (getCCY_CCYRYAKUNM3__c() != null) {
            _hashCode += getCCY_CCYRYAKUNM3__c().hashCode();
        }
        if (getCCY_CCYRYAKUNM6__c() != null) {
            _hashCode += getCCY_CCYRYAKUNM6__c().hashCode();
        }
        if (getCCY_HOJOKETASUU__c() != null) {
            _hashCode += getCCY_HOJOKETASUU__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDELFLG__c() != null) {
            _hashCode += getDELFLG__c().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getEvents() != null) {
            _hashCode += getEvents().hashCode();
        }
        if (getGETSUMATSUEIGYOBIKBN__c() != null) {
            _hashCode += getGETSUMATSUEIGYOBIKBN__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getKATEIKANSANRATE__c() != null) {
            _hashCode += getKATEIKANSANRATE__c().hashCode();
        }
        if (getKATEIRATEJISSHIBI_ZENKAI__c() != null) {
            _hashCode += getKATEIRATEJISSHIBI_ZENKAI__c().hashCode();
        }
        if (getKATEIRATEJISSHIBI__c() != null) {
            _hashCode += getKATEIRATEJISSHIBI__c().hashCode();
        }
        if (getKATEIRATE_ZENKAI__c() != null) {
            _hashCode += getKATEIRATE_ZENKAI__c().hashCode();
        }
        if (getKIJUNBI__c() != null) {
            _hashCode += getKIJUNBI__c().hashCode();
        }
        if (getLastActivityDate() != null) {
            _hashCode += getLastActivityDate().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getMULTI_DIVKBN_SHOUREIRATE__c() != null) {
            _hashCode += getMULTI_DIVKBN_SHOUREIRATE__c().hashCode();
        }
        if (getMULTI_DIVKBN_TTM__c() != null) {
            _hashCode += getMULTI_DIVKBN_TTM__c().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOpenActivities() != null) {
            _hashCode += getOpenActivities().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSHOUREIRATE__c() != null) {
            _hashCode += getSHOUREIRATE__c().hashCode();
        }
        if (getShares() != null) {
            _hashCode += getShares().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTEKIYOUKBN_SHOUREIRATE__c() != null) {
            _hashCode += getTEKIYOUKBN_SHOUREIRATE__c().hashCode();
        }
        if (getTEKIYOUKBN_TTM__c() != null) {
            _hashCode += getTEKIYOUKBN_TTM__c().hashCode();
        }
        if (getTTB__c() != null) {
            _hashCode += getTTB__c().hashCode();
        }
        if (getTTM_ICHIJI__c() != null) {
            _hashCode += getTTM_ICHIJI__c().hashCode();
        }
        if (getTTM__c() != null) {
            _hashCode += getTTM__c().hashCode();
        }
        if (getTTS__c() != null) {
            _hashCode += getTTS__c().hashCode();
        }
        if (getTasks() != null) {
            _hashCode += getTasks().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C000_GAIKOKUKAWASEINFO__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_GAIKOKUKAWASEINFO__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activityHistories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivityHistories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCYKBN_KIJUNBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCYKBN_KIJUNBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCYKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCYKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCYUNITKBN_SHOUREIRATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCYUNITKBN_SHOUREIRATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCYUNITKBN_TTM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCYUNITKBN_TTM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCY_CCYRYAKUNM3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCY_CCYRYAKUNM3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCY_CCYRYAKUNM6__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCY_CCYRYAKUNM6__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCY_HOJOKETASUU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCY_HOJOKETASUU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DELFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DELFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("events");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Events"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GETSUMATSUEIGYOBIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GETSUMATSUEIGYOBIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KATEIKANSANRATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KATEIKANSANRATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KATEIRATEJISSHIBI_ZENKAI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KATEIRATEJISSHIBI_ZENKAI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KATEIRATEJISSHIBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KATEIRATEJISSHIBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KATEIRATE_ZENKAI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KATEIRATE_ZENKAI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KIJUNBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KIJUNBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastActivityDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastActivityDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MULTI_DIVKBN_SHOUREIRATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MULTI_DIVKBN_SHOUREIRATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MULTI_DIVKBN_TTM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MULTI_DIVKBN_TTM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpenActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOUREIRATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOUREIRATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TEKIYOUKBN_SHOUREIRATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TEKIYOUKBN_SHOUREIRATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TEKIYOUKBN_TTM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TEKIYOUKBN_TTM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TTB__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TTB__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TTM_ICHIJI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TTM_ICHIJI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TTM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TTM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TTS__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TTS__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tasks");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Tasks"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
