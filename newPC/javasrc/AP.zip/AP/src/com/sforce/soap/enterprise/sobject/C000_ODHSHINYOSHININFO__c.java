/**
 * C000_ODHSHINYOSHININFO__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C000_ODHSHINYOSHININFO__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult activityHistories;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String BASERATECDNM__c;

    private java.lang.String BASERATECD__c;

    private java.util.Date CHOUINHI__c;

    private java.lang.String COMMITMENTID__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.String DATAKIJUNNENGETSU__c;

    private java.lang.Boolean DELFLG__c;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult events;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private java.lang.Double KASHIDASHIHEIZANGOUKEI__c;

    private java.lang.Double KASHIDASHIHEIZAN__c;

    private java.lang.Double KASHIDASHIMATSUZANGOUKEI__c;

    private java.lang.Double KASHIDASHIMATSUZAN__c;

    private java.lang.Double KASHIDASHISHIKINSHUUEKIGOUKEI__c;

    private java.lang.Double KASHIDASHISHIKINSHUUEKI__c;

    private java.lang.String KOKYAKUBANGOU__c;

    private java.lang.String KYOKUDO_TSUDOKBNNM__c;

    private java.lang.String KYOKUDO_TSUDOKBN__c;

    private java.lang.String LOCALKYOTENCD__c;

    private java.util.Date lastActivityDate;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private java.lang.String ODHKIJUNNENGETSU__c;

    private com.sforce.soap.enterprise.QueryResult openActivities;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String RINGIKIGEN__c;

    private java.lang.String SAIMUSHAKAKUDUKENM__c;

    private java.lang.String SAIMUSHAKAKUDUKE__c;

    private java.lang.String SAISHUUHENSAIKIGEN__c;

    private java.lang.String SCACD__c;

    private java.lang.String SCAYOSHINKBNNM__c;

    private java.lang.String SCAYOSHINKBN__c;

    private java.util.Date SHOUNINBI__c;

    private java.lang.String SHOUNINCCYCD__c;

    private java.lang.String SHOUNINCCY__c;

    private java.lang.Double SHOUNINKINGAKU__c;

    private com.sforce.soap.enterprise.QueryResult shares;

    private java.util.Calendar systemModstamp;

    private java.lang.String TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c;

    private java.lang.String TENBAN__c;

    private java.util.Date TORIHIKIHI__c;

    private java.lang.String TORIHIKISAKIEIBUNMEI__c;

    private com.sforce.soap.enterprise.QueryResult tasks;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    private java.lang.String YOSHINBANGOUSUBNO__c;

    private java.lang.String YOSHINBANGOU__c;

    private java.lang.String YOSHINKBNNM__c;

    private java.lang.String YOSHINKBN__c;

    private java.lang.String YOSHINSHOKANBUCD__c;

    private java.lang.String YOSHINSHOKANBUNM__c;

    public C000_ODHSHINYOSHININFO__c() {
    }

    public C000_ODHSHINYOSHININFO__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult activityHistories,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String BASERATECDNM__c,
           java.lang.String BASERATECD__c,
           java.util.Date CHOUINHI__c,
           java.lang.String COMMITMENTID__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.String DATAKIJUNNENGETSU__c,
           java.lang.Boolean DELFLG__c,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult events,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           java.lang.Double KASHIDASHIHEIZANGOUKEI__c,
           java.lang.Double KASHIDASHIHEIZAN__c,
           java.lang.Double KASHIDASHIMATSUZANGOUKEI__c,
           java.lang.Double KASHIDASHIMATSUZAN__c,
           java.lang.Double KASHIDASHISHIKINSHUUEKIGOUKEI__c,
           java.lang.Double KASHIDASHISHIKINSHUUEKI__c,
           java.lang.String KOKYAKUBANGOU__c,
           java.lang.String KYOKUDO_TSUDOKBNNM__c,
           java.lang.String KYOKUDO_TSUDOKBN__c,
           java.lang.String LOCALKYOTENCD__c,
           java.util.Date lastActivityDate,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           java.lang.String ODHKIJUNNENGETSU__c,
           com.sforce.soap.enterprise.QueryResult openActivities,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String RINGIKIGEN__c,
           java.lang.String SAIMUSHAKAKUDUKENM__c,
           java.lang.String SAIMUSHAKAKUDUKE__c,
           java.lang.String SAISHUUHENSAIKIGEN__c,
           java.lang.String SCACD__c,
           java.lang.String SCAYOSHINKBNNM__c,
           java.lang.String SCAYOSHINKBN__c,
           java.util.Date SHOUNINBI__c,
           java.lang.String SHOUNINCCYCD__c,
           java.lang.String SHOUNINCCY__c,
           java.lang.Double SHOUNINKINGAKU__c,
           com.sforce.soap.enterprise.QueryResult shares,
           java.util.Calendar systemModstamp,
           java.lang.String TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c,
           java.lang.String TENBAN__c,
           java.util.Date TORIHIKIHI__c,
           java.lang.String TORIHIKISAKIEIBUNMEI__c,
           com.sforce.soap.enterprise.QueryResult tasks,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess,
           java.lang.String YOSHINBANGOUSUBNO__c,
           java.lang.String YOSHINBANGOU__c,
           java.lang.String YOSHINKBNNM__c,
           java.lang.String YOSHINKBN__c,
           java.lang.String YOSHINSHOKANBUCD__c,
           java.lang.String YOSHINSHOKANBUNM__c) {
        super(
            fieldsToNull,
            id);
        this.activityHistories = activityHistories;
        this.attachments = attachments;
        this.BASERATECDNM__c = BASERATECDNM__c;
        this.BASERATECD__c = BASERATECD__c;
        this.CHOUINHI__c = CHOUINHI__c;
        this.COMMITMENTID__c = COMMITMENTID__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.DATAKIJUNNENGETSU__c = DATAKIJUNNENGETSU__c;
        this.DELFLG__c = DELFLG__c;
        this.duplicateRecordItems = duplicateRecordItems;
        this.events = events;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.KASHIDASHIHEIZANGOUKEI__c = KASHIDASHIHEIZANGOUKEI__c;
        this.KASHIDASHIHEIZAN__c = KASHIDASHIHEIZAN__c;
        this.KASHIDASHIMATSUZANGOUKEI__c = KASHIDASHIMATSUZANGOUKEI__c;
        this.KASHIDASHIMATSUZAN__c = KASHIDASHIMATSUZAN__c;
        this.KASHIDASHISHIKINSHUUEKIGOUKEI__c = KASHIDASHISHIKINSHUUEKIGOUKEI__c;
        this.KASHIDASHISHIKINSHUUEKI__c = KASHIDASHISHIKINSHUUEKI__c;
        this.KOKYAKUBANGOU__c = KOKYAKUBANGOU__c;
        this.KYOKUDO_TSUDOKBNNM__c = KYOKUDO_TSUDOKBNNM__c;
        this.KYOKUDO_TSUDOKBN__c = KYOKUDO_TSUDOKBN__c;
        this.LOCALKYOTENCD__c = LOCALKYOTENCD__c;
        this.lastActivityDate = lastActivityDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.ODHKIJUNNENGETSU__c = ODHKIJUNNENGETSU__c;
        this.openActivities = openActivities;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.RINGIKIGEN__c = RINGIKIGEN__c;
        this.SAIMUSHAKAKUDUKENM__c = SAIMUSHAKAKUDUKENM__c;
        this.SAIMUSHAKAKUDUKE__c = SAIMUSHAKAKUDUKE__c;
        this.SAISHUUHENSAIKIGEN__c = SAISHUUHENSAIKIGEN__c;
        this.SCACD__c = SCACD__c;
        this.SCAYOSHINKBNNM__c = SCAYOSHINKBNNM__c;
        this.SCAYOSHINKBN__c = SCAYOSHINKBN__c;
        this.SHOUNINBI__c = SHOUNINBI__c;
        this.SHOUNINCCYCD__c = SHOUNINCCYCD__c;
        this.SHOUNINCCY__c = SHOUNINCCY__c;
        this.SHOUNINKINGAKU__c = SHOUNINKINGAKU__c;
        this.shares = shares;
        this.systemModstamp = systemModstamp;
        this.TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c = TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c;
        this.TENBAN__c = TENBAN__c;
        this.TORIHIKIHI__c = TORIHIKIHI__c;
        this.TORIHIKISAKIEIBUNMEI__c = TORIHIKISAKIEIBUNMEI__c;
        this.tasks = tasks;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
        this.YOSHINBANGOUSUBNO__c = YOSHINBANGOUSUBNO__c;
        this.YOSHINBANGOU__c = YOSHINBANGOU__c;
        this.YOSHINKBNNM__c = YOSHINKBNNM__c;
        this.YOSHINKBN__c = YOSHINKBN__c;
        this.YOSHINSHOKANBUCD__c = YOSHINSHOKANBUCD__c;
        this.YOSHINSHOKANBUNM__c = YOSHINSHOKANBUNM__c;
    }


    /**
     * Gets the activityHistories value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return activityHistories
     */
    public com.sforce.soap.enterprise.QueryResult getActivityHistories() {
        return activityHistories;
    }


    /**
     * Sets the activityHistories value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param activityHistories
     */
    public void setActivityHistories(com.sforce.soap.enterprise.QueryResult activityHistories) {
        this.activityHistories = activityHistories;
    }


    /**
     * Gets the attachments value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the BASERATECDNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return BASERATECDNM__c
     */
    public java.lang.String getBASERATECDNM__c() {
        return BASERATECDNM__c;
    }


    /**
     * Sets the BASERATECDNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param BASERATECDNM__c
     */
    public void setBASERATECDNM__c(java.lang.String BASERATECDNM__c) {
        this.BASERATECDNM__c = BASERATECDNM__c;
    }


    /**
     * Gets the BASERATECD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return BASERATECD__c
     */
    public java.lang.String getBASERATECD__c() {
        return BASERATECD__c;
    }


    /**
     * Sets the BASERATECD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param BASERATECD__c
     */
    public void setBASERATECD__c(java.lang.String BASERATECD__c) {
        this.BASERATECD__c = BASERATECD__c;
    }


    /**
     * Gets the CHOUINHI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return CHOUINHI__c
     */
    public java.util.Date getCHOUINHI__c() {
        return CHOUINHI__c;
    }


    /**
     * Sets the CHOUINHI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param CHOUINHI__c
     */
    public void setCHOUINHI__c(java.util.Date CHOUINHI__c) {
        this.CHOUINHI__c = CHOUINHI__c;
    }


    /**
     * Gets the COMMITMENTID__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return COMMITMENTID__c
     */
    public java.lang.String getCOMMITMENTID__c() {
        return COMMITMENTID__c;
    }


    /**
     * Sets the COMMITMENTID__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param COMMITMENTID__c
     */
    public void setCOMMITMENTID__c(java.lang.String COMMITMENTID__c) {
        this.COMMITMENTID__c = COMMITMENTID__c;
    }


    /**
     * Gets the combinedAttachments value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the DATAKIJUNNENGETSU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return DATAKIJUNNENGETSU__c
     */
    public java.lang.String getDATAKIJUNNENGETSU__c() {
        return DATAKIJUNNENGETSU__c;
    }


    /**
     * Sets the DATAKIJUNNENGETSU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param DATAKIJUNNENGETSU__c
     */
    public void setDATAKIJUNNENGETSU__c(java.lang.String DATAKIJUNNENGETSU__c) {
        this.DATAKIJUNNENGETSU__c = DATAKIJUNNENGETSU__c;
    }


    /**
     * Gets the DELFLG__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return DELFLG__c
     */
    public java.lang.Boolean getDELFLG__c() {
        return DELFLG__c;
    }


    /**
     * Sets the DELFLG__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param DELFLG__c
     */
    public void setDELFLG__c(java.lang.Boolean DELFLG__c) {
        this.DELFLG__c = DELFLG__c;
    }


    /**
     * Gets the duplicateRecordItems value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the events value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return events
     */
    public com.sforce.soap.enterprise.QueryResult getEvents() {
        return events;
    }


    /**
     * Sets the events value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param events
     */
    public void setEvents(com.sforce.soap.enterprise.QueryResult events) {
        this.events = events;
    }


    /**
     * Gets the histories value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the KASHIDASHIHEIZANGOUKEI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return KASHIDASHIHEIZANGOUKEI__c
     */
    public java.lang.Double getKASHIDASHIHEIZANGOUKEI__c() {
        return KASHIDASHIHEIZANGOUKEI__c;
    }


    /**
     * Sets the KASHIDASHIHEIZANGOUKEI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param KASHIDASHIHEIZANGOUKEI__c
     */
    public void setKASHIDASHIHEIZANGOUKEI__c(java.lang.Double KASHIDASHIHEIZANGOUKEI__c) {
        this.KASHIDASHIHEIZANGOUKEI__c = KASHIDASHIHEIZANGOUKEI__c;
    }


    /**
     * Gets the KASHIDASHIHEIZAN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return KASHIDASHIHEIZAN__c
     */
    public java.lang.Double getKASHIDASHIHEIZAN__c() {
        return KASHIDASHIHEIZAN__c;
    }


    /**
     * Sets the KASHIDASHIHEIZAN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param KASHIDASHIHEIZAN__c
     */
    public void setKASHIDASHIHEIZAN__c(java.lang.Double KASHIDASHIHEIZAN__c) {
        this.KASHIDASHIHEIZAN__c = KASHIDASHIHEIZAN__c;
    }


    /**
     * Gets the KASHIDASHIMATSUZANGOUKEI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return KASHIDASHIMATSUZANGOUKEI__c
     */
    public java.lang.Double getKASHIDASHIMATSUZANGOUKEI__c() {
        return KASHIDASHIMATSUZANGOUKEI__c;
    }


    /**
     * Sets the KASHIDASHIMATSUZANGOUKEI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param KASHIDASHIMATSUZANGOUKEI__c
     */
    public void setKASHIDASHIMATSUZANGOUKEI__c(java.lang.Double KASHIDASHIMATSUZANGOUKEI__c) {
        this.KASHIDASHIMATSUZANGOUKEI__c = KASHIDASHIMATSUZANGOUKEI__c;
    }


    /**
     * Gets the KASHIDASHIMATSUZAN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return KASHIDASHIMATSUZAN__c
     */
    public java.lang.Double getKASHIDASHIMATSUZAN__c() {
        return KASHIDASHIMATSUZAN__c;
    }


    /**
     * Sets the KASHIDASHIMATSUZAN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param KASHIDASHIMATSUZAN__c
     */
    public void setKASHIDASHIMATSUZAN__c(java.lang.Double KASHIDASHIMATSUZAN__c) {
        this.KASHIDASHIMATSUZAN__c = KASHIDASHIMATSUZAN__c;
    }


    /**
     * Gets the KASHIDASHISHIKINSHUUEKIGOUKEI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return KASHIDASHISHIKINSHUUEKIGOUKEI__c
     */
    public java.lang.Double getKASHIDASHISHIKINSHUUEKIGOUKEI__c() {
        return KASHIDASHISHIKINSHUUEKIGOUKEI__c;
    }


    /**
     * Sets the KASHIDASHISHIKINSHUUEKIGOUKEI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param KASHIDASHISHIKINSHUUEKIGOUKEI__c
     */
    public void setKASHIDASHISHIKINSHUUEKIGOUKEI__c(java.lang.Double KASHIDASHISHIKINSHUUEKIGOUKEI__c) {
        this.KASHIDASHISHIKINSHUUEKIGOUKEI__c = KASHIDASHISHIKINSHUUEKIGOUKEI__c;
    }


    /**
     * Gets the KASHIDASHISHIKINSHUUEKI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return KASHIDASHISHIKINSHUUEKI__c
     */
    public java.lang.Double getKASHIDASHISHIKINSHUUEKI__c() {
        return KASHIDASHISHIKINSHUUEKI__c;
    }


    /**
     * Sets the KASHIDASHISHIKINSHUUEKI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param KASHIDASHISHIKINSHUUEKI__c
     */
    public void setKASHIDASHISHIKINSHUUEKI__c(java.lang.Double KASHIDASHISHIKINSHUUEKI__c) {
        this.KASHIDASHISHIKINSHUUEKI__c = KASHIDASHISHIKINSHUUEKI__c;
    }


    /**
     * Gets the KOKYAKUBANGOU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return KOKYAKUBANGOU__c
     */
    public java.lang.String getKOKYAKUBANGOU__c() {
        return KOKYAKUBANGOU__c;
    }


    /**
     * Sets the KOKYAKUBANGOU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param KOKYAKUBANGOU__c
     */
    public void setKOKYAKUBANGOU__c(java.lang.String KOKYAKUBANGOU__c) {
        this.KOKYAKUBANGOU__c = KOKYAKUBANGOU__c;
    }


    /**
     * Gets the KYOKUDO_TSUDOKBNNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return KYOKUDO_TSUDOKBNNM__c
     */
    public java.lang.String getKYOKUDO_TSUDOKBNNM__c() {
        return KYOKUDO_TSUDOKBNNM__c;
    }


    /**
     * Sets the KYOKUDO_TSUDOKBNNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param KYOKUDO_TSUDOKBNNM__c
     */
    public void setKYOKUDO_TSUDOKBNNM__c(java.lang.String KYOKUDO_TSUDOKBNNM__c) {
        this.KYOKUDO_TSUDOKBNNM__c = KYOKUDO_TSUDOKBNNM__c;
    }


    /**
     * Gets the KYOKUDO_TSUDOKBN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return KYOKUDO_TSUDOKBN__c
     */
    public java.lang.String getKYOKUDO_TSUDOKBN__c() {
        return KYOKUDO_TSUDOKBN__c;
    }


    /**
     * Sets the KYOKUDO_TSUDOKBN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param KYOKUDO_TSUDOKBN__c
     */
    public void setKYOKUDO_TSUDOKBN__c(java.lang.String KYOKUDO_TSUDOKBN__c) {
        this.KYOKUDO_TSUDOKBN__c = KYOKUDO_TSUDOKBN__c;
    }


    /**
     * Gets the LOCALKYOTENCD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return LOCALKYOTENCD__c
     */
    public java.lang.String getLOCALKYOTENCD__c() {
        return LOCALKYOTENCD__c;
    }


    /**
     * Sets the LOCALKYOTENCD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param LOCALKYOTENCD__c
     */
    public void setLOCALKYOTENCD__c(java.lang.String LOCALKYOTENCD__c) {
        this.LOCALKYOTENCD__c = LOCALKYOTENCD__c;
    }


    /**
     * Gets the lastActivityDate value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return lastActivityDate
     */
    public java.util.Date getLastActivityDate() {
        return lastActivityDate;
    }


    /**
     * Sets the lastActivityDate value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param lastActivityDate
     */
    public void setLastActivityDate(java.util.Date lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }


    /**
     * Gets the lastModifiedBy value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the ODHKIJUNNENGETSU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return ODHKIJUNNENGETSU__c
     */
    public java.lang.String getODHKIJUNNENGETSU__c() {
        return ODHKIJUNNENGETSU__c;
    }


    /**
     * Sets the ODHKIJUNNENGETSU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param ODHKIJUNNENGETSU__c
     */
    public void setODHKIJUNNENGETSU__c(java.lang.String ODHKIJUNNENGETSU__c) {
        this.ODHKIJUNNENGETSU__c = ODHKIJUNNENGETSU__c;
    }


    /**
     * Gets the openActivities value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return openActivities
     */
    public com.sforce.soap.enterprise.QueryResult getOpenActivities() {
        return openActivities;
    }


    /**
     * Sets the openActivities value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param openActivities
     */
    public void setOpenActivities(com.sforce.soap.enterprise.QueryResult openActivities) {
        this.openActivities = openActivities;
    }


    /**
     * Gets the owner value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the RINGIKIGEN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return RINGIKIGEN__c
     */
    public java.lang.String getRINGIKIGEN__c() {
        return RINGIKIGEN__c;
    }


    /**
     * Sets the RINGIKIGEN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param RINGIKIGEN__c
     */
    public void setRINGIKIGEN__c(java.lang.String RINGIKIGEN__c) {
        this.RINGIKIGEN__c = RINGIKIGEN__c;
    }


    /**
     * Gets the SAIMUSHAKAKUDUKENM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SAIMUSHAKAKUDUKENM__c
     */
    public java.lang.String getSAIMUSHAKAKUDUKENM__c() {
        return SAIMUSHAKAKUDUKENM__c;
    }


    /**
     * Sets the SAIMUSHAKAKUDUKENM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SAIMUSHAKAKUDUKENM__c
     */
    public void setSAIMUSHAKAKUDUKENM__c(java.lang.String SAIMUSHAKAKUDUKENM__c) {
        this.SAIMUSHAKAKUDUKENM__c = SAIMUSHAKAKUDUKENM__c;
    }


    /**
     * Gets the SAIMUSHAKAKUDUKE__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SAIMUSHAKAKUDUKE__c
     */
    public java.lang.String getSAIMUSHAKAKUDUKE__c() {
        return SAIMUSHAKAKUDUKE__c;
    }


    /**
     * Sets the SAIMUSHAKAKUDUKE__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SAIMUSHAKAKUDUKE__c
     */
    public void setSAIMUSHAKAKUDUKE__c(java.lang.String SAIMUSHAKAKUDUKE__c) {
        this.SAIMUSHAKAKUDUKE__c = SAIMUSHAKAKUDUKE__c;
    }


    /**
     * Gets the SAISHUUHENSAIKIGEN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SAISHUUHENSAIKIGEN__c
     */
    public java.lang.String getSAISHUUHENSAIKIGEN__c() {
        return SAISHUUHENSAIKIGEN__c;
    }


    /**
     * Sets the SAISHUUHENSAIKIGEN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SAISHUUHENSAIKIGEN__c
     */
    public void setSAISHUUHENSAIKIGEN__c(java.lang.String SAISHUUHENSAIKIGEN__c) {
        this.SAISHUUHENSAIKIGEN__c = SAISHUUHENSAIKIGEN__c;
    }


    /**
     * Gets the SCACD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SCACD__c
     */
    public java.lang.String getSCACD__c() {
        return SCACD__c;
    }


    /**
     * Sets the SCACD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SCACD__c
     */
    public void setSCACD__c(java.lang.String SCACD__c) {
        this.SCACD__c = SCACD__c;
    }


    /**
     * Gets the SCAYOSHINKBNNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SCAYOSHINKBNNM__c
     */
    public java.lang.String getSCAYOSHINKBNNM__c() {
        return SCAYOSHINKBNNM__c;
    }


    /**
     * Sets the SCAYOSHINKBNNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SCAYOSHINKBNNM__c
     */
    public void setSCAYOSHINKBNNM__c(java.lang.String SCAYOSHINKBNNM__c) {
        this.SCAYOSHINKBNNM__c = SCAYOSHINKBNNM__c;
    }


    /**
     * Gets the SCAYOSHINKBN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SCAYOSHINKBN__c
     */
    public java.lang.String getSCAYOSHINKBN__c() {
        return SCAYOSHINKBN__c;
    }


    /**
     * Sets the SCAYOSHINKBN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SCAYOSHINKBN__c
     */
    public void setSCAYOSHINKBN__c(java.lang.String SCAYOSHINKBN__c) {
        this.SCAYOSHINKBN__c = SCAYOSHINKBN__c;
    }


    /**
     * Gets the SHOUNINBI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SHOUNINBI__c
     */
    public java.util.Date getSHOUNINBI__c() {
        return SHOUNINBI__c;
    }


    /**
     * Sets the SHOUNINBI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SHOUNINBI__c
     */
    public void setSHOUNINBI__c(java.util.Date SHOUNINBI__c) {
        this.SHOUNINBI__c = SHOUNINBI__c;
    }


    /**
     * Gets the SHOUNINCCYCD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SHOUNINCCYCD__c
     */
    public java.lang.String getSHOUNINCCYCD__c() {
        return SHOUNINCCYCD__c;
    }


    /**
     * Sets the SHOUNINCCYCD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SHOUNINCCYCD__c
     */
    public void setSHOUNINCCYCD__c(java.lang.String SHOUNINCCYCD__c) {
        this.SHOUNINCCYCD__c = SHOUNINCCYCD__c;
    }


    /**
     * Gets the SHOUNINCCY__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SHOUNINCCY__c
     */
    public java.lang.String getSHOUNINCCY__c() {
        return SHOUNINCCY__c;
    }


    /**
     * Sets the SHOUNINCCY__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SHOUNINCCY__c
     */
    public void setSHOUNINCCY__c(java.lang.String SHOUNINCCY__c) {
        this.SHOUNINCCY__c = SHOUNINCCY__c;
    }


    /**
     * Gets the SHOUNINKINGAKU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return SHOUNINKINGAKU__c
     */
    public java.lang.Double getSHOUNINKINGAKU__c() {
        return SHOUNINKINGAKU__c;
    }


    /**
     * Sets the SHOUNINKINGAKU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param SHOUNINKINGAKU__c
     */
    public void setSHOUNINKINGAKU__c(java.lang.Double SHOUNINKINGAKU__c) {
        this.SHOUNINKINGAKU__c = SHOUNINKINGAKU__c;
    }


    /**
     * Gets the shares value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return shares
     */
    public com.sforce.soap.enterprise.QueryResult getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param shares
     */
    public void setShares(com.sforce.soap.enterprise.QueryResult shares) {
        this.shares = shares;
    }


    /**
     * Gets the systemModstamp value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c
     */
    public java.lang.String getTENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c() {
        return TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c;
    }


    /**
     * Sets the TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c
     */
    public void setTENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c(java.lang.String TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c) {
        this.TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c = TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c;
    }


    /**
     * Gets the TENBAN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return TENBAN__c
     */
    public java.lang.String getTENBAN__c() {
        return TENBAN__c;
    }


    /**
     * Sets the TENBAN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param TENBAN__c
     */
    public void setTENBAN__c(java.lang.String TENBAN__c) {
        this.TENBAN__c = TENBAN__c;
    }


    /**
     * Gets the TORIHIKIHI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return TORIHIKIHI__c
     */
    public java.util.Date getTORIHIKIHI__c() {
        return TORIHIKIHI__c;
    }


    /**
     * Sets the TORIHIKIHI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param TORIHIKIHI__c
     */
    public void setTORIHIKIHI__c(java.util.Date TORIHIKIHI__c) {
        this.TORIHIKIHI__c = TORIHIKIHI__c;
    }


    /**
     * Gets the TORIHIKISAKIEIBUNMEI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return TORIHIKISAKIEIBUNMEI__c
     */
    public java.lang.String getTORIHIKISAKIEIBUNMEI__c() {
        return TORIHIKISAKIEIBUNMEI__c;
    }


    /**
     * Sets the TORIHIKISAKIEIBUNMEI__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param TORIHIKISAKIEIBUNMEI__c
     */
    public void setTORIHIKISAKIEIBUNMEI__c(java.lang.String TORIHIKISAKIEIBUNMEI__c) {
        this.TORIHIKISAKIEIBUNMEI__c = TORIHIKISAKIEIBUNMEI__c;
    }


    /**
     * Gets the tasks value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return tasks
     */
    public com.sforce.soap.enterprise.QueryResult getTasks() {
        return tasks;
    }


    /**
     * Sets the tasks value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param tasks
     */
    public void setTasks(com.sforce.soap.enterprise.QueryResult tasks) {
        this.tasks = tasks;
    }


    /**
     * Gets the topicAssignments value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the YOSHINBANGOUSUBNO__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return YOSHINBANGOUSUBNO__c
     */
    public java.lang.String getYOSHINBANGOUSUBNO__c() {
        return YOSHINBANGOUSUBNO__c;
    }


    /**
     * Sets the YOSHINBANGOUSUBNO__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param YOSHINBANGOUSUBNO__c
     */
    public void setYOSHINBANGOUSUBNO__c(java.lang.String YOSHINBANGOUSUBNO__c) {
        this.YOSHINBANGOUSUBNO__c = YOSHINBANGOUSUBNO__c;
    }


    /**
     * Gets the YOSHINBANGOU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return YOSHINBANGOU__c
     */
    public java.lang.String getYOSHINBANGOU__c() {
        return YOSHINBANGOU__c;
    }


    /**
     * Sets the YOSHINBANGOU__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param YOSHINBANGOU__c
     */
    public void setYOSHINBANGOU__c(java.lang.String YOSHINBANGOU__c) {
        this.YOSHINBANGOU__c = YOSHINBANGOU__c;
    }


    /**
     * Gets the YOSHINKBNNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return YOSHINKBNNM__c
     */
    public java.lang.String getYOSHINKBNNM__c() {
        return YOSHINKBNNM__c;
    }


    /**
     * Sets the YOSHINKBNNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param YOSHINKBNNM__c
     */
    public void setYOSHINKBNNM__c(java.lang.String YOSHINKBNNM__c) {
        this.YOSHINKBNNM__c = YOSHINKBNNM__c;
    }


    /**
     * Gets the YOSHINKBN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return YOSHINKBN__c
     */
    public java.lang.String getYOSHINKBN__c() {
        return YOSHINKBN__c;
    }


    /**
     * Sets the YOSHINKBN__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param YOSHINKBN__c
     */
    public void setYOSHINKBN__c(java.lang.String YOSHINKBN__c) {
        this.YOSHINKBN__c = YOSHINKBN__c;
    }


    /**
     * Gets the YOSHINSHOKANBUCD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return YOSHINSHOKANBUCD__c
     */
    public java.lang.String getYOSHINSHOKANBUCD__c() {
        return YOSHINSHOKANBUCD__c;
    }


    /**
     * Sets the YOSHINSHOKANBUCD__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param YOSHINSHOKANBUCD__c
     */
    public void setYOSHINSHOKANBUCD__c(java.lang.String YOSHINSHOKANBUCD__c) {
        this.YOSHINSHOKANBUCD__c = YOSHINSHOKANBUCD__c;
    }


    /**
     * Gets the YOSHINSHOKANBUNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @return YOSHINSHOKANBUNM__c
     */
    public java.lang.String getYOSHINSHOKANBUNM__c() {
        return YOSHINSHOKANBUNM__c;
    }


    /**
     * Sets the YOSHINSHOKANBUNM__c value for this C000_ODHSHINYOSHININFO__c.
     * 
     * @param YOSHINSHOKANBUNM__c
     */
    public void setYOSHINSHOKANBUNM__c(java.lang.String YOSHINSHOKANBUNM__c) {
        this.YOSHINSHOKANBUNM__c = YOSHINSHOKANBUNM__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C000_ODHSHINYOSHININFO__c)) return false;
        C000_ODHSHINYOSHININFO__c other = (C000_ODHSHINYOSHININFO__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.activityHistories==null && other.getActivityHistories()==null) || 
             (this.activityHistories!=null &&
              this.activityHistories.equals(other.getActivityHistories()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.BASERATECDNM__c==null && other.getBASERATECDNM__c()==null) || 
             (this.BASERATECDNM__c!=null &&
              this.BASERATECDNM__c.equals(other.getBASERATECDNM__c()))) &&
            ((this.BASERATECD__c==null && other.getBASERATECD__c()==null) || 
             (this.BASERATECD__c!=null &&
              this.BASERATECD__c.equals(other.getBASERATECD__c()))) &&
            ((this.CHOUINHI__c==null && other.getCHOUINHI__c()==null) || 
             (this.CHOUINHI__c!=null &&
              this.CHOUINHI__c.equals(other.getCHOUINHI__c()))) &&
            ((this.COMMITMENTID__c==null && other.getCOMMITMENTID__c()==null) || 
             (this.COMMITMENTID__c!=null &&
              this.COMMITMENTID__c.equals(other.getCOMMITMENTID__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.DATAKIJUNNENGETSU__c==null && other.getDATAKIJUNNENGETSU__c()==null) || 
             (this.DATAKIJUNNENGETSU__c!=null &&
              this.DATAKIJUNNENGETSU__c.equals(other.getDATAKIJUNNENGETSU__c()))) &&
            ((this.DELFLG__c==null && other.getDELFLG__c()==null) || 
             (this.DELFLG__c!=null &&
              this.DELFLG__c.equals(other.getDELFLG__c()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.events==null && other.getEvents()==null) || 
             (this.events!=null &&
              this.events.equals(other.getEvents()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.KASHIDASHIHEIZANGOUKEI__c==null && other.getKASHIDASHIHEIZANGOUKEI__c()==null) || 
             (this.KASHIDASHIHEIZANGOUKEI__c!=null &&
              this.KASHIDASHIHEIZANGOUKEI__c.equals(other.getKASHIDASHIHEIZANGOUKEI__c()))) &&
            ((this.KASHIDASHIHEIZAN__c==null && other.getKASHIDASHIHEIZAN__c()==null) || 
             (this.KASHIDASHIHEIZAN__c!=null &&
              this.KASHIDASHIHEIZAN__c.equals(other.getKASHIDASHIHEIZAN__c()))) &&
            ((this.KASHIDASHIMATSUZANGOUKEI__c==null && other.getKASHIDASHIMATSUZANGOUKEI__c()==null) || 
             (this.KASHIDASHIMATSUZANGOUKEI__c!=null &&
              this.KASHIDASHIMATSUZANGOUKEI__c.equals(other.getKASHIDASHIMATSUZANGOUKEI__c()))) &&
            ((this.KASHIDASHIMATSUZAN__c==null && other.getKASHIDASHIMATSUZAN__c()==null) || 
             (this.KASHIDASHIMATSUZAN__c!=null &&
              this.KASHIDASHIMATSUZAN__c.equals(other.getKASHIDASHIMATSUZAN__c()))) &&
            ((this.KASHIDASHISHIKINSHUUEKIGOUKEI__c==null && other.getKASHIDASHISHIKINSHUUEKIGOUKEI__c()==null) || 
             (this.KASHIDASHISHIKINSHUUEKIGOUKEI__c!=null &&
              this.KASHIDASHISHIKINSHUUEKIGOUKEI__c.equals(other.getKASHIDASHISHIKINSHUUEKIGOUKEI__c()))) &&
            ((this.KASHIDASHISHIKINSHUUEKI__c==null && other.getKASHIDASHISHIKINSHUUEKI__c()==null) || 
             (this.KASHIDASHISHIKINSHUUEKI__c!=null &&
              this.KASHIDASHISHIKINSHUUEKI__c.equals(other.getKASHIDASHISHIKINSHUUEKI__c()))) &&
            ((this.KOKYAKUBANGOU__c==null && other.getKOKYAKUBANGOU__c()==null) || 
             (this.KOKYAKUBANGOU__c!=null &&
              this.KOKYAKUBANGOU__c.equals(other.getKOKYAKUBANGOU__c()))) &&
            ((this.KYOKUDO_TSUDOKBNNM__c==null && other.getKYOKUDO_TSUDOKBNNM__c()==null) || 
             (this.KYOKUDO_TSUDOKBNNM__c!=null &&
              this.KYOKUDO_TSUDOKBNNM__c.equals(other.getKYOKUDO_TSUDOKBNNM__c()))) &&
            ((this.KYOKUDO_TSUDOKBN__c==null && other.getKYOKUDO_TSUDOKBN__c()==null) || 
             (this.KYOKUDO_TSUDOKBN__c!=null &&
              this.KYOKUDO_TSUDOKBN__c.equals(other.getKYOKUDO_TSUDOKBN__c()))) &&
            ((this.LOCALKYOTENCD__c==null && other.getLOCALKYOTENCD__c()==null) || 
             (this.LOCALKYOTENCD__c!=null &&
              this.LOCALKYOTENCD__c.equals(other.getLOCALKYOTENCD__c()))) &&
            ((this.lastActivityDate==null && other.getLastActivityDate()==null) || 
             (this.lastActivityDate!=null &&
              this.lastActivityDate.equals(other.getLastActivityDate()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.ODHKIJUNNENGETSU__c==null && other.getODHKIJUNNENGETSU__c()==null) || 
             (this.ODHKIJUNNENGETSU__c!=null &&
              this.ODHKIJUNNENGETSU__c.equals(other.getODHKIJUNNENGETSU__c()))) &&
            ((this.openActivities==null && other.getOpenActivities()==null) || 
             (this.openActivities!=null &&
              this.openActivities.equals(other.getOpenActivities()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.RINGIKIGEN__c==null && other.getRINGIKIGEN__c()==null) || 
             (this.RINGIKIGEN__c!=null &&
              this.RINGIKIGEN__c.equals(other.getRINGIKIGEN__c()))) &&
            ((this.SAIMUSHAKAKUDUKENM__c==null && other.getSAIMUSHAKAKUDUKENM__c()==null) || 
             (this.SAIMUSHAKAKUDUKENM__c!=null &&
              this.SAIMUSHAKAKUDUKENM__c.equals(other.getSAIMUSHAKAKUDUKENM__c()))) &&
            ((this.SAIMUSHAKAKUDUKE__c==null && other.getSAIMUSHAKAKUDUKE__c()==null) || 
             (this.SAIMUSHAKAKUDUKE__c!=null &&
              this.SAIMUSHAKAKUDUKE__c.equals(other.getSAIMUSHAKAKUDUKE__c()))) &&
            ((this.SAISHUUHENSAIKIGEN__c==null && other.getSAISHUUHENSAIKIGEN__c()==null) || 
             (this.SAISHUUHENSAIKIGEN__c!=null &&
              this.SAISHUUHENSAIKIGEN__c.equals(other.getSAISHUUHENSAIKIGEN__c()))) &&
            ((this.SCACD__c==null && other.getSCACD__c()==null) || 
             (this.SCACD__c!=null &&
              this.SCACD__c.equals(other.getSCACD__c()))) &&
            ((this.SCAYOSHINKBNNM__c==null && other.getSCAYOSHINKBNNM__c()==null) || 
             (this.SCAYOSHINKBNNM__c!=null &&
              this.SCAYOSHINKBNNM__c.equals(other.getSCAYOSHINKBNNM__c()))) &&
            ((this.SCAYOSHINKBN__c==null && other.getSCAYOSHINKBN__c()==null) || 
             (this.SCAYOSHINKBN__c!=null &&
              this.SCAYOSHINKBN__c.equals(other.getSCAYOSHINKBN__c()))) &&
            ((this.SHOUNINBI__c==null && other.getSHOUNINBI__c()==null) || 
             (this.SHOUNINBI__c!=null &&
              this.SHOUNINBI__c.equals(other.getSHOUNINBI__c()))) &&
            ((this.SHOUNINCCYCD__c==null && other.getSHOUNINCCYCD__c()==null) || 
             (this.SHOUNINCCYCD__c!=null &&
              this.SHOUNINCCYCD__c.equals(other.getSHOUNINCCYCD__c()))) &&
            ((this.SHOUNINCCY__c==null && other.getSHOUNINCCY__c()==null) || 
             (this.SHOUNINCCY__c!=null &&
              this.SHOUNINCCY__c.equals(other.getSHOUNINCCY__c()))) &&
            ((this.SHOUNINKINGAKU__c==null && other.getSHOUNINKINGAKU__c()==null) || 
             (this.SHOUNINKINGAKU__c!=null &&
              this.SHOUNINKINGAKU__c.equals(other.getSHOUNINKINGAKU__c()))) &&
            ((this.shares==null && other.getShares()==null) || 
             (this.shares!=null &&
              this.shares.equals(other.getShares()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c==null && other.getTENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c()==null) || 
             (this.TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c!=null &&
              this.TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c.equals(other.getTENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c()))) &&
            ((this.TENBAN__c==null && other.getTENBAN__c()==null) || 
             (this.TENBAN__c!=null &&
              this.TENBAN__c.equals(other.getTENBAN__c()))) &&
            ((this.TORIHIKIHI__c==null && other.getTORIHIKIHI__c()==null) || 
             (this.TORIHIKIHI__c!=null &&
              this.TORIHIKIHI__c.equals(other.getTORIHIKIHI__c()))) &&
            ((this.TORIHIKISAKIEIBUNMEI__c==null && other.getTORIHIKISAKIEIBUNMEI__c()==null) || 
             (this.TORIHIKISAKIEIBUNMEI__c!=null &&
              this.TORIHIKISAKIEIBUNMEI__c.equals(other.getTORIHIKISAKIEIBUNMEI__c()))) &&
            ((this.tasks==null && other.getTasks()==null) || 
             (this.tasks!=null &&
              this.tasks.equals(other.getTasks()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess()))) &&
            ((this.YOSHINBANGOUSUBNO__c==null && other.getYOSHINBANGOUSUBNO__c()==null) || 
             (this.YOSHINBANGOUSUBNO__c!=null &&
              this.YOSHINBANGOUSUBNO__c.equals(other.getYOSHINBANGOUSUBNO__c()))) &&
            ((this.YOSHINBANGOU__c==null && other.getYOSHINBANGOU__c()==null) || 
             (this.YOSHINBANGOU__c!=null &&
              this.YOSHINBANGOU__c.equals(other.getYOSHINBANGOU__c()))) &&
            ((this.YOSHINKBNNM__c==null && other.getYOSHINKBNNM__c()==null) || 
             (this.YOSHINKBNNM__c!=null &&
              this.YOSHINKBNNM__c.equals(other.getYOSHINKBNNM__c()))) &&
            ((this.YOSHINKBN__c==null && other.getYOSHINKBN__c()==null) || 
             (this.YOSHINKBN__c!=null &&
              this.YOSHINKBN__c.equals(other.getYOSHINKBN__c()))) &&
            ((this.YOSHINSHOKANBUCD__c==null && other.getYOSHINSHOKANBUCD__c()==null) || 
             (this.YOSHINSHOKANBUCD__c!=null &&
              this.YOSHINSHOKANBUCD__c.equals(other.getYOSHINSHOKANBUCD__c()))) &&
            ((this.YOSHINSHOKANBUNM__c==null && other.getYOSHINSHOKANBUNM__c()==null) || 
             (this.YOSHINSHOKANBUNM__c!=null &&
              this.YOSHINSHOKANBUNM__c.equals(other.getYOSHINSHOKANBUNM__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getActivityHistories() != null) {
            _hashCode += getActivityHistories().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBASERATECDNM__c() != null) {
            _hashCode += getBASERATECDNM__c().hashCode();
        }
        if (getBASERATECD__c() != null) {
            _hashCode += getBASERATECD__c().hashCode();
        }
        if (getCHOUINHI__c() != null) {
            _hashCode += getCHOUINHI__c().hashCode();
        }
        if (getCOMMITMENTID__c() != null) {
            _hashCode += getCOMMITMENTID__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDATAKIJUNNENGETSU__c() != null) {
            _hashCode += getDATAKIJUNNENGETSU__c().hashCode();
        }
        if (getDELFLG__c() != null) {
            _hashCode += getDELFLG__c().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getEvents() != null) {
            _hashCode += getEvents().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getKASHIDASHIHEIZANGOUKEI__c() != null) {
            _hashCode += getKASHIDASHIHEIZANGOUKEI__c().hashCode();
        }
        if (getKASHIDASHIHEIZAN__c() != null) {
            _hashCode += getKASHIDASHIHEIZAN__c().hashCode();
        }
        if (getKASHIDASHIMATSUZANGOUKEI__c() != null) {
            _hashCode += getKASHIDASHIMATSUZANGOUKEI__c().hashCode();
        }
        if (getKASHIDASHIMATSUZAN__c() != null) {
            _hashCode += getKASHIDASHIMATSUZAN__c().hashCode();
        }
        if (getKASHIDASHISHIKINSHUUEKIGOUKEI__c() != null) {
            _hashCode += getKASHIDASHISHIKINSHUUEKIGOUKEI__c().hashCode();
        }
        if (getKASHIDASHISHIKINSHUUEKI__c() != null) {
            _hashCode += getKASHIDASHISHIKINSHUUEKI__c().hashCode();
        }
        if (getKOKYAKUBANGOU__c() != null) {
            _hashCode += getKOKYAKUBANGOU__c().hashCode();
        }
        if (getKYOKUDO_TSUDOKBNNM__c() != null) {
            _hashCode += getKYOKUDO_TSUDOKBNNM__c().hashCode();
        }
        if (getKYOKUDO_TSUDOKBN__c() != null) {
            _hashCode += getKYOKUDO_TSUDOKBN__c().hashCode();
        }
        if (getLOCALKYOTENCD__c() != null) {
            _hashCode += getLOCALKYOTENCD__c().hashCode();
        }
        if (getLastActivityDate() != null) {
            _hashCode += getLastActivityDate().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getODHKIJUNNENGETSU__c() != null) {
            _hashCode += getODHKIJUNNENGETSU__c().hashCode();
        }
        if (getOpenActivities() != null) {
            _hashCode += getOpenActivities().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getRINGIKIGEN__c() != null) {
            _hashCode += getRINGIKIGEN__c().hashCode();
        }
        if (getSAIMUSHAKAKUDUKENM__c() != null) {
            _hashCode += getSAIMUSHAKAKUDUKENM__c().hashCode();
        }
        if (getSAIMUSHAKAKUDUKE__c() != null) {
            _hashCode += getSAIMUSHAKAKUDUKE__c().hashCode();
        }
        if (getSAISHUUHENSAIKIGEN__c() != null) {
            _hashCode += getSAISHUUHENSAIKIGEN__c().hashCode();
        }
        if (getSCACD__c() != null) {
            _hashCode += getSCACD__c().hashCode();
        }
        if (getSCAYOSHINKBNNM__c() != null) {
            _hashCode += getSCAYOSHINKBNNM__c().hashCode();
        }
        if (getSCAYOSHINKBN__c() != null) {
            _hashCode += getSCAYOSHINKBN__c().hashCode();
        }
        if (getSHOUNINBI__c() != null) {
            _hashCode += getSHOUNINBI__c().hashCode();
        }
        if (getSHOUNINCCYCD__c() != null) {
            _hashCode += getSHOUNINCCYCD__c().hashCode();
        }
        if (getSHOUNINCCY__c() != null) {
            _hashCode += getSHOUNINCCY__c().hashCode();
        }
        if (getSHOUNINKINGAKU__c() != null) {
            _hashCode += getSHOUNINKINGAKU__c().hashCode();
        }
        if (getShares() != null) {
            _hashCode += getShares().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c() != null) {
            _hashCode += getTENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c().hashCode();
        }
        if (getTENBAN__c() != null) {
            _hashCode += getTENBAN__c().hashCode();
        }
        if (getTORIHIKIHI__c() != null) {
            _hashCode += getTORIHIKIHI__c().hashCode();
        }
        if (getTORIHIKISAKIEIBUNMEI__c() != null) {
            _hashCode += getTORIHIKISAKIEIBUNMEI__c().hashCode();
        }
        if (getTasks() != null) {
            _hashCode += getTasks().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        if (getYOSHINBANGOUSUBNO__c() != null) {
            _hashCode += getYOSHINBANGOUSUBNO__c().hashCode();
        }
        if (getYOSHINBANGOU__c() != null) {
            _hashCode += getYOSHINBANGOU__c().hashCode();
        }
        if (getYOSHINKBNNM__c() != null) {
            _hashCode += getYOSHINKBNNM__c().hashCode();
        }
        if (getYOSHINKBN__c() != null) {
            _hashCode += getYOSHINKBN__c().hashCode();
        }
        if (getYOSHINSHOKANBUCD__c() != null) {
            _hashCode += getYOSHINSHOKANBUCD__c().hashCode();
        }
        if (getYOSHINSHOKANBUNM__c() != null) {
            _hashCode += getYOSHINSHOKANBUNM__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C000_ODHSHINYOSHININFO__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_ODHSHINYOSHININFO__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activityHistories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivityHistories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BASERATECDNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BASERATECDNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BASERATECD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BASERATECD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHOUINHI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CHOUINHI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COMMITMENTID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "COMMITMENTID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DATAKIJUNNENGETSU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DATAKIJUNNENGETSU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DELFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DELFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("events");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Events"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KASHIDASHIHEIZANGOUKEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KASHIDASHIHEIZANGOUKEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KASHIDASHIHEIZAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KASHIDASHIHEIZAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KASHIDASHIMATSUZANGOUKEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KASHIDASHIMATSUZANGOUKEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KASHIDASHIMATSUZAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KASHIDASHIMATSUZAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KASHIDASHISHIKINSHUUEKIGOUKEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KASHIDASHISHIKINSHUUEKIGOUKEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KASHIDASHISHIKINSHUUEKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KASHIDASHISHIKINSHUUEKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKYAKUBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKYAKUBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOKUDO_TSUDOKBNNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOKUDO_TSUDOKBNNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOKUDO_TSUDOKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOKUDO_TSUDOKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LOCALKYOTENCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LOCALKYOTENCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastActivityDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastActivityDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ODHKIJUNNENGETSU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ODHKIJUNNENGETSU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpenActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RINGIKIGEN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RINGIKIGEN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAIMUSHAKAKUDUKENM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAIMUSHAKAKUDUKENM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAIMUSHAKAKUDUKE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAIMUSHAKAKUDUKE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAISHUUHENSAIKIGEN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAISHUUHENSAIKIGEN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCACD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SCACD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCAYOSHINKBNNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SCAYOSHINKBNNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCAYOSHINKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SCAYOSHINKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOUNINBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOUNINBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOUNINCCYCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOUNINCCYCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOUNINCCY__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOUNINCCY__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOUNINKINGAKU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOUNINKINGAKU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENBAN_KOKYAKUBANGOU_YOSHINBANGOU_SNCCY__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENBAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENBAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIHI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIHI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKISAKIEIBUNMEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKISAKIEIBUNMEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tasks");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Tasks"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOSHINBANGOUSUBNO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOSHINBANGOUSUBNO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOSHINBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOSHINBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOSHINKBNNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOSHINKBNNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOSHINKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOSHINKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOSHINSHOKANBUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOSHINSHOKANBUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOSHINSHOKANBUNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOSHINSHOKANBUNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
