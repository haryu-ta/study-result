/**
 * SingleEmailMessage.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise;

public class SingleEmailMessage  extends com.sforce.soap.enterprise.Email  implements java.io.Serializable {
    private java.lang.String[] bccAddresses;

    private java.lang.String[] ccAddresses;

    private java.lang.String charset;

    private java.lang.String[] documentAttachments;

    private java.lang.String[] entityAttachments;

    private com.sforce.soap.enterprise.EmailFileAttachment[] fileAttachments;

    private java.lang.String htmlBody;

    private java.lang.String inReplyTo;

    private com.sforce.soap.enterprise.SendEmailOptOutPolicy optOutPolicy;

    private java.lang.String orgWideEmailAddressId;

    private java.lang.String plainTextBody;

    private java.lang.String references;

    private java.lang.String targetObjectId;

    private java.lang.String templateId;

    private java.lang.String[] toAddresses;

    private java.lang.Boolean treatBodiesAsTemplate;

    private java.lang.Boolean treatTargetObjectAsRecipient;

    private java.lang.String whatId;

    public SingleEmailMessage() {
    }

    public SingleEmailMessage(
           java.lang.Boolean bccSender,
           com.sforce.soap.enterprise.EmailPriority emailPriority,
           java.lang.String replyTo,
           java.lang.Boolean saveAsActivity,
           java.lang.String senderDisplayName,
           java.lang.String subject,
           java.lang.Boolean useSignature,
           java.lang.String[] bccAddresses,
           java.lang.String[] ccAddresses,
           java.lang.String charset,
           java.lang.String[] documentAttachments,
           java.lang.String[] entityAttachments,
           com.sforce.soap.enterprise.EmailFileAttachment[] fileAttachments,
           java.lang.String htmlBody,
           java.lang.String inReplyTo,
           com.sforce.soap.enterprise.SendEmailOptOutPolicy optOutPolicy,
           java.lang.String orgWideEmailAddressId,
           java.lang.String plainTextBody,
           java.lang.String references,
           java.lang.String targetObjectId,
           java.lang.String templateId,
           java.lang.String[] toAddresses,
           java.lang.Boolean treatBodiesAsTemplate,
           java.lang.Boolean treatTargetObjectAsRecipient,
           java.lang.String whatId) {
        super(
            bccSender,
            emailPriority,
            replyTo,
            saveAsActivity,
            senderDisplayName,
            subject,
            useSignature);
        this.bccAddresses = bccAddresses;
        this.ccAddresses = ccAddresses;
        this.charset = charset;
        this.documentAttachments = documentAttachments;
        this.entityAttachments = entityAttachments;
        this.fileAttachments = fileAttachments;
        this.htmlBody = htmlBody;
        this.inReplyTo = inReplyTo;
        this.optOutPolicy = optOutPolicy;
        this.orgWideEmailAddressId = orgWideEmailAddressId;
        this.plainTextBody = plainTextBody;
        this.references = references;
        this.targetObjectId = targetObjectId;
        this.templateId = templateId;
        this.toAddresses = toAddresses;
        this.treatBodiesAsTemplate = treatBodiesAsTemplate;
        this.treatTargetObjectAsRecipient = treatTargetObjectAsRecipient;
        this.whatId = whatId;
    }


    /**
     * Gets the bccAddresses value for this SingleEmailMessage.
     * 
     * @return bccAddresses
     */
    public java.lang.String[] getBccAddresses() {
        return bccAddresses;
    }


    /**
     * Sets the bccAddresses value for this SingleEmailMessage.
     * 
     * @param bccAddresses
     */
    public void setBccAddresses(java.lang.String[] bccAddresses) {
        this.bccAddresses = bccAddresses;
    }

    public java.lang.String getBccAddresses(int i) {
        return this.bccAddresses[i];
    }

    public void setBccAddresses(int i, java.lang.String _value) {
        this.bccAddresses[i] = _value;
    }


    /**
     * Gets the ccAddresses value for this SingleEmailMessage.
     * 
     * @return ccAddresses
     */
    public java.lang.String[] getCcAddresses() {
        return ccAddresses;
    }


    /**
     * Sets the ccAddresses value for this SingleEmailMessage.
     * 
     * @param ccAddresses
     */
    public void setCcAddresses(java.lang.String[] ccAddresses) {
        this.ccAddresses = ccAddresses;
    }

    public java.lang.String getCcAddresses(int i) {
        return this.ccAddresses[i];
    }

    public void setCcAddresses(int i, java.lang.String _value) {
        this.ccAddresses[i] = _value;
    }


    /**
     * Gets the charset value for this SingleEmailMessage.
     * 
     * @return charset
     */
    public java.lang.String getCharset() {
        return charset;
    }


    /**
     * Sets the charset value for this SingleEmailMessage.
     * 
     * @param charset
     */
    public void setCharset(java.lang.String charset) {
        this.charset = charset;
    }


    /**
     * Gets the documentAttachments value for this SingleEmailMessage.
     * 
     * @return documentAttachments
     */
    public java.lang.String[] getDocumentAttachments() {
        return documentAttachments;
    }


    /**
     * Sets the documentAttachments value for this SingleEmailMessage.
     * 
     * @param documentAttachments
     */
    public void setDocumentAttachments(java.lang.String[] documentAttachments) {
        this.documentAttachments = documentAttachments;
    }

    public java.lang.String getDocumentAttachments(int i) {
        return this.documentAttachments[i];
    }

    public void setDocumentAttachments(int i, java.lang.String _value) {
        this.documentAttachments[i] = _value;
    }


    /**
     * Gets the entityAttachments value for this SingleEmailMessage.
     * 
     * @return entityAttachments
     */
    public java.lang.String[] getEntityAttachments() {
        return entityAttachments;
    }


    /**
     * Sets the entityAttachments value for this SingleEmailMessage.
     * 
     * @param entityAttachments
     */
    public void setEntityAttachments(java.lang.String[] entityAttachments) {
        this.entityAttachments = entityAttachments;
    }

    public java.lang.String getEntityAttachments(int i) {
        return this.entityAttachments[i];
    }

    public void setEntityAttachments(int i, java.lang.String _value) {
        this.entityAttachments[i] = _value;
    }


    /**
     * Gets the fileAttachments value for this SingleEmailMessage.
     * 
     * @return fileAttachments
     */
    public com.sforce.soap.enterprise.EmailFileAttachment[] getFileAttachments() {
        return fileAttachments;
    }


    /**
     * Sets the fileAttachments value for this SingleEmailMessage.
     * 
     * @param fileAttachments
     */
    public void setFileAttachments(com.sforce.soap.enterprise.EmailFileAttachment[] fileAttachments) {
        this.fileAttachments = fileAttachments;
    }

    public com.sforce.soap.enterprise.EmailFileAttachment getFileAttachments(int i) {
        return this.fileAttachments[i];
    }

    public void setFileAttachments(int i, com.sforce.soap.enterprise.EmailFileAttachment _value) {
        this.fileAttachments[i] = _value;
    }


    /**
     * Gets the htmlBody value for this SingleEmailMessage.
     * 
     * @return htmlBody
     */
    public java.lang.String getHtmlBody() {
        return htmlBody;
    }


    /**
     * Sets the htmlBody value for this SingleEmailMessage.
     * 
     * @param htmlBody
     */
    public void setHtmlBody(java.lang.String htmlBody) {
        this.htmlBody = htmlBody;
    }


    /**
     * Gets the inReplyTo value for this SingleEmailMessage.
     * 
     * @return inReplyTo
     */
    public java.lang.String getInReplyTo() {
        return inReplyTo;
    }


    /**
     * Sets the inReplyTo value for this SingleEmailMessage.
     * 
     * @param inReplyTo
     */
    public void setInReplyTo(java.lang.String inReplyTo) {
        this.inReplyTo = inReplyTo;
    }


    /**
     * Gets the optOutPolicy value for this SingleEmailMessage.
     * 
     * @return optOutPolicy
     */
    public com.sforce.soap.enterprise.SendEmailOptOutPolicy getOptOutPolicy() {
        return optOutPolicy;
    }


    /**
     * Sets the optOutPolicy value for this SingleEmailMessage.
     * 
     * @param optOutPolicy
     */
    public void setOptOutPolicy(com.sforce.soap.enterprise.SendEmailOptOutPolicy optOutPolicy) {
        this.optOutPolicy = optOutPolicy;
    }


    /**
     * Gets the orgWideEmailAddressId value for this SingleEmailMessage.
     * 
     * @return orgWideEmailAddressId
     */
    public java.lang.String getOrgWideEmailAddressId() {
        return orgWideEmailAddressId;
    }


    /**
     * Sets the orgWideEmailAddressId value for this SingleEmailMessage.
     * 
     * @param orgWideEmailAddressId
     */
    public void setOrgWideEmailAddressId(java.lang.String orgWideEmailAddressId) {
        this.orgWideEmailAddressId = orgWideEmailAddressId;
    }


    /**
     * Gets the plainTextBody value for this SingleEmailMessage.
     * 
     * @return plainTextBody
     */
    public java.lang.String getPlainTextBody() {
        return plainTextBody;
    }


    /**
     * Sets the plainTextBody value for this SingleEmailMessage.
     * 
     * @param plainTextBody
     */
    public void setPlainTextBody(java.lang.String plainTextBody) {
        this.plainTextBody = plainTextBody;
    }


    /**
     * Gets the references value for this SingleEmailMessage.
     * 
     * @return references
     */
    public java.lang.String getReferences() {
        return references;
    }


    /**
     * Sets the references value for this SingleEmailMessage.
     * 
     * @param references
     */
    public void setReferences(java.lang.String references) {
        this.references = references;
    }


    /**
     * Gets the targetObjectId value for this SingleEmailMessage.
     * 
     * @return targetObjectId
     */
    public java.lang.String getTargetObjectId() {
        return targetObjectId;
    }


    /**
     * Sets the targetObjectId value for this SingleEmailMessage.
     * 
     * @param targetObjectId
     */
    public void setTargetObjectId(java.lang.String targetObjectId) {
        this.targetObjectId = targetObjectId;
    }


    /**
     * Gets the templateId value for this SingleEmailMessage.
     * 
     * @return templateId
     */
    public java.lang.String getTemplateId() {
        return templateId;
    }


    /**
     * Sets the templateId value for this SingleEmailMessage.
     * 
     * @param templateId
     */
    public void setTemplateId(java.lang.String templateId) {
        this.templateId = templateId;
    }


    /**
     * Gets the toAddresses value for this SingleEmailMessage.
     * 
     * @return toAddresses
     */
    public java.lang.String[] getToAddresses() {
        return toAddresses;
    }


    /**
     * Sets the toAddresses value for this SingleEmailMessage.
     * 
     * @param toAddresses
     */
    public void setToAddresses(java.lang.String[] toAddresses) {
        this.toAddresses = toAddresses;
    }

    public java.lang.String getToAddresses(int i) {
        return this.toAddresses[i];
    }

    public void setToAddresses(int i, java.lang.String _value) {
        this.toAddresses[i] = _value;
    }


    /**
     * Gets the treatBodiesAsTemplate value for this SingleEmailMessage.
     * 
     * @return treatBodiesAsTemplate
     */
    public java.lang.Boolean getTreatBodiesAsTemplate() {
        return treatBodiesAsTemplate;
    }


    /**
     * Sets the treatBodiesAsTemplate value for this SingleEmailMessage.
     * 
     * @param treatBodiesAsTemplate
     */
    public void setTreatBodiesAsTemplate(java.lang.Boolean treatBodiesAsTemplate) {
        this.treatBodiesAsTemplate = treatBodiesAsTemplate;
    }


    /**
     * Gets the treatTargetObjectAsRecipient value for this SingleEmailMessage.
     * 
     * @return treatTargetObjectAsRecipient
     */
    public java.lang.Boolean getTreatTargetObjectAsRecipient() {
        return treatTargetObjectAsRecipient;
    }


    /**
     * Sets the treatTargetObjectAsRecipient value for this SingleEmailMessage.
     * 
     * @param treatTargetObjectAsRecipient
     */
    public void setTreatTargetObjectAsRecipient(java.lang.Boolean treatTargetObjectAsRecipient) {
        this.treatTargetObjectAsRecipient = treatTargetObjectAsRecipient;
    }


    /**
     * Gets the whatId value for this SingleEmailMessage.
     * 
     * @return whatId
     */
    public java.lang.String getWhatId() {
        return whatId;
    }


    /**
     * Sets the whatId value for this SingleEmailMessage.
     * 
     * @param whatId
     */
    public void setWhatId(java.lang.String whatId) {
        this.whatId = whatId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SingleEmailMessage)) return false;
        SingleEmailMessage other = (SingleEmailMessage) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.bccAddresses==null && other.getBccAddresses()==null) || 
             (this.bccAddresses!=null &&
              java.util.Arrays.equals(this.bccAddresses, other.getBccAddresses()))) &&
            ((this.ccAddresses==null && other.getCcAddresses()==null) || 
             (this.ccAddresses!=null &&
              java.util.Arrays.equals(this.ccAddresses, other.getCcAddresses()))) &&
            ((this.charset==null && other.getCharset()==null) || 
             (this.charset!=null &&
              this.charset.equals(other.getCharset()))) &&
            ((this.documentAttachments==null && other.getDocumentAttachments()==null) || 
             (this.documentAttachments!=null &&
              java.util.Arrays.equals(this.documentAttachments, other.getDocumentAttachments()))) &&
            ((this.entityAttachments==null && other.getEntityAttachments()==null) || 
             (this.entityAttachments!=null &&
              java.util.Arrays.equals(this.entityAttachments, other.getEntityAttachments()))) &&
            ((this.fileAttachments==null && other.getFileAttachments()==null) || 
             (this.fileAttachments!=null &&
              java.util.Arrays.equals(this.fileAttachments, other.getFileAttachments()))) &&
            ((this.htmlBody==null && other.getHtmlBody()==null) || 
             (this.htmlBody!=null &&
              this.htmlBody.equals(other.getHtmlBody()))) &&
            ((this.inReplyTo==null && other.getInReplyTo()==null) || 
             (this.inReplyTo!=null &&
              this.inReplyTo.equals(other.getInReplyTo()))) &&
            ((this.optOutPolicy==null && other.getOptOutPolicy()==null) || 
             (this.optOutPolicy!=null &&
              this.optOutPolicy.equals(other.getOptOutPolicy()))) &&
            ((this.orgWideEmailAddressId==null && other.getOrgWideEmailAddressId()==null) || 
             (this.orgWideEmailAddressId!=null &&
              this.orgWideEmailAddressId.equals(other.getOrgWideEmailAddressId()))) &&
            ((this.plainTextBody==null && other.getPlainTextBody()==null) || 
             (this.plainTextBody!=null &&
              this.plainTextBody.equals(other.getPlainTextBody()))) &&
            ((this.references==null && other.getReferences()==null) || 
             (this.references!=null &&
              this.references.equals(other.getReferences()))) &&
            ((this.targetObjectId==null && other.getTargetObjectId()==null) || 
             (this.targetObjectId!=null &&
              this.targetObjectId.equals(other.getTargetObjectId()))) &&
            ((this.templateId==null && other.getTemplateId()==null) || 
             (this.templateId!=null &&
              this.templateId.equals(other.getTemplateId()))) &&
            ((this.toAddresses==null && other.getToAddresses()==null) || 
             (this.toAddresses!=null &&
              java.util.Arrays.equals(this.toAddresses, other.getToAddresses()))) &&
            ((this.treatBodiesAsTemplate==null && other.getTreatBodiesAsTemplate()==null) || 
             (this.treatBodiesAsTemplate!=null &&
              this.treatBodiesAsTemplate.equals(other.getTreatBodiesAsTemplate()))) &&
            ((this.treatTargetObjectAsRecipient==null && other.getTreatTargetObjectAsRecipient()==null) || 
             (this.treatTargetObjectAsRecipient!=null &&
              this.treatTargetObjectAsRecipient.equals(other.getTreatTargetObjectAsRecipient()))) &&
            ((this.whatId==null && other.getWhatId()==null) || 
             (this.whatId!=null &&
              this.whatId.equals(other.getWhatId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getBccAddresses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getBccAddresses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getBccAddresses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCcAddresses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCcAddresses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCcAddresses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCharset() != null) {
            _hashCode += getCharset().hashCode();
        }
        if (getDocumentAttachments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDocumentAttachments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDocumentAttachments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEntityAttachments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEntityAttachments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEntityAttachments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFileAttachments() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getFileAttachments());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getFileAttachments(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getHtmlBody() != null) {
            _hashCode += getHtmlBody().hashCode();
        }
        if (getInReplyTo() != null) {
            _hashCode += getInReplyTo().hashCode();
        }
        if (getOptOutPolicy() != null) {
            _hashCode += getOptOutPolicy().hashCode();
        }
        if (getOrgWideEmailAddressId() != null) {
            _hashCode += getOrgWideEmailAddressId().hashCode();
        }
        if (getPlainTextBody() != null) {
            _hashCode += getPlainTextBody().hashCode();
        }
        if (getReferences() != null) {
            _hashCode += getReferences().hashCode();
        }
        if (getTargetObjectId() != null) {
            _hashCode += getTargetObjectId().hashCode();
        }
        if (getTemplateId() != null) {
            _hashCode += getTemplateId().hashCode();
        }
        if (getToAddresses() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getToAddresses());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getToAddresses(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTreatBodiesAsTemplate() != null) {
            _hashCode += getTreatBodiesAsTemplate().hashCode();
        }
        if (getTreatTargetObjectAsRecipient() != null) {
            _hashCode += getTreatTargetObjectAsRecipient().hashCode();
        }
        if (getWhatId() != null) {
            _hashCode += getWhatId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SingleEmailMessage.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "SingleEmailMessage"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bccAddresses");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "bccAddresses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ccAddresses");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "ccAddresses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("charset");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "charset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("documentAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "documentAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "ID"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("entityAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "entityAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "ID"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fileAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "fileAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "EmailFileAttachment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("htmlBody");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "htmlBody"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inReplyTo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "inReplyTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("optOutPolicy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "optOutPolicy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "SendEmailOptOutPolicy"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orgWideEmailAddressId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "orgWideEmailAddressId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("plainTextBody");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "plainTextBody"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("references");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "references"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("targetObjectId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "targetObjectId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("templateId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "templateId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toAddresses");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "toAddresses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("treatBodiesAsTemplate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "treatBodiesAsTemplate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("treatTargetObjectAsRecipient");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "treatTargetObjectAsRecipient"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("whatId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "whatId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
