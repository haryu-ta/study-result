/**
 * A006_MST_Shuyaku__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class A006_MST_Shuyaku__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult allocationLimitToKyoten__r;

    private com.sforce.soap.enterprise.QueryResult allocationLimitToProductAllocationLimit__r;

    private com.sforce.soap.enterprise.QueryResult allocationRateLimitToRate__r;

    private com.sforce.soap.enterprise.QueryResult allocationRateUsageToRate__r;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private com.sforce.soap.enterprise.QueryResult bankCreditAmountToshuyaku__r;

    private com.sforce.soap.enterprise.QueryResult bankToCountry__r;

    private com.sforce.soap.enterprise.QueryResult bankToGroup__r;

    private com.sforce.soap.enterprise.QueryResult branchToParentBranch__r;

    private com.sforce.soap.enterprise.QueryResult CIBToKyotenMatching__r;

    private com.sforce.soap.enterprise.QueryResult CLimitExToCountryCode__r;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.QueryResult commonToKyoten__r;

    private com.sforce.soap.enterprise.QueryResult commonToProduct__r;

    private com.sforce.soap.enterprise.QueryResult commonToRate__r;

    private com.sforce.soap.enterprise.QueryResult countryMatchingToCountry__r;

    private com.sforce.soap.enterprise.QueryResult countryToCountryCode__r;

    private com.sforce.soap.enterprise.QueryResult countryToRegion__r;

    private com.sforce.soap.enterprise.QueryResult creJitsuToKyoten__r;

    private com.sforce.soap.enterprise.QueryResult creJitsuToProduct__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult creditLimitAmericaToKyotenMatching__r;

    private com.sforce.soap.enterprise.QueryResult creditLimitAmericaToProductMatching__r;

    private com.sforce.soap.enterprise.QueryResult creditLimitAsiaMoneyToKyotenMatching__r;

    private com.sforce.soap.enterprise.QueryResult creditLimitAsiaMoneyToProductMatching__r;

    private com.sforce.soap.enterprise.QueryResult creditLimitAsiaOseToKyotenMatching__r;

    private com.sforce.soap.enterprise.QueryResult creditLimitAsiaOseToProductMatching__r;

    private com.sforce.soap.enterprise.QueryResult creditLimitEuropeToKyotenMatching__r;

    private com.sforce.soap.enterprise.QueryResult creditLimitEuropeToProductMatching__r;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult EIUToCountryCode__r;

    private com.sforce.soap.enterprise.QueryResult EMBIToCountryCode__r;

    private com.sforce.soap.enterprise.QueryResult gaiginCountryToCountry__r;

    private com.sforce.soap.enterprise.QueryResult groupCreditAmounttoGroup__r;

    private com.sforce.soap.enterprise.QueryResult groupToCountry__r;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.QueryResult jitsuzanCIBToProductsMatching__r;

    private com.sforce.soap.enterprise.QueryResult KOKUNAIForexToProduct__r;

    private com.sforce.soap.enterprise.QueryResult KOKUNAIGuaranteesToProduct__r;

    private com.sforce.soap.enterprise.QueryResult KOKUNAILoanCmtUndrnToProduct__r;

    private com.sforce.soap.enterprise.QueryResult KOKUNAILoanToProduct__r;

    private com.sforce.soap.enterprise.QueryResult kyotenMatchingToKyoten__r;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private com.sforce.soap.enterprise.QueryResult productsMatchingToProduct__r;

    private com.sforce.soap.enterprise.QueryResult relatedBranchToKyoten__r;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.QueryResult tradeToCountryCode__r;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    public A006_MST_Shuyaku__c() {
    }

    public A006_MST_Shuyaku__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult allocationLimitToKyoten__r,
           com.sforce.soap.enterprise.QueryResult allocationLimitToProductAllocationLimit__r,
           com.sforce.soap.enterprise.QueryResult allocationRateLimitToRate__r,
           com.sforce.soap.enterprise.QueryResult allocationRateUsageToRate__r,
           com.sforce.soap.enterprise.QueryResult attachments,
           com.sforce.soap.enterprise.QueryResult bankCreditAmountToshuyaku__r,
           com.sforce.soap.enterprise.QueryResult bankToCountry__r,
           com.sforce.soap.enterprise.QueryResult bankToGroup__r,
           com.sforce.soap.enterprise.QueryResult branchToParentBranch__r,
           com.sforce.soap.enterprise.QueryResult CIBToKyotenMatching__r,
           com.sforce.soap.enterprise.QueryResult CLimitExToCountryCode__r,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.QueryResult commonToKyoten__r,
           com.sforce.soap.enterprise.QueryResult commonToProduct__r,
           com.sforce.soap.enterprise.QueryResult commonToRate__r,
           com.sforce.soap.enterprise.QueryResult countryMatchingToCountry__r,
           com.sforce.soap.enterprise.QueryResult countryToCountryCode__r,
           com.sforce.soap.enterprise.QueryResult countryToRegion__r,
           com.sforce.soap.enterprise.QueryResult creJitsuToKyoten__r,
           com.sforce.soap.enterprise.QueryResult creJitsuToProduct__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult creditLimitAmericaToKyotenMatching__r,
           com.sforce.soap.enterprise.QueryResult creditLimitAmericaToProductMatching__r,
           com.sforce.soap.enterprise.QueryResult creditLimitAsiaMoneyToKyotenMatching__r,
           com.sforce.soap.enterprise.QueryResult creditLimitAsiaMoneyToProductMatching__r,
           com.sforce.soap.enterprise.QueryResult creditLimitAsiaOseToKyotenMatching__r,
           com.sforce.soap.enterprise.QueryResult creditLimitAsiaOseToProductMatching__r,
           com.sforce.soap.enterprise.QueryResult creditLimitEuropeToKyotenMatching__r,
           com.sforce.soap.enterprise.QueryResult creditLimitEuropeToProductMatching__r,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult EIUToCountryCode__r,
           com.sforce.soap.enterprise.QueryResult EMBIToCountryCode__r,
           com.sforce.soap.enterprise.QueryResult gaiginCountryToCountry__r,
           com.sforce.soap.enterprise.QueryResult groupCreditAmounttoGroup__r,
           com.sforce.soap.enterprise.QueryResult groupToCountry__r,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.QueryResult jitsuzanCIBToProductsMatching__r,
           com.sforce.soap.enterprise.QueryResult KOKUNAIForexToProduct__r,
           com.sforce.soap.enterprise.QueryResult KOKUNAIGuaranteesToProduct__r,
           com.sforce.soap.enterprise.QueryResult KOKUNAILoanCmtUndrnToProduct__r,
           com.sforce.soap.enterprise.QueryResult KOKUNAILoanToProduct__r,
           com.sforce.soap.enterprise.QueryResult kyotenMatchingToKyoten__r,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           com.sforce.soap.enterprise.QueryResult productsMatchingToProduct__r,
           com.sforce.soap.enterprise.QueryResult relatedBranchToKyoten__r,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.QueryResult tradeToCountryCode__r,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        super(
            fieldsToNull,
            id);
        this.allocationLimitToKyoten__r = allocationLimitToKyoten__r;
        this.allocationLimitToProductAllocationLimit__r = allocationLimitToProductAllocationLimit__r;
        this.allocationRateLimitToRate__r = allocationRateLimitToRate__r;
        this.allocationRateUsageToRate__r = allocationRateUsageToRate__r;
        this.attachments = attachments;
        this.bankCreditAmountToshuyaku__r = bankCreditAmountToshuyaku__r;
        this.bankToCountry__r = bankToCountry__r;
        this.bankToGroup__r = bankToGroup__r;
        this.branchToParentBranch__r = branchToParentBranch__r;
        this.CIBToKyotenMatching__r = CIBToKyotenMatching__r;
        this.CLimitExToCountryCode__r = CLimitExToCountryCode__r;
        this.combinedAttachments = combinedAttachments;
        this.commonToKyoten__r = commonToKyoten__r;
        this.commonToProduct__r = commonToProduct__r;
        this.commonToRate__r = commonToRate__r;
        this.countryMatchingToCountry__r = countryMatchingToCountry__r;
        this.countryToCountryCode__r = countryToCountryCode__r;
        this.countryToRegion__r = countryToRegion__r;
        this.creJitsuToKyoten__r = creJitsuToKyoten__r;
        this.creJitsuToProduct__r = creJitsuToProduct__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.creditLimitAmericaToKyotenMatching__r = creditLimitAmericaToKyotenMatching__r;
        this.creditLimitAmericaToProductMatching__r = creditLimitAmericaToProductMatching__r;
        this.creditLimitAsiaMoneyToKyotenMatching__r = creditLimitAsiaMoneyToKyotenMatching__r;
        this.creditLimitAsiaMoneyToProductMatching__r = creditLimitAsiaMoneyToProductMatching__r;
        this.creditLimitAsiaOseToKyotenMatching__r = creditLimitAsiaOseToKyotenMatching__r;
        this.creditLimitAsiaOseToProductMatching__r = creditLimitAsiaOseToProductMatching__r;
        this.creditLimitEuropeToKyotenMatching__r = creditLimitEuropeToKyotenMatching__r;
        this.creditLimitEuropeToProductMatching__r = creditLimitEuropeToProductMatching__r;
        this.duplicateRecordItems = duplicateRecordItems;
        this.EIUToCountryCode__r = EIUToCountryCode__r;
        this.EMBIToCountryCode__r = EMBIToCountryCode__r;
        this.gaiginCountryToCountry__r = gaiginCountryToCountry__r;
        this.groupCreditAmounttoGroup__r = groupCreditAmounttoGroup__r;
        this.groupToCountry__r = groupToCountry__r;
        this.isDeleted = isDeleted;
        this.jitsuzanCIBToProductsMatching__r = jitsuzanCIBToProductsMatching__r;
        this.KOKUNAIForexToProduct__r = KOKUNAIForexToProduct__r;
        this.KOKUNAIGuaranteesToProduct__r = KOKUNAIGuaranteesToProduct__r;
        this.KOKUNAILoanCmtUndrnToProduct__r = KOKUNAILoanCmtUndrnToProduct__r;
        this.KOKUNAILoanToProduct__r = KOKUNAILoanToProduct__r;
        this.kyotenMatchingToKyoten__r = kyotenMatchingToKyoten__r;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.productsMatchingToProduct__r = productsMatchingToProduct__r;
        this.relatedBranchToKyoten__r = relatedBranchToKyoten__r;
        this.systemModstamp = systemModstamp;
        this.topicAssignments = topicAssignments;
        this.tradeToCountryCode__r = tradeToCountryCode__r;
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the allocationLimitToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @return allocationLimitToKyoten__r
     */
    public com.sforce.soap.enterprise.QueryResult getAllocationLimitToKyoten__r() {
        return allocationLimitToKyoten__r;
    }


    /**
     * Sets the allocationLimitToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @param allocationLimitToKyoten__r
     */
    public void setAllocationLimitToKyoten__r(com.sforce.soap.enterprise.QueryResult allocationLimitToKyoten__r) {
        this.allocationLimitToKyoten__r = allocationLimitToKyoten__r;
    }


    /**
     * Gets the allocationLimitToProductAllocationLimit__r value for this A006_MST_Shuyaku__c.
     * 
     * @return allocationLimitToProductAllocationLimit__r
     */
    public com.sforce.soap.enterprise.QueryResult getAllocationLimitToProductAllocationLimit__r() {
        return allocationLimitToProductAllocationLimit__r;
    }


    /**
     * Sets the allocationLimitToProductAllocationLimit__r value for this A006_MST_Shuyaku__c.
     * 
     * @param allocationLimitToProductAllocationLimit__r
     */
    public void setAllocationLimitToProductAllocationLimit__r(com.sforce.soap.enterprise.QueryResult allocationLimitToProductAllocationLimit__r) {
        this.allocationLimitToProductAllocationLimit__r = allocationLimitToProductAllocationLimit__r;
    }


    /**
     * Gets the allocationRateLimitToRate__r value for this A006_MST_Shuyaku__c.
     * 
     * @return allocationRateLimitToRate__r
     */
    public com.sforce.soap.enterprise.QueryResult getAllocationRateLimitToRate__r() {
        return allocationRateLimitToRate__r;
    }


    /**
     * Sets the allocationRateLimitToRate__r value for this A006_MST_Shuyaku__c.
     * 
     * @param allocationRateLimitToRate__r
     */
    public void setAllocationRateLimitToRate__r(com.sforce.soap.enterprise.QueryResult allocationRateLimitToRate__r) {
        this.allocationRateLimitToRate__r = allocationRateLimitToRate__r;
    }


    /**
     * Gets the allocationRateUsageToRate__r value for this A006_MST_Shuyaku__c.
     * 
     * @return allocationRateUsageToRate__r
     */
    public com.sforce.soap.enterprise.QueryResult getAllocationRateUsageToRate__r() {
        return allocationRateUsageToRate__r;
    }


    /**
     * Sets the allocationRateUsageToRate__r value for this A006_MST_Shuyaku__c.
     * 
     * @param allocationRateUsageToRate__r
     */
    public void setAllocationRateUsageToRate__r(com.sforce.soap.enterprise.QueryResult allocationRateUsageToRate__r) {
        this.allocationRateUsageToRate__r = allocationRateUsageToRate__r;
    }


    /**
     * Gets the attachments value for this A006_MST_Shuyaku__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this A006_MST_Shuyaku__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the bankCreditAmountToshuyaku__r value for this A006_MST_Shuyaku__c.
     * 
     * @return bankCreditAmountToshuyaku__r
     */
    public com.sforce.soap.enterprise.QueryResult getBankCreditAmountToshuyaku__r() {
        return bankCreditAmountToshuyaku__r;
    }


    /**
     * Sets the bankCreditAmountToshuyaku__r value for this A006_MST_Shuyaku__c.
     * 
     * @param bankCreditAmountToshuyaku__r
     */
    public void setBankCreditAmountToshuyaku__r(com.sforce.soap.enterprise.QueryResult bankCreditAmountToshuyaku__r) {
        this.bankCreditAmountToshuyaku__r = bankCreditAmountToshuyaku__r;
    }


    /**
     * Gets the bankToCountry__r value for this A006_MST_Shuyaku__c.
     * 
     * @return bankToCountry__r
     */
    public com.sforce.soap.enterprise.QueryResult getBankToCountry__r() {
        return bankToCountry__r;
    }


    /**
     * Sets the bankToCountry__r value for this A006_MST_Shuyaku__c.
     * 
     * @param bankToCountry__r
     */
    public void setBankToCountry__r(com.sforce.soap.enterprise.QueryResult bankToCountry__r) {
        this.bankToCountry__r = bankToCountry__r;
    }


    /**
     * Gets the bankToGroup__r value for this A006_MST_Shuyaku__c.
     * 
     * @return bankToGroup__r
     */
    public com.sforce.soap.enterprise.QueryResult getBankToGroup__r() {
        return bankToGroup__r;
    }


    /**
     * Sets the bankToGroup__r value for this A006_MST_Shuyaku__c.
     * 
     * @param bankToGroup__r
     */
    public void setBankToGroup__r(com.sforce.soap.enterprise.QueryResult bankToGroup__r) {
        this.bankToGroup__r = bankToGroup__r;
    }


    /**
     * Gets the branchToParentBranch__r value for this A006_MST_Shuyaku__c.
     * 
     * @return branchToParentBranch__r
     */
    public com.sforce.soap.enterprise.QueryResult getBranchToParentBranch__r() {
        return branchToParentBranch__r;
    }


    /**
     * Sets the branchToParentBranch__r value for this A006_MST_Shuyaku__c.
     * 
     * @param branchToParentBranch__r
     */
    public void setBranchToParentBranch__r(com.sforce.soap.enterprise.QueryResult branchToParentBranch__r) {
        this.branchToParentBranch__r = branchToParentBranch__r;
    }


    /**
     * Gets the CIBToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return CIBToKyotenMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getCIBToKyotenMatching__r() {
        return CIBToKyotenMatching__r;
    }


    /**
     * Sets the CIBToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param CIBToKyotenMatching__r
     */
    public void setCIBToKyotenMatching__r(com.sforce.soap.enterprise.QueryResult CIBToKyotenMatching__r) {
        this.CIBToKyotenMatching__r = CIBToKyotenMatching__r;
    }


    /**
     * Gets the CLimitExToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @return CLimitExToCountryCode__r
     */
    public com.sforce.soap.enterprise.QueryResult getCLimitExToCountryCode__r() {
        return CLimitExToCountryCode__r;
    }


    /**
     * Sets the CLimitExToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @param CLimitExToCountryCode__r
     */
    public void setCLimitExToCountryCode__r(com.sforce.soap.enterprise.QueryResult CLimitExToCountryCode__r) {
        this.CLimitExToCountryCode__r = CLimitExToCountryCode__r;
    }


    /**
     * Gets the combinedAttachments value for this A006_MST_Shuyaku__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this A006_MST_Shuyaku__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the commonToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @return commonToKyoten__r
     */
    public com.sforce.soap.enterprise.QueryResult getCommonToKyoten__r() {
        return commonToKyoten__r;
    }


    /**
     * Sets the commonToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @param commonToKyoten__r
     */
    public void setCommonToKyoten__r(com.sforce.soap.enterprise.QueryResult commonToKyoten__r) {
        this.commonToKyoten__r = commonToKyoten__r;
    }


    /**
     * Gets the commonToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @return commonToProduct__r
     */
    public com.sforce.soap.enterprise.QueryResult getCommonToProduct__r() {
        return commonToProduct__r;
    }


    /**
     * Sets the commonToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @param commonToProduct__r
     */
    public void setCommonToProduct__r(com.sforce.soap.enterprise.QueryResult commonToProduct__r) {
        this.commonToProduct__r = commonToProduct__r;
    }


    /**
     * Gets the commonToRate__r value for this A006_MST_Shuyaku__c.
     * 
     * @return commonToRate__r
     */
    public com.sforce.soap.enterprise.QueryResult getCommonToRate__r() {
        return commonToRate__r;
    }


    /**
     * Sets the commonToRate__r value for this A006_MST_Shuyaku__c.
     * 
     * @param commonToRate__r
     */
    public void setCommonToRate__r(com.sforce.soap.enterprise.QueryResult commonToRate__r) {
        this.commonToRate__r = commonToRate__r;
    }


    /**
     * Gets the countryMatchingToCountry__r value for this A006_MST_Shuyaku__c.
     * 
     * @return countryMatchingToCountry__r
     */
    public com.sforce.soap.enterprise.QueryResult getCountryMatchingToCountry__r() {
        return countryMatchingToCountry__r;
    }


    /**
     * Sets the countryMatchingToCountry__r value for this A006_MST_Shuyaku__c.
     * 
     * @param countryMatchingToCountry__r
     */
    public void setCountryMatchingToCountry__r(com.sforce.soap.enterprise.QueryResult countryMatchingToCountry__r) {
        this.countryMatchingToCountry__r = countryMatchingToCountry__r;
    }


    /**
     * Gets the countryToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @return countryToCountryCode__r
     */
    public com.sforce.soap.enterprise.QueryResult getCountryToCountryCode__r() {
        return countryToCountryCode__r;
    }


    /**
     * Sets the countryToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @param countryToCountryCode__r
     */
    public void setCountryToCountryCode__r(com.sforce.soap.enterprise.QueryResult countryToCountryCode__r) {
        this.countryToCountryCode__r = countryToCountryCode__r;
    }


    /**
     * Gets the countryToRegion__r value for this A006_MST_Shuyaku__c.
     * 
     * @return countryToRegion__r
     */
    public com.sforce.soap.enterprise.QueryResult getCountryToRegion__r() {
        return countryToRegion__r;
    }


    /**
     * Sets the countryToRegion__r value for this A006_MST_Shuyaku__c.
     * 
     * @param countryToRegion__r
     */
    public void setCountryToRegion__r(com.sforce.soap.enterprise.QueryResult countryToRegion__r) {
        this.countryToRegion__r = countryToRegion__r;
    }


    /**
     * Gets the creJitsuToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creJitsuToKyoten__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreJitsuToKyoten__r() {
        return creJitsuToKyoten__r;
    }


    /**
     * Sets the creJitsuToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creJitsuToKyoten__r
     */
    public void setCreJitsuToKyoten__r(com.sforce.soap.enterprise.QueryResult creJitsuToKyoten__r) {
        this.creJitsuToKyoten__r = creJitsuToKyoten__r;
    }


    /**
     * Gets the creJitsuToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creJitsuToProduct__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreJitsuToProduct__r() {
        return creJitsuToProduct__r;
    }


    /**
     * Sets the creJitsuToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creJitsuToProduct__r
     */
    public void setCreJitsuToProduct__r(com.sforce.soap.enterprise.QueryResult creJitsuToProduct__r) {
        this.creJitsuToProduct__r = creJitsuToProduct__r;
    }


    /**
     * Gets the createdBy value for this A006_MST_Shuyaku__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this A006_MST_Shuyaku__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this A006_MST_Shuyaku__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this A006_MST_Shuyaku__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this A006_MST_Shuyaku__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this A006_MST_Shuyaku__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the creditLimitAmericaToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creditLimitAmericaToKyotenMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreditLimitAmericaToKyotenMatching__r() {
        return creditLimitAmericaToKyotenMatching__r;
    }


    /**
     * Sets the creditLimitAmericaToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creditLimitAmericaToKyotenMatching__r
     */
    public void setCreditLimitAmericaToKyotenMatching__r(com.sforce.soap.enterprise.QueryResult creditLimitAmericaToKyotenMatching__r) {
        this.creditLimitAmericaToKyotenMatching__r = creditLimitAmericaToKyotenMatching__r;
    }


    /**
     * Gets the creditLimitAmericaToProductMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creditLimitAmericaToProductMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreditLimitAmericaToProductMatching__r() {
        return creditLimitAmericaToProductMatching__r;
    }


    /**
     * Sets the creditLimitAmericaToProductMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creditLimitAmericaToProductMatching__r
     */
    public void setCreditLimitAmericaToProductMatching__r(com.sforce.soap.enterprise.QueryResult creditLimitAmericaToProductMatching__r) {
        this.creditLimitAmericaToProductMatching__r = creditLimitAmericaToProductMatching__r;
    }


    /**
     * Gets the creditLimitAsiaMoneyToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creditLimitAsiaMoneyToKyotenMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreditLimitAsiaMoneyToKyotenMatching__r() {
        return creditLimitAsiaMoneyToKyotenMatching__r;
    }


    /**
     * Sets the creditLimitAsiaMoneyToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creditLimitAsiaMoneyToKyotenMatching__r
     */
    public void setCreditLimitAsiaMoneyToKyotenMatching__r(com.sforce.soap.enterprise.QueryResult creditLimitAsiaMoneyToKyotenMatching__r) {
        this.creditLimitAsiaMoneyToKyotenMatching__r = creditLimitAsiaMoneyToKyotenMatching__r;
    }


    /**
     * Gets the creditLimitAsiaMoneyToProductMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creditLimitAsiaMoneyToProductMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreditLimitAsiaMoneyToProductMatching__r() {
        return creditLimitAsiaMoneyToProductMatching__r;
    }


    /**
     * Sets the creditLimitAsiaMoneyToProductMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creditLimitAsiaMoneyToProductMatching__r
     */
    public void setCreditLimitAsiaMoneyToProductMatching__r(com.sforce.soap.enterprise.QueryResult creditLimitAsiaMoneyToProductMatching__r) {
        this.creditLimitAsiaMoneyToProductMatching__r = creditLimitAsiaMoneyToProductMatching__r;
    }


    /**
     * Gets the creditLimitAsiaOseToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creditLimitAsiaOseToKyotenMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreditLimitAsiaOseToKyotenMatching__r() {
        return creditLimitAsiaOseToKyotenMatching__r;
    }


    /**
     * Sets the creditLimitAsiaOseToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creditLimitAsiaOseToKyotenMatching__r
     */
    public void setCreditLimitAsiaOseToKyotenMatching__r(com.sforce.soap.enterprise.QueryResult creditLimitAsiaOseToKyotenMatching__r) {
        this.creditLimitAsiaOseToKyotenMatching__r = creditLimitAsiaOseToKyotenMatching__r;
    }


    /**
     * Gets the creditLimitAsiaOseToProductMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creditLimitAsiaOseToProductMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreditLimitAsiaOseToProductMatching__r() {
        return creditLimitAsiaOseToProductMatching__r;
    }


    /**
     * Sets the creditLimitAsiaOseToProductMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creditLimitAsiaOseToProductMatching__r
     */
    public void setCreditLimitAsiaOseToProductMatching__r(com.sforce.soap.enterprise.QueryResult creditLimitAsiaOseToProductMatching__r) {
        this.creditLimitAsiaOseToProductMatching__r = creditLimitAsiaOseToProductMatching__r;
    }


    /**
     * Gets the creditLimitEuropeToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creditLimitEuropeToKyotenMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreditLimitEuropeToKyotenMatching__r() {
        return creditLimitEuropeToKyotenMatching__r;
    }


    /**
     * Sets the creditLimitEuropeToKyotenMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creditLimitEuropeToKyotenMatching__r
     */
    public void setCreditLimitEuropeToKyotenMatching__r(com.sforce.soap.enterprise.QueryResult creditLimitEuropeToKyotenMatching__r) {
        this.creditLimitEuropeToKyotenMatching__r = creditLimitEuropeToKyotenMatching__r;
    }


    /**
     * Gets the creditLimitEuropeToProductMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return creditLimitEuropeToProductMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreditLimitEuropeToProductMatching__r() {
        return creditLimitEuropeToProductMatching__r;
    }


    /**
     * Sets the creditLimitEuropeToProductMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param creditLimitEuropeToProductMatching__r
     */
    public void setCreditLimitEuropeToProductMatching__r(com.sforce.soap.enterprise.QueryResult creditLimitEuropeToProductMatching__r) {
        this.creditLimitEuropeToProductMatching__r = creditLimitEuropeToProductMatching__r;
    }


    /**
     * Gets the duplicateRecordItems value for this A006_MST_Shuyaku__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this A006_MST_Shuyaku__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the EIUToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @return EIUToCountryCode__r
     */
    public com.sforce.soap.enterprise.QueryResult getEIUToCountryCode__r() {
        return EIUToCountryCode__r;
    }


    /**
     * Sets the EIUToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @param EIUToCountryCode__r
     */
    public void setEIUToCountryCode__r(com.sforce.soap.enterprise.QueryResult EIUToCountryCode__r) {
        this.EIUToCountryCode__r = EIUToCountryCode__r;
    }


    /**
     * Gets the EMBIToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @return EMBIToCountryCode__r
     */
    public com.sforce.soap.enterprise.QueryResult getEMBIToCountryCode__r() {
        return EMBIToCountryCode__r;
    }


    /**
     * Sets the EMBIToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @param EMBIToCountryCode__r
     */
    public void setEMBIToCountryCode__r(com.sforce.soap.enterprise.QueryResult EMBIToCountryCode__r) {
        this.EMBIToCountryCode__r = EMBIToCountryCode__r;
    }


    /**
     * Gets the gaiginCountryToCountry__r value for this A006_MST_Shuyaku__c.
     * 
     * @return gaiginCountryToCountry__r
     */
    public com.sforce.soap.enterprise.QueryResult getGaiginCountryToCountry__r() {
        return gaiginCountryToCountry__r;
    }


    /**
     * Sets the gaiginCountryToCountry__r value for this A006_MST_Shuyaku__c.
     * 
     * @param gaiginCountryToCountry__r
     */
    public void setGaiginCountryToCountry__r(com.sforce.soap.enterprise.QueryResult gaiginCountryToCountry__r) {
        this.gaiginCountryToCountry__r = gaiginCountryToCountry__r;
    }


    /**
     * Gets the groupCreditAmounttoGroup__r value for this A006_MST_Shuyaku__c.
     * 
     * @return groupCreditAmounttoGroup__r
     */
    public com.sforce.soap.enterprise.QueryResult getGroupCreditAmounttoGroup__r() {
        return groupCreditAmounttoGroup__r;
    }


    /**
     * Sets the groupCreditAmounttoGroup__r value for this A006_MST_Shuyaku__c.
     * 
     * @param groupCreditAmounttoGroup__r
     */
    public void setGroupCreditAmounttoGroup__r(com.sforce.soap.enterprise.QueryResult groupCreditAmounttoGroup__r) {
        this.groupCreditAmounttoGroup__r = groupCreditAmounttoGroup__r;
    }


    /**
     * Gets the groupToCountry__r value for this A006_MST_Shuyaku__c.
     * 
     * @return groupToCountry__r
     */
    public com.sforce.soap.enterprise.QueryResult getGroupToCountry__r() {
        return groupToCountry__r;
    }


    /**
     * Sets the groupToCountry__r value for this A006_MST_Shuyaku__c.
     * 
     * @param groupToCountry__r
     */
    public void setGroupToCountry__r(com.sforce.soap.enterprise.QueryResult groupToCountry__r) {
        this.groupToCountry__r = groupToCountry__r;
    }


    /**
     * Gets the isDeleted value for this A006_MST_Shuyaku__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this A006_MST_Shuyaku__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the jitsuzanCIBToProductsMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @return jitsuzanCIBToProductsMatching__r
     */
    public com.sforce.soap.enterprise.QueryResult getJitsuzanCIBToProductsMatching__r() {
        return jitsuzanCIBToProductsMatching__r;
    }


    /**
     * Sets the jitsuzanCIBToProductsMatching__r value for this A006_MST_Shuyaku__c.
     * 
     * @param jitsuzanCIBToProductsMatching__r
     */
    public void setJitsuzanCIBToProductsMatching__r(com.sforce.soap.enterprise.QueryResult jitsuzanCIBToProductsMatching__r) {
        this.jitsuzanCIBToProductsMatching__r = jitsuzanCIBToProductsMatching__r;
    }


    /**
     * Gets the KOKUNAIForexToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @return KOKUNAIForexToProduct__r
     */
    public com.sforce.soap.enterprise.QueryResult getKOKUNAIForexToProduct__r() {
        return KOKUNAIForexToProduct__r;
    }


    /**
     * Sets the KOKUNAIForexToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @param KOKUNAIForexToProduct__r
     */
    public void setKOKUNAIForexToProduct__r(com.sforce.soap.enterprise.QueryResult KOKUNAIForexToProduct__r) {
        this.KOKUNAIForexToProduct__r = KOKUNAIForexToProduct__r;
    }


    /**
     * Gets the KOKUNAIGuaranteesToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @return KOKUNAIGuaranteesToProduct__r
     */
    public com.sforce.soap.enterprise.QueryResult getKOKUNAIGuaranteesToProduct__r() {
        return KOKUNAIGuaranteesToProduct__r;
    }


    /**
     * Sets the KOKUNAIGuaranteesToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @param KOKUNAIGuaranteesToProduct__r
     */
    public void setKOKUNAIGuaranteesToProduct__r(com.sforce.soap.enterprise.QueryResult KOKUNAIGuaranteesToProduct__r) {
        this.KOKUNAIGuaranteesToProduct__r = KOKUNAIGuaranteesToProduct__r;
    }


    /**
     * Gets the KOKUNAILoanCmtUndrnToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @return KOKUNAILoanCmtUndrnToProduct__r
     */
    public com.sforce.soap.enterprise.QueryResult getKOKUNAILoanCmtUndrnToProduct__r() {
        return KOKUNAILoanCmtUndrnToProduct__r;
    }


    /**
     * Sets the KOKUNAILoanCmtUndrnToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @param KOKUNAILoanCmtUndrnToProduct__r
     */
    public void setKOKUNAILoanCmtUndrnToProduct__r(com.sforce.soap.enterprise.QueryResult KOKUNAILoanCmtUndrnToProduct__r) {
        this.KOKUNAILoanCmtUndrnToProduct__r = KOKUNAILoanCmtUndrnToProduct__r;
    }


    /**
     * Gets the KOKUNAILoanToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @return KOKUNAILoanToProduct__r
     */
    public com.sforce.soap.enterprise.QueryResult getKOKUNAILoanToProduct__r() {
        return KOKUNAILoanToProduct__r;
    }


    /**
     * Sets the KOKUNAILoanToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @param KOKUNAILoanToProduct__r
     */
    public void setKOKUNAILoanToProduct__r(com.sforce.soap.enterprise.QueryResult KOKUNAILoanToProduct__r) {
        this.KOKUNAILoanToProduct__r = KOKUNAILoanToProduct__r;
    }


    /**
     * Gets the kyotenMatchingToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @return kyotenMatchingToKyoten__r
     */
    public com.sforce.soap.enterprise.QueryResult getKyotenMatchingToKyoten__r() {
        return kyotenMatchingToKyoten__r;
    }


    /**
     * Sets the kyotenMatchingToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @param kyotenMatchingToKyoten__r
     */
    public void setKyotenMatchingToKyoten__r(com.sforce.soap.enterprise.QueryResult kyotenMatchingToKyoten__r) {
        this.kyotenMatchingToKyoten__r = kyotenMatchingToKyoten__r;
    }


    /**
     * Gets the lastModifiedBy value for this A006_MST_Shuyaku__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this A006_MST_Shuyaku__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this A006_MST_Shuyaku__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this A006_MST_Shuyaku__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this A006_MST_Shuyaku__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this A006_MST_Shuyaku__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this A006_MST_Shuyaku__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this A006_MST_Shuyaku__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this A006_MST_Shuyaku__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this A006_MST_Shuyaku__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this A006_MST_Shuyaku__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this A006_MST_Shuyaku__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this A006_MST_Shuyaku__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this A006_MST_Shuyaku__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the owner value for this A006_MST_Shuyaku__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this A006_MST_Shuyaku__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this A006_MST_Shuyaku__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this A006_MST_Shuyaku__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this A006_MST_Shuyaku__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this A006_MST_Shuyaku__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this A006_MST_Shuyaku__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this A006_MST_Shuyaku__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the productsMatchingToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @return productsMatchingToProduct__r
     */
    public com.sforce.soap.enterprise.QueryResult getProductsMatchingToProduct__r() {
        return productsMatchingToProduct__r;
    }


    /**
     * Sets the productsMatchingToProduct__r value for this A006_MST_Shuyaku__c.
     * 
     * @param productsMatchingToProduct__r
     */
    public void setProductsMatchingToProduct__r(com.sforce.soap.enterprise.QueryResult productsMatchingToProduct__r) {
        this.productsMatchingToProduct__r = productsMatchingToProduct__r;
    }


    /**
     * Gets the relatedBranchToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @return relatedBranchToKyoten__r
     */
    public com.sforce.soap.enterprise.QueryResult getRelatedBranchToKyoten__r() {
        return relatedBranchToKyoten__r;
    }


    /**
     * Sets the relatedBranchToKyoten__r value for this A006_MST_Shuyaku__c.
     * 
     * @param relatedBranchToKyoten__r
     */
    public void setRelatedBranchToKyoten__r(com.sforce.soap.enterprise.QueryResult relatedBranchToKyoten__r) {
        this.relatedBranchToKyoten__r = relatedBranchToKyoten__r;
    }


    /**
     * Gets the systemModstamp value for this A006_MST_Shuyaku__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this A006_MST_Shuyaku__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the topicAssignments value for this A006_MST_Shuyaku__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this A006_MST_Shuyaku__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the tradeToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @return tradeToCountryCode__r
     */
    public com.sforce.soap.enterprise.QueryResult getTradeToCountryCode__r() {
        return tradeToCountryCode__r;
    }


    /**
     * Sets the tradeToCountryCode__r value for this A006_MST_Shuyaku__c.
     * 
     * @param tradeToCountryCode__r
     */
    public void setTradeToCountryCode__r(com.sforce.soap.enterprise.QueryResult tradeToCountryCode__r) {
        this.tradeToCountryCode__r = tradeToCountryCode__r;
    }


    /**
     * Gets the userRecordAccess value for this A006_MST_Shuyaku__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this A006_MST_Shuyaku__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof A006_MST_Shuyaku__c)) return false;
        A006_MST_Shuyaku__c other = (A006_MST_Shuyaku__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.allocationLimitToKyoten__r==null && other.getAllocationLimitToKyoten__r()==null) || 
             (this.allocationLimitToKyoten__r!=null &&
              this.allocationLimitToKyoten__r.equals(other.getAllocationLimitToKyoten__r()))) &&
            ((this.allocationLimitToProductAllocationLimit__r==null && other.getAllocationLimitToProductAllocationLimit__r()==null) || 
             (this.allocationLimitToProductAllocationLimit__r!=null &&
              this.allocationLimitToProductAllocationLimit__r.equals(other.getAllocationLimitToProductAllocationLimit__r()))) &&
            ((this.allocationRateLimitToRate__r==null && other.getAllocationRateLimitToRate__r()==null) || 
             (this.allocationRateLimitToRate__r!=null &&
              this.allocationRateLimitToRate__r.equals(other.getAllocationRateLimitToRate__r()))) &&
            ((this.allocationRateUsageToRate__r==null && other.getAllocationRateUsageToRate__r()==null) || 
             (this.allocationRateUsageToRate__r!=null &&
              this.allocationRateUsageToRate__r.equals(other.getAllocationRateUsageToRate__r()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.bankCreditAmountToshuyaku__r==null && other.getBankCreditAmountToshuyaku__r()==null) || 
             (this.bankCreditAmountToshuyaku__r!=null &&
              this.bankCreditAmountToshuyaku__r.equals(other.getBankCreditAmountToshuyaku__r()))) &&
            ((this.bankToCountry__r==null && other.getBankToCountry__r()==null) || 
             (this.bankToCountry__r!=null &&
              this.bankToCountry__r.equals(other.getBankToCountry__r()))) &&
            ((this.bankToGroup__r==null && other.getBankToGroup__r()==null) || 
             (this.bankToGroup__r!=null &&
              this.bankToGroup__r.equals(other.getBankToGroup__r()))) &&
            ((this.branchToParentBranch__r==null && other.getBranchToParentBranch__r()==null) || 
             (this.branchToParentBranch__r!=null &&
              this.branchToParentBranch__r.equals(other.getBranchToParentBranch__r()))) &&
            ((this.CIBToKyotenMatching__r==null && other.getCIBToKyotenMatching__r()==null) || 
             (this.CIBToKyotenMatching__r!=null &&
              this.CIBToKyotenMatching__r.equals(other.getCIBToKyotenMatching__r()))) &&
            ((this.CLimitExToCountryCode__r==null && other.getCLimitExToCountryCode__r()==null) || 
             (this.CLimitExToCountryCode__r!=null &&
              this.CLimitExToCountryCode__r.equals(other.getCLimitExToCountryCode__r()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.commonToKyoten__r==null && other.getCommonToKyoten__r()==null) || 
             (this.commonToKyoten__r!=null &&
              this.commonToKyoten__r.equals(other.getCommonToKyoten__r()))) &&
            ((this.commonToProduct__r==null && other.getCommonToProduct__r()==null) || 
             (this.commonToProduct__r!=null &&
              this.commonToProduct__r.equals(other.getCommonToProduct__r()))) &&
            ((this.commonToRate__r==null && other.getCommonToRate__r()==null) || 
             (this.commonToRate__r!=null &&
              this.commonToRate__r.equals(other.getCommonToRate__r()))) &&
            ((this.countryMatchingToCountry__r==null && other.getCountryMatchingToCountry__r()==null) || 
             (this.countryMatchingToCountry__r!=null &&
              this.countryMatchingToCountry__r.equals(other.getCountryMatchingToCountry__r()))) &&
            ((this.countryToCountryCode__r==null && other.getCountryToCountryCode__r()==null) || 
             (this.countryToCountryCode__r!=null &&
              this.countryToCountryCode__r.equals(other.getCountryToCountryCode__r()))) &&
            ((this.countryToRegion__r==null && other.getCountryToRegion__r()==null) || 
             (this.countryToRegion__r!=null &&
              this.countryToRegion__r.equals(other.getCountryToRegion__r()))) &&
            ((this.creJitsuToKyoten__r==null && other.getCreJitsuToKyoten__r()==null) || 
             (this.creJitsuToKyoten__r!=null &&
              this.creJitsuToKyoten__r.equals(other.getCreJitsuToKyoten__r()))) &&
            ((this.creJitsuToProduct__r==null && other.getCreJitsuToProduct__r()==null) || 
             (this.creJitsuToProduct__r!=null &&
              this.creJitsuToProduct__r.equals(other.getCreJitsuToProduct__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.creditLimitAmericaToKyotenMatching__r==null && other.getCreditLimitAmericaToKyotenMatching__r()==null) || 
             (this.creditLimitAmericaToKyotenMatching__r!=null &&
              this.creditLimitAmericaToKyotenMatching__r.equals(other.getCreditLimitAmericaToKyotenMatching__r()))) &&
            ((this.creditLimitAmericaToProductMatching__r==null && other.getCreditLimitAmericaToProductMatching__r()==null) || 
             (this.creditLimitAmericaToProductMatching__r!=null &&
              this.creditLimitAmericaToProductMatching__r.equals(other.getCreditLimitAmericaToProductMatching__r()))) &&
            ((this.creditLimitAsiaMoneyToKyotenMatching__r==null && other.getCreditLimitAsiaMoneyToKyotenMatching__r()==null) || 
             (this.creditLimitAsiaMoneyToKyotenMatching__r!=null &&
              this.creditLimitAsiaMoneyToKyotenMatching__r.equals(other.getCreditLimitAsiaMoneyToKyotenMatching__r()))) &&
            ((this.creditLimitAsiaMoneyToProductMatching__r==null && other.getCreditLimitAsiaMoneyToProductMatching__r()==null) || 
             (this.creditLimitAsiaMoneyToProductMatching__r!=null &&
              this.creditLimitAsiaMoneyToProductMatching__r.equals(other.getCreditLimitAsiaMoneyToProductMatching__r()))) &&
            ((this.creditLimitAsiaOseToKyotenMatching__r==null && other.getCreditLimitAsiaOseToKyotenMatching__r()==null) || 
             (this.creditLimitAsiaOseToKyotenMatching__r!=null &&
              this.creditLimitAsiaOseToKyotenMatching__r.equals(other.getCreditLimitAsiaOseToKyotenMatching__r()))) &&
            ((this.creditLimitAsiaOseToProductMatching__r==null && other.getCreditLimitAsiaOseToProductMatching__r()==null) || 
             (this.creditLimitAsiaOseToProductMatching__r!=null &&
              this.creditLimitAsiaOseToProductMatching__r.equals(other.getCreditLimitAsiaOseToProductMatching__r()))) &&
            ((this.creditLimitEuropeToKyotenMatching__r==null && other.getCreditLimitEuropeToKyotenMatching__r()==null) || 
             (this.creditLimitEuropeToKyotenMatching__r!=null &&
              this.creditLimitEuropeToKyotenMatching__r.equals(other.getCreditLimitEuropeToKyotenMatching__r()))) &&
            ((this.creditLimitEuropeToProductMatching__r==null && other.getCreditLimitEuropeToProductMatching__r()==null) || 
             (this.creditLimitEuropeToProductMatching__r!=null &&
              this.creditLimitEuropeToProductMatching__r.equals(other.getCreditLimitEuropeToProductMatching__r()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.EIUToCountryCode__r==null && other.getEIUToCountryCode__r()==null) || 
             (this.EIUToCountryCode__r!=null &&
              this.EIUToCountryCode__r.equals(other.getEIUToCountryCode__r()))) &&
            ((this.EMBIToCountryCode__r==null && other.getEMBIToCountryCode__r()==null) || 
             (this.EMBIToCountryCode__r!=null &&
              this.EMBIToCountryCode__r.equals(other.getEMBIToCountryCode__r()))) &&
            ((this.gaiginCountryToCountry__r==null && other.getGaiginCountryToCountry__r()==null) || 
             (this.gaiginCountryToCountry__r!=null &&
              this.gaiginCountryToCountry__r.equals(other.getGaiginCountryToCountry__r()))) &&
            ((this.groupCreditAmounttoGroup__r==null && other.getGroupCreditAmounttoGroup__r()==null) || 
             (this.groupCreditAmounttoGroup__r!=null &&
              this.groupCreditAmounttoGroup__r.equals(other.getGroupCreditAmounttoGroup__r()))) &&
            ((this.groupToCountry__r==null && other.getGroupToCountry__r()==null) || 
             (this.groupToCountry__r!=null &&
              this.groupToCountry__r.equals(other.getGroupToCountry__r()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.jitsuzanCIBToProductsMatching__r==null && other.getJitsuzanCIBToProductsMatching__r()==null) || 
             (this.jitsuzanCIBToProductsMatching__r!=null &&
              this.jitsuzanCIBToProductsMatching__r.equals(other.getJitsuzanCIBToProductsMatching__r()))) &&
            ((this.KOKUNAIForexToProduct__r==null && other.getKOKUNAIForexToProduct__r()==null) || 
             (this.KOKUNAIForexToProduct__r!=null &&
              this.KOKUNAIForexToProduct__r.equals(other.getKOKUNAIForexToProduct__r()))) &&
            ((this.KOKUNAIGuaranteesToProduct__r==null && other.getKOKUNAIGuaranteesToProduct__r()==null) || 
             (this.KOKUNAIGuaranteesToProduct__r!=null &&
              this.KOKUNAIGuaranteesToProduct__r.equals(other.getKOKUNAIGuaranteesToProduct__r()))) &&
            ((this.KOKUNAILoanCmtUndrnToProduct__r==null && other.getKOKUNAILoanCmtUndrnToProduct__r()==null) || 
             (this.KOKUNAILoanCmtUndrnToProduct__r!=null &&
              this.KOKUNAILoanCmtUndrnToProduct__r.equals(other.getKOKUNAILoanCmtUndrnToProduct__r()))) &&
            ((this.KOKUNAILoanToProduct__r==null && other.getKOKUNAILoanToProduct__r()==null) || 
             (this.KOKUNAILoanToProduct__r!=null &&
              this.KOKUNAILoanToProduct__r.equals(other.getKOKUNAILoanToProduct__r()))) &&
            ((this.kyotenMatchingToKyoten__r==null && other.getKyotenMatchingToKyoten__r()==null) || 
             (this.kyotenMatchingToKyoten__r!=null &&
              this.kyotenMatchingToKyoten__r.equals(other.getKyotenMatchingToKyoten__r()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.productsMatchingToProduct__r==null && other.getProductsMatchingToProduct__r()==null) || 
             (this.productsMatchingToProduct__r!=null &&
              this.productsMatchingToProduct__r.equals(other.getProductsMatchingToProduct__r()))) &&
            ((this.relatedBranchToKyoten__r==null && other.getRelatedBranchToKyoten__r()==null) || 
             (this.relatedBranchToKyoten__r!=null &&
              this.relatedBranchToKyoten__r.equals(other.getRelatedBranchToKyoten__r()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.tradeToCountryCode__r==null && other.getTradeToCountryCode__r()==null) || 
             (this.tradeToCountryCode__r!=null &&
              this.tradeToCountryCode__r.equals(other.getTradeToCountryCode__r()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAllocationLimitToKyoten__r() != null) {
            _hashCode += getAllocationLimitToKyoten__r().hashCode();
        }
        if (getAllocationLimitToProductAllocationLimit__r() != null) {
            _hashCode += getAllocationLimitToProductAllocationLimit__r().hashCode();
        }
        if (getAllocationRateLimitToRate__r() != null) {
            _hashCode += getAllocationRateLimitToRate__r().hashCode();
        }
        if (getAllocationRateUsageToRate__r() != null) {
            _hashCode += getAllocationRateUsageToRate__r().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBankCreditAmountToshuyaku__r() != null) {
            _hashCode += getBankCreditAmountToshuyaku__r().hashCode();
        }
        if (getBankToCountry__r() != null) {
            _hashCode += getBankToCountry__r().hashCode();
        }
        if (getBankToGroup__r() != null) {
            _hashCode += getBankToGroup__r().hashCode();
        }
        if (getBranchToParentBranch__r() != null) {
            _hashCode += getBranchToParentBranch__r().hashCode();
        }
        if (getCIBToKyotenMatching__r() != null) {
            _hashCode += getCIBToKyotenMatching__r().hashCode();
        }
        if (getCLimitExToCountryCode__r() != null) {
            _hashCode += getCLimitExToCountryCode__r().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCommonToKyoten__r() != null) {
            _hashCode += getCommonToKyoten__r().hashCode();
        }
        if (getCommonToProduct__r() != null) {
            _hashCode += getCommonToProduct__r().hashCode();
        }
        if (getCommonToRate__r() != null) {
            _hashCode += getCommonToRate__r().hashCode();
        }
        if (getCountryMatchingToCountry__r() != null) {
            _hashCode += getCountryMatchingToCountry__r().hashCode();
        }
        if (getCountryToCountryCode__r() != null) {
            _hashCode += getCountryToCountryCode__r().hashCode();
        }
        if (getCountryToRegion__r() != null) {
            _hashCode += getCountryToRegion__r().hashCode();
        }
        if (getCreJitsuToKyoten__r() != null) {
            _hashCode += getCreJitsuToKyoten__r().hashCode();
        }
        if (getCreJitsuToProduct__r() != null) {
            _hashCode += getCreJitsuToProduct__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getCreditLimitAmericaToKyotenMatching__r() != null) {
            _hashCode += getCreditLimitAmericaToKyotenMatching__r().hashCode();
        }
        if (getCreditLimitAmericaToProductMatching__r() != null) {
            _hashCode += getCreditLimitAmericaToProductMatching__r().hashCode();
        }
        if (getCreditLimitAsiaMoneyToKyotenMatching__r() != null) {
            _hashCode += getCreditLimitAsiaMoneyToKyotenMatching__r().hashCode();
        }
        if (getCreditLimitAsiaMoneyToProductMatching__r() != null) {
            _hashCode += getCreditLimitAsiaMoneyToProductMatching__r().hashCode();
        }
        if (getCreditLimitAsiaOseToKyotenMatching__r() != null) {
            _hashCode += getCreditLimitAsiaOseToKyotenMatching__r().hashCode();
        }
        if (getCreditLimitAsiaOseToProductMatching__r() != null) {
            _hashCode += getCreditLimitAsiaOseToProductMatching__r().hashCode();
        }
        if (getCreditLimitEuropeToKyotenMatching__r() != null) {
            _hashCode += getCreditLimitEuropeToKyotenMatching__r().hashCode();
        }
        if (getCreditLimitEuropeToProductMatching__r() != null) {
            _hashCode += getCreditLimitEuropeToProductMatching__r().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getEIUToCountryCode__r() != null) {
            _hashCode += getEIUToCountryCode__r().hashCode();
        }
        if (getEMBIToCountryCode__r() != null) {
            _hashCode += getEMBIToCountryCode__r().hashCode();
        }
        if (getGaiginCountryToCountry__r() != null) {
            _hashCode += getGaiginCountryToCountry__r().hashCode();
        }
        if (getGroupCreditAmounttoGroup__r() != null) {
            _hashCode += getGroupCreditAmounttoGroup__r().hashCode();
        }
        if (getGroupToCountry__r() != null) {
            _hashCode += getGroupToCountry__r().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getJitsuzanCIBToProductsMatching__r() != null) {
            _hashCode += getJitsuzanCIBToProductsMatching__r().hashCode();
        }
        if (getKOKUNAIForexToProduct__r() != null) {
            _hashCode += getKOKUNAIForexToProduct__r().hashCode();
        }
        if (getKOKUNAIGuaranteesToProduct__r() != null) {
            _hashCode += getKOKUNAIGuaranteesToProduct__r().hashCode();
        }
        if (getKOKUNAILoanCmtUndrnToProduct__r() != null) {
            _hashCode += getKOKUNAILoanCmtUndrnToProduct__r().hashCode();
        }
        if (getKOKUNAILoanToProduct__r() != null) {
            _hashCode += getKOKUNAILoanToProduct__r().hashCode();
        }
        if (getKyotenMatchingToKyoten__r() != null) {
            _hashCode += getKyotenMatchingToKyoten__r().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getProductsMatchingToProduct__r() != null) {
            _hashCode += getProductsMatchingToProduct__r().hashCode();
        }
        if (getRelatedBranchToKyoten__r() != null) {
            _hashCode += getRelatedBranchToKyoten__r().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getTradeToCountryCode__r() != null) {
            _hashCode += getTradeToCountryCode__r().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(A006_MST_Shuyaku__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A006_MST_Shuyaku__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allocationLimitToKyoten__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AllocationLimitToKyoten__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allocationLimitToProductAllocationLimit__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AllocationLimitToProductAllocationLimit__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allocationRateLimitToRate__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AllocationRateLimitToRate__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allocationRateUsageToRate__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AllocationRateUsageToRate__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankCreditAmountToshuyaku__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BankCreditAmountToshuyaku__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankToCountry__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BankToCountry__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankToGroup__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BankToGroup__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("branchToParentBranch__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BranchToParentBranch__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIBToKyotenMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIBToKyotenMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLimitExToCountryCode__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CLimitExToCountryCode__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commonToKyoten__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CommonToKyoten__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commonToProduct__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CommonToProduct__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("commonToRate__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CommonToRate__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("countryMatchingToCountry__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CountryMatchingToCountry__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("countryToCountryCode__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CountryToCountryCode__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("countryToRegion__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CountryToRegion__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creJitsuToKyoten__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreJitsuToKyoten__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creJitsuToProduct__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreJitsuToProduct__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimitAmericaToKyotenMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreditLimitAmericaToKyotenMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimitAmericaToProductMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreditLimitAmericaToProductMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimitAsiaMoneyToKyotenMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreditLimitAsiaMoneyToKyotenMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimitAsiaMoneyToProductMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreditLimitAsiaMoneyToProductMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimitAsiaOseToKyotenMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreditLimitAsiaOseToKyotenMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimitAsiaOseToProductMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreditLimitAsiaOseToProductMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimitEuropeToKyotenMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreditLimitEuropeToKyotenMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimitEuropeToProductMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreditLimitEuropeToProductMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EIUToCountryCode__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EIUToCountryCode__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EMBIToCountryCode__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EMBIToCountryCode__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gaiginCountryToCountry__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GaiginCountryToCountry__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupCreditAmounttoGroup__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GroupCreditAmounttoGroup__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupToCountry__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GroupToCountry__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jitsuzanCIBToProductsMatching__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JitsuzanCIBToProductsMatching__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKUNAIForexToProduct__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKUNAIForexToProduct__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKUNAIGuaranteesToProduct__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKUNAIGuaranteesToProduct__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKUNAILoanCmtUndrnToProduct__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKUNAILoanCmtUndrnToProduct__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKUNAILoanToProduct__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKUNAILoanToProduct__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("kyotenMatchingToKyoten__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KyotenMatchingToKyoten__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productsMatchingToProduct__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProductsMatchingToProduct__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relatedBranchToKyoten__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RelatedBranchToKyoten__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tradeToCountryCode__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TradeToCountryCode__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
