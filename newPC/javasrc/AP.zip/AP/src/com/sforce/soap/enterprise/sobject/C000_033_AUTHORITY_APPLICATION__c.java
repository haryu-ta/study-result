/**
 * C000_033_AUTHORITY_APPLICATION__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C000_033_AUTHORITY_APPLICATION__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String APPLICATIONID__c;

    private java.lang.String APPLINAME__c;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;

    private java.lang.String BUTENBANGOU__c;

    private com.sforce.soap.enterprise.QueryResult c000_OPERATIONCONTROL_02__r;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.util.Calendar d_APPLY_DATE__c;

    private java.lang.String d_APPLY_USER__c;

    private com.sforce.soap.enterprise.sobject.User d_APPLY_USER__r;

    private java.util.Calendar d_APPROVE_DATE__c;

    private java.lang.String d_APPROVE_USER__c;

    private com.sforce.soap.enterprise.sobject.User d_APPROVE_USER__r;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private java.lang.String GROUP_NAME__c;

    private java.lang.String GROUP_NO__c;

    private java.lang.String HONBU_EIGYOKYOTENFLG__c;

    private java.util.Calendar i_APPLY_DATE__c;

    private java.lang.String i_APPLY_USER__c;

    private com.sforce.soap.enterprise.sobject.User i_APPLY_USER__r;

    private java.util.Calendar i_APPROVE_DATE__c;

    private java.lang.String i_APPROVE_USER__c;

    private com.sforce.soap.enterprise.sobject.User i_APPROVE_USER__r;

    private java.lang.Boolean isDeleted;

    private java.lang.String KACD__c;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private java.lang.Double PRIORITY_LV__c;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String STATUS__c;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private java.lang.String USER_SFID__c;

    private com.sforce.soap.enterprise.sobject.User USER_SFID__r;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    private java.lang.String YAKUSHOKU_LV__c;

    public C000_033_AUTHORITY_APPLICATION__c() {
    }

    public C000_033_AUTHORITY_APPLICATION__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String APPLICATIONID__c,
           java.lang.String APPLINAME__c,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c,
           java.lang.String BUTENBANGOU__c,
           com.sforce.soap.enterprise.QueryResult c000_OPERATIONCONTROL_02__r,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.util.Calendar d_APPLY_DATE__c,
           java.lang.String d_APPLY_USER__c,
           com.sforce.soap.enterprise.sobject.User d_APPLY_USER__r,
           java.util.Calendar d_APPROVE_DATE__c,
           java.lang.String d_APPROVE_USER__c,
           com.sforce.soap.enterprise.sobject.User d_APPROVE_USER__r,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           java.lang.String GROUP_NAME__c,
           java.lang.String GROUP_NO__c,
           java.lang.String HONBU_EIGYOKYOTENFLG__c,
           java.util.Calendar i_APPLY_DATE__c,
           java.lang.String i_APPLY_USER__c,
           com.sforce.soap.enterprise.sobject.User i_APPLY_USER__r,
           java.util.Calendar i_APPROVE_DATE__c,
           java.lang.String i_APPROVE_USER__c,
           com.sforce.soap.enterprise.sobject.User i_APPROVE_USER__r,
           java.lang.Boolean isDeleted,
           java.lang.String KACD__c,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           java.lang.Double PRIORITY_LV__c,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String STATUS__c,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           java.lang.String USER_SFID__c,
           com.sforce.soap.enterprise.sobject.User USER_SFID__r,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess,
           java.lang.String YAKUSHOKU_LV__c) {
        super(
            fieldsToNull,
            id);
        this.APPLICATIONID__c = APPLICATIONID__c;
        this.APPLINAME__c = APPLINAME__c;
        this.attachments = attachments;
        this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c = BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;
        this.BUTENBANGOU__c = BUTENBANGOU__c;
        this.c000_OPERATIONCONTROL_02__r = c000_OPERATIONCONTROL_02__r;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.d_APPLY_DATE__c = d_APPLY_DATE__c;
        this.d_APPLY_USER__c = d_APPLY_USER__c;
        this.d_APPLY_USER__r = d_APPLY_USER__r;
        this.d_APPROVE_DATE__c = d_APPROVE_DATE__c;
        this.d_APPROVE_USER__c = d_APPROVE_USER__c;
        this.d_APPROVE_USER__r = d_APPROVE_USER__r;
        this.duplicateRecordItems = duplicateRecordItems;
        this.GROUP_NAME__c = GROUP_NAME__c;
        this.GROUP_NO__c = GROUP_NO__c;
        this.HONBU_EIGYOKYOTENFLG__c = HONBU_EIGYOKYOTENFLG__c;
        this.i_APPLY_DATE__c = i_APPLY_DATE__c;
        this.i_APPLY_USER__c = i_APPLY_USER__c;
        this.i_APPLY_USER__r = i_APPLY_USER__r;
        this.i_APPROVE_DATE__c = i_APPROVE_DATE__c;
        this.i_APPROVE_USER__c = i_APPROVE_USER__c;
        this.i_APPROVE_USER__r = i_APPROVE_USER__r;
        this.isDeleted = isDeleted;
        this.KACD__c = KACD__c;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.owner = owner;
        this.ownerId = ownerId;
        this.PRIORITY_LV__c = PRIORITY_LV__c;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.STATUS__c = STATUS__c;
        this.systemModstamp = systemModstamp;
        this.topicAssignments = topicAssignments;
        this.USER_SFID__c = USER_SFID__c;
        this.USER_SFID__r = USER_SFID__r;
        this.userRecordAccess = userRecordAccess;
        this.YAKUSHOKU_LV__c = YAKUSHOKU_LV__c;
    }


    /**
     * Gets the APPLICATIONID__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return APPLICATIONID__c
     */
    public java.lang.String getAPPLICATIONID__c() {
        return APPLICATIONID__c;
    }


    /**
     * Sets the APPLICATIONID__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param APPLICATIONID__c
     */
    public void setAPPLICATIONID__c(java.lang.String APPLICATIONID__c) {
        this.APPLICATIONID__c = APPLICATIONID__c;
    }


    /**
     * Gets the APPLINAME__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return APPLINAME__c
     */
    public java.lang.String getAPPLINAME__c() {
        return APPLINAME__c;
    }


    /**
     * Sets the APPLINAME__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param APPLINAME__c
     */
    public void setAPPLINAME__c(java.lang.String APPLINAME__c) {
        this.APPLINAME__c = APPLINAME__c;
    }


    /**
     * Gets the attachments value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c
     */
    public java.lang.String getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c() {
        return BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;
    }


    /**
     * Sets the BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c
     */
    public void setBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c(java.lang.String BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c) {
        this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c = BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;
    }


    /**
     * Gets the BUTENBANGOU__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return BUTENBANGOU__c
     */
    public java.lang.String getBUTENBANGOU__c() {
        return BUTENBANGOU__c;
    }


    /**
     * Sets the BUTENBANGOU__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param BUTENBANGOU__c
     */
    public void setBUTENBANGOU__c(java.lang.String BUTENBANGOU__c) {
        this.BUTENBANGOU__c = BUTENBANGOU__c;
    }


    /**
     * Gets the c000_OPERATIONCONTROL_02__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return c000_OPERATIONCONTROL_02__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_OPERATIONCONTROL_02__r() {
        return c000_OPERATIONCONTROL_02__r;
    }


    /**
     * Sets the c000_OPERATIONCONTROL_02__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param c000_OPERATIONCONTROL_02__r
     */
    public void setC000_OPERATIONCONTROL_02__r(com.sforce.soap.enterprise.QueryResult c000_OPERATIONCONTROL_02__r) {
        this.c000_OPERATIONCONTROL_02__r = c000_OPERATIONCONTROL_02__r;
    }


    /**
     * Gets the combinedAttachments value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the d_APPLY_DATE__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return d_APPLY_DATE__c
     */
    public java.util.Calendar getD_APPLY_DATE__c() {
        return d_APPLY_DATE__c;
    }


    /**
     * Sets the d_APPLY_DATE__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param d_APPLY_DATE__c
     */
    public void setD_APPLY_DATE__c(java.util.Calendar d_APPLY_DATE__c) {
        this.d_APPLY_DATE__c = d_APPLY_DATE__c;
    }


    /**
     * Gets the d_APPLY_USER__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return d_APPLY_USER__c
     */
    public java.lang.String getD_APPLY_USER__c() {
        return d_APPLY_USER__c;
    }


    /**
     * Sets the d_APPLY_USER__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param d_APPLY_USER__c
     */
    public void setD_APPLY_USER__c(java.lang.String d_APPLY_USER__c) {
        this.d_APPLY_USER__c = d_APPLY_USER__c;
    }


    /**
     * Gets the d_APPLY_USER__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return d_APPLY_USER__r
     */
    public com.sforce.soap.enterprise.sobject.User getD_APPLY_USER__r() {
        return d_APPLY_USER__r;
    }


    /**
     * Sets the d_APPLY_USER__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param d_APPLY_USER__r
     */
    public void setD_APPLY_USER__r(com.sforce.soap.enterprise.sobject.User d_APPLY_USER__r) {
        this.d_APPLY_USER__r = d_APPLY_USER__r;
    }


    /**
     * Gets the d_APPROVE_DATE__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return d_APPROVE_DATE__c
     */
    public java.util.Calendar getD_APPROVE_DATE__c() {
        return d_APPROVE_DATE__c;
    }


    /**
     * Sets the d_APPROVE_DATE__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param d_APPROVE_DATE__c
     */
    public void setD_APPROVE_DATE__c(java.util.Calendar d_APPROVE_DATE__c) {
        this.d_APPROVE_DATE__c = d_APPROVE_DATE__c;
    }


    /**
     * Gets the d_APPROVE_USER__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return d_APPROVE_USER__c
     */
    public java.lang.String getD_APPROVE_USER__c() {
        return d_APPROVE_USER__c;
    }


    /**
     * Sets the d_APPROVE_USER__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param d_APPROVE_USER__c
     */
    public void setD_APPROVE_USER__c(java.lang.String d_APPROVE_USER__c) {
        this.d_APPROVE_USER__c = d_APPROVE_USER__c;
    }


    /**
     * Gets the d_APPROVE_USER__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return d_APPROVE_USER__r
     */
    public com.sforce.soap.enterprise.sobject.User getD_APPROVE_USER__r() {
        return d_APPROVE_USER__r;
    }


    /**
     * Sets the d_APPROVE_USER__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param d_APPROVE_USER__r
     */
    public void setD_APPROVE_USER__r(com.sforce.soap.enterprise.sobject.User d_APPROVE_USER__r) {
        this.d_APPROVE_USER__r = d_APPROVE_USER__r;
    }


    /**
     * Gets the duplicateRecordItems value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the GROUP_NAME__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return GROUP_NAME__c
     */
    public java.lang.String getGROUP_NAME__c() {
        return GROUP_NAME__c;
    }


    /**
     * Sets the GROUP_NAME__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param GROUP_NAME__c
     */
    public void setGROUP_NAME__c(java.lang.String GROUP_NAME__c) {
        this.GROUP_NAME__c = GROUP_NAME__c;
    }


    /**
     * Gets the GROUP_NO__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return GROUP_NO__c
     */
    public java.lang.String getGROUP_NO__c() {
        return GROUP_NO__c;
    }


    /**
     * Sets the GROUP_NO__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param GROUP_NO__c
     */
    public void setGROUP_NO__c(java.lang.String GROUP_NO__c) {
        this.GROUP_NO__c = GROUP_NO__c;
    }


    /**
     * Gets the HONBU_EIGYOKYOTENFLG__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return HONBU_EIGYOKYOTENFLG__c
     */
    public java.lang.String getHONBU_EIGYOKYOTENFLG__c() {
        return HONBU_EIGYOKYOTENFLG__c;
    }


    /**
     * Sets the HONBU_EIGYOKYOTENFLG__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param HONBU_EIGYOKYOTENFLG__c
     */
    public void setHONBU_EIGYOKYOTENFLG__c(java.lang.String HONBU_EIGYOKYOTENFLG__c) {
        this.HONBU_EIGYOKYOTENFLG__c = HONBU_EIGYOKYOTENFLG__c;
    }


    /**
     * Gets the i_APPLY_DATE__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return i_APPLY_DATE__c
     */
    public java.util.Calendar getI_APPLY_DATE__c() {
        return i_APPLY_DATE__c;
    }


    /**
     * Sets the i_APPLY_DATE__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param i_APPLY_DATE__c
     */
    public void setI_APPLY_DATE__c(java.util.Calendar i_APPLY_DATE__c) {
        this.i_APPLY_DATE__c = i_APPLY_DATE__c;
    }


    /**
     * Gets the i_APPLY_USER__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return i_APPLY_USER__c
     */
    public java.lang.String getI_APPLY_USER__c() {
        return i_APPLY_USER__c;
    }


    /**
     * Sets the i_APPLY_USER__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param i_APPLY_USER__c
     */
    public void setI_APPLY_USER__c(java.lang.String i_APPLY_USER__c) {
        this.i_APPLY_USER__c = i_APPLY_USER__c;
    }


    /**
     * Gets the i_APPLY_USER__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return i_APPLY_USER__r
     */
    public com.sforce.soap.enterprise.sobject.User getI_APPLY_USER__r() {
        return i_APPLY_USER__r;
    }


    /**
     * Sets the i_APPLY_USER__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param i_APPLY_USER__r
     */
    public void setI_APPLY_USER__r(com.sforce.soap.enterprise.sobject.User i_APPLY_USER__r) {
        this.i_APPLY_USER__r = i_APPLY_USER__r;
    }


    /**
     * Gets the i_APPROVE_DATE__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return i_APPROVE_DATE__c
     */
    public java.util.Calendar getI_APPROVE_DATE__c() {
        return i_APPROVE_DATE__c;
    }


    /**
     * Sets the i_APPROVE_DATE__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param i_APPROVE_DATE__c
     */
    public void setI_APPROVE_DATE__c(java.util.Calendar i_APPROVE_DATE__c) {
        this.i_APPROVE_DATE__c = i_APPROVE_DATE__c;
    }


    /**
     * Gets the i_APPROVE_USER__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return i_APPROVE_USER__c
     */
    public java.lang.String getI_APPROVE_USER__c() {
        return i_APPROVE_USER__c;
    }


    /**
     * Sets the i_APPROVE_USER__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param i_APPROVE_USER__c
     */
    public void setI_APPROVE_USER__c(java.lang.String i_APPROVE_USER__c) {
        this.i_APPROVE_USER__c = i_APPROVE_USER__c;
    }


    /**
     * Gets the i_APPROVE_USER__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return i_APPROVE_USER__r
     */
    public com.sforce.soap.enterprise.sobject.User getI_APPROVE_USER__r() {
        return i_APPROVE_USER__r;
    }


    /**
     * Sets the i_APPROVE_USER__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param i_APPROVE_USER__r
     */
    public void setI_APPROVE_USER__r(com.sforce.soap.enterprise.sobject.User i_APPROVE_USER__r) {
        this.i_APPROVE_USER__r = i_APPROVE_USER__r;
    }


    /**
     * Gets the isDeleted value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the KACD__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return KACD__c
     */
    public java.lang.String getKACD__c() {
        return KACD__c;
    }


    /**
     * Sets the KACD__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param KACD__c
     */
    public void setKACD__c(java.lang.String KACD__c) {
        this.KACD__c = KACD__c;
    }


    /**
     * Gets the lastModifiedBy value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the owner value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the PRIORITY_LV__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return PRIORITY_LV__c
     */
    public java.lang.Double getPRIORITY_LV__c() {
        return PRIORITY_LV__c;
    }


    /**
     * Sets the PRIORITY_LV__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param PRIORITY_LV__c
     */
    public void setPRIORITY_LV__c(java.lang.Double PRIORITY_LV__c) {
        this.PRIORITY_LV__c = PRIORITY_LV__c;
    }


    /**
     * Gets the processInstances value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the STATUS__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return STATUS__c
     */
    public java.lang.String getSTATUS__c() {
        return STATUS__c;
    }


    /**
     * Sets the STATUS__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param STATUS__c
     */
    public void setSTATUS__c(java.lang.String STATUS__c) {
        this.STATUS__c = STATUS__c;
    }


    /**
     * Gets the systemModstamp value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the topicAssignments value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the USER_SFID__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return USER_SFID__c
     */
    public java.lang.String getUSER_SFID__c() {
        return USER_SFID__c;
    }


    /**
     * Sets the USER_SFID__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param USER_SFID__c
     */
    public void setUSER_SFID__c(java.lang.String USER_SFID__c) {
        this.USER_SFID__c = USER_SFID__c;
    }


    /**
     * Gets the USER_SFID__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return USER_SFID__r
     */
    public com.sforce.soap.enterprise.sobject.User getUSER_SFID__r() {
        return USER_SFID__r;
    }


    /**
     * Sets the USER_SFID__r value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param USER_SFID__r
     */
    public void setUSER_SFID__r(com.sforce.soap.enterprise.sobject.User USER_SFID__r) {
        this.USER_SFID__r = USER_SFID__r;
    }


    /**
     * Gets the userRecordAccess value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the YAKUSHOKU_LV__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @return YAKUSHOKU_LV__c
     */
    public java.lang.String getYAKUSHOKU_LV__c() {
        return YAKUSHOKU_LV__c;
    }


    /**
     * Sets the YAKUSHOKU_LV__c value for this C000_033_AUTHORITY_APPLICATION__c.
     * 
     * @param YAKUSHOKU_LV__c
     */
    public void setYAKUSHOKU_LV__c(java.lang.String YAKUSHOKU_LV__c) {
        this.YAKUSHOKU_LV__c = YAKUSHOKU_LV__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C000_033_AUTHORITY_APPLICATION__c)) return false;
        C000_033_AUTHORITY_APPLICATION__c other = (C000_033_AUTHORITY_APPLICATION__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.APPLICATIONID__c==null && other.getAPPLICATIONID__c()==null) || 
             (this.APPLICATIONID__c!=null &&
              this.APPLICATIONID__c.equals(other.getAPPLICATIONID__c()))) &&
            ((this.APPLINAME__c==null && other.getAPPLINAME__c()==null) || 
             (this.APPLINAME__c!=null &&
              this.APPLINAME__c.equals(other.getAPPLINAME__c()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c==null && other.getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c()==null) || 
             (this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c!=null &&
              this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c.equals(other.getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c()))) &&
            ((this.BUTENBANGOU__c==null && other.getBUTENBANGOU__c()==null) || 
             (this.BUTENBANGOU__c!=null &&
              this.BUTENBANGOU__c.equals(other.getBUTENBANGOU__c()))) &&
            ((this.c000_OPERATIONCONTROL_02__r==null && other.getC000_OPERATIONCONTROL_02__r()==null) || 
             (this.c000_OPERATIONCONTROL_02__r!=null &&
              this.c000_OPERATIONCONTROL_02__r.equals(other.getC000_OPERATIONCONTROL_02__r()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.d_APPLY_DATE__c==null && other.getD_APPLY_DATE__c()==null) || 
             (this.d_APPLY_DATE__c!=null &&
              this.d_APPLY_DATE__c.equals(other.getD_APPLY_DATE__c()))) &&
            ((this.d_APPLY_USER__c==null && other.getD_APPLY_USER__c()==null) || 
             (this.d_APPLY_USER__c!=null &&
              this.d_APPLY_USER__c.equals(other.getD_APPLY_USER__c()))) &&
            ((this.d_APPLY_USER__r==null && other.getD_APPLY_USER__r()==null) || 
             (this.d_APPLY_USER__r!=null &&
              this.d_APPLY_USER__r.equals(other.getD_APPLY_USER__r()))) &&
            ((this.d_APPROVE_DATE__c==null && other.getD_APPROVE_DATE__c()==null) || 
             (this.d_APPROVE_DATE__c!=null &&
              this.d_APPROVE_DATE__c.equals(other.getD_APPROVE_DATE__c()))) &&
            ((this.d_APPROVE_USER__c==null && other.getD_APPROVE_USER__c()==null) || 
             (this.d_APPROVE_USER__c!=null &&
              this.d_APPROVE_USER__c.equals(other.getD_APPROVE_USER__c()))) &&
            ((this.d_APPROVE_USER__r==null && other.getD_APPROVE_USER__r()==null) || 
             (this.d_APPROVE_USER__r!=null &&
              this.d_APPROVE_USER__r.equals(other.getD_APPROVE_USER__r()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.GROUP_NAME__c==null && other.getGROUP_NAME__c()==null) || 
             (this.GROUP_NAME__c!=null &&
              this.GROUP_NAME__c.equals(other.getGROUP_NAME__c()))) &&
            ((this.GROUP_NO__c==null && other.getGROUP_NO__c()==null) || 
             (this.GROUP_NO__c!=null &&
              this.GROUP_NO__c.equals(other.getGROUP_NO__c()))) &&
            ((this.HONBU_EIGYOKYOTENFLG__c==null && other.getHONBU_EIGYOKYOTENFLG__c()==null) || 
             (this.HONBU_EIGYOKYOTENFLG__c!=null &&
              this.HONBU_EIGYOKYOTENFLG__c.equals(other.getHONBU_EIGYOKYOTENFLG__c()))) &&
            ((this.i_APPLY_DATE__c==null && other.getI_APPLY_DATE__c()==null) || 
             (this.i_APPLY_DATE__c!=null &&
              this.i_APPLY_DATE__c.equals(other.getI_APPLY_DATE__c()))) &&
            ((this.i_APPLY_USER__c==null && other.getI_APPLY_USER__c()==null) || 
             (this.i_APPLY_USER__c!=null &&
              this.i_APPLY_USER__c.equals(other.getI_APPLY_USER__c()))) &&
            ((this.i_APPLY_USER__r==null && other.getI_APPLY_USER__r()==null) || 
             (this.i_APPLY_USER__r!=null &&
              this.i_APPLY_USER__r.equals(other.getI_APPLY_USER__r()))) &&
            ((this.i_APPROVE_DATE__c==null && other.getI_APPROVE_DATE__c()==null) || 
             (this.i_APPROVE_DATE__c!=null &&
              this.i_APPROVE_DATE__c.equals(other.getI_APPROVE_DATE__c()))) &&
            ((this.i_APPROVE_USER__c==null && other.getI_APPROVE_USER__c()==null) || 
             (this.i_APPROVE_USER__c!=null &&
              this.i_APPROVE_USER__c.equals(other.getI_APPROVE_USER__c()))) &&
            ((this.i_APPROVE_USER__r==null && other.getI_APPROVE_USER__r()==null) || 
             (this.i_APPROVE_USER__r!=null &&
              this.i_APPROVE_USER__r.equals(other.getI_APPROVE_USER__r()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.KACD__c==null && other.getKACD__c()==null) || 
             (this.KACD__c!=null &&
              this.KACD__c.equals(other.getKACD__c()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.PRIORITY_LV__c==null && other.getPRIORITY_LV__c()==null) || 
             (this.PRIORITY_LV__c!=null &&
              this.PRIORITY_LV__c.equals(other.getPRIORITY_LV__c()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.STATUS__c==null && other.getSTATUS__c()==null) || 
             (this.STATUS__c!=null &&
              this.STATUS__c.equals(other.getSTATUS__c()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.USER_SFID__c==null && other.getUSER_SFID__c()==null) || 
             (this.USER_SFID__c!=null &&
              this.USER_SFID__c.equals(other.getUSER_SFID__c()))) &&
            ((this.USER_SFID__r==null && other.getUSER_SFID__r()==null) || 
             (this.USER_SFID__r!=null &&
              this.USER_SFID__r.equals(other.getUSER_SFID__r()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess()))) &&
            ((this.YAKUSHOKU_LV__c==null && other.getYAKUSHOKU_LV__c()==null) || 
             (this.YAKUSHOKU_LV__c!=null &&
              this.YAKUSHOKU_LV__c.equals(other.getYAKUSHOKU_LV__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAPPLICATIONID__c() != null) {
            _hashCode += getAPPLICATIONID__c().hashCode();
        }
        if (getAPPLINAME__c() != null) {
            _hashCode += getAPPLINAME__c().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c() != null) {
            _hashCode += getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c().hashCode();
        }
        if (getBUTENBANGOU__c() != null) {
            _hashCode += getBUTENBANGOU__c().hashCode();
        }
        if (getC000_OPERATIONCONTROL_02__r() != null) {
            _hashCode += getC000_OPERATIONCONTROL_02__r().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getD_APPLY_DATE__c() != null) {
            _hashCode += getD_APPLY_DATE__c().hashCode();
        }
        if (getD_APPLY_USER__c() != null) {
            _hashCode += getD_APPLY_USER__c().hashCode();
        }
        if (getD_APPLY_USER__r() != null) {
            _hashCode += getD_APPLY_USER__r().hashCode();
        }
        if (getD_APPROVE_DATE__c() != null) {
            _hashCode += getD_APPROVE_DATE__c().hashCode();
        }
        if (getD_APPROVE_USER__c() != null) {
            _hashCode += getD_APPROVE_USER__c().hashCode();
        }
        if (getD_APPROVE_USER__r() != null) {
            _hashCode += getD_APPROVE_USER__r().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getGROUP_NAME__c() != null) {
            _hashCode += getGROUP_NAME__c().hashCode();
        }
        if (getGROUP_NO__c() != null) {
            _hashCode += getGROUP_NO__c().hashCode();
        }
        if (getHONBU_EIGYOKYOTENFLG__c() != null) {
            _hashCode += getHONBU_EIGYOKYOTENFLG__c().hashCode();
        }
        if (getI_APPLY_DATE__c() != null) {
            _hashCode += getI_APPLY_DATE__c().hashCode();
        }
        if (getI_APPLY_USER__c() != null) {
            _hashCode += getI_APPLY_USER__c().hashCode();
        }
        if (getI_APPLY_USER__r() != null) {
            _hashCode += getI_APPLY_USER__r().hashCode();
        }
        if (getI_APPROVE_DATE__c() != null) {
            _hashCode += getI_APPROVE_DATE__c().hashCode();
        }
        if (getI_APPROVE_USER__c() != null) {
            _hashCode += getI_APPROVE_USER__c().hashCode();
        }
        if (getI_APPROVE_USER__r() != null) {
            _hashCode += getI_APPROVE_USER__r().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getKACD__c() != null) {
            _hashCode += getKACD__c().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getPRIORITY_LV__c() != null) {
            _hashCode += getPRIORITY_LV__c().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSTATUS__c() != null) {
            _hashCode += getSTATUS__c().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUSER_SFID__c() != null) {
            _hashCode += getUSER_SFID__c().hashCode();
        }
        if (getUSER_SFID__r() != null) {
            _hashCode += getUSER_SFID__r().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        if (getYAKUSHOKU_LV__c() != null) {
            _hashCode += getYAKUSHOKU_LV__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C000_033_AUTHORITY_APPLICATION__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_033_AUTHORITY_APPLICATION__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("APPLICATIONID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "APPLICATIONID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("APPLINAME__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "APPLINAME__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_OPERATIONCONTROL_02__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_OPERATIONCONTROL_02__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d_APPLY_DATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D_APPLY_DATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d_APPLY_USER__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D_APPLY_USER__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d_APPLY_USER__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D_APPLY_USER__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d_APPROVE_DATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D_APPROVE_DATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d_APPROVE_USER__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D_APPROVE_USER__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d_APPROVE_USER__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D_APPROVE_USER__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GROUP_NAME__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GROUP_NAME__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GROUP_NO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GROUP_NO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HONBU_EIGYOKYOTENFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HONBU_EIGYOKYOTENFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("i_APPLY_DATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "I_APPLY_DATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("i_APPLY_USER__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "I_APPLY_USER__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("i_APPLY_USER__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "I_APPLY_USER__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("i_APPROVE_DATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "I_APPROVE_DATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("i_APPROVE_USER__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "I_APPROVE_USER__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("i_APPROVE_USER__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "I_APPROVE_USER__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KACD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KACD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PRIORITY_LV__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PRIORITY_LV__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "STATUS__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("USER_SFID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "USER_SFID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("USER_SFID__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "USER_SFID__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YAKUSHOKU_LV__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YAKUSHOKU_LV__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
