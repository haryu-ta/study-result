/**
 * AMWFBNK__AppliRole__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class AMWFBNK__AppliRole__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.Boolean AMWFBNK__Accepting2_Accept__c;

    private java.lang.Boolean AMWFBNK__Accepting2_Notify__c;

    private java.lang.String AMWFBNK__AppliCode__c;

    private java.lang.String AMWFBNK__AppliName__c;

    private java.lang.Boolean AMWFBNK__Approved_Notify__c;

    private java.lang.Boolean AMWFBNK__Approved_Withdraw__c;

    private java.lang.Boolean AMWFBNK__Available__c;

    private java.lang.String AMWFBNK__FlowCode__c;

    private java.lang.Double AMWFBNK__MemberCount__c;

    private com.sforce.soap.enterprise.QueryResult AMWFBNK__Members__r;

    private java.lang.Boolean AMWFBNK__New_Notify__c;

    private java.lang.Boolean AMWFBNK__New_Send__c;

    private java.lang.Boolean AMWFBNK__Rejected_Notify__c;

    private java.lang.Boolean AMWFBNK__Sending1_Approve__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check10__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check11__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check12__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check13__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check14__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check15__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check16__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check17__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check18__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check19__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check1__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check20__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check2__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check3__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check4__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check5__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check6__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check7__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check8__c;

    private java.lang.Boolean AMWFBNK__Sending1_Check9__c;

    private java.lang.Boolean AMWFBNK__Sending1_DlgtApprove__c;

    private java.lang.Boolean AMWFBNK__Sending1_DlgtReject__c;

    private java.lang.Boolean AMWFBNK__Sending1_Notify__c;

    private java.lang.Boolean AMWFBNK__Sending1_Passback__c;

    private java.lang.Boolean AMWFBNK__Sending1_Reject__c;

    private java.lang.Boolean AMWFBNK__Sending1_Send__c;

    private java.lang.Boolean AMWFBNK__Sending2_Approve__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check10__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check11__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check12__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check13__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check14__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check15__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check16__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check17__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check18__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check19__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check1__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check20__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check2__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check3__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check4__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check5__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check6__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check7__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check8__c;

    private java.lang.Boolean AMWFBNK__Sending2_Check9__c;

    private java.lang.Boolean AMWFBNK__Sending2_DlgtApprove__c;

    private java.lang.Boolean AMWFBNK__Sending2_DlgtReject__c;

    private java.lang.Boolean AMWFBNK__Sending2_Notify__c;

    private java.lang.Boolean AMWFBNK__Sending2_Passback__c;

    private java.lang.Boolean AMWFBNK__Sending2_Reject__c;

    private java.lang.Boolean AMWFBNK__Sending2_Send__c;

    private java.lang.String AMWFBNK__Type__c;

    private java.lang.Boolean AMWFBNK__Withdrawing_Notify__c;

    private java.lang.Boolean AMWFBNK__Withdrawn_Notify__c;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    public AMWFBNK__AppliRole__c() {
    }

    public AMWFBNK__AppliRole__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.Boolean AMWFBNK__Accepting2_Accept__c,
           java.lang.Boolean AMWFBNK__Accepting2_Notify__c,
           java.lang.String AMWFBNK__AppliCode__c,
           java.lang.String AMWFBNK__AppliName__c,
           java.lang.Boolean AMWFBNK__Approved_Notify__c,
           java.lang.Boolean AMWFBNK__Approved_Withdraw__c,
           java.lang.Boolean AMWFBNK__Available__c,
           java.lang.String AMWFBNK__FlowCode__c,
           java.lang.Double AMWFBNK__MemberCount__c,
           com.sforce.soap.enterprise.QueryResult AMWFBNK__Members__r,
           java.lang.Boolean AMWFBNK__New_Notify__c,
           java.lang.Boolean AMWFBNK__New_Send__c,
           java.lang.Boolean AMWFBNK__Rejected_Notify__c,
           java.lang.Boolean AMWFBNK__Sending1_Approve__c,
           java.lang.Boolean AMWFBNK__Sending1_Check10__c,
           java.lang.Boolean AMWFBNK__Sending1_Check11__c,
           java.lang.Boolean AMWFBNK__Sending1_Check12__c,
           java.lang.Boolean AMWFBNK__Sending1_Check13__c,
           java.lang.Boolean AMWFBNK__Sending1_Check14__c,
           java.lang.Boolean AMWFBNK__Sending1_Check15__c,
           java.lang.Boolean AMWFBNK__Sending1_Check16__c,
           java.lang.Boolean AMWFBNK__Sending1_Check17__c,
           java.lang.Boolean AMWFBNK__Sending1_Check18__c,
           java.lang.Boolean AMWFBNK__Sending1_Check19__c,
           java.lang.Boolean AMWFBNK__Sending1_Check1__c,
           java.lang.Boolean AMWFBNK__Sending1_Check20__c,
           java.lang.Boolean AMWFBNK__Sending1_Check2__c,
           java.lang.Boolean AMWFBNK__Sending1_Check3__c,
           java.lang.Boolean AMWFBNK__Sending1_Check4__c,
           java.lang.Boolean AMWFBNK__Sending1_Check5__c,
           java.lang.Boolean AMWFBNK__Sending1_Check6__c,
           java.lang.Boolean AMWFBNK__Sending1_Check7__c,
           java.lang.Boolean AMWFBNK__Sending1_Check8__c,
           java.lang.Boolean AMWFBNK__Sending1_Check9__c,
           java.lang.Boolean AMWFBNK__Sending1_DlgtApprove__c,
           java.lang.Boolean AMWFBNK__Sending1_DlgtReject__c,
           java.lang.Boolean AMWFBNK__Sending1_Notify__c,
           java.lang.Boolean AMWFBNK__Sending1_Passback__c,
           java.lang.Boolean AMWFBNK__Sending1_Reject__c,
           java.lang.Boolean AMWFBNK__Sending1_Send__c,
           java.lang.Boolean AMWFBNK__Sending2_Approve__c,
           java.lang.Boolean AMWFBNK__Sending2_Check10__c,
           java.lang.Boolean AMWFBNK__Sending2_Check11__c,
           java.lang.Boolean AMWFBNK__Sending2_Check12__c,
           java.lang.Boolean AMWFBNK__Sending2_Check13__c,
           java.lang.Boolean AMWFBNK__Sending2_Check14__c,
           java.lang.Boolean AMWFBNK__Sending2_Check15__c,
           java.lang.Boolean AMWFBNK__Sending2_Check16__c,
           java.lang.Boolean AMWFBNK__Sending2_Check17__c,
           java.lang.Boolean AMWFBNK__Sending2_Check18__c,
           java.lang.Boolean AMWFBNK__Sending2_Check19__c,
           java.lang.Boolean AMWFBNK__Sending2_Check1__c,
           java.lang.Boolean AMWFBNK__Sending2_Check20__c,
           java.lang.Boolean AMWFBNK__Sending2_Check2__c,
           java.lang.Boolean AMWFBNK__Sending2_Check3__c,
           java.lang.Boolean AMWFBNK__Sending2_Check4__c,
           java.lang.Boolean AMWFBNK__Sending2_Check5__c,
           java.lang.Boolean AMWFBNK__Sending2_Check6__c,
           java.lang.Boolean AMWFBNK__Sending2_Check7__c,
           java.lang.Boolean AMWFBNK__Sending2_Check8__c,
           java.lang.Boolean AMWFBNK__Sending2_Check9__c,
           java.lang.Boolean AMWFBNK__Sending2_DlgtApprove__c,
           java.lang.Boolean AMWFBNK__Sending2_DlgtReject__c,
           java.lang.Boolean AMWFBNK__Sending2_Notify__c,
           java.lang.Boolean AMWFBNK__Sending2_Passback__c,
           java.lang.Boolean AMWFBNK__Sending2_Reject__c,
           java.lang.Boolean AMWFBNK__Sending2_Send__c,
           java.lang.String AMWFBNK__Type__c,
           java.lang.Boolean AMWFBNK__Withdrawing_Notify__c,
           java.lang.Boolean AMWFBNK__Withdrawn_Notify__c,
           com.sforce.soap.enterprise.QueryResult attachments,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        super(
            fieldsToNull,
            id);
        this.AMWFBNK__Accepting2_Accept__c = AMWFBNK__Accepting2_Accept__c;
        this.AMWFBNK__Accepting2_Notify__c = AMWFBNK__Accepting2_Notify__c;
        this.AMWFBNK__AppliCode__c = AMWFBNK__AppliCode__c;
        this.AMWFBNK__AppliName__c = AMWFBNK__AppliName__c;
        this.AMWFBNK__Approved_Notify__c = AMWFBNK__Approved_Notify__c;
        this.AMWFBNK__Approved_Withdraw__c = AMWFBNK__Approved_Withdraw__c;
        this.AMWFBNK__Available__c = AMWFBNK__Available__c;
        this.AMWFBNK__FlowCode__c = AMWFBNK__FlowCode__c;
        this.AMWFBNK__MemberCount__c = AMWFBNK__MemberCount__c;
        this.AMWFBNK__Members__r = AMWFBNK__Members__r;
        this.AMWFBNK__New_Notify__c = AMWFBNK__New_Notify__c;
        this.AMWFBNK__New_Send__c = AMWFBNK__New_Send__c;
        this.AMWFBNK__Rejected_Notify__c = AMWFBNK__Rejected_Notify__c;
        this.AMWFBNK__Sending1_Approve__c = AMWFBNK__Sending1_Approve__c;
        this.AMWFBNK__Sending1_Check10__c = AMWFBNK__Sending1_Check10__c;
        this.AMWFBNK__Sending1_Check11__c = AMWFBNK__Sending1_Check11__c;
        this.AMWFBNK__Sending1_Check12__c = AMWFBNK__Sending1_Check12__c;
        this.AMWFBNK__Sending1_Check13__c = AMWFBNK__Sending1_Check13__c;
        this.AMWFBNK__Sending1_Check14__c = AMWFBNK__Sending1_Check14__c;
        this.AMWFBNK__Sending1_Check15__c = AMWFBNK__Sending1_Check15__c;
        this.AMWFBNK__Sending1_Check16__c = AMWFBNK__Sending1_Check16__c;
        this.AMWFBNK__Sending1_Check17__c = AMWFBNK__Sending1_Check17__c;
        this.AMWFBNK__Sending1_Check18__c = AMWFBNK__Sending1_Check18__c;
        this.AMWFBNK__Sending1_Check19__c = AMWFBNK__Sending1_Check19__c;
        this.AMWFBNK__Sending1_Check1__c = AMWFBNK__Sending1_Check1__c;
        this.AMWFBNK__Sending1_Check20__c = AMWFBNK__Sending1_Check20__c;
        this.AMWFBNK__Sending1_Check2__c = AMWFBNK__Sending1_Check2__c;
        this.AMWFBNK__Sending1_Check3__c = AMWFBNK__Sending1_Check3__c;
        this.AMWFBNK__Sending1_Check4__c = AMWFBNK__Sending1_Check4__c;
        this.AMWFBNK__Sending1_Check5__c = AMWFBNK__Sending1_Check5__c;
        this.AMWFBNK__Sending1_Check6__c = AMWFBNK__Sending1_Check6__c;
        this.AMWFBNK__Sending1_Check7__c = AMWFBNK__Sending1_Check7__c;
        this.AMWFBNK__Sending1_Check8__c = AMWFBNK__Sending1_Check8__c;
        this.AMWFBNK__Sending1_Check9__c = AMWFBNK__Sending1_Check9__c;
        this.AMWFBNK__Sending1_DlgtApprove__c = AMWFBNK__Sending1_DlgtApprove__c;
        this.AMWFBNK__Sending1_DlgtReject__c = AMWFBNK__Sending1_DlgtReject__c;
        this.AMWFBNK__Sending1_Notify__c = AMWFBNK__Sending1_Notify__c;
        this.AMWFBNK__Sending1_Passback__c = AMWFBNK__Sending1_Passback__c;
        this.AMWFBNK__Sending1_Reject__c = AMWFBNK__Sending1_Reject__c;
        this.AMWFBNK__Sending1_Send__c = AMWFBNK__Sending1_Send__c;
        this.AMWFBNK__Sending2_Approve__c = AMWFBNK__Sending2_Approve__c;
        this.AMWFBNK__Sending2_Check10__c = AMWFBNK__Sending2_Check10__c;
        this.AMWFBNK__Sending2_Check11__c = AMWFBNK__Sending2_Check11__c;
        this.AMWFBNK__Sending2_Check12__c = AMWFBNK__Sending2_Check12__c;
        this.AMWFBNK__Sending2_Check13__c = AMWFBNK__Sending2_Check13__c;
        this.AMWFBNK__Sending2_Check14__c = AMWFBNK__Sending2_Check14__c;
        this.AMWFBNK__Sending2_Check15__c = AMWFBNK__Sending2_Check15__c;
        this.AMWFBNK__Sending2_Check16__c = AMWFBNK__Sending2_Check16__c;
        this.AMWFBNK__Sending2_Check17__c = AMWFBNK__Sending2_Check17__c;
        this.AMWFBNK__Sending2_Check18__c = AMWFBNK__Sending2_Check18__c;
        this.AMWFBNK__Sending2_Check19__c = AMWFBNK__Sending2_Check19__c;
        this.AMWFBNK__Sending2_Check1__c = AMWFBNK__Sending2_Check1__c;
        this.AMWFBNK__Sending2_Check20__c = AMWFBNK__Sending2_Check20__c;
        this.AMWFBNK__Sending2_Check2__c = AMWFBNK__Sending2_Check2__c;
        this.AMWFBNK__Sending2_Check3__c = AMWFBNK__Sending2_Check3__c;
        this.AMWFBNK__Sending2_Check4__c = AMWFBNK__Sending2_Check4__c;
        this.AMWFBNK__Sending2_Check5__c = AMWFBNK__Sending2_Check5__c;
        this.AMWFBNK__Sending2_Check6__c = AMWFBNK__Sending2_Check6__c;
        this.AMWFBNK__Sending2_Check7__c = AMWFBNK__Sending2_Check7__c;
        this.AMWFBNK__Sending2_Check8__c = AMWFBNK__Sending2_Check8__c;
        this.AMWFBNK__Sending2_Check9__c = AMWFBNK__Sending2_Check9__c;
        this.AMWFBNK__Sending2_DlgtApprove__c = AMWFBNK__Sending2_DlgtApprove__c;
        this.AMWFBNK__Sending2_DlgtReject__c = AMWFBNK__Sending2_DlgtReject__c;
        this.AMWFBNK__Sending2_Notify__c = AMWFBNK__Sending2_Notify__c;
        this.AMWFBNK__Sending2_Passback__c = AMWFBNK__Sending2_Passback__c;
        this.AMWFBNK__Sending2_Reject__c = AMWFBNK__Sending2_Reject__c;
        this.AMWFBNK__Sending2_Send__c = AMWFBNK__Sending2_Send__c;
        this.AMWFBNK__Type__c = AMWFBNK__Type__c;
        this.AMWFBNK__Withdrawing_Notify__c = AMWFBNK__Withdrawing_Notify__c;
        this.AMWFBNK__Withdrawn_Notify__c = AMWFBNK__Withdrawn_Notify__c;
        this.attachments = attachments;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.duplicateRecordItems = duplicateRecordItems;
        this.isDeleted = isDeleted;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.systemModstamp = systemModstamp;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the AMWFBNK__Accepting2_Accept__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Accepting2_Accept__c
     */
    public java.lang.Boolean getAMWFBNK__Accepting2_Accept__c() {
        return AMWFBNK__Accepting2_Accept__c;
    }


    /**
     * Sets the AMWFBNK__Accepting2_Accept__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Accepting2_Accept__c
     */
    public void setAMWFBNK__Accepting2_Accept__c(java.lang.Boolean AMWFBNK__Accepting2_Accept__c) {
        this.AMWFBNK__Accepting2_Accept__c = AMWFBNK__Accepting2_Accept__c;
    }


    /**
     * Gets the AMWFBNK__Accepting2_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Accepting2_Notify__c
     */
    public java.lang.Boolean getAMWFBNK__Accepting2_Notify__c() {
        return AMWFBNK__Accepting2_Notify__c;
    }


    /**
     * Sets the AMWFBNK__Accepting2_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Accepting2_Notify__c
     */
    public void setAMWFBNK__Accepting2_Notify__c(java.lang.Boolean AMWFBNK__Accepting2_Notify__c) {
        this.AMWFBNK__Accepting2_Notify__c = AMWFBNK__Accepting2_Notify__c;
    }


    /**
     * Gets the AMWFBNK__AppliCode__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__AppliCode__c
     */
    public java.lang.String getAMWFBNK__AppliCode__c() {
        return AMWFBNK__AppliCode__c;
    }


    /**
     * Sets the AMWFBNK__AppliCode__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__AppliCode__c
     */
    public void setAMWFBNK__AppliCode__c(java.lang.String AMWFBNK__AppliCode__c) {
        this.AMWFBNK__AppliCode__c = AMWFBNK__AppliCode__c;
    }


    /**
     * Gets the AMWFBNK__AppliName__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__AppliName__c
     */
    public java.lang.String getAMWFBNK__AppliName__c() {
        return AMWFBNK__AppliName__c;
    }


    /**
     * Sets the AMWFBNK__AppliName__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__AppliName__c
     */
    public void setAMWFBNK__AppliName__c(java.lang.String AMWFBNK__AppliName__c) {
        this.AMWFBNK__AppliName__c = AMWFBNK__AppliName__c;
    }


    /**
     * Gets the AMWFBNK__Approved_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Approved_Notify__c
     */
    public java.lang.Boolean getAMWFBNK__Approved_Notify__c() {
        return AMWFBNK__Approved_Notify__c;
    }


    /**
     * Sets the AMWFBNK__Approved_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Approved_Notify__c
     */
    public void setAMWFBNK__Approved_Notify__c(java.lang.Boolean AMWFBNK__Approved_Notify__c) {
        this.AMWFBNK__Approved_Notify__c = AMWFBNK__Approved_Notify__c;
    }


    /**
     * Gets the AMWFBNK__Approved_Withdraw__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Approved_Withdraw__c
     */
    public java.lang.Boolean getAMWFBNK__Approved_Withdraw__c() {
        return AMWFBNK__Approved_Withdraw__c;
    }


    /**
     * Sets the AMWFBNK__Approved_Withdraw__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Approved_Withdraw__c
     */
    public void setAMWFBNK__Approved_Withdraw__c(java.lang.Boolean AMWFBNK__Approved_Withdraw__c) {
        this.AMWFBNK__Approved_Withdraw__c = AMWFBNK__Approved_Withdraw__c;
    }


    /**
     * Gets the AMWFBNK__Available__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Available__c
     */
    public java.lang.Boolean getAMWFBNK__Available__c() {
        return AMWFBNK__Available__c;
    }


    /**
     * Sets the AMWFBNK__Available__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Available__c
     */
    public void setAMWFBNK__Available__c(java.lang.Boolean AMWFBNK__Available__c) {
        this.AMWFBNK__Available__c = AMWFBNK__Available__c;
    }


    /**
     * Gets the AMWFBNK__FlowCode__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__FlowCode__c
     */
    public java.lang.String getAMWFBNK__FlowCode__c() {
        return AMWFBNK__FlowCode__c;
    }


    /**
     * Sets the AMWFBNK__FlowCode__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__FlowCode__c
     */
    public void setAMWFBNK__FlowCode__c(java.lang.String AMWFBNK__FlowCode__c) {
        this.AMWFBNK__FlowCode__c = AMWFBNK__FlowCode__c;
    }


    /**
     * Gets the AMWFBNK__MemberCount__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__MemberCount__c
     */
    public java.lang.Double getAMWFBNK__MemberCount__c() {
        return AMWFBNK__MemberCount__c;
    }


    /**
     * Sets the AMWFBNK__MemberCount__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__MemberCount__c
     */
    public void setAMWFBNK__MemberCount__c(java.lang.Double AMWFBNK__MemberCount__c) {
        this.AMWFBNK__MemberCount__c = AMWFBNK__MemberCount__c;
    }


    /**
     * Gets the AMWFBNK__Members__r value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Members__r
     */
    public com.sforce.soap.enterprise.QueryResult getAMWFBNK__Members__r() {
        return AMWFBNK__Members__r;
    }


    /**
     * Sets the AMWFBNK__Members__r value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Members__r
     */
    public void setAMWFBNK__Members__r(com.sforce.soap.enterprise.QueryResult AMWFBNK__Members__r) {
        this.AMWFBNK__Members__r = AMWFBNK__Members__r;
    }


    /**
     * Gets the AMWFBNK__New_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__New_Notify__c
     */
    public java.lang.Boolean getAMWFBNK__New_Notify__c() {
        return AMWFBNK__New_Notify__c;
    }


    /**
     * Sets the AMWFBNK__New_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__New_Notify__c
     */
    public void setAMWFBNK__New_Notify__c(java.lang.Boolean AMWFBNK__New_Notify__c) {
        this.AMWFBNK__New_Notify__c = AMWFBNK__New_Notify__c;
    }


    /**
     * Gets the AMWFBNK__New_Send__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__New_Send__c
     */
    public java.lang.Boolean getAMWFBNK__New_Send__c() {
        return AMWFBNK__New_Send__c;
    }


    /**
     * Sets the AMWFBNK__New_Send__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__New_Send__c
     */
    public void setAMWFBNK__New_Send__c(java.lang.Boolean AMWFBNK__New_Send__c) {
        this.AMWFBNK__New_Send__c = AMWFBNK__New_Send__c;
    }


    /**
     * Gets the AMWFBNK__Rejected_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Rejected_Notify__c
     */
    public java.lang.Boolean getAMWFBNK__Rejected_Notify__c() {
        return AMWFBNK__Rejected_Notify__c;
    }


    /**
     * Sets the AMWFBNK__Rejected_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Rejected_Notify__c
     */
    public void setAMWFBNK__Rejected_Notify__c(java.lang.Boolean AMWFBNK__Rejected_Notify__c) {
        this.AMWFBNK__Rejected_Notify__c = AMWFBNK__Rejected_Notify__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Approve__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Approve__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Approve__c() {
        return AMWFBNK__Sending1_Approve__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Approve__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Approve__c
     */
    public void setAMWFBNK__Sending1_Approve__c(java.lang.Boolean AMWFBNK__Sending1_Approve__c) {
        this.AMWFBNK__Sending1_Approve__c = AMWFBNK__Sending1_Approve__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check10__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check10__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check10__c() {
        return AMWFBNK__Sending1_Check10__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check10__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check10__c
     */
    public void setAMWFBNK__Sending1_Check10__c(java.lang.Boolean AMWFBNK__Sending1_Check10__c) {
        this.AMWFBNK__Sending1_Check10__c = AMWFBNK__Sending1_Check10__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check11__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check11__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check11__c() {
        return AMWFBNK__Sending1_Check11__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check11__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check11__c
     */
    public void setAMWFBNK__Sending1_Check11__c(java.lang.Boolean AMWFBNK__Sending1_Check11__c) {
        this.AMWFBNK__Sending1_Check11__c = AMWFBNK__Sending1_Check11__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check12__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check12__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check12__c() {
        return AMWFBNK__Sending1_Check12__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check12__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check12__c
     */
    public void setAMWFBNK__Sending1_Check12__c(java.lang.Boolean AMWFBNK__Sending1_Check12__c) {
        this.AMWFBNK__Sending1_Check12__c = AMWFBNK__Sending1_Check12__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check13__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check13__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check13__c() {
        return AMWFBNK__Sending1_Check13__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check13__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check13__c
     */
    public void setAMWFBNK__Sending1_Check13__c(java.lang.Boolean AMWFBNK__Sending1_Check13__c) {
        this.AMWFBNK__Sending1_Check13__c = AMWFBNK__Sending1_Check13__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check14__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check14__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check14__c() {
        return AMWFBNK__Sending1_Check14__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check14__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check14__c
     */
    public void setAMWFBNK__Sending1_Check14__c(java.lang.Boolean AMWFBNK__Sending1_Check14__c) {
        this.AMWFBNK__Sending1_Check14__c = AMWFBNK__Sending1_Check14__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check15__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check15__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check15__c() {
        return AMWFBNK__Sending1_Check15__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check15__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check15__c
     */
    public void setAMWFBNK__Sending1_Check15__c(java.lang.Boolean AMWFBNK__Sending1_Check15__c) {
        this.AMWFBNK__Sending1_Check15__c = AMWFBNK__Sending1_Check15__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check16__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check16__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check16__c() {
        return AMWFBNK__Sending1_Check16__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check16__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check16__c
     */
    public void setAMWFBNK__Sending1_Check16__c(java.lang.Boolean AMWFBNK__Sending1_Check16__c) {
        this.AMWFBNK__Sending1_Check16__c = AMWFBNK__Sending1_Check16__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check17__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check17__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check17__c() {
        return AMWFBNK__Sending1_Check17__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check17__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check17__c
     */
    public void setAMWFBNK__Sending1_Check17__c(java.lang.Boolean AMWFBNK__Sending1_Check17__c) {
        this.AMWFBNK__Sending1_Check17__c = AMWFBNK__Sending1_Check17__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check18__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check18__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check18__c() {
        return AMWFBNK__Sending1_Check18__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check18__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check18__c
     */
    public void setAMWFBNK__Sending1_Check18__c(java.lang.Boolean AMWFBNK__Sending1_Check18__c) {
        this.AMWFBNK__Sending1_Check18__c = AMWFBNK__Sending1_Check18__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check19__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check19__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check19__c() {
        return AMWFBNK__Sending1_Check19__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check19__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check19__c
     */
    public void setAMWFBNK__Sending1_Check19__c(java.lang.Boolean AMWFBNK__Sending1_Check19__c) {
        this.AMWFBNK__Sending1_Check19__c = AMWFBNK__Sending1_Check19__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check1__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check1__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check1__c() {
        return AMWFBNK__Sending1_Check1__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check1__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check1__c
     */
    public void setAMWFBNK__Sending1_Check1__c(java.lang.Boolean AMWFBNK__Sending1_Check1__c) {
        this.AMWFBNK__Sending1_Check1__c = AMWFBNK__Sending1_Check1__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check20__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check20__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check20__c() {
        return AMWFBNK__Sending1_Check20__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check20__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check20__c
     */
    public void setAMWFBNK__Sending1_Check20__c(java.lang.Boolean AMWFBNK__Sending1_Check20__c) {
        this.AMWFBNK__Sending1_Check20__c = AMWFBNK__Sending1_Check20__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check2__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check2__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check2__c() {
        return AMWFBNK__Sending1_Check2__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check2__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check2__c
     */
    public void setAMWFBNK__Sending1_Check2__c(java.lang.Boolean AMWFBNK__Sending1_Check2__c) {
        this.AMWFBNK__Sending1_Check2__c = AMWFBNK__Sending1_Check2__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check3__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check3__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check3__c() {
        return AMWFBNK__Sending1_Check3__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check3__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check3__c
     */
    public void setAMWFBNK__Sending1_Check3__c(java.lang.Boolean AMWFBNK__Sending1_Check3__c) {
        this.AMWFBNK__Sending1_Check3__c = AMWFBNK__Sending1_Check3__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check4__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check4__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check4__c() {
        return AMWFBNK__Sending1_Check4__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check4__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check4__c
     */
    public void setAMWFBNK__Sending1_Check4__c(java.lang.Boolean AMWFBNK__Sending1_Check4__c) {
        this.AMWFBNK__Sending1_Check4__c = AMWFBNK__Sending1_Check4__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check5__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check5__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check5__c() {
        return AMWFBNK__Sending1_Check5__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check5__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check5__c
     */
    public void setAMWFBNK__Sending1_Check5__c(java.lang.Boolean AMWFBNK__Sending1_Check5__c) {
        this.AMWFBNK__Sending1_Check5__c = AMWFBNK__Sending1_Check5__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check6__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check6__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check6__c() {
        return AMWFBNK__Sending1_Check6__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check6__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check6__c
     */
    public void setAMWFBNK__Sending1_Check6__c(java.lang.Boolean AMWFBNK__Sending1_Check6__c) {
        this.AMWFBNK__Sending1_Check6__c = AMWFBNK__Sending1_Check6__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check7__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check7__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check7__c() {
        return AMWFBNK__Sending1_Check7__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check7__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check7__c
     */
    public void setAMWFBNK__Sending1_Check7__c(java.lang.Boolean AMWFBNK__Sending1_Check7__c) {
        this.AMWFBNK__Sending1_Check7__c = AMWFBNK__Sending1_Check7__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check8__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check8__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check8__c() {
        return AMWFBNK__Sending1_Check8__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check8__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check8__c
     */
    public void setAMWFBNK__Sending1_Check8__c(java.lang.Boolean AMWFBNK__Sending1_Check8__c) {
        this.AMWFBNK__Sending1_Check8__c = AMWFBNK__Sending1_Check8__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Check9__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Check9__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Check9__c() {
        return AMWFBNK__Sending1_Check9__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Check9__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Check9__c
     */
    public void setAMWFBNK__Sending1_Check9__c(java.lang.Boolean AMWFBNK__Sending1_Check9__c) {
        this.AMWFBNK__Sending1_Check9__c = AMWFBNK__Sending1_Check9__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_DlgtApprove__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_DlgtApprove__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_DlgtApprove__c() {
        return AMWFBNK__Sending1_DlgtApprove__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_DlgtApprove__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_DlgtApprove__c
     */
    public void setAMWFBNK__Sending1_DlgtApprove__c(java.lang.Boolean AMWFBNK__Sending1_DlgtApprove__c) {
        this.AMWFBNK__Sending1_DlgtApprove__c = AMWFBNK__Sending1_DlgtApprove__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_DlgtReject__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_DlgtReject__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_DlgtReject__c() {
        return AMWFBNK__Sending1_DlgtReject__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_DlgtReject__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_DlgtReject__c
     */
    public void setAMWFBNK__Sending1_DlgtReject__c(java.lang.Boolean AMWFBNK__Sending1_DlgtReject__c) {
        this.AMWFBNK__Sending1_DlgtReject__c = AMWFBNK__Sending1_DlgtReject__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Notify__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Notify__c() {
        return AMWFBNK__Sending1_Notify__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Notify__c
     */
    public void setAMWFBNK__Sending1_Notify__c(java.lang.Boolean AMWFBNK__Sending1_Notify__c) {
        this.AMWFBNK__Sending1_Notify__c = AMWFBNK__Sending1_Notify__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Passback__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Passback__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Passback__c() {
        return AMWFBNK__Sending1_Passback__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Passback__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Passback__c
     */
    public void setAMWFBNK__Sending1_Passback__c(java.lang.Boolean AMWFBNK__Sending1_Passback__c) {
        this.AMWFBNK__Sending1_Passback__c = AMWFBNK__Sending1_Passback__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Reject__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Reject__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Reject__c() {
        return AMWFBNK__Sending1_Reject__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Reject__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Reject__c
     */
    public void setAMWFBNK__Sending1_Reject__c(java.lang.Boolean AMWFBNK__Sending1_Reject__c) {
        this.AMWFBNK__Sending1_Reject__c = AMWFBNK__Sending1_Reject__c;
    }


    /**
     * Gets the AMWFBNK__Sending1_Send__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending1_Send__c
     */
    public java.lang.Boolean getAMWFBNK__Sending1_Send__c() {
        return AMWFBNK__Sending1_Send__c;
    }


    /**
     * Sets the AMWFBNK__Sending1_Send__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending1_Send__c
     */
    public void setAMWFBNK__Sending1_Send__c(java.lang.Boolean AMWFBNK__Sending1_Send__c) {
        this.AMWFBNK__Sending1_Send__c = AMWFBNK__Sending1_Send__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Approve__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Approve__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Approve__c() {
        return AMWFBNK__Sending2_Approve__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Approve__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Approve__c
     */
    public void setAMWFBNK__Sending2_Approve__c(java.lang.Boolean AMWFBNK__Sending2_Approve__c) {
        this.AMWFBNK__Sending2_Approve__c = AMWFBNK__Sending2_Approve__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check10__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check10__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check10__c() {
        return AMWFBNK__Sending2_Check10__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check10__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check10__c
     */
    public void setAMWFBNK__Sending2_Check10__c(java.lang.Boolean AMWFBNK__Sending2_Check10__c) {
        this.AMWFBNK__Sending2_Check10__c = AMWFBNK__Sending2_Check10__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check11__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check11__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check11__c() {
        return AMWFBNK__Sending2_Check11__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check11__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check11__c
     */
    public void setAMWFBNK__Sending2_Check11__c(java.lang.Boolean AMWFBNK__Sending2_Check11__c) {
        this.AMWFBNK__Sending2_Check11__c = AMWFBNK__Sending2_Check11__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check12__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check12__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check12__c() {
        return AMWFBNK__Sending2_Check12__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check12__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check12__c
     */
    public void setAMWFBNK__Sending2_Check12__c(java.lang.Boolean AMWFBNK__Sending2_Check12__c) {
        this.AMWFBNK__Sending2_Check12__c = AMWFBNK__Sending2_Check12__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check13__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check13__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check13__c() {
        return AMWFBNK__Sending2_Check13__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check13__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check13__c
     */
    public void setAMWFBNK__Sending2_Check13__c(java.lang.Boolean AMWFBNK__Sending2_Check13__c) {
        this.AMWFBNK__Sending2_Check13__c = AMWFBNK__Sending2_Check13__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check14__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check14__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check14__c() {
        return AMWFBNK__Sending2_Check14__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check14__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check14__c
     */
    public void setAMWFBNK__Sending2_Check14__c(java.lang.Boolean AMWFBNK__Sending2_Check14__c) {
        this.AMWFBNK__Sending2_Check14__c = AMWFBNK__Sending2_Check14__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check15__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check15__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check15__c() {
        return AMWFBNK__Sending2_Check15__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check15__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check15__c
     */
    public void setAMWFBNK__Sending2_Check15__c(java.lang.Boolean AMWFBNK__Sending2_Check15__c) {
        this.AMWFBNK__Sending2_Check15__c = AMWFBNK__Sending2_Check15__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check16__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check16__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check16__c() {
        return AMWFBNK__Sending2_Check16__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check16__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check16__c
     */
    public void setAMWFBNK__Sending2_Check16__c(java.lang.Boolean AMWFBNK__Sending2_Check16__c) {
        this.AMWFBNK__Sending2_Check16__c = AMWFBNK__Sending2_Check16__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check17__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check17__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check17__c() {
        return AMWFBNK__Sending2_Check17__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check17__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check17__c
     */
    public void setAMWFBNK__Sending2_Check17__c(java.lang.Boolean AMWFBNK__Sending2_Check17__c) {
        this.AMWFBNK__Sending2_Check17__c = AMWFBNK__Sending2_Check17__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check18__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check18__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check18__c() {
        return AMWFBNK__Sending2_Check18__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check18__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check18__c
     */
    public void setAMWFBNK__Sending2_Check18__c(java.lang.Boolean AMWFBNK__Sending2_Check18__c) {
        this.AMWFBNK__Sending2_Check18__c = AMWFBNK__Sending2_Check18__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check19__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check19__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check19__c() {
        return AMWFBNK__Sending2_Check19__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check19__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check19__c
     */
    public void setAMWFBNK__Sending2_Check19__c(java.lang.Boolean AMWFBNK__Sending2_Check19__c) {
        this.AMWFBNK__Sending2_Check19__c = AMWFBNK__Sending2_Check19__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check1__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check1__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check1__c() {
        return AMWFBNK__Sending2_Check1__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check1__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check1__c
     */
    public void setAMWFBNK__Sending2_Check1__c(java.lang.Boolean AMWFBNK__Sending2_Check1__c) {
        this.AMWFBNK__Sending2_Check1__c = AMWFBNK__Sending2_Check1__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check20__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check20__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check20__c() {
        return AMWFBNK__Sending2_Check20__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check20__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check20__c
     */
    public void setAMWFBNK__Sending2_Check20__c(java.lang.Boolean AMWFBNK__Sending2_Check20__c) {
        this.AMWFBNK__Sending2_Check20__c = AMWFBNK__Sending2_Check20__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check2__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check2__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check2__c() {
        return AMWFBNK__Sending2_Check2__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check2__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check2__c
     */
    public void setAMWFBNK__Sending2_Check2__c(java.lang.Boolean AMWFBNK__Sending2_Check2__c) {
        this.AMWFBNK__Sending2_Check2__c = AMWFBNK__Sending2_Check2__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check3__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check3__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check3__c() {
        return AMWFBNK__Sending2_Check3__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check3__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check3__c
     */
    public void setAMWFBNK__Sending2_Check3__c(java.lang.Boolean AMWFBNK__Sending2_Check3__c) {
        this.AMWFBNK__Sending2_Check3__c = AMWFBNK__Sending2_Check3__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check4__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check4__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check4__c() {
        return AMWFBNK__Sending2_Check4__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check4__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check4__c
     */
    public void setAMWFBNK__Sending2_Check4__c(java.lang.Boolean AMWFBNK__Sending2_Check4__c) {
        this.AMWFBNK__Sending2_Check4__c = AMWFBNK__Sending2_Check4__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check5__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check5__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check5__c() {
        return AMWFBNK__Sending2_Check5__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check5__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check5__c
     */
    public void setAMWFBNK__Sending2_Check5__c(java.lang.Boolean AMWFBNK__Sending2_Check5__c) {
        this.AMWFBNK__Sending2_Check5__c = AMWFBNK__Sending2_Check5__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check6__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check6__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check6__c() {
        return AMWFBNK__Sending2_Check6__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check6__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check6__c
     */
    public void setAMWFBNK__Sending2_Check6__c(java.lang.Boolean AMWFBNK__Sending2_Check6__c) {
        this.AMWFBNK__Sending2_Check6__c = AMWFBNK__Sending2_Check6__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check7__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check7__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check7__c() {
        return AMWFBNK__Sending2_Check7__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check7__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check7__c
     */
    public void setAMWFBNK__Sending2_Check7__c(java.lang.Boolean AMWFBNK__Sending2_Check7__c) {
        this.AMWFBNK__Sending2_Check7__c = AMWFBNK__Sending2_Check7__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check8__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check8__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check8__c() {
        return AMWFBNK__Sending2_Check8__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check8__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check8__c
     */
    public void setAMWFBNK__Sending2_Check8__c(java.lang.Boolean AMWFBNK__Sending2_Check8__c) {
        this.AMWFBNK__Sending2_Check8__c = AMWFBNK__Sending2_Check8__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Check9__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Check9__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Check9__c() {
        return AMWFBNK__Sending2_Check9__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Check9__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Check9__c
     */
    public void setAMWFBNK__Sending2_Check9__c(java.lang.Boolean AMWFBNK__Sending2_Check9__c) {
        this.AMWFBNK__Sending2_Check9__c = AMWFBNK__Sending2_Check9__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_DlgtApprove__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_DlgtApprove__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_DlgtApprove__c() {
        return AMWFBNK__Sending2_DlgtApprove__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_DlgtApprove__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_DlgtApprove__c
     */
    public void setAMWFBNK__Sending2_DlgtApprove__c(java.lang.Boolean AMWFBNK__Sending2_DlgtApprove__c) {
        this.AMWFBNK__Sending2_DlgtApprove__c = AMWFBNK__Sending2_DlgtApprove__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_DlgtReject__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_DlgtReject__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_DlgtReject__c() {
        return AMWFBNK__Sending2_DlgtReject__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_DlgtReject__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_DlgtReject__c
     */
    public void setAMWFBNK__Sending2_DlgtReject__c(java.lang.Boolean AMWFBNK__Sending2_DlgtReject__c) {
        this.AMWFBNK__Sending2_DlgtReject__c = AMWFBNK__Sending2_DlgtReject__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Notify__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Notify__c() {
        return AMWFBNK__Sending2_Notify__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Notify__c
     */
    public void setAMWFBNK__Sending2_Notify__c(java.lang.Boolean AMWFBNK__Sending2_Notify__c) {
        this.AMWFBNK__Sending2_Notify__c = AMWFBNK__Sending2_Notify__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Passback__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Passback__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Passback__c() {
        return AMWFBNK__Sending2_Passback__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Passback__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Passback__c
     */
    public void setAMWFBNK__Sending2_Passback__c(java.lang.Boolean AMWFBNK__Sending2_Passback__c) {
        this.AMWFBNK__Sending2_Passback__c = AMWFBNK__Sending2_Passback__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Reject__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Reject__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Reject__c() {
        return AMWFBNK__Sending2_Reject__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Reject__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Reject__c
     */
    public void setAMWFBNK__Sending2_Reject__c(java.lang.Boolean AMWFBNK__Sending2_Reject__c) {
        this.AMWFBNK__Sending2_Reject__c = AMWFBNK__Sending2_Reject__c;
    }


    /**
     * Gets the AMWFBNK__Sending2_Send__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Sending2_Send__c
     */
    public java.lang.Boolean getAMWFBNK__Sending2_Send__c() {
        return AMWFBNK__Sending2_Send__c;
    }


    /**
     * Sets the AMWFBNK__Sending2_Send__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Sending2_Send__c
     */
    public void setAMWFBNK__Sending2_Send__c(java.lang.Boolean AMWFBNK__Sending2_Send__c) {
        this.AMWFBNK__Sending2_Send__c = AMWFBNK__Sending2_Send__c;
    }


    /**
     * Gets the AMWFBNK__Type__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Type__c
     */
    public java.lang.String getAMWFBNK__Type__c() {
        return AMWFBNK__Type__c;
    }


    /**
     * Sets the AMWFBNK__Type__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Type__c
     */
    public void setAMWFBNK__Type__c(java.lang.String AMWFBNK__Type__c) {
        this.AMWFBNK__Type__c = AMWFBNK__Type__c;
    }


    /**
     * Gets the AMWFBNK__Withdrawing_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Withdrawing_Notify__c
     */
    public java.lang.Boolean getAMWFBNK__Withdrawing_Notify__c() {
        return AMWFBNK__Withdrawing_Notify__c;
    }


    /**
     * Sets the AMWFBNK__Withdrawing_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Withdrawing_Notify__c
     */
    public void setAMWFBNK__Withdrawing_Notify__c(java.lang.Boolean AMWFBNK__Withdrawing_Notify__c) {
        this.AMWFBNK__Withdrawing_Notify__c = AMWFBNK__Withdrawing_Notify__c;
    }


    /**
     * Gets the AMWFBNK__Withdrawn_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @return AMWFBNK__Withdrawn_Notify__c
     */
    public java.lang.Boolean getAMWFBNK__Withdrawn_Notify__c() {
        return AMWFBNK__Withdrawn_Notify__c;
    }


    /**
     * Sets the AMWFBNK__Withdrawn_Notify__c value for this AMWFBNK__AppliRole__c.
     * 
     * @param AMWFBNK__Withdrawn_Notify__c
     */
    public void setAMWFBNK__Withdrawn_Notify__c(java.lang.Boolean AMWFBNK__Withdrawn_Notify__c) {
        this.AMWFBNK__Withdrawn_Notify__c = AMWFBNK__Withdrawn_Notify__c;
    }


    /**
     * Gets the attachments value for this AMWFBNK__AppliRole__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this AMWFBNK__AppliRole__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the combinedAttachments value for this AMWFBNK__AppliRole__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this AMWFBNK__AppliRole__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this AMWFBNK__AppliRole__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this AMWFBNK__AppliRole__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this AMWFBNK__AppliRole__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this AMWFBNK__AppliRole__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this AMWFBNK__AppliRole__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this AMWFBNK__AppliRole__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the duplicateRecordItems value for this AMWFBNK__AppliRole__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this AMWFBNK__AppliRole__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the isDeleted value for this AMWFBNK__AppliRole__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this AMWFBNK__AppliRole__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the lastModifiedBy value for this AMWFBNK__AppliRole__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this AMWFBNK__AppliRole__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this AMWFBNK__AppliRole__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this AMWFBNK__AppliRole__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this AMWFBNK__AppliRole__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this AMWFBNK__AppliRole__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this AMWFBNK__AppliRole__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this AMWFBNK__AppliRole__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this AMWFBNK__AppliRole__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this AMWFBNK__AppliRole__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this AMWFBNK__AppliRole__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this AMWFBNK__AppliRole__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this AMWFBNK__AppliRole__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this AMWFBNK__AppliRole__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the owner value for this AMWFBNK__AppliRole__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this AMWFBNK__AppliRole__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this AMWFBNK__AppliRole__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this AMWFBNK__AppliRole__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this AMWFBNK__AppliRole__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this AMWFBNK__AppliRole__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this AMWFBNK__AppliRole__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this AMWFBNK__AppliRole__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the systemModstamp value for this AMWFBNK__AppliRole__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this AMWFBNK__AppliRole__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the topicAssignments value for this AMWFBNK__AppliRole__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this AMWFBNK__AppliRole__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this AMWFBNK__AppliRole__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this AMWFBNK__AppliRole__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AMWFBNK__AppliRole__c)) return false;
        AMWFBNK__AppliRole__c other = (AMWFBNK__AppliRole__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AMWFBNK__Accepting2_Accept__c==null && other.getAMWFBNK__Accepting2_Accept__c()==null) || 
             (this.AMWFBNK__Accepting2_Accept__c!=null &&
              this.AMWFBNK__Accepting2_Accept__c.equals(other.getAMWFBNK__Accepting2_Accept__c()))) &&
            ((this.AMWFBNK__Accepting2_Notify__c==null && other.getAMWFBNK__Accepting2_Notify__c()==null) || 
             (this.AMWFBNK__Accepting2_Notify__c!=null &&
              this.AMWFBNK__Accepting2_Notify__c.equals(other.getAMWFBNK__Accepting2_Notify__c()))) &&
            ((this.AMWFBNK__AppliCode__c==null && other.getAMWFBNK__AppliCode__c()==null) || 
             (this.AMWFBNK__AppliCode__c!=null &&
              this.AMWFBNK__AppliCode__c.equals(other.getAMWFBNK__AppliCode__c()))) &&
            ((this.AMWFBNK__AppliName__c==null && other.getAMWFBNK__AppliName__c()==null) || 
             (this.AMWFBNK__AppliName__c!=null &&
              this.AMWFBNK__AppliName__c.equals(other.getAMWFBNK__AppliName__c()))) &&
            ((this.AMWFBNK__Approved_Notify__c==null && other.getAMWFBNK__Approved_Notify__c()==null) || 
             (this.AMWFBNK__Approved_Notify__c!=null &&
              this.AMWFBNK__Approved_Notify__c.equals(other.getAMWFBNK__Approved_Notify__c()))) &&
            ((this.AMWFBNK__Approved_Withdraw__c==null && other.getAMWFBNK__Approved_Withdraw__c()==null) || 
             (this.AMWFBNK__Approved_Withdraw__c!=null &&
              this.AMWFBNK__Approved_Withdraw__c.equals(other.getAMWFBNK__Approved_Withdraw__c()))) &&
            ((this.AMWFBNK__Available__c==null && other.getAMWFBNK__Available__c()==null) || 
             (this.AMWFBNK__Available__c!=null &&
              this.AMWFBNK__Available__c.equals(other.getAMWFBNK__Available__c()))) &&
            ((this.AMWFBNK__FlowCode__c==null && other.getAMWFBNK__FlowCode__c()==null) || 
             (this.AMWFBNK__FlowCode__c!=null &&
              this.AMWFBNK__FlowCode__c.equals(other.getAMWFBNK__FlowCode__c()))) &&
            ((this.AMWFBNK__MemberCount__c==null && other.getAMWFBNK__MemberCount__c()==null) || 
             (this.AMWFBNK__MemberCount__c!=null &&
              this.AMWFBNK__MemberCount__c.equals(other.getAMWFBNK__MemberCount__c()))) &&
            ((this.AMWFBNK__Members__r==null && other.getAMWFBNK__Members__r()==null) || 
             (this.AMWFBNK__Members__r!=null &&
              this.AMWFBNK__Members__r.equals(other.getAMWFBNK__Members__r()))) &&
            ((this.AMWFBNK__New_Notify__c==null && other.getAMWFBNK__New_Notify__c()==null) || 
             (this.AMWFBNK__New_Notify__c!=null &&
              this.AMWFBNK__New_Notify__c.equals(other.getAMWFBNK__New_Notify__c()))) &&
            ((this.AMWFBNK__New_Send__c==null && other.getAMWFBNK__New_Send__c()==null) || 
             (this.AMWFBNK__New_Send__c!=null &&
              this.AMWFBNK__New_Send__c.equals(other.getAMWFBNK__New_Send__c()))) &&
            ((this.AMWFBNK__Rejected_Notify__c==null && other.getAMWFBNK__Rejected_Notify__c()==null) || 
             (this.AMWFBNK__Rejected_Notify__c!=null &&
              this.AMWFBNK__Rejected_Notify__c.equals(other.getAMWFBNK__Rejected_Notify__c()))) &&
            ((this.AMWFBNK__Sending1_Approve__c==null && other.getAMWFBNK__Sending1_Approve__c()==null) || 
             (this.AMWFBNK__Sending1_Approve__c!=null &&
              this.AMWFBNK__Sending1_Approve__c.equals(other.getAMWFBNK__Sending1_Approve__c()))) &&
            ((this.AMWFBNK__Sending1_Check10__c==null && other.getAMWFBNK__Sending1_Check10__c()==null) || 
             (this.AMWFBNK__Sending1_Check10__c!=null &&
              this.AMWFBNK__Sending1_Check10__c.equals(other.getAMWFBNK__Sending1_Check10__c()))) &&
            ((this.AMWFBNK__Sending1_Check11__c==null && other.getAMWFBNK__Sending1_Check11__c()==null) || 
             (this.AMWFBNK__Sending1_Check11__c!=null &&
              this.AMWFBNK__Sending1_Check11__c.equals(other.getAMWFBNK__Sending1_Check11__c()))) &&
            ((this.AMWFBNK__Sending1_Check12__c==null && other.getAMWFBNK__Sending1_Check12__c()==null) || 
             (this.AMWFBNK__Sending1_Check12__c!=null &&
              this.AMWFBNK__Sending1_Check12__c.equals(other.getAMWFBNK__Sending1_Check12__c()))) &&
            ((this.AMWFBNK__Sending1_Check13__c==null && other.getAMWFBNK__Sending1_Check13__c()==null) || 
             (this.AMWFBNK__Sending1_Check13__c!=null &&
              this.AMWFBNK__Sending1_Check13__c.equals(other.getAMWFBNK__Sending1_Check13__c()))) &&
            ((this.AMWFBNK__Sending1_Check14__c==null && other.getAMWFBNK__Sending1_Check14__c()==null) || 
             (this.AMWFBNK__Sending1_Check14__c!=null &&
              this.AMWFBNK__Sending1_Check14__c.equals(other.getAMWFBNK__Sending1_Check14__c()))) &&
            ((this.AMWFBNK__Sending1_Check15__c==null && other.getAMWFBNK__Sending1_Check15__c()==null) || 
             (this.AMWFBNK__Sending1_Check15__c!=null &&
              this.AMWFBNK__Sending1_Check15__c.equals(other.getAMWFBNK__Sending1_Check15__c()))) &&
            ((this.AMWFBNK__Sending1_Check16__c==null && other.getAMWFBNK__Sending1_Check16__c()==null) || 
             (this.AMWFBNK__Sending1_Check16__c!=null &&
              this.AMWFBNK__Sending1_Check16__c.equals(other.getAMWFBNK__Sending1_Check16__c()))) &&
            ((this.AMWFBNK__Sending1_Check17__c==null && other.getAMWFBNK__Sending1_Check17__c()==null) || 
             (this.AMWFBNK__Sending1_Check17__c!=null &&
              this.AMWFBNK__Sending1_Check17__c.equals(other.getAMWFBNK__Sending1_Check17__c()))) &&
            ((this.AMWFBNK__Sending1_Check18__c==null && other.getAMWFBNK__Sending1_Check18__c()==null) || 
             (this.AMWFBNK__Sending1_Check18__c!=null &&
              this.AMWFBNK__Sending1_Check18__c.equals(other.getAMWFBNK__Sending1_Check18__c()))) &&
            ((this.AMWFBNK__Sending1_Check19__c==null && other.getAMWFBNK__Sending1_Check19__c()==null) || 
             (this.AMWFBNK__Sending1_Check19__c!=null &&
              this.AMWFBNK__Sending1_Check19__c.equals(other.getAMWFBNK__Sending1_Check19__c()))) &&
            ((this.AMWFBNK__Sending1_Check1__c==null && other.getAMWFBNK__Sending1_Check1__c()==null) || 
             (this.AMWFBNK__Sending1_Check1__c!=null &&
              this.AMWFBNK__Sending1_Check1__c.equals(other.getAMWFBNK__Sending1_Check1__c()))) &&
            ((this.AMWFBNK__Sending1_Check20__c==null && other.getAMWFBNK__Sending1_Check20__c()==null) || 
             (this.AMWFBNK__Sending1_Check20__c!=null &&
              this.AMWFBNK__Sending1_Check20__c.equals(other.getAMWFBNK__Sending1_Check20__c()))) &&
            ((this.AMWFBNK__Sending1_Check2__c==null && other.getAMWFBNK__Sending1_Check2__c()==null) || 
             (this.AMWFBNK__Sending1_Check2__c!=null &&
              this.AMWFBNK__Sending1_Check2__c.equals(other.getAMWFBNK__Sending1_Check2__c()))) &&
            ((this.AMWFBNK__Sending1_Check3__c==null && other.getAMWFBNK__Sending1_Check3__c()==null) || 
             (this.AMWFBNK__Sending1_Check3__c!=null &&
              this.AMWFBNK__Sending1_Check3__c.equals(other.getAMWFBNK__Sending1_Check3__c()))) &&
            ((this.AMWFBNK__Sending1_Check4__c==null && other.getAMWFBNK__Sending1_Check4__c()==null) || 
             (this.AMWFBNK__Sending1_Check4__c!=null &&
              this.AMWFBNK__Sending1_Check4__c.equals(other.getAMWFBNK__Sending1_Check4__c()))) &&
            ((this.AMWFBNK__Sending1_Check5__c==null && other.getAMWFBNK__Sending1_Check5__c()==null) || 
             (this.AMWFBNK__Sending1_Check5__c!=null &&
              this.AMWFBNK__Sending1_Check5__c.equals(other.getAMWFBNK__Sending1_Check5__c()))) &&
            ((this.AMWFBNK__Sending1_Check6__c==null && other.getAMWFBNK__Sending1_Check6__c()==null) || 
             (this.AMWFBNK__Sending1_Check6__c!=null &&
              this.AMWFBNK__Sending1_Check6__c.equals(other.getAMWFBNK__Sending1_Check6__c()))) &&
            ((this.AMWFBNK__Sending1_Check7__c==null && other.getAMWFBNK__Sending1_Check7__c()==null) || 
             (this.AMWFBNK__Sending1_Check7__c!=null &&
              this.AMWFBNK__Sending1_Check7__c.equals(other.getAMWFBNK__Sending1_Check7__c()))) &&
            ((this.AMWFBNK__Sending1_Check8__c==null && other.getAMWFBNK__Sending1_Check8__c()==null) || 
             (this.AMWFBNK__Sending1_Check8__c!=null &&
              this.AMWFBNK__Sending1_Check8__c.equals(other.getAMWFBNK__Sending1_Check8__c()))) &&
            ((this.AMWFBNK__Sending1_Check9__c==null && other.getAMWFBNK__Sending1_Check9__c()==null) || 
             (this.AMWFBNK__Sending1_Check9__c!=null &&
              this.AMWFBNK__Sending1_Check9__c.equals(other.getAMWFBNK__Sending1_Check9__c()))) &&
            ((this.AMWFBNK__Sending1_DlgtApprove__c==null && other.getAMWFBNK__Sending1_DlgtApprove__c()==null) || 
             (this.AMWFBNK__Sending1_DlgtApprove__c!=null &&
              this.AMWFBNK__Sending1_DlgtApprove__c.equals(other.getAMWFBNK__Sending1_DlgtApprove__c()))) &&
            ((this.AMWFBNK__Sending1_DlgtReject__c==null && other.getAMWFBNK__Sending1_DlgtReject__c()==null) || 
             (this.AMWFBNK__Sending1_DlgtReject__c!=null &&
              this.AMWFBNK__Sending1_DlgtReject__c.equals(other.getAMWFBNK__Sending1_DlgtReject__c()))) &&
            ((this.AMWFBNK__Sending1_Notify__c==null && other.getAMWFBNK__Sending1_Notify__c()==null) || 
             (this.AMWFBNK__Sending1_Notify__c!=null &&
              this.AMWFBNK__Sending1_Notify__c.equals(other.getAMWFBNK__Sending1_Notify__c()))) &&
            ((this.AMWFBNK__Sending1_Passback__c==null && other.getAMWFBNK__Sending1_Passback__c()==null) || 
             (this.AMWFBNK__Sending1_Passback__c!=null &&
              this.AMWFBNK__Sending1_Passback__c.equals(other.getAMWFBNK__Sending1_Passback__c()))) &&
            ((this.AMWFBNK__Sending1_Reject__c==null && other.getAMWFBNK__Sending1_Reject__c()==null) || 
             (this.AMWFBNK__Sending1_Reject__c!=null &&
              this.AMWFBNK__Sending1_Reject__c.equals(other.getAMWFBNK__Sending1_Reject__c()))) &&
            ((this.AMWFBNK__Sending1_Send__c==null && other.getAMWFBNK__Sending1_Send__c()==null) || 
             (this.AMWFBNK__Sending1_Send__c!=null &&
              this.AMWFBNK__Sending1_Send__c.equals(other.getAMWFBNK__Sending1_Send__c()))) &&
            ((this.AMWFBNK__Sending2_Approve__c==null && other.getAMWFBNK__Sending2_Approve__c()==null) || 
             (this.AMWFBNK__Sending2_Approve__c!=null &&
              this.AMWFBNK__Sending2_Approve__c.equals(other.getAMWFBNK__Sending2_Approve__c()))) &&
            ((this.AMWFBNK__Sending2_Check10__c==null && other.getAMWFBNK__Sending2_Check10__c()==null) || 
             (this.AMWFBNK__Sending2_Check10__c!=null &&
              this.AMWFBNK__Sending2_Check10__c.equals(other.getAMWFBNK__Sending2_Check10__c()))) &&
            ((this.AMWFBNK__Sending2_Check11__c==null && other.getAMWFBNK__Sending2_Check11__c()==null) || 
             (this.AMWFBNK__Sending2_Check11__c!=null &&
              this.AMWFBNK__Sending2_Check11__c.equals(other.getAMWFBNK__Sending2_Check11__c()))) &&
            ((this.AMWFBNK__Sending2_Check12__c==null && other.getAMWFBNK__Sending2_Check12__c()==null) || 
             (this.AMWFBNK__Sending2_Check12__c!=null &&
              this.AMWFBNK__Sending2_Check12__c.equals(other.getAMWFBNK__Sending2_Check12__c()))) &&
            ((this.AMWFBNK__Sending2_Check13__c==null && other.getAMWFBNK__Sending2_Check13__c()==null) || 
             (this.AMWFBNK__Sending2_Check13__c!=null &&
              this.AMWFBNK__Sending2_Check13__c.equals(other.getAMWFBNK__Sending2_Check13__c()))) &&
            ((this.AMWFBNK__Sending2_Check14__c==null && other.getAMWFBNK__Sending2_Check14__c()==null) || 
             (this.AMWFBNK__Sending2_Check14__c!=null &&
              this.AMWFBNK__Sending2_Check14__c.equals(other.getAMWFBNK__Sending2_Check14__c()))) &&
            ((this.AMWFBNK__Sending2_Check15__c==null && other.getAMWFBNK__Sending2_Check15__c()==null) || 
             (this.AMWFBNK__Sending2_Check15__c!=null &&
              this.AMWFBNK__Sending2_Check15__c.equals(other.getAMWFBNK__Sending2_Check15__c()))) &&
            ((this.AMWFBNK__Sending2_Check16__c==null && other.getAMWFBNK__Sending2_Check16__c()==null) || 
             (this.AMWFBNK__Sending2_Check16__c!=null &&
              this.AMWFBNK__Sending2_Check16__c.equals(other.getAMWFBNK__Sending2_Check16__c()))) &&
            ((this.AMWFBNK__Sending2_Check17__c==null && other.getAMWFBNK__Sending2_Check17__c()==null) || 
             (this.AMWFBNK__Sending2_Check17__c!=null &&
              this.AMWFBNK__Sending2_Check17__c.equals(other.getAMWFBNK__Sending2_Check17__c()))) &&
            ((this.AMWFBNK__Sending2_Check18__c==null && other.getAMWFBNK__Sending2_Check18__c()==null) || 
             (this.AMWFBNK__Sending2_Check18__c!=null &&
              this.AMWFBNK__Sending2_Check18__c.equals(other.getAMWFBNK__Sending2_Check18__c()))) &&
            ((this.AMWFBNK__Sending2_Check19__c==null && other.getAMWFBNK__Sending2_Check19__c()==null) || 
             (this.AMWFBNK__Sending2_Check19__c!=null &&
              this.AMWFBNK__Sending2_Check19__c.equals(other.getAMWFBNK__Sending2_Check19__c()))) &&
            ((this.AMWFBNK__Sending2_Check1__c==null && other.getAMWFBNK__Sending2_Check1__c()==null) || 
             (this.AMWFBNK__Sending2_Check1__c!=null &&
              this.AMWFBNK__Sending2_Check1__c.equals(other.getAMWFBNK__Sending2_Check1__c()))) &&
            ((this.AMWFBNK__Sending2_Check20__c==null && other.getAMWFBNK__Sending2_Check20__c()==null) || 
             (this.AMWFBNK__Sending2_Check20__c!=null &&
              this.AMWFBNK__Sending2_Check20__c.equals(other.getAMWFBNK__Sending2_Check20__c()))) &&
            ((this.AMWFBNK__Sending2_Check2__c==null && other.getAMWFBNK__Sending2_Check2__c()==null) || 
             (this.AMWFBNK__Sending2_Check2__c!=null &&
              this.AMWFBNK__Sending2_Check2__c.equals(other.getAMWFBNK__Sending2_Check2__c()))) &&
            ((this.AMWFBNK__Sending2_Check3__c==null && other.getAMWFBNK__Sending2_Check3__c()==null) || 
             (this.AMWFBNK__Sending2_Check3__c!=null &&
              this.AMWFBNK__Sending2_Check3__c.equals(other.getAMWFBNK__Sending2_Check3__c()))) &&
            ((this.AMWFBNK__Sending2_Check4__c==null && other.getAMWFBNK__Sending2_Check4__c()==null) || 
             (this.AMWFBNK__Sending2_Check4__c!=null &&
              this.AMWFBNK__Sending2_Check4__c.equals(other.getAMWFBNK__Sending2_Check4__c()))) &&
            ((this.AMWFBNK__Sending2_Check5__c==null && other.getAMWFBNK__Sending2_Check5__c()==null) || 
             (this.AMWFBNK__Sending2_Check5__c!=null &&
              this.AMWFBNK__Sending2_Check5__c.equals(other.getAMWFBNK__Sending2_Check5__c()))) &&
            ((this.AMWFBNK__Sending2_Check6__c==null && other.getAMWFBNK__Sending2_Check6__c()==null) || 
             (this.AMWFBNK__Sending2_Check6__c!=null &&
              this.AMWFBNK__Sending2_Check6__c.equals(other.getAMWFBNK__Sending2_Check6__c()))) &&
            ((this.AMWFBNK__Sending2_Check7__c==null && other.getAMWFBNK__Sending2_Check7__c()==null) || 
             (this.AMWFBNK__Sending2_Check7__c!=null &&
              this.AMWFBNK__Sending2_Check7__c.equals(other.getAMWFBNK__Sending2_Check7__c()))) &&
            ((this.AMWFBNK__Sending2_Check8__c==null && other.getAMWFBNK__Sending2_Check8__c()==null) || 
             (this.AMWFBNK__Sending2_Check8__c!=null &&
              this.AMWFBNK__Sending2_Check8__c.equals(other.getAMWFBNK__Sending2_Check8__c()))) &&
            ((this.AMWFBNK__Sending2_Check9__c==null && other.getAMWFBNK__Sending2_Check9__c()==null) || 
             (this.AMWFBNK__Sending2_Check9__c!=null &&
              this.AMWFBNK__Sending2_Check9__c.equals(other.getAMWFBNK__Sending2_Check9__c()))) &&
            ((this.AMWFBNK__Sending2_DlgtApprove__c==null && other.getAMWFBNK__Sending2_DlgtApprove__c()==null) || 
             (this.AMWFBNK__Sending2_DlgtApprove__c!=null &&
              this.AMWFBNK__Sending2_DlgtApprove__c.equals(other.getAMWFBNK__Sending2_DlgtApprove__c()))) &&
            ((this.AMWFBNK__Sending2_DlgtReject__c==null && other.getAMWFBNK__Sending2_DlgtReject__c()==null) || 
             (this.AMWFBNK__Sending2_DlgtReject__c!=null &&
              this.AMWFBNK__Sending2_DlgtReject__c.equals(other.getAMWFBNK__Sending2_DlgtReject__c()))) &&
            ((this.AMWFBNK__Sending2_Notify__c==null && other.getAMWFBNK__Sending2_Notify__c()==null) || 
             (this.AMWFBNK__Sending2_Notify__c!=null &&
              this.AMWFBNK__Sending2_Notify__c.equals(other.getAMWFBNK__Sending2_Notify__c()))) &&
            ((this.AMWFBNK__Sending2_Passback__c==null && other.getAMWFBNK__Sending2_Passback__c()==null) || 
             (this.AMWFBNK__Sending2_Passback__c!=null &&
              this.AMWFBNK__Sending2_Passback__c.equals(other.getAMWFBNK__Sending2_Passback__c()))) &&
            ((this.AMWFBNK__Sending2_Reject__c==null && other.getAMWFBNK__Sending2_Reject__c()==null) || 
             (this.AMWFBNK__Sending2_Reject__c!=null &&
              this.AMWFBNK__Sending2_Reject__c.equals(other.getAMWFBNK__Sending2_Reject__c()))) &&
            ((this.AMWFBNK__Sending2_Send__c==null && other.getAMWFBNK__Sending2_Send__c()==null) || 
             (this.AMWFBNK__Sending2_Send__c!=null &&
              this.AMWFBNK__Sending2_Send__c.equals(other.getAMWFBNK__Sending2_Send__c()))) &&
            ((this.AMWFBNK__Type__c==null && other.getAMWFBNK__Type__c()==null) || 
             (this.AMWFBNK__Type__c!=null &&
              this.AMWFBNK__Type__c.equals(other.getAMWFBNK__Type__c()))) &&
            ((this.AMWFBNK__Withdrawing_Notify__c==null && other.getAMWFBNK__Withdrawing_Notify__c()==null) || 
             (this.AMWFBNK__Withdrawing_Notify__c!=null &&
              this.AMWFBNK__Withdrawing_Notify__c.equals(other.getAMWFBNK__Withdrawing_Notify__c()))) &&
            ((this.AMWFBNK__Withdrawn_Notify__c==null && other.getAMWFBNK__Withdrawn_Notify__c()==null) || 
             (this.AMWFBNK__Withdrawn_Notify__c!=null &&
              this.AMWFBNK__Withdrawn_Notify__c.equals(other.getAMWFBNK__Withdrawn_Notify__c()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAMWFBNK__Accepting2_Accept__c() != null) {
            _hashCode += getAMWFBNK__Accepting2_Accept__c().hashCode();
        }
        if (getAMWFBNK__Accepting2_Notify__c() != null) {
            _hashCode += getAMWFBNK__Accepting2_Notify__c().hashCode();
        }
        if (getAMWFBNK__AppliCode__c() != null) {
            _hashCode += getAMWFBNK__AppliCode__c().hashCode();
        }
        if (getAMWFBNK__AppliName__c() != null) {
            _hashCode += getAMWFBNK__AppliName__c().hashCode();
        }
        if (getAMWFBNK__Approved_Notify__c() != null) {
            _hashCode += getAMWFBNK__Approved_Notify__c().hashCode();
        }
        if (getAMWFBNK__Approved_Withdraw__c() != null) {
            _hashCode += getAMWFBNK__Approved_Withdraw__c().hashCode();
        }
        if (getAMWFBNK__Available__c() != null) {
            _hashCode += getAMWFBNK__Available__c().hashCode();
        }
        if (getAMWFBNK__FlowCode__c() != null) {
            _hashCode += getAMWFBNK__FlowCode__c().hashCode();
        }
        if (getAMWFBNK__MemberCount__c() != null) {
            _hashCode += getAMWFBNK__MemberCount__c().hashCode();
        }
        if (getAMWFBNK__Members__r() != null) {
            _hashCode += getAMWFBNK__Members__r().hashCode();
        }
        if (getAMWFBNK__New_Notify__c() != null) {
            _hashCode += getAMWFBNK__New_Notify__c().hashCode();
        }
        if (getAMWFBNK__New_Send__c() != null) {
            _hashCode += getAMWFBNK__New_Send__c().hashCode();
        }
        if (getAMWFBNK__Rejected_Notify__c() != null) {
            _hashCode += getAMWFBNK__Rejected_Notify__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Approve__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Approve__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check10__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check10__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check11__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check11__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check12__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check12__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check13__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check13__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check14__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check14__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check15__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check15__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check16__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check16__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check17__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check17__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check18__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check18__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check19__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check19__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check1__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check1__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check20__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check20__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check2__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check2__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check3__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check3__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check4__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check4__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check5__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check5__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check6__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check6__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check7__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check7__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check8__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check8__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Check9__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Check9__c().hashCode();
        }
        if (getAMWFBNK__Sending1_DlgtApprove__c() != null) {
            _hashCode += getAMWFBNK__Sending1_DlgtApprove__c().hashCode();
        }
        if (getAMWFBNK__Sending1_DlgtReject__c() != null) {
            _hashCode += getAMWFBNK__Sending1_DlgtReject__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Notify__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Notify__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Passback__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Passback__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Reject__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Reject__c().hashCode();
        }
        if (getAMWFBNK__Sending1_Send__c() != null) {
            _hashCode += getAMWFBNK__Sending1_Send__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Approve__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Approve__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check10__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check10__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check11__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check11__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check12__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check12__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check13__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check13__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check14__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check14__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check15__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check15__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check16__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check16__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check17__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check17__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check18__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check18__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check19__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check19__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check1__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check1__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check20__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check20__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check2__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check2__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check3__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check3__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check4__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check4__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check5__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check5__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check6__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check6__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check7__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check7__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check8__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check8__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Check9__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Check9__c().hashCode();
        }
        if (getAMWFBNK__Sending2_DlgtApprove__c() != null) {
            _hashCode += getAMWFBNK__Sending2_DlgtApprove__c().hashCode();
        }
        if (getAMWFBNK__Sending2_DlgtReject__c() != null) {
            _hashCode += getAMWFBNK__Sending2_DlgtReject__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Notify__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Notify__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Passback__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Passback__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Reject__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Reject__c().hashCode();
        }
        if (getAMWFBNK__Sending2_Send__c() != null) {
            _hashCode += getAMWFBNK__Sending2_Send__c().hashCode();
        }
        if (getAMWFBNK__Type__c() != null) {
            _hashCode += getAMWFBNK__Type__c().hashCode();
        }
        if (getAMWFBNK__Withdrawing_Notify__c() != null) {
            _hashCode += getAMWFBNK__Withdrawing_Notify__c().hashCode();
        }
        if (getAMWFBNK__Withdrawn_Notify__c() != null) {
            _hashCode += getAMWFBNK__Withdrawn_Notify__c().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AMWFBNK__AppliRole__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__AppliRole__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Accepting2_Accept__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Accepting2_Accept__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Accepting2_Notify__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Accepting2_Notify__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__AppliCode__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__AppliCode__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__AppliName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__AppliName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Approved_Notify__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Approved_Notify__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Approved_Withdraw__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Approved_Withdraw__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Available__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Available__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FlowCode__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FlowCode__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__MemberCount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__MemberCount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Members__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Members__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__New_Notify__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__New_Notify__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__New_Send__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__New_Send__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Rejected_Notify__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Rejected_Notify__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Approve__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Approve__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check11__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check11__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check12__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check12__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check13__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check13__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check14__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check14__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check15__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check15__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check16__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check16__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check17__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check17__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check18__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check18__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check19__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check19__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check20__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check20__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check6__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check6__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check7__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check7__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check8__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check8__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Check9__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Check9__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_DlgtApprove__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_DlgtApprove__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_DlgtReject__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_DlgtReject__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Notify__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Notify__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Passback__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Passback__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Reject__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Reject__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending1_Send__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending1_Send__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Approve__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Approve__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check11__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check11__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check12__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check12__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check13__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check13__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check14__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check14__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check15__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check15__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check16__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check16__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check17__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check17__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check18__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check18__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check19__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check19__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check20__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check20__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check6__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check6__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check7__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check7__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check8__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check8__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Check9__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Check9__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_DlgtApprove__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_DlgtApprove__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_DlgtReject__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_DlgtReject__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Notify__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Notify__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Passback__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Passback__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Reject__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Reject__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Sending2_Send__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Sending2_Send__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Type__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Type__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Withdrawing_Notify__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Withdrawing_Notify__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Withdrawn_Notify__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Withdrawn_Notify__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
