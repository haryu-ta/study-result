/**
 * C002_Case__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C002_Case__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String a010_ActionPlan__c;

    private java.lang.String a010_AnkenShudousha__c;

    private java.lang.String a010_AnkenShurui1__c;

    private java.lang.String a010_AnkenShurui2__c;

    private java.lang.String a010_AnkenShurui3__c;

    private java.lang.String a010_Bikou__c;

    private java.lang.String a010_CaseId__c;

    private java.lang.String a010_Country__c;

    private java.lang.String a010_CsvTantou_01__c;

    private java.lang.String a010_GBADUnit__c;

    private java.lang.String a010_Group__c;

    private java.lang.String a010_Kakudo__c;

    private java.lang.String a010_KankeiBusho1__c;

    private java.lang.String a010_KankeiBusho2__c;

    private java.lang.String a010_Kekka__c;

    private java.lang.String a010_RenkeiKaigaiKyoten1__c;

    private java.lang.String a010_RenkeiKaigaiKyoten2__c;

    private java.lang.String a010_Saido__c;

    private java.lang.String a010_Shisaku__c;

    private java.lang.String a010_ShuekiShurui1__c;

    private java.lang.String a010_ShuekiShurui2__c;

    private java.lang.Double a010_Shuekigaku__c;

    private java.util.Date a010_YoteizukiHizuke__c;

    private java.lang.Double a010_YoteizukiInt__c;

    private java.lang.String a010_Yoteizuki__c;

    private java.lang.String a014_AnkenShurui__c;

    private java.util.Date a014_CaseCloseDate__c;

    private java.lang.Boolean a014_ChokusetsuSoshutsu__c;

    private java.util.Date a014_DecisionDate__c;

    private java.lang.String a014_DecisionMeeting__c;

    private java.lang.String a014_Kakudo__c;

    private java.lang.String a014_Outline__c;

    private java.lang.String a014_RelateState1__c;

    private java.lang.String a014_RelateState2__c;

    private java.lang.String a014_RelateState3__c;

    private java.lang.String a014_RelateTeam__c;

    private java.lang.Double a014_RenketsuShueki__c;

    private java.lang.Double a014_ShuekiAmount__c;

    private java.lang.Double a014_TantaiShueki__c;

    private java.lang.String a014_TantouTeam1__c;

    private java.lang.String a014_TantouTeam2__c;

    private java.lang.String a014_TantouTeam3__c;

    private java.lang.String a014_Tantousha1__c;

    private java.lang.String a014_Tantousha2__c;

    private java.lang.String a014_Tantousha3__c;

    private java.lang.String a015_AnkenCategory__c;

    private java.lang.String a015_AnkenShubetsu__c;

    private java.lang.Boolean a015_RisihokyuuSeido__c;

    private java.lang.String a015_ToushiBasyo__c;

    private java.lang.Double a015_ToushiKingaku__c;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.Boolean c002_AllowedChangeCustomer__c;

    private java.lang.Double c002_Amount2__c;

    private java.lang.Double c002_Amount3__c;

    private java.lang.Double c002_Amount__c;

    private java.lang.String c002_AppName__c;

    private java.lang.String c002_CRM_AnkenId__c;

    private java.lang.String c002_CaseId__c;

    private java.lang.String c002_CaseName__c;

    private com.sforce.soap.enterprise.QueryResult c002_Cases_01__r;

    private java.lang.String c002_CsvLastModifiedDate__c;

    private java.lang.String c002_CsvRecordTantou__c;

    private java.lang.String c002_CustomerId__c;

    private java.lang.String c002_CustomerName__c;

    private java.lang.String c002_CustomerRef__c;

    private com.sforce.soap.enterprise.sobject.C001_Customer__c c002_CustomerRef__r;

    private java.util.Date c002_Date1__c;

    private java.util.Date c002_DateFrom__c;

    private java.util.Date c002_DateTo__c;

    private java.lang.String c002_Detail__c;

    private java.lang.String c002_Kakudo1__c;

    private java.lang.String c002_Kakudo2__c;

    private java.lang.String c002_KyotenName__c;

    private java.lang.String c002_Outline__c;

    private java.lang.Double c002_ProfitRenketsu__c;

    private java.lang.Double c002_ProfitTantai__c;

    private java.lang.String c002_RMTanto__c;

    private java.lang.String c002_RecordTantouButenName__c;

    private java.lang.String c002_RecordTantou__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_RecordTantou__r;

    private java.lang.String c002_RecordTypeName2__c;

    private java.lang.String c002_RelatedTaskID__c;

    private java.lang.String c002_RevenueDivision__c;

    private java.lang.String c002_Shinmitsudo__c;

    private java.lang.String c002_TantobuTemban__c;

    private java.lang.String c002_Tantou01_Group__c;

    private java.lang.String c002_Tantou01_Name__c;

    private java.lang.String c002_Tantou02_Group__c;

    private java.lang.String c002_Tantou02_Name__c;

    private java.lang.String c002_Tantou03_Group__c;

    private java.lang.String c002_Tantou03_Name__c;

    private java.lang.String c002_Tantou04_Group__c;

    private java.lang.String c002_Tantou04_Name__c;

    private java.lang.String c002_Tantou_01__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_01__r;

    private java.lang.String c002_Tantou_02__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_02__r;

    private java.lang.String c002_Tantou_03__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_03__r;

    private java.lang.String c002_Tantou_04__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_04__r;

    private java.lang.String c002_Tantou_05__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_05__r;

    private java.lang.String c002_Tantou_Kensaku__c;

    private java.lang.String c002_TembanCif__c;

    private java.lang.String c002_TokoKakuzuke__c;

    private java.lang.String c002_Work__c;

    private java.lang.String c002_YomikomiNo__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.util.Calendar lastReferencedDate;

    private java.util.Calendar lastViewedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private com.sforce.soap.enterprise.sobject.RecordType recordType;

    private java.lang.String recordTypeId;

    private com.sforce.soap.enterprise.QueryResult shares;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    public C002_Case__c() {
    }

    public C002_Case__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String a010_ActionPlan__c,
           java.lang.String a010_AnkenShudousha__c,
           java.lang.String a010_AnkenShurui1__c,
           java.lang.String a010_AnkenShurui2__c,
           java.lang.String a010_AnkenShurui3__c,
           java.lang.String a010_Bikou__c,
           java.lang.String a010_CaseId__c,
           java.lang.String a010_Country__c,
           java.lang.String a010_CsvTantou_01__c,
           java.lang.String a010_GBADUnit__c,
           java.lang.String a010_Group__c,
           java.lang.String a010_Kakudo__c,
           java.lang.String a010_KankeiBusho1__c,
           java.lang.String a010_KankeiBusho2__c,
           java.lang.String a010_Kekka__c,
           java.lang.String a010_RenkeiKaigaiKyoten1__c,
           java.lang.String a010_RenkeiKaigaiKyoten2__c,
           java.lang.String a010_Saido__c,
           java.lang.String a010_Shisaku__c,
           java.lang.String a010_ShuekiShurui1__c,
           java.lang.String a010_ShuekiShurui2__c,
           java.lang.Double a010_Shuekigaku__c,
           java.util.Date a010_YoteizukiHizuke__c,
           java.lang.Double a010_YoteizukiInt__c,
           java.lang.String a010_Yoteizuki__c,
           java.lang.String a014_AnkenShurui__c,
           java.util.Date a014_CaseCloseDate__c,
           java.lang.Boolean a014_ChokusetsuSoshutsu__c,
           java.util.Date a014_DecisionDate__c,
           java.lang.String a014_DecisionMeeting__c,
           java.lang.String a014_Kakudo__c,
           java.lang.String a014_Outline__c,
           java.lang.String a014_RelateState1__c,
           java.lang.String a014_RelateState2__c,
           java.lang.String a014_RelateState3__c,
           java.lang.String a014_RelateTeam__c,
           java.lang.Double a014_RenketsuShueki__c,
           java.lang.Double a014_ShuekiAmount__c,
           java.lang.Double a014_TantaiShueki__c,
           java.lang.String a014_TantouTeam1__c,
           java.lang.String a014_TantouTeam2__c,
           java.lang.String a014_TantouTeam3__c,
           java.lang.String a014_Tantousha1__c,
           java.lang.String a014_Tantousha2__c,
           java.lang.String a014_Tantousha3__c,
           java.lang.String a015_AnkenCategory__c,
           java.lang.String a015_AnkenShubetsu__c,
           java.lang.Boolean a015_RisihokyuuSeido__c,
           java.lang.String a015_ToushiBasyo__c,
           java.lang.Double a015_ToushiKingaku__c,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.Boolean c002_AllowedChangeCustomer__c,
           java.lang.Double c002_Amount2__c,
           java.lang.Double c002_Amount3__c,
           java.lang.Double c002_Amount__c,
           java.lang.String c002_AppName__c,
           java.lang.String c002_CRM_AnkenId__c,
           java.lang.String c002_CaseId__c,
           java.lang.String c002_CaseName__c,
           com.sforce.soap.enterprise.QueryResult c002_Cases_01__r,
           java.lang.String c002_CsvLastModifiedDate__c,
           java.lang.String c002_CsvRecordTantou__c,
           java.lang.String c002_CustomerId__c,
           java.lang.String c002_CustomerName__c,
           java.lang.String c002_CustomerRef__c,
           com.sforce.soap.enterprise.sobject.C001_Customer__c c002_CustomerRef__r,
           java.util.Date c002_Date1__c,
           java.util.Date c002_DateFrom__c,
           java.util.Date c002_DateTo__c,
           java.lang.String c002_Detail__c,
           java.lang.String c002_Kakudo1__c,
           java.lang.String c002_Kakudo2__c,
           java.lang.String c002_KyotenName__c,
           java.lang.String c002_Outline__c,
           java.lang.Double c002_ProfitRenketsu__c,
           java.lang.Double c002_ProfitTantai__c,
           java.lang.String c002_RMTanto__c,
           java.lang.String c002_RecordTantouButenName__c,
           java.lang.String c002_RecordTantou__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_RecordTantou__r,
           java.lang.String c002_RecordTypeName2__c,
           java.lang.String c002_RelatedTaskID__c,
           java.lang.String c002_RevenueDivision__c,
           java.lang.String c002_Shinmitsudo__c,
           java.lang.String c002_TantobuTemban__c,
           java.lang.String c002_Tantou01_Group__c,
           java.lang.String c002_Tantou01_Name__c,
           java.lang.String c002_Tantou02_Group__c,
           java.lang.String c002_Tantou02_Name__c,
           java.lang.String c002_Tantou03_Group__c,
           java.lang.String c002_Tantou03_Name__c,
           java.lang.String c002_Tantou04_Group__c,
           java.lang.String c002_Tantou04_Name__c,
           java.lang.String c002_Tantou_01__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_01__r,
           java.lang.String c002_Tantou_02__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_02__r,
           java.lang.String c002_Tantou_03__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_03__r,
           java.lang.String c002_Tantou_04__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_04__r,
           java.lang.String c002_Tantou_05__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_05__r,
           java.lang.String c002_Tantou_Kensaku__c,
           java.lang.String c002_TembanCif__c,
           java.lang.String c002_TokoKakuzuke__c,
           java.lang.String c002_Work__c,
           java.lang.String c002_YomikomiNo__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.util.Calendar lastReferencedDate,
           java.util.Calendar lastViewedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           com.sforce.soap.enterprise.sobject.RecordType recordType,
           java.lang.String recordTypeId,
           com.sforce.soap.enterprise.QueryResult shares,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        super(
            fieldsToNull,
            id);
        this.a010_ActionPlan__c = a010_ActionPlan__c;
        this.a010_AnkenShudousha__c = a010_AnkenShudousha__c;
        this.a010_AnkenShurui1__c = a010_AnkenShurui1__c;
        this.a010_AnkenShurui2__c = a010_AnkenShurui2__c;
        this.a010_AnkenShurui3__c = a010_AnkenShurui3__c;
        this.a010_Bikou__c = a010_Bikou__c;
        this.a010_CaseId__c = a010_CaseId__c;
        this.a010_Country__c = a010_Country__c;
        this.a010_CsvTantou_01__c = a010_CsvTantou_01__c;
        this.a010_GBADUnit__c = a010_GBADUnit__c;
        this.a010_Group__c = a010_Group__c;
        this.a010_Kakudo__c = a010_Kakudo__c;
        this.a010_KankeiBusho1__c = a010_KankeiBusho1__c;
        this.a010_KankeiBusho2__c = a010_KankeiBusho2__c;
        this.a010_Kekka__c = a010_Kekka__c;
        this.a010_RenkeiKaigaiKyoten1__c = a010_RenkeiKaigaiKyoten1__c;
        this.a010_RenkeiKaigaiKyoten2__c = a010_RenkeiKaigaiKyoten2__c;
        this.a010_Saido__c = a010_Saido__c;
        this.a010_Shisaku__c = a010_Shisaku__c;
        this.a010_ShuekiShurui1__c = a010_ShuekiShurui1__c;
        this.a010_ShuekiShurui2__c = a010_ShuekiShurui2__c;
        this.a010_Shuekigaku__c = a010_Shuekigaku__c;
        this.a010_YoteizukiHizuke__c = a010_YoteizukiHizuke__c;
        this.a010_YoteizukiInt__c = a010_YoteizukiInt__c;
        this.a010_Yoteizuki__c = a010_Yoteizuki__c;
        this.a014_AnkenShurui__c = a014_AnkenShurui__c;
        this.a014_CaseCloseDate__c = a014_CaseCloseDate__c;
        this.a014_ChokusetsuSoshutsu__c = a014_ChokusetsuSoshutsu__c;
        this.a014_DecisionDate__c = a014_DecisionDate__c;
        this.a014_DecisionMeeting__c = a014_DecisionMeeting__c;
        this.a014_Kakudo__c = a014_Kakudo__c;
        this.a014_Outline__c = a014_Outline__c;
        this.a014_RelateState1__c = a014_RelateState1__c;
        this.a014_RelateState2__c = a014_RelateState2__c;
        this.a014_RelateState3__c = a014_RelateState3__c;
        this.a014_RelateTeam__c = a014_RelateTeam__c;
        this.a014_RenketsuShueki__c = a014_RenketsuShueki__c;
        this.a014_ShuekiAmount__c = a014_ShuekiAmount__c;
        this.a014_TantaiShueki__c = a014_TantaiShueki__c;
        this.a014_TantouTeam1__c = a014_TantouTeam1__c;
        this.a014_TantouTeam2__c = a014_TantouTeam2__c;
        this.a014_TantouTeam3__c = a014_TantouTeam3__c;
        this.a014_Tantousha1__c = a014_Tantousha1__c;
        this.a014_Tantousha2__c = a014_Tantousha2__c;
        this.a014_Tantousha3__c = a014_Tantousha3__c;
        this.a015_AnkenCategory__c = a015_AnkenCategory__c;
        this.a015_AnkenShubetsu__c = a015_AnkenShubetsu__c;
        this.a015_RisihokyuuSeido__c = a015_RisihokyuuSeido__c;
        this.a015_ToushiBasyo__c = a015_ToushiBasyo__c;
        this.a015_ToushiKingaku__c = a015_ToushiKingaku__c;
        this.attachments = attachments;
        this.c002_AllowedChangeCustomer__c = c002_AllowedChangeCustomer__c;
        this.c002_Amount2__c = c002_Amount2__c;
        this.c002_Amount3__c = c002_Amount3__c;
        this.c002_Amount__c = c002_Amount__c;
        this.c002_AppName__c = c002_AppName__c;
        this.c002_CRM_AnkenId__c = c002_CRM_AnkenId__c;
        this.c002_CaseId__c = c002_CaseId__c;
        this.c002_CaseName__c = c002_CaseName__c;
        this.c002_Cases_01__r = c002_Cases_01__r;
        this.c002_CsvLastModifiedDate__c = c002_CsvLastModifiedDate__c;
        this.c002_CsvRecordTantou__c = c002_CsvRecordTantou__c;
        this.c002_CustomerId__c = c002_CustomerId__c;
        this.c002_CustomerName__c = c002_CustomerName__c;
        this.c002_CustomerRef__c = c002_CustomerRef__c;
        this.c002_CustomerRef__r = c002_CustomerRef__r;
        this.c002_Date1__c = c002_Date1__c;
        this.c002_DateFrom__c = c002_DateFrom__c;
        this.c002_DateTo__c = c002_DateTo__c;
        this.c002_Detail__c = c002_Detail__c;
        this.c002_Kakudo1__c = c002_Kakudo1__c;
        this.c002_Kakudo2__c = c002_Kakudo2__c;
        this.c002_KyotenName__c = c002_KyotenName__c;
        this.c002_Outline__c = c002_Outline__c;
        this.c002_ProfitRenketsu__c = c002_ProfitRenketsu__c;
        this.c002_ProfitTantai__c = c002_ProfitTantai__c;
        this.c002_RMTanto__c = c002_RMTanto__c;
        this.c002_RecordTantouButenName__c = c002_RecordTantouButenName__c;
        this.c002_RecordTantou__c = c002_RecordTantou__c;
        this.c002_RecordTantou__r = c002_RecordTantou__r;
        this.c002_RecordTypeName2__c = c002_RecordTypeName2__c;
        this.c002_RelatedTaskID__c = c002_RelatedTaskID__c;
        this.c002_RevenueDivision__c = c002_RevenueDivision__c;
        this.c002_Shinmitsudo__c = c002_Shinmitsudo__c;
        this.c002_TantobuTemban__c = c002_TantobuTemban__c;
        this.c002_Tantou01_Group__c = c002_Tantou01_Group__c;
        this.c002_Tantou01_Name__c = c002_Tantou01_Name__c;
        this.c002_Tantou02_Group__c = c002_Tantou02_Group__c;
        this.c002_Tantou02_Name__c = c002_Tantou02_Name__c;
        this.c002_Tantou03_Group__c = c002_Tantou03_Group__c;
        this.c002_Tantou03_Name__c = c002_Tantou03_Name__c;
        this.c002_Tantou04_Group__c = c002_Tantou04_Group__c;
        this.c002_Tantou04_Name__c = c002_Tantou04_Name__c;
        this.c002_Tantou_01__c = c002_Tantou_01__c;
        this.c002_Tantou_01__r = c002_Tantou_01__r;
        this.c002_Tantou_02__c = c002_Tantou_02__c;
        this.c002_Tantou_02__r = c002_Tantou_02__r;
        this.c002_Tantou_03__c = c002_Tantou_03__c;
        this.c002_Tantou_03__r = c002_Tantou_03__r;
        this.c002_Tantou_04__c = c002_Tantou_04__c;
        this.c002_Tantou_04__r = c002_Tantou_04__r;
        this.c002_Tantou_05__c = c002_Tantou_05__c;
        this.c002_Tantou_05__r = c002_Tantou_05__r;
        this.c002_Tantou_Kensaku__c = c002_Tantou_Kensaku__c;
        this.c002_TembanCif__c = c002_TembanCif__c;
        this.c002_TokoKakuzuke__c = c002_TokoKakuzuke__c;
        this.c002_Work__c = c002_Work__c;
        this.c002_YomikomiNo__c = c002_YomikomiNo__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.duplicateRecordItems = duplicateRecordItems;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lastReferencedDate = lastReferencedDate;
        this.lastViewedDate = lastViewedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.recordType = recordType;
        this.recordTypeId = recordTypeId;
        this.shares = shares;
        this.systemModstamp = systemModstamp;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the a010_ActionPlan__c value for this C002_Case__c.
     * 
     * @return a010_ActionPlan__c
     */
    public java.lang.String getA010_ActionPlan__c() {
        return a010_ActionPlan__c;
    }


    /**
     * Sets the a010_ActionPlan__c value for this C002_Case__c.
     * 
     * @param a010_ActionPlan__c
     */
    public void setA010_ActionPlan__c(java.lang.String a010_ActionPlan__c) {
        this.a010_ActionPlan__c = a010_ActionPlan__c;
    }


    /**
     * Gets the a010_AnkenShudousha__c value for this C002_Case__c.
     * 
     * @return a010_AnkenShudousha__c
     */
    public java.lang.String getA010_AnkenShudousha__c() {
        return a010_AnkenShudousha__c;
    }


    /**
     * Sets the a010_AnkenShudousha__c value for this C002_Case__c.
     * 
     * @param a010_AnkenShudousha__c
     */
    public void setA010_AnkenShudousha__c(java.lang.String a010_AnkenShudousha__c) {
        this.a010_AnkenShudousha__c = a010_AnkenShudousha__c;
    }


    /**
     * Gets the a010_AnkenShurui1__c value for this C002_Case__c.
     * 
     * @return a010_AnkenShurui1__c
     */
    public java.lang.String getA010_AnkenShurui1__c() {
        return a010_AnkenShurui1__c;
    }


    /**
     * Sets the a010_AnkenShurui1__c value for this C002_Case__c.
     * 
     * @param a010_AnkenShurui1__c
     */
    public void setA010_AnkenShurui1__c(java.lang.String a010_AnkenShurui1__c) {
        this.a010_AnkenShurui1__c = a010_AnkenShurui1__c;
    }


    /**
     * Gets the a010_AnkenShurui2__c value for this C002_Case__c.
     * 
     * @return a010_AnkenShurui2__c
     */
    public java.lang.String getA010_AnkenShurui2__c() {
        return a010_AnkenShurui2__c;
    }


    /**
     * Sets the a010_AnkenShurui2__c value for this C002_Case__c.
     * 
     * @param a010_AnkenShurui2__c
     */
    public void setA010_AnkenShurui2__c(java.lang.String a010_AnkenShurui2__c) {
        this.a010_AnkenShurui2__c = a010_AnkenShurui2__c;
    }


    /**
     * Gets the a010_AnkenShurui3__c value for this C002_Case__c.
     * 
     * @return a010_AnkenShurui3__c
     */
    public java.lang.String getA010_AnkenShurui3__c() {
        return a010_AnkenShurui3__c;
    }


    /**
     * Sets the a010_AnkenShurui3__c value for this C002_Case__c.
     * 
     * @param a010_AnkenShurui3__c
     */
    public void setA010_AnkenShurui3__c(java.lang.String a010_AnkenShurui3__c) {
        this.a010_AnkenShurui3__c = a010_AnkenShurui3__c;
    }


    /**
     * Gets the a010_Bikou__c value for this C002_Case__c.
     * 
     * @return a010_Bikou__c
     */
    public java.lang.String getA010_Bikou__c() {
        return a010_Bikou__c;
    }


    /**
     * Sets the a010_Bikou__c value for this C002_Case__c.
     * 
     * @param a010_Bikou__c
     */
    public void setA010_Bikou__c(java.lang.String a010_Bikou__c) {
        this.a010_Bikou__c = a010_Bikou__c;
    }


    /**
     * Gets the a010_CaseId__c value for this C002_Case__c.
     * 
     * @return a010_CaseId__c
     */
    public java.lang.String getA010_CaseId__c() {
        return a010_CaseId__c;
    }


    /**
     * Sets the a010_CaseId__c value for this C002_Case__c.
     * 
     * @param a010_CaseId__c
     */
    public void setA010_CaseId__c(java.lang.String a010_CaseId__c) {
        this.a010_CaseId__c = a010_CaseId__c;
    }


    /**
     * Gets the a010_Country__c value for this C002_Case__c.
     * 
     * @return a010_Country__c
     */
    public java.lang.String getA010_Country__c() {
        return a010_Country__c;
    }


    /**
     * Sets the a010_Country__c value for this C002_Case__c.
     * 
     * @param a010_Country__c
     */
    public void setA010_Country__c(java.lang.String a010_Country__c) {
        this.a010_Country__c = a010_Country__c;
    }


    /**
     * Gets the a010_CsvTantou_01__c value for this C002_Case__c.
     * 
     * @return a010_CsvTantou_01__c
     */
    public java.lang.String getA010_CsvTantou_01__c() {
        return a010_CsvTantou_01__c;
    }


    /**
     * Sets the a010_CsvTantou_01__c value for this C002_Case__c.
     * 
     * @param a010_CsvTantou_01__c
     */
    public void setA010_CsvTantou_01__c(java.lang.String a010_CsvTantou_01__c) {
        this.a010_CsvTantou_01__c = a010_CsvTantou_01__c;
    }


    /**
     * Gets the a010_GBADUnit__c value for this C002_Case__c.
     * 
     * @return a010_GBADUnit__c
     */
    public java.lang.String getA010_GBADUnit__c() {
        return a010_GBADUnit__c;
    }


    /**
     * Sets the a010_GBADUnit__c value for this C002_Case__c.
     * 
     * @param a010_GBADUnit__c
     */
    public void setA010_GBADUnit__c(java.lang.String a010_GBADUnit__c) {
        this.a010_GBADUnit__c = a010_GBADUnit__c;
    }


    /**
     * Gets the a010_Group__c value for this C002_Case__c.
     * 
     * @return a010_Group__c
     */
    public java.lang.String getA010_Group__c() {
        return a010_Group__c;
    }


    /**
     * Sets the a010_Group__c value for this C002_Case__c.
     * 
     * @param a010_Group__c
     */
    public void setA010_Group__c(java.lang.String a010_Group__c) {
        this.a010_Group__c = a010_Group__c;
    }


    /**
     * Gets the a010_Kakudo__c value for this C002_Case__c.
     * 
     * @return a010_Kakudo__c
     */
    public java.lang.String getA010_Kakudo__c() {
        return a010_Kakudo__c;
    }


    /**
     * Sets the a010_Kakudo__c value for this C002_Case__c.
     * 
     * @param a010_Kakudo__c
     */
    public void setA010_Kakudo__c(java.lang.String a010_Kakudo__c) {
        this.a010_Kakudo__c = a010_Kakudo__c;
    }


    /**
     * Gets the a010_KankeiBusho1__c value for this C002_Case__c.
     * 
     * @return a010_KankeiBusho1__c
     */
    public java.lang.String getA010_KankeiBusho1__c() {
        return a010_KankeiBusho1__c;
    }


    /**
     * Sets the a010_KankeiBusho1__c value for this C002_Case__c.
     * 
     * @param a010_KankeiBusho1__c
     */
    public void setA010_KankeiBusho1__c(java.lang.String a010_KankeiBusho1__c) {
        this.a010_KankeiBusho1__c = a010_KankeiBusho1__c;
    }


    /**
     * Gets the a010_KankeiBusho2__c value for this C002_Case__c.
     * 
     * @return a010_KankeiBusho2__c
     */
    public java.lang.String getA010_KankeiBusho2__c() {
        return a010_KankeiBusho2__c;
    }


    /**
     * Sets the a010_KankeiBusho2__c value for this C002_Case__c.
     * 
     * @param a010_KankeiBusho2__c
     */
    public void setA010_KankeiBusho2__c(java.lang.String a010_KankeiBusho2__c) {
        this.a010_KankeiBusho2__c = a010_KankeiBusho2__c;
    }


    /**
     * Gets the a010_Kekka__c value for this C002_Case__c.
     * 
     * @return a010_Kekka__c
     */
    public java.lang.String getA010_Kekka__c() {
        return a010_Kekka__c;
    }


    /**
     * Sets the a010_Kekka__c value for this C002_Case__c.
     * 
     * @param a010_Kekka__c
     */
    public void setA010_Kekka__c(java.lang.String a010_Kekka__c) {
        this.a010_Kekka__c = a010_Kekka__c;
    }


    /**
     * Gets the a010_RenkeiKaigaiKyoten1__c value for this C002_Case__c.
     * 
     * @return a010_RenkeiKaigaiKyoten1__c
     */
    public java.lang.String getA010_RenkeiKaigaiKyoten1__c() {
        return a010_RenkeiKaigaiKyoten1__c;
    }


    /**
     * Sets the a010_RenkeiKaigaiKyoten1__c value for this C002_Case__c.
     * 
     * @param a010_RenkeiKaigaiKyoten1__c
     */
    public void setA010_RenkeiKaigaiKyoten1__c(java.lang.String a010_RenkeiKaigaiKyoten1__c) {
        this.a010_RenkeiKaigaiKyoten1__c = a010_RenkeiKaigaiKyoten1__c;
    }


    /**
     * Gets the a010_RenkeiKaigaiKyoten2__c value for this C002_Case__c.
     * 
     * @return a010_RenkeiKaigaiKyoten2__c
     */
    public java.lang.String getA010_RenkeiKaigaiKyoten2__c() {
        return a010_RenkeiKaigaiKyoten2__c;
    }


    /**
     * Sets the a010_RenkeiKaigaiKyoten2__c value for this C002_Case__c.
     * 
     * @param a010_RenkeiKaigaiKyoten2__c
     */
    public void setA010_RenkeiKaigaiKyoten2__c(java.lang.String a010_RenkeiKaigaiKyoten2__c) {
        this.a010_RenkeiKaigaiKyoten2__c = a010_RenkeiKaigaiKyoten2__c;
    }


    /**
     * Gets the a010_Saido__c value for this C002_Case__c.
     * 
     * @return a010_Saido__c
     */
    public java.lang.String getA010_Saido__c() {
        return a010_Saido__c;
    }


    /**
     * Sets the a010_Saido__c value for this C002_Case__c.
     * 
     * @param a010_Saido__c
     */
    public void setA010_Saido__c(java.lang.String a010_Saido__c) {
        this.a010_Saido__c = a010_Saido__c;
    }


    /**
     * Gets the a010_Shisaku__c value for this C002_Case__c.
     * 
     * @return a010_Shisaku__c
     */
    public java.lang.String getA010_Shisaku__c() {
        return a010_Shisaku__c;
    }


    /**
     * Sets the a010_Shisaku__c value for this C002_Case__c.
     * 
     * @param a010_Shisaku__c
     */
    public void setA010_Shisaku__c(java.lang.String a010_Shisaku__c) {
        this.a010_Shisaku__c = a010_Shisaku__c;
    }


    /**
     * Gets the a010_ShuekiShurui1__c value for this C002_Case__c.
     * 
     * @return a010_ShuekiShurui1__c
     */
    public java.lang.String getA010_ShuekiShurui1__c() {
        return a010_ShuekiShurui1__c;
    }


    /**
     * Sets the a010_ShuekiShurui1__c value for this C002_Case__c.
     * 
     * @param a010_ShuekiShurui1__c
     */
    public void setA010_ShuekiShurui1__c(java.lang.String a010_ShuekiShurui1__c) {
        this.a010_ShuekiShurui1__c = a010_ShuekiShurui1__c;
    }


    /**
     * Gets the a010_ShuekiShurui2__c value for this C002_Case__c.
     * 
     * @return a010_ShuekiShurui2__c
     */
    public java.lang.String getA010_ShuekiShurui2__c() {
        return a010_ShuekiShurui2__c;
    }


    /**
     * Sets the a010_ShuekiShurui2__c value for this C002_Case__c.
     * 
     * @param a010_ShuekiShurui2__c
     */
    public void setA010_ShuekiShurui2__c(java.lang.String a010_ShuekiShurui2__c) {
        this.a010_ShuekiShurui2__c = a010_ShuekiShurui2__c;
    }


    /**
     * Gets the a010_Shuekigaku__c value for this C002_Case__c.
     * 
     * @return a010_Shuekigaku__c
     */
    public java.lang.Double getA010_Shuekigaku__c() {
        return a010_Shuekigaku__c;
    }


    /**
     * Sets the a010_Shuekigaku__c value for this C002_Case__c.
     * 
     * @param a010_Shuekigaku__c
     */
    public void setA010_Shuekigaku__c(java.lang.Double a010_Shuekigaku__c) {
        this.a010_Shuekigaku__c = a010_Shuekigaku__c;
    }


    /**
     * Gets the a010_YoteizukiHizuke__c value for this C002_Case__c.
     * 
     * @return a010_YoteizukiHizuke__c
     */
    public java.util.Date getA010_YoteizukiHizuke__c() {
        return a010_YoteizukiHizuke__c;
    }


    /**
     * Sets the a010_YoteizukiHizuke__c value for this C002_Case__c.
     * 
     * @param a010_YoteizukiHizuke__c
     */
    public void setA010_YoteizukiHizuke__c(java.util.Date a010_YoteizukiHizuke__c) {
        this.a010_YoteizukiHizuke__c = a010_YoteizukiHizuke__c;
    }


    /**
     * Gets the a010_YoteizukiInt__c value for this C002_Case__c.
     * 
     * @return a010_YoteizukiInt__c
     */
    public java.lang.Double getA010_YoteizukiInt__c() {
        return a010_YoteizukiInt__c;
    }


    /**
     * Sets the a010_YoteizukiInt__c value for this C002_Case__c.
     * 
     * @param a010_YoteizukiInt__c
     */
    public void setA010_YoteizukiInt__c(java.lang.Double a010_YoteizukiInt__c) {
        this.a010_YoteizukiInt__c = a010_YoteizukiInt__c;
    }


    /**
     * Gets the a010_Yoteizuki__c value for this C002_Case__c.
     * 
     * @return a010_Yoteizuki__c
     */
    public java.lang.String getA010_Yoteizuki__c() {
        return a010_Yoteizuki__c;
    }


    /**
     * Sets the a010_Yoteizuki__c value for this C002_Case__c.
     * 
     * @param a010_Yoteizuki__c
     */
    public void setA010_Yoteizuki__c(java.lang.String a010_Yoteizuki__c) {
        this.a010_Yoteizuki__c = a010_Yoteizuki__c;
    }


    /**
     * Gets the a014_AnkenShurui__c value for this C002_Case__c.
     * 
     * @return a014_AnkenShurui__c
     */
    public java.lang.String getA014_AnkenShurui__c() {
        return a014_AnkenShurui__c;
    }


    /**
     * Sets the a014_AnkenShurui__c value for this C002_Case__c.
     * 
     * @param a014_AnkenShurui__c
     */
    public void setA014_AnkenShurui__c(java.lang.String a014_AnkenShurui__c) {
        this.a014_AnkenShurui__c = a014_AnkenShurui__c;
    }


    /**
     * Gets the a014_CaseCloseDate__c value for this C002_Case__c.
     * 
     * @return a014_CaseCloseDate__c
     */
    public java.util.Date getA014_CaseCloseDate__c() {
        return a014_CaseCloseDate__c;
    }


    /**
     * Sets the a014_CaseCloseDate__c value for this C002_Case__c.
     * 
     * @param a014_CaseCloseDate__c
     */
    public void setA014_CaseCloseDate__c(java.util.Date a014_CaseCloseDate__c) {
        this.a014_CaseCloseDate__c = a014_CaseCloseDate__c;
    }


    /**
     * Gets the a014_ChokusetsuSoshutsu__c value for this C002_Case__c.
     * 
     * @return a014_ChokusetsuSoshutsu__c
     */
    public java.lang.Boolean getA014_ChokusetsuSoshutsu__c() {
        return a014_ChokusetsuSoshutsu__c;
    }


    /**
     * Sets the a014_ChokusetsuSoshutsu__c value for this C002_Case__c.
     * 
     * @param a014_ChokusetsuSoshutsu__c
     */
    public void setA014_ChokusetsuSoshutsu__c(java.lang.Boolean a014_ChokusetsuSoshutsu__c) {
        this.a014_ChokusetsuSoshutsu__c = a014_ChokusetsuSoshutsu__c;
    }


    /**
     * Gets the a014_DecisionDate__c value for this C002_Case__c.
     * 
     * @return a014_DecisionDate__c
     */
    public java.util.Date getA014_DecisionDate__c() {
        return a014_DecisionDate__c;
    }


    /**
     * Sets the a014_DecisionDate__c value for this C002_Case__c.
     * 
     * @param a014_DecisionDate__c
     */
    public void setA014_DecisionDate__c(java.util.Date a014_DecisionDate__c) {
        this.a014_DecisionDate__c = a014_DecisionDate__c;
    }


    /**
     * Gets the a014_DecisionMeeting__c value for this C002_Case__c.
     * 
     * @return a014_DecisionMeeting__c
     */
    public java.lang.String getA014_DecisionMeeting__c() {
        return a014_DecisionMeeting__c;
    }


    /**
     * Sets the a014_DecisionMeeting__c value for this C002_Case__c.
     * 
     * @param a014_DecisionMeeting__c
     */
    public void setA014_DecisionMeeting__c(java.lang.String a014_DecisionMeeting__c) {
        this.a014_DecisionMeeting__c = a014_DecisionMeeting__c;
    }


    /**
     * Gets the a014_Kakudo__c value for this C002_Case__c.
     * 
     * @return a014_Kakudo__c
     */
    public java.lang.String getA014_Kakudo__c() {
        return a014_Kakudo__c;
    }


    /**
     * Sets the a014_Kakudo__c value for this C002_Case__c.
     * 
     * @param a014_Kakudo__c
     */
    public void setA014_Kakudo__c(java.lang.String a014_Kakudo__c) {
        this.a014_Kakudo__c = a014_Kakudo__c;
    }


    /**
     * Gets the a014_Outline__c value for this C002_Case__c.
     * 
     * @return a014_Outline__c
     */
    public java.lang.String getA014_Outline__c() {
        return a014_Outline__c;
    }


    /**
     * Sets the a014_Outline__c value for this C002_Case__c.
     * 
     * @param a014_Outline__c
     */
    public void setA014_Outline__c(java.lang.String a014_Outline__c) {
        this.a014_Outline__c = a014_Outline__c;
    }


    /**
     * Gets the a014_RelateState1__c value for this C002_Case__c.
     * 
     * @return a014_RelateState1__c
     */
    public java.lang.String getA014_RelateState1__c() {
        return a014_RelateState1__c;
    }


    /**
     * Sets the a014_RelateState1__c value for this C002_Case__c.
     * 
     * @param a014_RelateState1__c
     */
    public void setA014_RelateState1__c(java.lang.String a014_RelateState1__c) {
        this.a014_RelateState1__c = a014_RelateState1__c;
    }


    /**
     * Gets the a014_RelateState2__c value for this C002_Case__c.
     * 
     * @return a014_RelateState2__c
     */
    public java.lang.String getA014_RelateState2__c() {
        return a014_RelateState2__c;
    }


    /**
     * Sets the a014_RelateState2__c value for this C002_Case__c.
     * 
     * @param a014_RelateState2__c
     */
    public void setA014_RelateState2__c(java.lang.String a014_RelateState2__c) {
        this.a014_RelateState2__c = a014_RelateState2__c;
    }


    /**
     * Gets the a014_RelateState3__c value for this C002_Case__c.
     * 
     * @return a014_RelateState3__c
     */
    public java.lang.String getA014_RelateState3__c() {
        return a014_RelateState3__c;
    }


    /**
     * Sets the a014_RelateState3__c value for this C002_Case__c.
     * 
     * @param a014_RelateState3__c
     */
    public void setA014_RelateState3__c(java.lang.String a014_RelateState3__c) {
        this.a014_RelateState3__c = a014_RelateState3__c;
    }


    /**
     * Gets the a014_RelateTeam__c value for this C002_Case__c.
     * 
     * @return a014_RelateTeam__c
     */
    public java.lang.String getA014_RelateTeam__c() {
        return a014_RelateTeam__c;
    }


    /**
     * Sets the a014_RelateTeam__c value for this C002_Case__c.
     * 
     * @param a014_RelateTeam__c
     */
    public void setA014_RelateTeam__c(java.lang.String a014_RelateTeam__c) {
        this.a014_RelateTeam__c = a014_RelateTeam__c;
    }


    /**
     * Gets the a014_RenketsuShueki__c value for this C002_Case__c.
     * 
     * @return a014_RenketsuShueki__c
     */
    public java.lang.Double getA014_RenketsuShueki__c() {
        return a014_RenketsuShueki__c;
    }


    /**
     * Sets the a014_RenketsuShueki__c value for this C002_Case__c.
     * 
     * @param a014_RenketsuShueki__c
     */
    public void setA014_RenketsuShueki__c(java.lang.Double a014_RenketsuShueki__c) {
        this.a014_RenketsuShueki__c = a014_RenketsuShueki__c;
    }


    /**
     * Gets the a014_ShuekiAmount__c value for this C002_Case__c.
     * 
     * @return a014_ShuekiAmount__c
     */
    public java.lang.Double getA014_ShuekiAmount__c() {
        return a014_ShuekiAmount__c;
    }


    /**
     * Sets the a014_ShuekiAmount__c value for this C002_Case__c.
     * 
     * @param a014_ShuekiAmount__c
     */
    public void setA014_ShuekiAmount__c(java.lang.Double a014_ShuekiAmount__c) {
        this.a014_ShuekiAmount__c = a014_ShuekiAmount__c;
    }


    /**
     * Gets the a014_TantaiShueki__c value for this C002_Case__c.
     * 
     * @return a014_TantaiShueki__c
     */
    public java.lang.Double getA014_TantaiShueki__c() {
        return a014_TantaiShueki__c;
    }


    /**
     * Sets the a014_TantaiShueki__c value for this C002_Case__c.
     * 
     * @param a014_TantaiShueki__c
     */
    public void setA014_TantaiShueki__c(java.lang.Double a014_TantaiShueki__c) {
        this.a014_TantaiShueki__c = a014_TantaiShueki__c;
    }


    /**
     * Gets the a014_TantouTeam1__c value for this C002_Case__c.
     * 
     * @return a014_TantouTeam1__c
     */
    public java.lang.String getA014_TantouTeam1__c() {
        return a014_TantouTeam1__c;
    }


    /**
     * Sets the a014_TantouTeam1__c value for this C002_Case__c.
     * 
     * @param a014_TantouTeam1__c
     */
    public void setA014_TantouTeam1__c(java.lang.String a014_TantouTeam1__c) {
        this.a014_TantouTeam1__c = a014_TantouTeam1__c;
    }


    /**
     * Gets the a014_TantouTeam2__c value for this C002_Case__c.
     * 
     * @return a014_TantouTeam2__c
     */
    public java.lang.String getA014_TantouTeam2__c() {
        return a014_TantouTeam2__c;
    }


    /**
     * Sets the a014_TantouTeam2__c value for this C002_Case__c.
     * 
     * @param a014_TantouTeam2__c
     */
    public void setA014_TantouTeam2__c(java.lang.String a014_TantouTeam2__c) {
        this.a014_TantouTeam2__c = a014_TantouTeam2__c;
    }


    /**
     * Gets the a014_TantouTeam3__c value for this C002_Case__c.
     * 
     * @return a014_TantouTeam3__c
     */
    public java.lang.String getA014_TantouTeam3__c() {
        return a014_TantouTeam3__c;
    }


    /**
     * Sets the a014_TantouTeam3__c value for this C002_Case__c.
     * 
     * @param a014_TantouTeam3__c
     */
    public void setA014_TantouTeam3__c(java.lang.String a014_TantouTeam3__c) {
        this.a014_TantouTeam3__c = a014_TantouTeam3__c;
    }


    /**
     * Gets the a014_Tantousha1__c value for this C002_Case__c.
     * 
     * @return a014_Tantousha1__c
     */
    public java.lang.String getA014_Tantousha1__c() {
        return a014_Tantousha1__c;
    }


    /**
     * Sets the a014_Tantousha1__c value for this C002_Case__c.
     * 
     * @param a014_Tantousha1__c
     */
    public void setA014_Tantousha1__c(java.lang.String a014_Tantousha1__c) {
        this.a014_Tantousha1__c = a014_Tantousha1__c;
    }


    /**
     * Gets the a014_Tantousha2__c value for this C002_Case__c.
     * 
     * @return a014_Tantousha2__c
     */
    public java.lang.String getA014_Tantousha2__c() {
        return a014_Tantousha2__c;
    }


    /**
     * Sets the a014_Tantousha2__c value for this C002_Case__c.
     * 
     * @param a014_Tantousha2__c
     */
    public void setA014_Tantousha2__c(java.lang.String a014_Tantousha2__c) {
        this.a014_Tantousha2__c = a014_Tantousha2__c;
    }


    /**
     * Gets the a014_Tantousha3__c value for this C002_Case__c.
     * 
     * @return a014_Tantousha3__c
     */
    public java.lang.String getA014_Tantousha3__c() {
        return a014_Tantousha3__c;
    }


    /**
     * Sets the a014_Tantousha3__c value for this C002_Case__c.
     * 
     * @param a014_Tantousha3__c
     */
    public void setA014_Tantousha3__c(java.lang.String a014_Tantousha3__c) {
        this.a014_Tantousha3__c = a014_Tantousha3__c;
    }


    /**
     * Gets the a015_AnkenCategory__c value for this C002_Case__c.
     * 
     * @return a015_AnkenCategory__c
     */
    public java.lang.String getA015_AnkenCategory__c() {
        return a015_AnkenCategory__c;
    }


    /**
     * Sets the a015_AnkenCategory__c value for this C002_Case__c.
     * 
     * @param a015_AnkenCategory__c
     */
    public void setA015_AnkenCategory__c(java.lang.String a015_AnkenCategory__c) {
        this.a015_AnkenCategory__c = a015_AnkenCategory__c;
    }


    /**
     * Gets the a015_AnkenShubetsu__c value for this C002_Case__c.
     * 
     * @return a015_AnkenShubetsu__c
     */
    public java.lang.String getA015_AnkenShubetsu__c() {
        return a015_AnkenShubetsu__c;
    }


    /**
     * Sets the a015_AnkenShubetsu__c value for this C002_Case__c.
     * 
     * @param a015_AnkenShubetsu__c
     */
    public void setA015_AnkenShubetsu__c(java.lang.String a015_AnkenShubetsu__c) {
        this.a015_AnkenShubetsu__c = a015_AnkenShubetsu__c;
    }


    /**
     * Gets the a015_RisihokyuuSeido__c value for this C002_Case__c.
     * 
     * @return a015_RisihokyuuSeido__c
     */
    public java.lang.Boolean getA015_RisihokyuuSeido__c() {
        return a015_RisihokyuuSeido__c;
    }


    /**
     * Sets the a015_RisihokyuuSeido__c value for this C002_Case__c.
     * 
     * @param a015_RisihokyuuSeido__c
     */
    public void setA015_RisihokyuuSeido__c(java.lang.Boolean a015_RisihokyuuSeido__c) {
        this.a015_RisihokyuuSeido__c = a015_RisihokyuuSeido__c;
    }


    /**
     * Gets the a015_ToushiBasyo__c value for this C002_Case__c.
     * 
     * @return a015_ToushiBasyo__c
     */
    public java.lang.String getA015_ToushiBasyo__c() {
        return a015_ToushiBasyo__c;
    }


    /**
     * Sets the a015_ToushiBasyo__c value for this C002_Case__c.
     * 
     * @param a015_ToushiBasyo__c
     */
    public void setA015_ToushiBasyo__c(java.lang.String a015_ToushiBasyo__c) {
        this.a015_ToushiBasyo__c = a015_ToushiBasyo__c;
    }


    /**
     * Gets the a015_ToushiKingaku__c value for this C002_Case__c.
     * 
     * @return a015_ToushiKingaku__c
     */
    public java.lang.Double getA015_ToushiKingaku__c() {
        return a015_ToushiKingaku__c;
    }


    /**
     * Sets the a015_ToushiKingaku__c value for this C002_Case__c.
     * 
     * @param a015_ToushiKingaku__c
     */
    public void setA015_ToushiKingaku__c(java.lang.Double a015_ToushiKingaku__c) {
        this.a015_ToushiKingaku__c = a015_ToushiKingaku__c;
    }


    /**
     * Gets the attachments value for this C002_Case__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C002_Case__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the c002_AllowedChangeCustomer__c value for this C002_Case__c.
     * 
     * @return c002_AllowedChangeCustomer__c
     */
    public java.lang.Boolean getC002_AllowedChangeCustomer__c() {
        return c002_AllowedChangeCustomer__c;
    }


    /**
     * Sets the c002_AllowedChangeCustomer__c value for this C002_Case__c.
     * 
     * @param c002_AllowedChangeCustomer__c
     */
    public void setC002_AllowedChangeCustomer__c(java.lang.Boolean c002_AllowedChangeCustomer__c) {
        this.c002_AllowedChangeCustomer__c = c002_AllowedChangeCustomer__c;
    }


    /**
     * Gets the c002_Amount2__c value for this C002_Case__c.
     * 
     * @return c002_Amount2__c
     */
    public java.lang.Double getC002_Amount2__c() {
        return c002_Amount2__c;
    }


    /**
     * Sets the c002_Amount2__c value for this C002_Case__c.
     * 
     * @param c002_Amount2__c
     */
    public void setC002_Amount2__c(java.lang.Double c002_Amount2__c) {
        this.c002_Amount2__c = c002_Amount2__c;
    }


    /**
     * Gets the c002_Amount3__c value for this C002_Case__c.
     * 
     * @return c002_Amount3__c
     */
    public java.lang.Double getC002_Amount3__c() {
        return c002_Amount3__c;
    }


    /**
     * Sets the c002_Amount3__c value for this C002_Case__c.
     * 
     * @param c002_Amount3__c
     */
    public void setC002_Amount3__c(java.lang.Double c002_Amount3__c) {
        this.c002_Amount3__c = c002_Amount3__c;
    }


    /**
     * Gets the c002_Amount__c value for this C002_Case__c.
     * 
     * @return c002_Amount__c
     */
    public java.lang.Double getC002_Amount__c() {
        return c002_Amount__c;
    }


    /**
     * Sets the c002_Amount__c value for this C002_Case__c.
     * 
     * @param c002_Amount__c
     */
    public void setC002_Amount__c(java.lang.Double c002_Amount__c) {
        this.c002_Amount__c = c002_Amount__c;
    }


    /**
     * Gets the c002_AppName__c value for this C002_Case__c.
     * 
     * @return c002_AppName__c
     */
    public java.lang.String getC002_AppName__c() {
        return c002_AppName__c;
    }


    /**
     * Sets the c002_AppName__c value for this C002_Case__c.
     * 
     * @param c002_AppName__c
     */
    public void setC002_AppName__c(java.lang.String c002_AppName__c) {
        this.c002_AppName__c = c002_AppName__c;
    }


    /**
     * Gets the c002_CRM_AnkenId__c value for this C002_Case__c.
     * 
     * @return c002_CRM_AnkenId__c
     */
    public java.lang.String getC002_CRM_AnkenId__c() {
        return c002_CRM_AnkenId__c;
    }


    /**
     * Sets the c002_CRM_AnkenId__c value for this C002_Case__c.
     * 
     * @param c002_CRM_AnkenId__c
     */
    public void setC002_CRM_AnkenId__c(java.lang.String c002_CRM_AnkenId__c) {
        this.c002_CRM_AnkenId__c = c002_CRM_AnkenId__c;
    }


    /**
     * Gets the c002_CaseId__c value for this C002_Case__c.
     * 
     * @return c002_CaseId__c
     */
    public java.lang.String getC002_CaseId__c() {
        return c002_CaseId__c;
    }


    /**
     * Sets the c002_CaseId__c value for this C002_Case__c.
     * 
     * @param c002_CaseId__c
     */
    public void setC002_CaseId__c(java.lang.String c002_CaseId__c) {
        this.c002_CaseId__c = c002_CaseId__c;
    }


    /**
     * Gets the c002_CaseName__c value for this C002_Case__c.
     * 
     * @return c002_CaseName__c
     */
    public java.lang.String getC002_CaseName__c() {
        return c002_CaseName__c;
    }


    /**
     * Sets the c002_CaseName__c value for this C002_Case__c.
     * 
     * @param c002_CaseName__c
     */
    public void setC002_CaseName__c(java.lang.String c002_CaseName__c) {
        this.c002_CaseName__c = c002_CaseName__c;
    }


    /**
     * Gets the c002_Cases_01__r value for this C002_Case__c.
     * 
     * @return c002_Cases_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Cases_01__r() {
        return c002_Cases_01__r;
    }


    /**
     * Sets the c002_Cases_01__r value for this C002_Case__c.
     * 
     * @param c002_Cases_01__r
     */
    public void setC002_Cases_01__r(com.sforce.soap.enterprise.QueryResult c002_Cases_01__r) {
        this.c002_Cases_01__r = c002_Cases_01__r;
    }


    /**
     * Gets the c002_CsvLastModifiedDate__c value for this C002_Case__c.
     * 
     * @return c002_CsvLastModifiedDate__c
     */
    public java.lang.String getC002_CsvLastModifiedDate__c() {
        return c002_CsvLastModifiedDate__c;
    }


    /**
     * Sets the c002_CsvLastModifiedDate__c value for this C002_Case__c.
     * 
     * @param c002_CsvLastModifiedDate__c
     */
    public void setC002_CsvLastModifiedDate__c(java.lang.String c002_CsvLastModifiedDate__c) {
        this.c002_CsvLastModifiedDate__c = c002_CsvLastModifiedDate__c;
    }


    /**
     * Gets the c002_CsvRecordTantou__c value for this C002_Case__c.
     * 
     * @return c002_CsvRecordTantou__c
     */
    public java.lang.String getC002_CsvRecordTantou__c() {
        return c002_CsvRecordTantou__c;
    }


    /**
     * Sets the c002_CsvRecordTantou__c value for this C002_Case__c.
     * 
     * @param c002_CsvRecordTantou__c
     */
    public void setC002_CsvRecordTantou__c(java.lang.String c002_CsvRecordTantou__c) {
        this.c002_CsvRecordTantou__c = c002_CsvRecordTantou__c;
    }


    /**
     * Gets the c002_CustomerId__c value for this C002_Case__c.
     * 
     * @return c002_CustomerId__c
     */
    public java.lang.String getC002_CustomerId__c() {
        return c002_CustomerId__c;
    }


    /**
     * Sets the c002_CustomerId__c value for this C002_Case__c.
     * 
     * @param c002_CustomerId__c
     */
    public void setC002_CustomerId__c(java.lang.String c002_CustomerId__c) {
        this.c002_CustomerId__c = c002_CustomerId__c;
    }


    /**
     * Gets the c002_CustomerName__c value for this C002_Case__c.
     * 
     * @return c002_CustomerName__c
     */
    public java.lang.String getC002_CustomerName__c() {
        return c002_CustomerName__c;
    }


    /**
     * Sets the c002_CustomerName__c value for this C002_Case__c.
     * 
     * @param c002_CustomerName__c
     */
    public void setC002_CustomerName__c(java.lang.String c002_CustomerName__c) {
        this.c002_CustomerName__c = c002_CustomerName__c;
    }


    /**
     * Gets the c002_CustomerRef__c value for this C002_Case__c.
     * 
     * @return c002_CustomerRef__c
     */
    public java.lang.String getC002_CustomerRef__c() {
        return c002_CustomerRef__c;
    }


    /**
     * Sets the c002_CustomerRef__c value for this C002_Case__c.
     * 
     * @param c002_CustomerRef__c
     */
    public void setC002_CustomerRef__c(java.lang.String c002_CustomerRef__c) {
        this.c002_CustomerRef__c = c002_CustomerRef__c;
    }


    /**
     * Gets the c002_CustomerRef__r value for this C002_Case__c.
     * 
     * @return c002_CustomerRef__r
     */
    public com.sforce.soap.enterprise.sobject.C001_Customer__c getC002_CustomerRef__r() {
        return c002_CustomerRef__r;
    }


    /**
     * Sets the c002_CustomerRef__r value for this C002_Case__c.
     * 
     * @param c002_CustomerRef__r
     */
    public void setC002_CustomerRef__r(com.sforce.soap.enterprise.sobject.C001_Customer__c c002_CustomerRef__r) {
        this.c002_CustomerRef__r = c002_CustomerRef__r;
    }


    /**
     * Gets the c002_Date1__c value for this C002_Case__c.
     * 
     * @return c002_Date1__c
     */
    public java.util.Date getC002_Date1__c() {
        return c002_Date1__c;
    }


    /**
     * Sets the c002_Date1__c value for this C002_Case__c.
     * 
     * @param c002_Date1__c
     */
    public void setC002_Date1__c(java.util.Date c002_Date1__c) {
        this.c002_Date1__c = c002_Date1__c;
    }


    /**
     * Gets the c002_DateFrom__c value for this C002_Case__c.
     * 
     * @return c002_DateFrom__c
     */
    public java.util.Date getC002_DateFrom__c() {
        return c002_DateFrom__c;
    }


    /**
     * Sets the c002_DateFrom__c value for this C002_Case__c.
     * 
     * @param c002_DateFrom__c
     */
    public void setC002_DateFrom__c(java.util.Date c002_DateFrom__c) {
        this.c002_DateFrom__c = c002_DateFrom__c;
    }


    /**
     * Gets the c002_DateTo__c value for this C002_Case__c.
     * 
     * @return c002_DateTo__c
     */
    public java.util.Date getC002_DateTo__c() {
        return c002_DateTo__c;
    }


    /**
     * Sets the c002_DateTo__c value for this C002_Case__c.
     * 
     * @param c002_DateTo__c
     */
    public void setC002_DateTo__c(java.util.Date c002_DateTo__c) {
        this.c002_DateTo__c = c002_DateTo__c;
    }


    /**
     * Gets the c002_Detail__c value for this C002_Case__c.
     * 
     * @return c002_Detail__c
     */
    public java.lang.String getC002_Detail__c() {
        return c002_Detail__c;
    }


    /**
     * Sets the c002_Detail__c value for this C002_Case__c.
     * 
     * @param c002_Detail__c
     */
    public void setC002_Detail__c(java.lang.String c002_Detail__c) {
        this.c002_Detail__c = c002_Detail__c;
    }


    /**
     * Gets the c002_Kakudo1__c value for this C002_Case__c.
     * 
     * @return c002_Kakudo1__c
     */
    public java.lang.String getC002_Kakudo1__c() {
        return c002_Kakudo1__c;
    }


    /**
     * Sets the c002_Kakudo1__c value for this C002_Case__c.
     * 
     * @param c002_Kakudo1__c
     */
    public void setC002_Kakudo1__c(java.lang.String c002_Kakudo1__c) {
        this.c002_Kakudo1__c = c002_Kakudo1__c;
    }


    /**
     * Gets the c002_Kakudo2__c value for this C002_Case__c.
     * 
     * @return c002_Kakudo2__c
     */
    public java.lang.String getC002_Kakudo2__c() {
        return c002_Kakudo2__c;
    }


    /**
     * Sets the c002_Kakudo2__c value for this C002_Case__c.
     * 
     * @param c002_Kakudo2__c
     */
    public void setC002_Kakudo2__c(java.lang.String c002_Kakudo2__c) {
        this.c002_Kakudo2__c = c002_Kakudo2__c;
    }


    /**
     * Gets the c002_KyotenName__c value for this C002_Case__c.
     * 
     * @return c002_KyotenName__c
     */
    public java.lang.String getC002_KyotenName__c() {
        return c002_KyotenName__c;
    }


    /**
     * Sets the c002_KyotenName__c value for this C002_Case__c.
     * 
     * @param c002_KyotenName__c
     */
    public void setC002_KyotenName__c(java.lang.String c002_KyotenName__c) {
        this.c002_KyotenName__c = c002_KyotenName__c;
    }


    /**
     * Gets the c002_Outline__c value for this C002_Case__c.
     * 
     * @return c002_Outline__c
     */
    public java.lang.String getC002_Outline__c() {
        return c002_Outline__c;
    }


    /**
     * Sets the c002_Outline__c value for this C002_Case__c.
     * 
     * @param c002_Outline__c
     */
    public void setC002_Outline__c(java.lang.String c002_Outline__c) {
        this.c002_Outline__c = c002_Outline__c;
    }


    /**
     * Gets the c002_ProfitRenketsu__c value for this C002_Case__c.
     * 
     * @return c002_ProfitRenketsu__c
     */
    public java.lang.Double getC002_ProfitRenketsu__c() {
        return c002_ProfitRenketsu__c;
    }


    /**
     * Sets the c002_ProfitRenketsu__c value for this C002_Case__c.
     * 
     * @param c002_ProfitRenketsu__c
     */
    public void setC002_ProfitRenketsu__c(java.lang.Double c002_ProfitRenketsu__c) {
        this.c002_ProfitRenketsu__c = c002_ProfitRenketsu__c;
    }


    /**
     * Gets the c002_ProfitTantai__c value for this C002_Case__c.
     * 
     * @return c002_ProfitTantai__c
     */
    public java.lang.Double getC002_ProfitTantai__c() {
        return c002_ProfitTantai__c;
    }


    /**
     * Sets the c002_ProfitTantai__c value for this C002_Case__c.
     * 
     * @param c002_ProfitTantai__c
     */
    public void setC002_ProfitTantai__c(java.lang.Double c002_ProfitTantai__c) {
        this.c002_ProfitTantai__c = c002_ProfitTantai__c;
    }


    /**
     * Gets the c002_RMTanto__c value for this C002_Case__c.
     * 
     * @return c002_RMTanto__c
     */
    public java.lang.String getC002_RMTanto__c() {
        return c002_RMTanto__c;
    }


    /**
     * Sets the c002_RMTanto__c value for this C002_Case__c.
     * 
     * @param c002_RMTanto__c
     */
    public void setC002_RMTanto__c(java.lang.String c002_RMTanto__c) {
        this.c002_RMTanto__c = c002_RMTanto__c;
    }


    /**
     * Gets the c002_RecordTantouButenName__c value for this C002_Case__c.
     * 
     * @return c002_RecordTantouButenName__c
     */
    public java.lang.String getC002_RecordTantouButenName__c() {
        return c002_RecordTantouButenName__c;
    }


    /**
     * Sets the c002_RecordTantouButenName__c value for this C002_Case__c.
     * 
     * @param c002_RecordTantouButenName__c
     */
    public void setC002_RecordTantouButenName__c(java.lang.String c002_RecordTantouButenName__c) {
        this.c002_RecordTantouButenName__c = c002_RecordTantouButenName__c;
    }


    /**
     * Gets the c002_RecordTantou__c value for this C002_Case__c.
     * 
     * @return c002_RecordTantou__c
     */
    public java.lang.String getC002_RecordTantou__c() {
        return c002_RecordTantou__c;
    }


    /**
     * Sets the c002_RecordTantou__c value for this C002_Case__c.
     * 
     * @param c002_RecordTantou__c
     */
    public void setC002_RecordTantou__c(java.lang.String c002_RecordTantou__c) {
        this.c002_RecordTantou__c = c002_RecordTantou__c;
    }


    /**
     * Gets the c002_RecordTantou__r value for this C002_Case__c.
     * 
     * @return c002_RecordTantou__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getC002_RecordTantou__r() {
        return c002_RecordTantou__r;
    }


    /**
     * Sets the c002_RecordTantou__r value for this C002_Case__c.
     * 
     * @param c002_RecordTantou__r
     */
    public void setC002_RecordTantou__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_RecordTantou__r) {
        this.c002_RecordTantou__r = c002_RecordTantou__r;
    }


    /**
     * Gets the c002_RecordTypeName2__c value for this C002_Case__c.
     * 
     * @return c002_RecordTypeName2__c
     */
    public java.lang.String getC002_RecordTypeName2__c() {
        return c002_RecordTypeName2__c;
    }


    /**
     * Sets the c002_RecordTypeName2__c value for this C002_Case__c.
     * 
     * @param c002_RecordTypeName2__c
     */
    public void setC002_RecordTypeName2__c(java.lang.String c002_RecordTypeName2__c) {
        this.c002_RecordTypeName2__c = c002_RecordTypeName2__c;
    }


    /**
     * Gets the c002_RelatedTaskID__c value for this C002_Case__c.
     * 
     * @return c002_RelatedTaskID__c
     */
    public java.lang.String getC002_RelatedTaskID__c() {
        return c002_RelatedTaskID__c;
    }


    /**
     * Sets the c002_RelatedTaskID__c value for this C002_Case__c.
     * 
     * @param c002_RelatedTaskID__c
     */
    public void setC002_RelatedTaskID__c(java.lang.String c002_RelatedTaskID__c) {
        this.c002_RelatedTaskID__c = c002_RelatedTaskID__c;
    }


    /**
     * Gets the c002_RevenueDivision__c value for this C002_Case__c.
     * 
     * @return c002_RevenueDivision__c
     */
    public java.lang.String getC002_RevenueDivision__c() {
        return c002_RevenueDivision__c;
    }


    /**
     * Sets the c002_RevenueDivision__c value for this C002_Case__c.
     * 
     * @param c002_RevenueDivision__c
     */
    public void setC002_RevenueDivision__c(java.lang.String c002_RevenueDivision__c) {
        this.c002_RevenueDivision__c = c002_RevenueDivision__c;
    }


    /**
     * Gets the c002_Shinmitsudo__c value for this C002_Case__c.
     * 
     * @return c002_Shinmitsudo__c
     */
    public java.lang.String getC002_Shinmitsudo__c() {
        return c002_Shinmitsudo__c;
    }


    /**
     * Sets the c002_Shinmitsudo__c value for this C002_Case__c.
     * 
     * @param c002_Shinmitsudo__c
     */
    public void setC002_Shinmitsudo__c(java.lang.String c002_Shinmitsudo__c) {
        this.c002_Shinmitsudo__c = c002_Shinmitsudo__c;
    }


    /**
     * Gets the c002_TantobuTemban__c value for this C002_Case__c.
     * 
     * @return c002_TantobuTemban__c
     */
    public java.lang.String getC002_TantobuTemban__c() {
        return c002_TantobuTemban__c;
    }


    /**
     * Sets the c002_TantobuTemban__c value for this C002_Case__c.
     * 
     * @param c002_TantobuTemban__c
     */
    public void setC002_TantobuTemban__c(java.lang.String c002_TantobuTemban__c) {
        this.c002_TantobuTemban__c = c002_TantobuTemban__c;
    }


    /**
     * Gets the c002_Tantou01_Group__c value for this C002_Case__c.
     * 
     * @return c002_Tantou01_Group__c
     */
    public java.lang.String getC002_Tantou01_Group__c() {
        return c002_Tantou01_Group__c;
    }


    /**
     * Sets the c002_Tantou01_Group__c value for this C002_Case__c.
     * 
     * @param c002_Tantou01_Group__c
     */
    public void setC002_Tantou01_Group__c(java.lang.String c002_Tantou01_Group__c) {
        this.c002_Tantou01_Group__c = c002_Tantou01_Group__c;
    }


    /**
     * Gets the c002_Tantou01_Name__c value for this C002_Case__c.
     * 
     * @return c002_Tantou01_Name__c
     */
    public java.lang.String getC002_Tantou01_Name__c() {
        return c002_Tantou01_Name__c;
    }


    /**
     * Sets the c002_Tantou01_Name__c value for this C002_Case__c.
     * 
     * @param c002_Tantou01_Name__c
     */
    public void setC002_Tantou01_Name__c(java.lang.String c002_Tantou01_Name__c) {
        this.c002_Tantou01_Name__c = c002_Tantou01_Name__c;
    }


    /**
     * Gets the c002_Tantou02_Group__c value for this C002_Case__c.
     * 
     * @return c002_Tantou02_Group__c
     */
    public java.lang.String getC002_Tantou02_Group__c() {
        return c002_Tantou02_Group__c;
    }


    /**
     * Sets the c002_Tantou02_Group__c value for this C002_Case__c.
     * 
     * @param c002_Tantou02_Group__c
     */
    public void setC002_Tantou02_Group__c(java.lang.String c002_Tantou02_Group__c) {
        this.c002_Tantou02_Group__c = c002_Tantou02_Group__c;
    }


    /**
     * Gets the c002_Tantou02_Name__c value for this C002_Case__c.
     * 
     * @return c002_Tantou02_Name__c
     */
    public java.lang.String getC002_Tantou02_Name__c() {
        return c002_Tantou02_Name__c;
    }


    /**
     * Sets the c002_Tantou02_Name__c value for this C002_Case__c.
     * 
     * @param c002_Tantou02_Name__c
     */
    public void setC002_Tantou02_Name__c(java.lang.String c002_Tantou02_Name__c) {
        this.c002_Tantou02_Name__c = c002_Tantou02_Name__c;
    }


    /**
     * Gets the c002_Tantou03_Group__c value for this C002_Case__c.
     * 
     * @return c002_Tantou03_Group__c
     */
    public java.lang.String getC002_Tantou03_Group__c() {
        return c002_Tantou03_Group__c;
    }


    /**
     * Sets the c002_Tantou03_Group__c value for this C002_Case__c.
     * 
     * @param c002_Tantou03_Group__c
     */
    public void setC002_Tantou03_Group__c(java.lang.String c002_Tantou03_Group__c) {
        this.c002_Tantou03_Group__c = c002_Tantou03_Group__c;
    }


    /**
     * Gets the c002_Tantou03_Name__c value for this C002_Case__c.
     * 
     * @return c002_Tantou03_Name__c
     */
    public java.lang.String getC002_Tantou03_Name__c() {
        return c002_Tantou03_Name__c;
    }


    /**
     * Sets the c002_Tantou03_Name__c value for this C002_Case__c.
     * 
     * @param c002_Tantou03_Name__c
     */
    public void setC002_Tantou03_Name__c(java.lang.String c002_Tantou03_Name__c) {
        this.c002_Tantou03_Name__c = c002_Tantou03_Name__c;
    }


    /**
     * Gets the c002_Tantou04_Group__c value for this C002_Case__c.
     * 
     * @return c002_Tantou04_Group__c
     */
    public java.lang.String getC002_Tantou04_Group__c() {
        return c002_Tantou04_Group__c;
    }


    /**
     * Sets the c002_Tantou04_Group__c value for this C002_Case__c.
     * 
     * @param c002_Tantou04_Group__c
     */
    public void setC002_Tantou04_Group__c(java.lang.String c002_Tantou04_Group__c) {
        this.c002_Tantou04_Group__c = c002_Tantou04_Group__c;
    }


    /**
     * Gets the c002_Tantou04_Name__c value for this C002_Case__c.
     * 
     * @return c002_Tantou04_Name__c
     */
    public java.lang.String getC002_Tantou04_Name__c() {
        return c002_Tantou04_Name__c;
    }


    /**
     * Sets the c002_Tantou04_Name__c value for this C002_Case__c.
     * 
     * @param c002_Tantou04_Name__c
     */
    public void setC002_Tantou04_Name__c(java.lang.String c002_Tantou04_Name__c) {
        this.c002_Tantou04_Name__c = c002_Tantou04_Name__c;
    }


    /**
     * Gets the c002_Tantou_01__c value for this C002_Case__c.
     * 
     * @return c002_Tantou_01__c
     */
    public java.lang.String getC002_Tantou_01__c() {
        return c002_Tantou_01__c;
    }


    /**
     * Sets the c002_Tantou_01__c value for this C002_Case__c.
     * 
     * @param c002_Tantou_01__c
     */
    public void setC002_Tantou_01__c(java.lang.String c002_Tantou_01__c) {
        this.c002_Tantou_01__c = c002_Tantou_01__c;
    }


    /**
     * Gets the c002_Tantou_01__r value for this C002_Case__c.
     * 
     * @return c002_Tantou_01__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getC002_Tantou_01__r() {
        return c002_Tantou_01__r;
    }


    /**
     * Sets the c002_Tantou_01__r value for this C002_Case__c.
     * 
     * @param c002_Tantou_01__r
     */
    public void setC002_Tantou_01__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_01__r) {
        this.c002_Tantou_01__r = c002_Tantou_01__r;
    }


    /**
     * Gets the c002_Tantou_02__c value for this C002_Case__c.
     * 
     * @return c002_Tantou_02__c
     */
    public java.lang.String getC002_Tantou_02__c() {
        return c002_Tantou_02__c;
    }


    /**
     * Sets the c002_Tantou_02__c value for this C002_Case__c.
     * 
     * @param c002_Tantou_02__c
     */
    public void setC002_Tantou_02__c(java.lang.String c002_Tantou_02__c) {
        this.c002_Tantou_02__c = c002_Tantou_02__c;
    }


    /**
     * Gets the c002_Tantou_02__r value for this C002_Case__c.
     * 
     * @return c002_Tantou_02__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getC002_Tantou_02__r() {
        return c002_Tantou_02__r;
    }


    /**
     * Sets the c002_Tantou_02__r value for this C002_Case__c.
     * 
     * @param c002_Tantou_02__r
     */
    public void setC002_Tantou_02__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_02__r) {
        this.c002_Tantou_02__r = c002_Tantou_02__r;
    }


    /**
     * Gets the c002_Tantou_03__c value for this C002_Case__c.
     * 
     * @return c002_Tantou_03__c
     */
    public java.lang.String getC002_Tantou_03__c() {
        return c002_Tantou_03__c;
    }


    /**
     * Sets the c002_Tantou_03__c value for this C002_Case__c.
     * 
     * @param c002_Tantou_03__c
     */
    public void setC002_Tantou_03__c(java.lang.String c002_Tantou_03__c) {
        this.c002_Tantou_03__c = c002_Tantou_03__c;
    }


    /**
     * Gets the c002_Tantou_03__r value for this C002_Case__c.
     * 
     * @return c002_Tantou_03__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getC002_Tantou_03__r() {
        return c002_Tantou_03__r;
    }


    /**
     * Sets the c002_Tantou_03__r value for this C002_Case__c.
     * 
     * @param c002_Tantou_03__r
     */
    public void setC002_Tantou_03__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_03__r) {
        this.c002_Tantou_03__r = c002_Tantou_03__r;
    }


    /**
     * Gets the c002_Tantou_04__c value for this C002_Case__c.
     * 
     * @return c002_Tantou_04__c
     */
    public java.lang.String getC002_Tantou_04__c() {
        return c002_Tantou_04__c;
    }


    /**
     * Sets the c002_Tantou_04__c value for this C002_Case__c.
     * 
     * @param c002_Tantou_04__c
     */
    public void setC002_Tantou_04__c(java.lang.String c002_Tantou_04__c) {
        this.c002_Tantou_04__c = c002_Tantou_04__c;
    }


    /**
     * Gets the c002_Tantou_04__r value for this C002_Case__c.
     * 
     * @return c002_Tantou_04__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getC002_Tantou_04__r() {
        return c002_Tantou_04__r;
    }


    /**
     * Sets the c002_Tantou_04__r value for this C002_Case__c.
     * 
     * @param c002_Tantou_04__r
     */
    public void setC002_Tantou_04__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_04__r) {
        this.c002_Tantou_04__r = c002_Tantou_04__r;
    }


    /**
     * Gets the c002_Tantou_05__c value for this C002_Case__c.
     * 
     * @return c002_Tantou_05__c
     */
    public java.lang.String getC002_Tantou_05__c() {
        return c002_Tantou_05__c;
    }


    /**
     * Sets the c002_Tantou_05__c value for this C002_Case__c.
     * 
     * @param c002_Tantou_05__c
     */
    public void setC002_Tantou_05__c(java.lang.String c002_Tantou_05__c) {
        this.c002_Tantou_05__c = c002_Tantou_05__c;
    }


    /**
     * Gets the c002_Tantou_05__r value for this C002_Case__c.
     * 
     * @return c002_Tantou_05__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getC002_Tantou_05__r() {
        return c002_Tantou_05__r;
    }


    /**
     * Sets the c002_Tantou_05__r value for this C002_Case__c.
     * 
     * @param c002_Tantou_05__r
     */
    public void setC002_Tantou_05__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tantou_05__r) {
        this.c002_Tantou_05__r = c002_Tantou_05__r;
    }


    /**
     * Gets the c002_Tantou_Kensaku__c value for this C002_Case__c.
     * 
     * @return c002_Tantou_Kensaku__c
     */
    public java.lang.String getC002_Tantou_Kensaku__c() {
        return c002_Tantou_Kensaku__c;
    }


    /**
     * Sets the c002_Tantou_Kensaku__c value for this C002_Case__c.
     * 
     * @param c002_Tantou_Kensaku__c
     */
    public void setC002_Tantou_Kensaku__c(java.lang.String c002_Tantou_Kensaku__c) {
        this.c002_Tantou_Kensaku__c = c002_Tantou_Kensaku__c;
    }


    /**
     * Gets the c002_TembanCif__c value for this C002_Case__c.
     * 
     * @return c002_TembanCif__c
     */
    public java.lang.String getC002_TembanCif__c() {
        return c002_TembanCif__c;
    }


    /**
     * Sets the c002_TembanCif__c value for this C002_Case__c.
     * 
     * @param c002_TembanCif__c
     */
    public void setC002_TembanCif__c(java.lang.String c002_TembanCif__c) {
        this.c002_TembanCif__c = c002_TembanCif__c;
    }


    /**
     * Gets the c002_TokoKakuzuke__c value for this C002_Case__c.
     * 
     * @return c002_TokoKakuzuke__c
     */
    public java.lang.String getC002_TokoKakuzuke__c() {
        return c002_TokoKakuzuke__c;
    }


    /**
     * Sets the c002_TokoKakuzuke__c value for this C002_Case__c.
     * 
     * @param c002_TokoKakuzuke__c
     */
    public void setC002_TokoKakuzuke__c(java.lang.String c002_TokoKakuzuke__c) {
        this.c002_TokoKakuzuke__c = c002_TokoKakuzuke__c;
    }


    /**
     * Gets the c002_Work__c value for this C002_Case__c.
     * 
     * @return c002_Work__c
     */
    public java.lang.String getC002_Work__c() {
        return c002_Work__c;
    }


    /**
     * Sets the c002_Work__c value for this C002_Case__c.
     * 
     * @param c002_Work__c
     */
    public void setC002_Work__c(java.lang.String c002_Work__c) {
        this.c002_Work__c = c002_Work__c;
    }


    /**
     * Gets the c002_YomikomiNo__c value for this C002_Case__c.
     * 
     * @return c002_YomikomiNo__c
     */
    public java.lang.String getC002_YomikomiNo__c() {
        return c002_YomikomiNo__c;
    }


    /**
     * Sets the c002_YomikomiNo__c value for this C002_Case__c.
     * 
     * @param c002_YomikomiNo__c
     */
    public void setC002_YomikomiNo__c(java.lang.String c002_YomikomiNo__c) {
        this.c002_YomikomiNo__c = c002_YomikomiNo__c;
    }


    /**
     * Gets the combinedAttachments value for this C002_Case__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C002_Case__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C002_Case__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C002_Case__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C002_Case__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C002_Case__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C002_Case__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C002_Case__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the duplicateRecordItems value for this C002_Case__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C002_Case__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the histories value for this C002_Case__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this C002_Case__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this C002_Case__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C002_Case__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the lastModifiedBy value for this C002_Case__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C002_Case__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C002_Case__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C002_Case__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C002_Case__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C002_Case__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lastReferencedDate value for this C002_Case__c.
     * 
     * @return lastReferencedDate
     */
    public java.util.Calendar getLastReferencedDate() {
        return lastReferencedDate;
    }


    /**
     * Sets the lastReferencedDate value for this C002_Case__c.
     * 
     * @param lastReferencedDate
     */
    public void setLastReferencedDate(java.util.Calendar lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }


    /**
     * Gets the lastViewedDate value for this C002_Case__c.
     * 
     * @return lastViewedDate
     */
    public java.util.Calendar getLastViewedDate() {
        return lastViewedDate;
    }


    /**
     * Sets the lastViewedDate value for this C002_Case__c.
     * 
     * @param lastViewedDate
     */
    public void setLastViewedDate(java.util.Calendar lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C002_Case__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C002_Case__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this C002_Case__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C002_Case__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C002_Case__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C002_Case__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C002_Case__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C002_Case__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the owner value for this C002_Case__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this C002_Case__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this C002_Case__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this C002_Case__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this C002_Case__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C002_Case__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C002_Case__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C002_Case__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the recordType value for this C002_Case__c.
     * 
     * @return recordType
     */
    public com.sforce.soap.enterprise.sobject.RecordType getRecordType() {
        return recordType;
    }


    /**
     * Sets the recordType value for this C002_Case__c.
     * 
     * @param recordType
     */
    public void setRecordType(com.sforce.soap.enterprise.sobject.RecordType recordType) {
        this.recordType = recordType;
    }


    /**
     * Gets the recordTypeId value for this C002_Case__c.
     * 
     * @return recordTypeId
     */
    public java.lang.String getRecordTypeId() {
        return recordTypeId;
    }


    /**
     * Sets the recordTypeId value for this C002_Case__c.
     * 
     * @param recordTypeId
     */
    public void setRecordTypeId(java.lang.String recordTypeId) {
        this.recordTypeId = recordTypeId;
    }


    /**
     * Gets the shares value for this C002_Case__c.
     * 
     * @return shares
     */
    public com.sforce.soap.enterprise.QueryResult getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this C002_Case__c.
     * 
     * @param shares
     */
    public void setShares(com.sforce.soap.enterprise.QueryResult shares) {
        this.shares = shares;
    }


    /**
     * Gets the systemModstamp value for this C002_Case__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C002_Case__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the topicAssignments value for this C002_Case__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C002_Case__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this C002_Case__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C002_Case__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C002_Case__c)) return false;
        C002_Case__c other = (C002_Case__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.a010_ActionPlan__c==null && other.getA010_ActionPlan__c()==null) || 
             (this.a010_ActionPlan__c!=null &&
              this.a010_ActionPlan__c.equals(other.getA010_ActionPlan__c()))) &&
            ((this.a010_AnkenShudousha__c==null && other.getA010_AnkenShudousha__c()==null) || 
             (this.a010_AnkenShudousha__c!=null &&
              this.a010_AnkenShudousha__c.equals(other.getA010_AnkenShudousha__c()))) &&
            ((this.a010_AnkenShurui1__c==null && other.getA010_AnkenShurui1__c()==null) || 
             (this.a010_AnkenShurui1__c!=null &&
              this.a010_AnkenShurui1__c.equals(other.getA010_AnkenShurui1__c()))) &&
            ((this.a010_AnkenShurui2__c==null && other.getA010_AnkenShurui2__c()==null) || 
             (this.a010_AnkenShurui2__c!=null &&
              this.a010_AnkenShurui2__c.equals(other.getA010_AnkenShurui2__c()))) &&
            ((this.a010_AnkenShurui3__c==null && other.getA010_AnkenShurui3__c()==null) || 
             (this.a010_AnkenShurui3__c!=null &&
              this.a010_AnkenShurui3__c.equals(other.getA010_AnkenShurui3__c()))) &&
            ((this.a010_Bikou__c==null && other.getA010_Bikou__c()==null) || 
             (this.a010_Bikou__c!=null &&
              this.a010_Bikou__c.equals(other.getA010_Bikou__c()))) &&
            ((this.a010_CaseId__c==null && other.getA010_CaseId__c()==null) || 
             (this.a010_CaseId__c!=null &&
              this.a010_CaseId__c.equals(other.getA010_CaseId__c()))) &&
            ((this.a010_Country__c==null && other.getA010_Country__c()==null) || 
             (this.a010_Country__c!=null &&
              this.a010_Country__c.equals(other.getA010_Country__c()))) &&
            ((this.a010_CsvTantou_01__c==null && other.getA010_CsvTantou_01__c()==null) || 
             (this.a010_CsvTantou_01__c!=null &&
              this.a010_CsvTantou_01__c.equals(other.getA010_CsvTantou_01__c()))) &&
            ((this.a010_GBADUnit__c==null && other.getA010_GBADUnit__c()==null) || 
             (this.a010_GBADUnit__c!=null &&
              this.a010_GBADUnit__c.equals(other.getA010_GBADUnit__c()))) &&
            ((this.a010_Group__c==null && other.getA010_Group__c()==null) || 
             (this.a010_Group__c!=null &&
              this.a010_Group__c.equals(other.getA010_Group__c()))) &&
            ((this.a010_Kakudo__c==null && other.getA010_Kakudo__c()==null) || 
             (this.a010_Kakudo__c!=null &&
              this.a010_Kakudo__c.equals(other.getA010_Kakudo__c()))) &&
            ((this.a010_KankeiBusho1__c==null && other.getA010_KankeiBusho1__c()==null) || 
             (this.a010_KankeiBusho1__c!=null &&
              this.a010_KankeiBusho1__c.equals(other.getA010_KankeiBusho1__c()))) &&
            ((this.a010_KankeiBusho2__c==null && other.getA010_KankeiBusho2__c()==null) || 
             (this.a010_KankeiBusho2__c!=null &&
              this.a010_KankeiBusho2__c.equals(other.getA010_KankeiBusho2__c()))) &&
            ((this.a010_Kekka__c==null && other.getA010_Kekka__c()==null) || 
             (this.a010_Kekka__c!=null &&
              this.a010_Kekka__c.equals(other.getA010_Kekka__c()))) &&
            ((this.a010_RenkeiKaigaiKyoten1__c==null && other.getA010_RenkeiKaigaiKyoten1__c()==null) || 
             (this.a010_RenkeiKaigaiKyoten1__c!=null &&
              this.a010_RenkeiKaigaiKyoten1__c.equals(other.getA010_RenkeiKaigaiKyoten1__c()))) &&
            ((this.a010_RenkeiKaigaiKyoten2__c==null && other.getA010_RenkeiKaigaiKyoten2__c()==null) || 
             (this.a010_RenkeiKaigaiKyoten2__c!=null &&
              this.a010_RenkeiKaigaiKyoten2__c.equals(other.getA010_RenkeiKaigaiKyoten2__c()))) &&
            ((this.a010_Saido__c==null && other.getA010_Saido__c()==null) || 
             (this.a010_Saido__c!=null &&
              this.a010_Saido__c.equals(other.getA010_Saido__c()))) &&
            ((this.a010_Shisaku__c==null && other.getA010_Shisaku__c()==null) || 
             (this.a010_Shisaku__c!=null &&
              this.a010_Shisaku__c.equals(other.getA010_Shisaku__c()))) &&
            ((this.a010_ShuekiShurui1__c==null && other.getA010_ShuekiShurui1__c()==null) || 
             (this.a010_ShuekiShurui1__c!=null &&
              this.a010_ShuekiShurui1__c.equals(other.getA010_ShuekiShurui1__c()))) &&
            ((this.a010_ShuekiShurui2__c==null && other.getA010_ShuekiShurui2__c()==null) || 
             (this.a010_ShuekiShurui2__c!=null &&
              this.a010_ShuekiShurui2__c.equals(other.getA010_ShuekiShurui2__c()))) &&
            ((this.a010_Shuekigaku__c==null && other.getA010_Shuekigaku__c()==null) || 
             (this.a010_Shuekigaku__c!=null &&
              this.a010_Shuekigaku__c.equals(other.getA010_Shuekigaku__c()))) &&
            ((this.a010_YoteizukiHizuke__c==null && other.getA010_YoteizukiHizuke__c()==null) || 
             (this.a010_YoteizukiHizuke__c!=null &&
              this.a010_YoteizukiHizuke__c.equals(other.getA010_YoteizukiHizuke__c()))) &&
            ((this.a010_YoteizukiInt__c==null && other.getA010_YoteizukiInt__c()==null) || 
             (this.a010_YoteizukiInt__c!=null &&
              this.a010_YoteizukiInt__c.equals(other.getA010_YoteizukiInt__c()))) &&
            ((this.a010_Yoteizuki__c==null && other.getA010_Yoteizuki__c()==null) || 
             (this.a010_Yoteizuki__c!=null &&
              this.a010_Yoteizuki__c.equals(other.getA010_Yoteizuki__c()))) &&
            ((this.a014_AnkenShurui__c==null && other.getA014_AnkenShurui__c()==null) || 
             (this.a014_AnkenShurui__c!=null &&
              this.a014_AnkenShurui__c.equals(other.getA014_AnkenShurui__c()))) &&
            ((this.a014_CaseCloseDate__c==null && other.getA014_CaseCloseDate__c()==null) || 
             (this.a014_CaseCloseDate__c!=null &&
              this.a014_CaseCloseDate__c.equals(other.getA014_CaseCloseDate__c()))) &&
            ((this.a014_ChokusetsuSoshutsu__c==null && other.getA014_ChokusetsuSoshutsu__c()==null) || 
             (this.a014_ChokusetsuSoshutsu__c!=null &&
              this.a014_ChokusetsuSoshutsu__c.equals(other.getA014_ChokusetsuSoshutsu__c()))) &&
            ((this.a014_DecisionDate__c==null && other.getA014_DecisionDate__c()==null) || 
             (this.a014_DecisionDate__c!=null &&
              this.a014_DecisionDate__c.equals(other.getA014_DecisionDate__c()))) &&
            ((this.a014_DecisionMeeting__c==null && other.getA014_DecisionMeeting__c()==null) || 
             (this.a014_DecisionMeeting__c!=null &&
              this.a014_DecisionMeeting__c.equals(other.getA014_DecisionMeeting__c()))) &&
            ((this.a014_Kakudo__c==null && other.getA014_Kakudo__c()==null) || 
             (this.a014_Kakudo__c!=null &&
              this.a014_Kakudo__c.equals(other.getA014_Kakudo__c()))) &&
            ((this.a014_Outline__c==null && other.getA014_Outline__c()==null) || 
             (this.a014_Outline__c!=null &&
              this.a014_Outline__c.equals(other.getA014_Outline__c()))) &&
            ((this.a014_RelateState1__c==null && other.getA014_RelateState1__c()==null) || 
             (this.a014_RelateState1__c!=null &&
              this.a014_RelateState1__c.equals(other.getA014_RelateState1__c()))) &&
            ((this.a014_RelateState2__c==null && other.getA014_RelateState2__c()==null) || 
             (this.a014_RelateState2__c!=null &&
              this.a014_RelateState2__c.equals(other.getA014_RelateState2__c()))) &&
            ((this.a014_RelateState3__c==null && other.getA014_RelateState3__c()==null) || 
             (this.a014_RelateState3__c!=null &&
              this.a014_RelateState3__c.equals(other.getA014_RelateState3__c()))) &&
            ((this.a014_RelateTeam__c==null && other.getA014_RelateTeam__c()==null) || 
             (this.a014_RelateTeam__c!=null &&
              this.a014_RelateTeam__c.equals(other.getA014_RelateTeam__c()))) &&
            ((this.a014_RenketsuShueki__c==null && other.getA014_RenketsuShueki__c()==null) || 
             (this.a014_RenketsuShueki__c!=null &&
              this.a014_RenketsuShueki__c.equals(other.getA014_RenketsuShueki__c()))) &&
            ((this.a014_ShuekiAmount__c==null && other.getA014_ShuekiAmount__c()==null) || 
             (this.a014_ShuekiAmount__c!=null &&
              this.a014_ShuekiAmount__c.equals(other.getA014_ShuekiAmount__c()))) &&
            ((this.a014_TantaiShueki__c==null && other.getA014_TantaiShueki__c()==null) || 
             (this.a014_TantaiShueki__c!=null &&
              this.a014_TantaiShueki__c.equals(other.getA014_TantaiShueki__c()))) &&
            ((this.a014_TantouTeam1__c==null && other.getA014_TantouTeam1__c()==null) || 
             (this.a014_TantouTeam1__c!=null &&
              this.a014_TantouTeam1__c.equals(other.getA014_TantouTeam1__c()))) &&
            ((this.a014_TantouTeam2__c==null && other.getA014_TantouTeam2__c()==null) || 
             (this.a014_TantouTeam2__c!=null &&
              this.a014_TantouTeam2__c.equals(other.getA014_TantouTeam2__c()))) &&
            ((this.a014_TantouTeam3__c==null && other.getA014_TantouTeam3__c()==null) || 
             (this.a014_TantouTeam3__c!=null &&
              this.a014_TantouTeam3__c.equals(other.getA014_TantouTeam3__c()))) &&
            ((this.a014_Tantousha1__c==null && other.getA014_Tantousha1__c()==null) || 
             (this.a014_Tantousha1__c!=null &&
              this.a014_Tantousha1__c.equals(other.getA014_Tantousha1__c()))) &&
            ((this.a014_Tantousha2__c==null && other.getA014_Tantousha2__c()==null) || 
             (this.a014_Tantousha2__c!=null &&
              this.a014_Tantousha2__c.equals(other.getA014_Tantousha2__c()))) &&
            ((this.a014_Tantousha3__c==null && other.getA014_Tantousha3__c()==null) || 
             (this.a014_Tantousha3__c!=null &&
              this.a014_Tantousha3__c.equals(other.getA014_Tantousha3__c()))) &&
            ((this.a015_AnkenCategory__c==null && other.getA015_AnkenCategory__c()==null) || 
             (this.a015_AnkenCategory__c!=null &&
              this.a015_AnkenCategory__c.equals(other.getA015_AnkenCategory__c()))) &&
            ((this.a015_AnkenShubetsu__c==null && other.getA015_AnkenShubetsu__c()==null) || 
             (this.a015_AnkenShubetsu__c!=null &&
              this.a015_AnkenShubetsu__c.equals(other.getA015_AnkenShubetsu__c()))) &&
            ((this.a015_RisihokyuuSeido__c==null && other.getA015_RisihokyuuSeido__c()==null) || 
             (this.a015_RisihokyuuSeido__c!=null &&
              this.a015_RisihokyuuSeido__c.equals(other.getA015_RisihokyuuSeido__c()))) &&
            ((this.a015_ToushiBasyo__c==null && other.getA015_ToushiBasyo__c()==null) || 
             (this.a015_ToushiBasyo__c!=null &&
              this.a015_ToushiBasyo__c.equals(other.getA015_ToushiBasyo__c()))) &&
            ((this.a015_ToushiKingaku__c==null && other.getA015_ToushiKingaku__c()==null) || 
             (this.a015_ToushiKingaku__c!=null &&
              this.a015_ToushiKingaku__c.equals(other.getA015_ToushiKingaku__c()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.c002_AllowedChangeCustomer__c==null && other.getC002_AllowedChangeCustomer__c()==null) || 
             (this.c002_AllowedChangeCustomer__c!=null &&
              this.c002_AllowedChangeCustomer__c.equals(other.getC002_AllowedChangeCustomer__c()))) &&
            ((this.c002_Amount2__c==null && other.getC002_Amount2__c()==null) || 
             (this.c002_Amount2__c!=null &&
              this.c002_Amount2__c.equals(other.getC002_Amount2__c()))) &&
            ((this.c002_Amount3__c==null && other.getC002_Amount3__c()==null) || 
             (this.c002_Amount3__c!=null &&
              this.c002_Amount3__c.equals(other.getC002_Amount3__c()))) &&
            ((this.c002_Amount__c==null && other.getC002_Amount__c()==null) || 
             (this.c002_Amount__c!=null &&
              this.c002_Amount__c.equals(other.getC002_Amount__c()))) &&
            ((this.c002_AppName__c==null && other.getC002_AppName__c()==null) || 
             (this.c002_AppName__c!=null &&
              this.c002_AppName__c.equals(other.getC002_AppName__c()))) &&
            ((this.c002_CRM_AnkenId__c==null && other.getC002_CRM_AnkenId__c()==null) || 
             (this.c002_CRM_AnkenId__c!=null &&
              this.c002_CRM_AnkenId__c.equals(other.getC002_CRM_AnkenId__c()))) &&
            ((this.c002_CaseId__c==null && other.getC002_CaseId__c()==null) || 
             (this.c002_CaseId__c!=null &&
              this.c002_CaseId__c.equals(other.getC002_CaseId__c()))) &&
            ((this.c002_CaseName__c==null && other.getC002_CaseName__c()==null) || 
             (this.c002_CaseName__c!=null &&
              this.c002_CaseName__c.equals(other.getC002_CaseName__c()))) &&
            ((this.c002_Cases_01__r==null && other.getC002_Cases_01__r()==null) || 
             (this.c002_Cases_01__r!=null &&
              this.c002_Cases_01__r.equals(other.getC002_Cases_01__r()))) &&
            ((this.c002_CsvLastModifiedDate__c==null && other.getC002_CsvLastModifiedDate__c()==null) || 
             (this.c002_CsvLastModifiedDate__c!=null &&
              this.c002_CsvLastModifiedDate__c.equals(other.getC002_CsvLastModifiedDate__c()))) &&
            ((this.c002_CsvRecordTantou__c==null && other.getC002_CsvRecordTantou__c()==null) || 
             (this.c002_CsvRecordTantou__c!=null &&
              this.c002_CsvRecordTantou__c.equals(other.getC002_CsvRecordTantou__c()))) &&
            ((this.c002_CustomerId__c==null && other.getC002_CustomerId__c()==null) || 
             (this.c002_CustomerId__c!=null &&
              this.c002_CustomerId__c.equals(other.getC002_CustomerId__c()))) &&
            ((this.c002_CustomerName__c==null && other.getC002_CustomerName__c()==null) || 
             (this.c002_CustomerName__c!=null &&
              this.c002_CustomerName__c.equals(other.getC002_CustomerName__c()))) &&
            ((this.c002_CustomerRef__c==null && other.getC002_CustomerRef__c()==null) || 
             (this.c002_CustomerRef__c!=null &&
              this.c002_CustomerRef__c.equals(other.getC002_CustomerRef__c()))) &&
            ((this.c002_CustomerRef__r==null && other.getC002_CustomerRef__r()==null) || 
             (this.c002_CustomerRef__r!=null &&
              this.c002_CustomerRef__r.equals(other.getC002_CustomerRef__r()))) &&
            ((this.c002_Date1__c==null && other.getC002_Date1__c()==null) || 
             (this.c002_Date1__c!=null &&
              this.c002_Date1__c.equals(other.getC002_Date1__c()))) &&
            ((this.c002_DateFrom__c==null && other.getC002_DateFrom__c()==null) || 
             (this.c002_DateFrom__c!=null &&
              this.c002_DateFrom__c.equals(other.getC002_DateFrom__c()))) &&
            ((this.c002_DateTo__c==null && other.getC002_DateTo__c()==null) || 
             (this.c002_DateTo__c!=null &&
              this.c002_DateTo__c.equals(other.getC002_DateTo__c()))) &&
            ((this.c002_Detail__c==null && other.getC002_Detail__c()==null) || 
             (this.c002_Detail__c!=null &&
              this.c002_Detail__c.equals(other.getC002_Detail__c()))) &&
            ((this.c002_Kakudo1__c==null && other.getC002_Kakudo1__c()==null) || 
             (this.c002_Kakudo1__c!=null &&
              this.c002_Kakudo1__c.equals(other.getC002_Kakudo1__c()))) &&
            ((this.c002_Kakudo2__c==null && other.getC002_Kakudo2__c()==null) || 
             (this.c002_Kakudo2__c!=null &&
              this.c002_Kakudo2__c.equals(other.getC002_Kakudo2__c()))) &&
            ((this.c002_KyotenName__c==null && other.getC002_KyotenName__c()==null) || 
             (this.c002_KyotenName__c!=null &&
              this.c002_KyotenName__c.equals(other.getC002_KyotenName__c()))) &&
            ((this.c002_Outline__c==null && other.getC002_Outline__c()==null) || 
             (this.c002_Outline__c!=null &&
              this.c002_Outline__c.equals(other.getC002_Outline__c()))) &&
            ((this.c002_ProfitRenketsu__c==null && other.getC002_ProfitRenketsu__c()==null) || 
             (this.c002_ProfitRenketsu__c!=null &&
              this.c002_ProfitRenketsu__c.equals(other.getC002_ProfitRenketsu__c()))) &&
            ((this.c002_ProfitTantai__c==null && other.getC002_ProfitTantai__c()==null) || 
             (this.c002_ProfitTantai__c!=null &&
              this.c002_ProfitTantai__c.equals(other.getC002_ProfitTantai__c()))) &&
            ((this.c002_RMTanto__c==null && other.getC002_RMTanto__c()==null) || 
             (this.c002_RMTanto__c!=null &&
              this.c002_RMTanto__c.equals(other.getC002_RMTanto__c()))) &&
            ((this.c002_RecordTantouButenName__c==null && other.getC002_RecordTantouButenName__c()==null) || 
             (this.c002_RecordTantouButenName__c!=null &&
              this.c002_RecordTantouButenName__c.equals(other.getC002_RecordTantouButenName__c()))) &&
            ((this.c002_RecordTantou__c==null && other.getC002_RecordTantou__c()==null) || 
             (this.c002_RecordTantou__c!=null &&
              this.c002_RecordTantou__c.equals(other.getC002_RecordTantou__c()))) &&
            ((this.c002_RecordTantou__r==null && other.getC002_RecordTantou__r()==null) || 
             (this.c002_RecordTantou__r!=null &&
              this.c002_RecordTantou__r.equals(other.getC002_RecordTantou__r()))) &&
            ((this.c002_RecordTypeName2__c==null && other.getC002_RecordTypeName2__c()==null) || 
             (this.c002_RecordTypeName2__c!=null &&
              this.c002_RecordTypeName2__c.equals(other.getC002_RecordTypeName2__c()))) &&
            ((this.c002_RelatedTaskID__c==null && other.getC002_RelatedTaskID__c()==null) || 
             (this.c002_RelatedTaskID__c!=null &&
              this.c002_RelatedTaskID__c.equals(other.getC002_RelatedTaskID__c()))) &&
            ((this.c002_RevenueDivision__c==null && other.getC002_RevenueDivision__c()==null) || 
             (this.c002_RevenueDivision__c!=null &&
              this.c002_RevenueDivision__c.equals(other.getC002_RevenueDivision__c()))) &&
            ((this.c002_Shinmitsudo__c==null && other.getC002_Shinmitsudo__c()==null) || 
             (this.c002_Shinmitsudo__c!=null &&
              this.c002_Shinmitsudo__c.equals(other.getC002_Shinmitsudo__c()))) &&
            ((this.c002_TantobuTemban__c==null && other.getC002_TantobuTemban__c()==null) || 
             (this.c002_TantobuTemban__c!=null &&
              this.c002_TantobuTemban__c.equals(other.getC002_TantobuTemban__c()))) &&
            ((this.c002_Tantou01_Group__c==null && other.getC002_Tantou01_Group__c()==null) || 
             (this.c002_Tantou01_Group__c!=null &&
              this.c002_Tantou01_Group__c.equals(other.getC002_Tantou01_Group__c()))) &&
            ((this.c002_Tantou01_Name__c==null && other.getC002_Tantou01_Name__c()==null) || 
             (this.c002_Tantou01_Name__c!=null &&
              this.c002_Tantou01_Name__c.equals(other.getC002_Tantou01_Name__c()))) &&
            ((this.c002_Tantou02_Group__c==null && other.getC002_Tantou02_Group__c()==null) || 
             (this.c002_Tantou02_Group__c!=null &&
              this.c002_Tantou02_Group__c.equals(other.getC002_Tantou02_Group__c()))) &&
            ((this.c002_Tantou02_Name__c==null && other.getC002_Tantou02_Name__c()==null) || 
             (this.c002_Tantou02_Name__c!=null &&
              this.c002_Tantou02_Name__c.equals(other.getC002_Tantou02_Name__c()))) &&
            ((this.c002_Tantou03_Group__c==null && other.getC002_Tantou03_Group__c()==null) || 
             (this.c002_Tantou03_Group__c!=null &&
              this.c002_Tantou03_Group__c.equals(other.getC002_Tantou03_Group__c()))) &&
            ((this.c002_Tantou03_Name__c==null && other.getC002_Tantou03_Name__c()==null) || 
             (this.c002_Tantou03_Name__c!=null &&
              this.c002_Tantou03_Name__c.equals(other.getC002_Tantou03_Name__c()))) &&
            ((this.c002_Tantou04_Group__c==null && other.getC002_Tantou04_Group__c()==null) || 
             (this.c002_Tantou04_Group__c!=null &&
              this.c002_Tantou04_Group__c.equals(other.getC002_Tantou04_Group__c()))) &&
            ((this.c002_Tantou04_Name__c==null && other.getC002_Tantou04_Name__c()==null) || 
             (this.c002_Tantou04_Name__c!=null &&
              this.c002_Tantou04_Name__c.equals(other.getC002_Tantou04_Name__c()))) &&
            ((this.c002_Tantou_01__c==null && other.getC002_Tantou_01__c()==null) || 
             (this.c002_Tantou_01__c!=null &&
              this.c002_Tantou_01__c.equals(other.getC002_Tantou_01__c()))) &&
            ((this.c002_Tantou_01__r==null && other.getC002_Tantou_01__r()==null) || 
             (this.c002_Tantou_01__r!=null &&
              this.c002_Tantou_01__r.equals(other.getC002_Tantou_01__r()))) &&
            ((this.c002_Tantou_02__c==null && other.getC002_Tantou_02__c()==null) || 
             (this.c002_Tantou_02__c!=null &&
              this.c002_Tantou_02__c.equals(other.getC002_Tantou_02__c()))) &&
            ((this.c002_Tantou_02__r==null && other.getC002_Tantou_02__r()==null) || 
             (this.c002_Tantou_02__r!=null &&
              this.c002_Tantou_02__r.equals(other.getC002_Tantou_02__r()))) &&
            ((this.c002_Tantou_03__c==null && other.getC002_Tantou_03__c()==null) || 
             (this.c002_Tantou_03__c!=null &&
              this.c002_Tantou_03__c.equals(other.getC002_Tantou_03__c()))) &&
            ((this.c002_Tantou_03__r==null && other.getC002_Tantou_03__r()==null) || 
             (this.c002_Tantou_03__r!=null &&
              this.c002_Tantou_03__r.equals(other.getC002_Tantou_03__r()))) &&
            ((this.c002_Tantou_04__c==null && other.getC002_Tantou_04__c()==null) || 
             (this.c002_Tantou_04__c!=null &&
              this.c002_Tantou_04__c.equals(other.getC002_Tantou_04__c()))) &&
            ((this.c002_Tantou_04__r==null && other.getC002_Tantou_04__r()==null) || 
             (this.c002_Tantou_04__r!=null &&
              this.c002_Tantou_04__r.equals(other.getC002_Tantou_04__r()))) &&
            ((this.c002_Tantou_05__c==null && other.getC002_Tantou_05__c()==null) || 
             (this.c002_Tantou_05__c!=null &&
              this.c002_Tantou_05__c.equals(other.getC002_Tantou_05__c()))) &&
            ((this.c002_Tantou_05__r==null && other.getC002_Tantou_05__r()==null) || 
             (this.c002_Tantou_05__r!=null &&
              this.c002_Tantou_05__r.equals(other.getC002_Tantou_05__r()))) &&
            ((this.c002_Tantou_Kensaku__c==null && other.getC002_Tantou_Kensaku__c()==null) || 
             (this.c002_Tantou_Kensaku__c!=null &&
              this.c002_Tantou_Kensaku__c.equals(other.getC002_Tantou_Kensaku__c()))) &&
            ((this.c002_TembanCif__c==null && other.getC002_TembanCif__c()==null) || 
             (this.c002_TembanCif__c!=null &&
              this.c002_TembanCif__c.equals(other.getC002_TembanCif__c()))) &&
            ((this.c002_TokoKakuzuke__c==null && other.getC002_TokoKakuzuke__c()==null) || 
             (this.c002_TokoKakuzuke__c!=null &&
              this.c002_TokoKakuzuke__c.equals(other.getC002_TokoKakuzuke__c()))) &&
            ((this.c002_Work__c==null && other.getC002_Work__c()==null) || 
             (this.c002_Work__c!=null &&
              this.c002_Work__c.equals(other.getC002_Work__c()))) &&
            ((this.c002_YomikomiNo__c==null && other.getC002_YomikomiNo__c()==null) || 
             (this.c002_YomikomiNo__c!=null &&
              this.c002_YomikomiNo__c.equals(other.getC002_YomikomiNo__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lastReferencedDate==null && other.getLastReferencedDate()==null) || 
             (this.lastReferencedDate!=null &&
              this.lastReferencedDate.equals(other.getLastReferencedDate()))) &&
            ((this.lastViewedDate==null && other.getLastViewedDate()==null) || 
             (this.lastViewedDate!=null &&
              this.lastViewedDate.equals(other.getLastViewedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.recordType==null && other.getRecordType()==null) || 
             (this.recordType!=null &&
              this.recordType.equals(other.getRecordType()))) &&
            ((this.recordTypeId==null && other.getRecordTypeId()==null) || 
             (this.recordTypeId!=null &&
              this.recordTypeId.equals(other.getRecordTypeId()))) &&
            ((this.shares==null && other.getShares()==null) || 
             (this.shares!=null &&
              this.shares.equals(other.getShares()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getA010_ActionPlan__c() != null) {
            _hashCode += getA010_ActionPlan__c().hashCode();
        }
        if (getA010_AnkenShudousha__c() != null) {
            _hashCode += getA010_AnkenShudousha__c().hashCode();
        }
        if (getA010_AnkenShurui1__c() != null) {
            _hashCode += getA010_AnkenShurui1__c().hashCode();
        }
        if (getA010_AnkenShurui2__c() != null) {
            _hashCode += getA010_AnkenShurui2__c().hashCode();
        }
        if (getA010_AnkenShurui3__c() != null) {
            _hashCode += getA010_AnkenShurui3__c().hashCode();
        }
        if (getA010_Bikou__c() != null) {
            _hashCode += getA010_Bikou__c().hashCode();
        }
        if (getA010_CaseId__c() != null) {
            _hashCode += getA010_CaseId__c().hashCode();
        }
        if (getA010_Country__c() != null) {
            _hashCode += getA010_Country__c().hashCode();
        }
        if (getA010_CsvTantou_01__c() != null) {
            _hashCode += getA010_CsvTantou_01__c().hashCode();
        }
        if (getA010_GBADUnit__c() != null) {
            _hashCode += getA010_GBADUnit__c().hashCode();
        }
        if (getA010_Group__c() != null) {
            _hashCode += getA010_Group__c().hashCode();
        }
        if (getA010_Kakudo__c() != null) {
            _hashCode += getA010_Kakudo__c().hashCode();
        }
        if (getA010_KankeiBusho1__c() != null) {
            _hashCode += getA010_KankeiBusho1__c().hashCode();
        }
        if (getA010_KankeiBusho2__c() != null) {
            _hashCode += getA010_KankeiBusho2__c().hashCode();
        }
        if (getA010_Kekka__c() != null) {
            _hashCode += getA010_Kekka__c().hashCode();
        }
        if (getA010_RenkeiKaigaiKyoten1__c() != null) {
            _hashCode += getA010_RenkeiKaigaiKyoten1__c().hashCode();
        }
        if (getA010_RenkeiKaigaiKyoten2__c() != null) {
            _hashCode += getA010_RenkeiKaigaiKyoten2__c().hashCode();
        }
        if (getA010_Saido__c() != null) {
            _hashCode += getA010_Saido__c().hashCode();
        }
        if (getA010_Shisaku__c() != null) {
            _hashCode += getA010_Shisaku__c().hashCode();
        }
        if (getA010_ShuekiShurui1__c() != null) {
            _hashCode += getA010_ShuekiShurui1__c().hashCode();
        }
        if (getA010_ShuekiShurui2__c() != null) {
            _hashCode += getA010_ShuekiShurui2__c().hashCode();
        }
        if (getA010_Shuekigaku__c() != null) {
            _hashCode += getA010_Shuekigaku__c().hashCode();
        }
        if (getA010_YoteizukiHizuke__c() != null) {
            _hashCode += getA010_YoteizukiHizuke__c().hashCode();
        }
        if (getA010_YoteizukiInt__c() != null) {
            _hashCode += getA010_YoteizukiInt__c().hashCode();
        }
        if (getA010_Yoteizuki__c() != null) {
            _hashCode += getA010_Yoteizuki__c().hashCode();
        }
        if (getA014_AnkenShurui__c() != null) {
            _hashCode += getA014_AnkenShurui__c().hashCode();
        }
        if (getA014_CaseCloseDate__c() != null) {
            _hashCode += getA014_CaseCloseDate__c().hashCode();
        }
        if (getA014_ChokusetsuSoshutsu__c() != null) {
            _hashCode += getA014_ChokusetsuSoshutsu__c().hashCode();
        }
        if (getA014_DecisionDate__c() != null) {
            _hashCode += getA014_DecisionDate__c().hashCode();
        }
        if (getA014_DecisionMeeting__c() != null) {
            _hashCode += getA014_DecisionMeeting__c().hashCode();
        }
        if (getA014_Kakudo__c() != null) {
            _hashCode += getA014_Kakudo__c().hashCode();
        }
        if (getA014_Outline__c() != null) {
            _hashCode += getA014_Outline__c().hashCode();
        }
        if (getA014_RelateState1__c() != null) {
            _hashCode += getA014_RelateState1__c().hashCode();
        }
        if (getA014_RelateState2__c() != null) {
            _hashCode += getA014_RelateState2__c().hashCode();
        }
        if (getA014_RelateState3__c() != null) {
            _hashCode += getA014_RelateState3__c().hashCode();
        }
        if (getA014_RelateTeam__c() != null) {
            _hashCode += getA014_RelateTeam__c().hashCode();
        }
        if (getA014_RenketsuShueki__c() != null) {
            _hashCode += getA014_RenketsuShueki__c().hashCode();
        }
        if (getA014_ShuekiAmount__c() != null) {
            _hashCode += getA014_ShuekiAmount__c().hashCode();
        }
        if (getA014_TantaiShueki__c() != null) {
            _hashCode += getA014_TantaiShueki__c().hashCode();
        }
        if (getA014_TantouTeam1__c() != null) {
            _hashCode += getA014_TantouTeam1__c().hashCode();
        }
        if (getA014_TantouTeam2__c() != null) {
            _hashCode += getA014_TantouTeam2__c().hashCode();
        }
        if (getA014_TantouTeam3__c() != null) {
            _hashCode += getA014_TantouTeam3__c().hashCode();
        }
        if (getA014_Tantousha1__c() != null) {
            _hashCode += getA014_Tantousha1__c().hashCode();
        }
        if (getA014_Tantousha2__c() != null) {
            _hashCode += getA014_Tantousha2__c().hashCode();
        }
        if (getA014_Tantousha3__c() != null) {
            _hashCode += getA014_Tantousha3__c().hashCode();
        }
        if (getA015_AnkenCategory__c() != null) {
            _hashCode += getA015_AnkenCategory__c().hashCode();
        }
        if (getA015_AnkenShubetsu__c() != null) {
            _hashCode += getA015_AnkenShubetsu__c().hashCode();
        }
        if (getA015_RisihokyuuSeido__c() != null) {
            _hashCode += getA015_RisihokyuuSeido__c().hashCode();
        }
        if (getA015_ToushiBasyo__c() != null) {
            _hashCode += getA015_ToushiBasyo__c().hashCode();
        }
        if (getA015_ToushiKingaku__c() != null) {
            _hashCode += getA015_ToushiKingaku__c().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getC002_AllowedChangeCustomer__c() != null) {
            _hashCode += getC002_AllowedChangeCustomer__c().hashCode();
        }
        if (getC002_Amount2__c() != null) {
            _hashCode += getC002_Amount2__c().hashCode();
        }
        if (getC002_Amount3__c() != null) {
            _hashCode += getC002_Amount3__c().hashCode();
        }
        if (getC002_Amount__c() != null) {
            _hashCode += getC002_Amount__c().hashCode();
        }
        if (getC002_AppName__c() != null) {
            _hashCode += getC002_AppName__c().hashCode();
        }
        if (getC002_CRM_AnkenId__c() != null) {
            _hashCode += getC002_CRM_AnkenId__c().hashCode();
        }
        if (getC002_CaseId__c() != null) {
            _hashCode += getC002_CaseId__c().hashCode();
        }
        if (getC002_CaseName__c() != null) {
            _hashCode += getC002_CaseName__c().hashCode();
        }
        if (getC002_Cases_01__r() != null) {
            _hashCode += getC002_Cases_01__r().hashCode();
        }
        if (getC002_CsvLastModifiedDate__c() != null) {
            _hashCode += getC002_CsvLastModifiedDate__c().hashCode();
        }
        if (getC002_CsvRecordTantou__c() != null) {
            _hashCode += getC002_CsvRecordTantou__c().hashCode();
        }
        if (getC002_CustomerId__c() != null) {
            _hashCode += getC002_CustomerId__c().hashCode();
        }
        if (getC002_CustomerName__c() != null) {
            _hashCode += getC002_CustomerName__c().hashCode();
        }
        if (getC002_CustomerRef__c() != null) {
            _hashCode += getC002_CustomerRef__c().hashCode();
        }
        if (getC002_CustomerRef__r() != null) {
            _hashCode += getC002_CustomerRef__r().hashCode();
        }
        if (getC002_Date1__c() != null) {
            _hashCode += getC002_Date1__c().hashCode();
        }
        if (getC002_DateFrom__c() != null) {
            _hashCode += getC002_DateFrom__c().hashCode();
        }
        if (getC002_DateTo__c() != null) {
            _hashCode += getC002_DateTo__c().hashCode();
        }
        if (getC002_Detail__c() != null) {
            _hashCode += getC002_Detail__c().hashCode();
        }
        if (getC002_Kakudo1__c() != null) {
            _hashCode += getC002_Kakudo1__c().hashCode();
        }
        if (getC002_Kakudo2__c() != null) {
            _hashCode += getC002_Kakudo2__c().hashCode();
        }
        if (getC002_KyotenName__c() != null) {
            _hashCode += getC002_KyotenName__c().hashCode();
        }
        if (getC002_Outline__c() != null) {
            _hashCode += getC002_Outline__c().hashCode();
        }
        if (getC002_ProfitRenketsu__c() != null) {
            _hashCode += getC002_ProfitRenketsu__c().hashCode();
        }
        if (getC002_ProfitTantai__c() != null) {
            _hashCode += getC002_ProfitTantai__c().hashCode();
        }
        if (getC002_RMTanto__c() != null) {
            _hashCode += getC002_RMTanto__c().hashCode();
        }
        if (getC002_RecordTantouButenName__c() != null) {
            _hashCode += getC002_RecordTantouButenName__c().hashCode();
        }
        if (getC002_RecordTantou__c() != null) {
            _hashCode += getC002_RecordTantou__c().hashCode();
        }
        if (getC002_RecordTantou__r() != null) {
            _hashCode += getC002_RecordTantou__r().hashCode();
        }
        if (getC002_RecordTypeName2__c() != null) {
            _hashCode += getC002_RecordTypeName2__c().hashCode();
        }
        if (getC002_RelatedTaskID__c() != null) {
            _hashCode += getC002_RelatedTaskID__c().hashCode();
        }
        if (getC002_RevenueDivision__c() != null) {
            _hashCode += getC002_RevenueDivision__c().hashCode();
        }
        if (getC002_Shinmitsudo__c() != null) {
            _hashCode += getC002_Shinmitsudo__c().hashCode();
        }
        if (getC002_TantobuTemban__c() != null) {
            _hashCode += getC002_TantobuTemban__c().hashCode();
        }
        if (getC002_Tantou01_Group__c() != null) {
            _hashCode += getC002_Tantou01_Group__c().hashCode();
        }
        if (getC002_Tantou01_Name__c() != null) {
            _hashCode += getC002_Tantou01_Name__c().hashCode();
        }
        if (getC002_Tantou02_Group__c() != null) {
            _hashCode += getC002_Tantou02_Group__c().hashCode();
        }
        if (getC002_Tantou02_Name__c() != null) {
            _hashCode += getC002_Tantou02_Name__c().hashCode();
        }
        if (getC002_Tantou03_Group__c() != null) {
            _hashCode += getC002_Tantou03_Group__c().hashCode();
        }
        if (getC002_Tantou03_Name__c() != null) {
            _hashCode += getC002_Tantou03_Name__c().hashCode();
        }
        if (getC002_Tantou04_Group__c() != null) {
            _hashCode += getC002_Tantou04_Group__c().hashCode();
        }
        if (getC002_Tantou04_Name__c() != null) {
            _hashCode += getC002_Tantou04_Name__c().hashCode();
        }
        if (getC002_Tantou_01__c() != null) {
            _hashCode += getC002_Tantou_01__c().hashCode();
        }
        if (getC002_Tantou_01__r() != null) {
            _hashCode += getC002_Tantou_01__r().hashCode();
        }
        if (getC002_Tantou_02__c() != null) {
            _hashCode += getC002_Tantou_02__c().hashCode();
        }
        if (getC002_Tantou_02__r() != null) {
            _hashCode += getC002_Tantou_02__r().hashCode();
        }
        if (getC002_Tantou_03__c() != null) {
            _hashCode += getC002_Tantou_03__c().hashCode();
        }
        if (getC002_Tantou_03__r() != null) {
            _hashCode += getC002_Tantou_03__r().hashCode();
        }
        if (getC002_Tantou_04__c() != null) {
            _hashCode += getC002_Tantou_04__c().hashCode();
        }
        if (getC002_Tantou_04__r() != null) {
            _hashCode += getC002_Tantou_04__r().hashCode();
        }
        if (getC002_Tantou_05__c() != null) {
            _hashCode += getC002_Tantou_05__c().hashCode();
        }
        if (getC002_Tantou_05__r() != null) {
            _hashCode += getC002_Tantou_05__r().hashCode();
        }
        if (getC002_Tantou_Kensaku__c() != null) {
            _hashCode += getC002_Tantou_Kensaku__c().hashCode();
        }
        if (getC002_TembanCif__c() != null) {
            _hashCode += getC002_TembanCif__c().hashCode();
        }
        if (getC002_TokoKakuzuke__c() != null) {
            _hashCode += getC002_TokoKakuzuke__c().hashCode();
        }
        if (getC002_Work__c() != null) {
            _hashCode += getC002_Work__c().hashCode();
        }
        if (getC002_YomikomiNo__c() != null) {
            _hashCode += getC002_YomikomiNo__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLastReferencedDate() != null) {
            _hashCode += getLastReferencedDate().hashCode();
        }
        if (getLastViewedDate() != null) {
            _hashCode += getLastViewedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getRecordType() != null) {
            _hashCode += getRecordType().hashCode();
        }
        if (getRecordTypeId() != null) {
            _hashCode += getRecordTypeId().hashCode();
        }
        if (getShares() != null) {
            _hashCode += getShares().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C002_Case__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Case__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_ActionPlan__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_ActionPlan__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_AnkenShudousha__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_AnkenShudousha__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_AnkenShurui1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_AnkenShurui1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_AnkenShurui2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_AnkenShurui2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_AnkenShurui3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_AnkenShurui3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_Bikou__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_Bikou__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_CaseId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_CaseId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_Country__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_Country__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_CsvTantou_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_CsvTantou_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_GBADUnit__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_GBADUnit__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_Group__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_Group__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_Kakudo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_Kakudo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_KankeiBusho1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_KankeiBusho1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_KankeiBusho2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_KankeiBusho2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_Kekka__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_Kekka__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_RenkeiKaigaiKyoten1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_RenkeiKaigaiKyoten1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_RenkeiKaigaiKyoten2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_RenkeiKaigaiKyoten2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_Saido__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_Saido__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_Shisaku__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_Shisaku__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_ShuekiShurui1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_ShuekiShurui1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_ShuekiShurui2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_ShuekiShurui2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_Shuekigaku__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_Shuekigaku__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_YoteizukiHizuke__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_YoteizukiHizuke__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_YoteizukiInt__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_YoteizukiInt__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a010_Yoteizuki__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A010_Yoteizuki__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_AnkenShurui__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_AnkenShurui__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_CaseCloseDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_CaseCloseDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_ChokusetsuSoshutsu__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_ChokusetsuSoshutsu__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_DecisionDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_DecisionDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_DecisionMeeting__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_DecisionMeeting__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_Kakudo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_Kakudo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_Outline__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_Outline__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_RelateState1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_RelateState1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_RelateState2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_RelateState2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_RelateState3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_RelateState3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_RelateTeam__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_RelateTeam__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_RenketsuShueki__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_RenketsuShueki__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_ShuekiAmount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_ShuekiAmount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TantaiShueki__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TantaiShueki__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TantouTeam1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TantouTeam1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TantouTeam2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TantouTeam2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TantouTeam3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TantouTeam3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_Tantousha1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_Tantousha1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_Tantousha2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_Tantousha2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_Tantousha3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_Tantousha3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a015_AnkenCategory__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A015_AnkenCategory__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a015_AnkenShubetsu__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A015_AnkenShubetsu__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a015_RisihokyuuSeido__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A015_RisihokyuuSeido__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a015_ToushiBasyo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A015_ToushiBasyo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a015_ToushiKingaku__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A015_ToushiKingaku__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_AllowedChangeCustomer__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_AllowedChangeCustomer__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Amount2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Amount2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Amount3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Amount3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Amount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Amount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_AppName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_AppName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CRM_AnkenId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CRM_AnkenId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CaseId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CaseId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CaseName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CaseName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Cases_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Cases_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CsvLastModifiedDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CsvLastModifiedDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CsvRecordTantou__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CsvRecordTantou__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CustomerId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CustomerId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CustomerName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CustomerName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CustomerRef__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CustomerRef__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CustomerRef__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CustomerRef__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C001_Customer__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Date1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Date1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_DateFrom__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_DateFrom__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_DateTo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_DateTo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Detail__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Detail__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Kakudo1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Kakudo1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Kakudo2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Kakudo2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_KyotenName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_KyotenName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Outline__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Outline__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_ProfitRenketsu__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_ProfitRenketsu__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_ProfitTantai__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_ProfitTantai__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RMTanto__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RMTanto__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RecordTantouButenName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RecordTantouButenName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RecordTantou__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RecordTantou__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RecordTantou__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RecordTantou__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RecordTypeName2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RecordTypeName2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RelatedTaskID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RelatedTaskID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RevenueDivision__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RevenueDivision__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Shinmitsudo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Shinmitsudo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_TantobuTemban__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_TantobuTemban__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou01_Group__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou01_Group__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou01_Name__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou01_Name__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou02_Group__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou02_Group__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou02_Name__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou02_Name__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou03_Group__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou03_Group__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou03_Name__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou03_Name__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou04_Group__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou04_Group__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou04_Name__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou04_Name__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_02__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_02__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_02__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_02__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_03__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_03__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_03__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_03__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_04__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_04__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_04__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_04__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_05__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_05__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_05__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_05__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tantou_Kensaku__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tantou_Kensaku__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_TembanCif__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_TembanCif__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_TokoKakuzuke__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_TokoKakuzuke__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Work__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Work__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_YomikomiNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_YomikomiNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastReferencedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastReferencedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastViewedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastViewedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recordType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RecordType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RecordType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recordTypeId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RecordTypeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
