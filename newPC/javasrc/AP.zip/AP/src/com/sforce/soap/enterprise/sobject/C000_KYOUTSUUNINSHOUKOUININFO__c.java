/**
 * C000_KYOUTSUUNINSHOUKOUININFO__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C000_KYOUTSUUNINSHOUKOUININFO__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult a001_ANKEN_TorikomiJoho_05__r;

    private com.sforce.soap.enterprise.QueryResult a002_ANKEN_Zairyou_003__r;

    private java.lang.String AREAPOSTCD__c;

    private java.lang.String AREATENBAN__c;

    private com.sforce.soap.enterprise.QueryResult activityHistories;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String BUTENBANGOUSHIYOUFLG__c;

    private java.lang.String BUTENBANGOU__c;

    private java.lang.String BUTENNM1__c;

    private java.lang.String BUTENNM2__c;

    private java.lang.String BUTENNM3__c;

    private java.lang.String BUTENNMRENKETSU__c;

    private com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_03__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_03__r;

    private com.sforce.soap.enterprise.QueryResult c002_Users_01__r;

    private com.sforce.soap.enterprise.QueryResult c002_Users_02__r;

    private com.sforce.soap.enterprise.QueryResult c002_Users_03__r;

    private com.sforce.soap.enterprise.QueryResult c002_Users_04__r;

    private com.sforce.soap.enterprise.QueryResult c002_Users_05__r;

    private com.sforce.soap.enterprise.QueryResult c002_Users_06__r;

    private com.sforce.soap.enterprise.QueryResult c002_Users_07__r;

    private com.sforce.soap.enterprise.QueryResult c002_Users_08__r;

    private com.sforce.soap.enterprise.QueryResult c002_Users_09__r;

    private java.lang.String CHAKUNINBI_WAREKI__c;

    private java.lang.String CHAKUNINNENGOU_WAREKI__c;

    private java.lang.String COURSECD__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult d002_001__r;

    private com.sforce.soap.enterprise.QueryResult d002_002__r;

    private com.sforce.soap.enterprise.QueryResult d003_001__r;

    private com.sforce.soap.enterprise.QueryResult d003_002__r;

    private com.sforce.soap.enterprise.QueryResult d004_ToDoSnaps__r;

    private com.sforce.soap.enterprise.QueryResult d004_ToDos__r;

    private java.lang.Boolean DELFLG__c;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult events;

    private java.lang.String FUNINHINENGOU_WAREKI__c;

    private java.lang.String FUNINHI_WAREKI__c;

    private java.lang.String FUZAIKBN__c;

    private java.lang.String GAPPEIKBN__c;

    private java.lang.String GRADEGRP__c;

    private java.lang.String GYOUMUCD__c;

    private java.lang.String HAKENMOTOBANGOU__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.String IDOUHATSUREIBI_WAREKI__c;

    private java.lang.String IDOUNENGOU_WAREKI__c;

    private java.lang.Boolean isDeleted;

    private java.lang.String JITAKURENRAKUSAKI__c;

    private java.lang.String JOUCHUUBUTENBANGOU__c;

    private java.lang.String JOUCHUUBUTENNM__c;

    private java.lang.String KAIGAIFLG__c;

    private java.lang.String KAISHACD__c;

    private java.lang.String KAISHANM__c;

    private java.lang.String KANASHIMEI__c;

    private java.lang.String KANJISHIMEISEARCH__c;

    private java.lang.String KANJISHIMEI__c;

    private java.lang.String KANRENKAISHAKBN__c;

    private java.lang.String KA_GRCD__c;

    private java.lang.String KA_GROUPNM__c;

    private java.lang.String KENMUBUTENBANGOU1__c;

    private java.lang.String KENMUBUTENBANGOU2__c;

    private java.lang.String KENMUBUTENBANGOU3__c;

    private java.lang.String KENMUBUTENBANGOU4__c;

    private java.lang.String KENMUBUTENBANGOU5__c;

    private java.lang.String KENMUKA_GRCD1__c;

    private java.lang.String KENMUKA_GRCD2__c;

    private java.lang.String KENMUKA_GRCD3__c;

    private java.lang.String KENMUKA_GRCD4__c;

    private java.lang.String KENMUKA_GRCD5__c;

    private java.lang.String KENMUSHISHANAIHOUJINBUCD1__c;

    private java.lang.String KENMUSHISHANAIHOUJINBUCD2__c;

    private java.lang.String KENMUSHISHANAIHOUJINBUCD3__c;

    private java.lang.String KENMUSHISHANAIHOUJINBUCD4__c;

    private java.lang.String KENMUSHISHANAIHOUJINBUCD5__c;

    private java.lang.String KENMUYAKUSHOKUCD1__c;

    private java.lang.String KENMUYAKUSHOKUCD2__c;

    private java.lang.String KENMUYAKUSHOKUCD3__c;

    private java.lang.String KENMUYAKUSHOKUCD4__c;

    private java.lang.String KENMUYAKUSHOKUCD5__c;

    private java.lang.String KIJUNBI_SEIREKI__c;

    private java.lang.String KOUINBANGOU__c;

    private java.lang.String KOUINGAIUCHIWAKEKBN__c;

    private java.lang.String KOUINKBN__c;

    private java.lang.String KOUINUCHIWAKEKBN__c;

    private com.sforce.soap.enterprise.QueryResult KYOUTSUUNINSHOKOUININFO__r;

    private com.sforce.soap.enterprise.QueryResult KYOUTSUUNINSHOUKOUININFOs__r;

    private java.util.Date lastActivityDate;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private java.lang.String o49_FLG__c;

    private com.sforce.soap.enterprise.QueryResult openActivities;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private java.lang.String POSTCDNM1__c;

    private java.lang.String POSTCDNM2__c;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String QN_FLG__c;

    private java.lang.String RANKKBN__c;

    private java.lang.String ROMEJISHIMEI__c;

    private java.lang.String SENNINKBN__c;

    private java.lang.String SHIKAKUCD__c;

    private java.lang.String SHISHANAIHOUJINBUCD__c;

    private java.lang.String SHOKUMUHATSUREIBI__c;

    private java.lang.String SHOKUMUHENKOUNENGOU_WAREKI__c;

    private java.lang.String SHOKUMUTANTOUCD1__c;

    private java.lang.String SHOKUMUTANTOUCD2__c;

    private java.lang.String SHOKUMUTANTOUCD3__c;

    private java.lang.String SHOKUSHU1__c;

    private java.lang.String SHOKUSHU2__c;

    private java.lang.String SHOKUSHU3__c;

    private java.lang.String SHUKKOUCD__c;

    private java.lang.String SHUKKOUSAKIBANGOU__c;

    private java.lang.String SMTPADDRESS__c;

    private com.sforce.soap.enterprise.QueryResult saikenJotoTsuchi_Cifkouininfo__r;

    private com.sforce.soap.enterprise.QueryResult saikenJotoTsuchi_kouininfo__r;

    private com.sforce.soap.enterprise.QueryResult shares;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult tasks;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private java.lang.String USERID__c;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    private java.lang.String YAKUDUKEKBN__c;

    private java.lang.String YAKUSHOKUCD__c;

    private java.lang.String YAKUSHOKUNM_RYAKU__c;

    private java.lang.String YAKUSHOKUNM_SEISHIKI__c;

    public C000_KYOUTSUUNINSHOUKOUININFO__c() {
    }

    public C000_KYOUTSUUNINSHOUKOUININFO__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult a001_ANKEN_TorikomiJoho_05__r,
           com.sforce.soap.enterprise.QueryResult a002_ANKEN_Zairyou_003__r,
           java.lang.String AREAPOSTCD__c,
           java.lang.String AREATENBAN__c,
           com.sforce.soap.enterprise.QueryResult activityHistories,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String BUTENBANGOUSHIYOUFLG__c,
           java.lang.String BUTENBANGOU__c,
           java.lang.String BUTENNM1__c,
           java.lang.String BUTENNM2__c,
           java.lang.String BUTENNM3__c,
           java.lang.String BUTENNMRENKETSU__c,
           com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_01__r,
           com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_03__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_03__r,
           com.sforce.soap.enterprise.QueryResult c002_Users_01__r,
           com.sforce.soap.enterprise.QueryResult c002_Users_02__r,
           com.sforce.soap.enterprise.QueryResult c002_Users_03__r,
           com.sforce.soap.enterprise.QueryResult c002_Users_04__r,
           com.sforce.soap.enterprise.QueryResult c002_Users_05__r,
           com.sforce.soap.enterprise.QueryResult c002_Users_06__r,
           com.sforce.soap.enterprise.QueryResult c002_Users_07__r,
           com.sforce.soap.enterprise.QueryResult c002_Users_08__r,
           com.sforce.soap.enterprise.QueryResult c002_Users_09__r,
           java.lang.String CHAKUNINBI_WAREKI__c,
           java.lang.String CHAKUNINNENGOU_WAREKI__c,
           java.lang.String COURSECD__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult d002_001__r,
           com.sforce.soap.enterprise.QueryResult d002_002__r,
           com.sforce.soap.enterprise.QueryResult d003_001__r,
           com.sforce.soap.enterprise.QueryResult d003_002__r,
           com.sforce.soap.enterprise.QueryResult d004_ToDoSnaps__r,
           com.sforce.soap.enterprise.QueryResult d004_ToDos__r,
           java.lang.Boolean DELFLG__c,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult events,
           java.lang.String FUNINHINENGOU_WAREKI__c,
           java.lang.String FUNINHI_WAREKI__c,
           java.lang.String FUZAIKBN__c,
           java.lang.String GAPPEIKBN__c,
           java.lang.String GRADEGRP__c,
           java.lang.String GYOUMUCD__c,
           java.lang.String HAKENMOTOBANGOU__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.String IDOUHATSUREIBI_WAREKI__c,
           java.lang.String IDOUNENGOU_WAREKI__c,
           java.lang.Boolean isDeleted,
           java.lang.String JITAKURENRAKUSAKI__c,
           java.lang.String JOUCHUUBUTENBANGOU__c,
           java.lang.String JOUCHUUBUTENNM__c,
           java.lang.String KAIGAIFLG__c,
           java.lang.String KAISHACD__c,
           java.lang.String KAISHANM__c,
           java.lang.String KANASHIMEI__c,
           java.lang.String KANJISHIMEISEARCH__c,
           java.lang.String KANJISHIMEI__c,
           java.lang.String KANRENKAISHAKBN__c,
           java.lang.String KA_GRCD__c,
           java.lang.String KA_GROUPNM__c,
           java.lang.String KENMUBUTENBANGOU1__c,
           java.lang.String KENMUBUTENBANGOU2__c,
           java.lang.String KENMUBUTENBANGOU3__c,
           java.lang.String KENMUBUTENBANGOU4__c,
           java.lang.String KENMUBUTENBANGOU5__c,
           java.lang.String KENMUKA_GRCD1__c,
           java.lang.String KENMUKA_GRCD2__c,
           java.lang.String KENMUKA_GRCD3__c,
           java.lang.String KENMUKA_GRCD4__c,
           java.lang.String KENMUKA_GRCD5__c,
           java.lang.String KENMUSHISHANAIHOUJINBUCD1__c,
           java.lang.String KENMUSHISHANAIHOUJINBUCD2__c,
           java.lang.String KENMUSHISHANAIHOUJINBUCD3__c,
           java.lang.String KENMUSHISHANAIHOUJINBUCD4__c,
           java.lang.String KENMUSHISHANAIHOUJINBUCD5__c,
           java.lang.String KENMUYAKUSHOKUCD1__c,
           java.lang.String KENMUYAKUSHOKUCD2__c,
           java.lang.String KENMUYAKUSHOKUCD3__c,
           java.lang.String KENMUYAKUSHOKUCD4__c,
           java.lang.String KENMUYAKUSHOKUCD5__c,
           java.lang.String KIJUNBI_SEIREKI__c,
           java.lang.String KOUINBANGOU__c,
           java.lang.String KOUINGAIUCHIWAKEKBN__c,
           java.lang.String KOUINKBN__c,
           java.lang.String KOUINUCHIWAKEKBN__c,
           com.sforce.soap.enterprise.QueryResult KYOUTSUUNINSHOKOUININFO__r,
           com.sforce.soap.enterprise.QueryResult KYOUTSUUNINSHOUKOUININFOs__r,
           java.util.Date lastActivityDate,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           java.lang.String o49_FLG__c,
           com.sforce.soap.enterprise.QueryResult openActivities,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           java.lang.String POSTCDNM1__c,
           java.lang.String POSTCDNM2__c,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String QN_FLG__c,
           java.lang.String RANKKBN__c,
           java.lang.String ROMEJISHIMEI__c,
           java.lang.String SENNINKBN__c,
           java.lang.String SHIKAKUCD__c,
           java.lang.String SHISHANAIHOUJINBUCD__c,
           java.lang.String SHOKUMUHATSUREIBI__c,
           java.lang.String SHOKUMUHENKOUNENGOU_WAREKI__c,
           java.lang.String SHOKUMUTANTOUCD1__c,
           java.lang.String SHOKUMUTANTOUCD2__c,
           java.lang.String SHOKUMUTANTOUCD3__c,
           java.lang.String SHOKUSHU1__c,
           java.lang.String SHOKUSHU2__c,
           java.lang.String SHOKUSHU3__c,
           java.lang.String SHUKKOUCD__c,
           java.lang.String SHUKKOUSAKIBANGOU__c,
           java.lang.String SMTPADDRESS__c,
           com.sforce.soap.enterprise.QueryResult saikenJotoTsuchi_Cifkouininfo__r,
           com.sforce.soap.enterprise.QueryResult saikenJotoTsuchi_kouininfo__r,
           com.sforce.soap.enterprise.QueryResult shares,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult tasks,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           java.lang.String USERID__c,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess,
           java.lang.String YAKUDUKEKBN__c,
           java.lang.String YAKUSHOKUCD__c,
           java.lang.String YAKUSHOKUNM_RYAKU__c,
           java.lang.String YAKUSHOKUNM_SEISHIKI__c) {
        super(
            fieldsToNull,
            id);
        this.a001_ANKEN_TorikomiJoho_05__r = a001_ANKEN_TorikomiJoho_05__r;
        this.a002_ANKEN_Zairyou_003__r = a002_ANKEN_Zairyou_003__r;
        this.AREAPOSTCD__c = AREAPOSTCD__c;
        this.AREATENBAN__c = AREATENBAN__c;
        this.activityHistories = activityHistories;
        this.attachments = attachments;
        this.BUTENBANGOUSHIYOUFLG__c = BUTENBANGOUSHIYOUFLG__c;
        this.BUTENBANGOU__c = BUTENBANGOU__c;
        this.BUTENNM1__c = BUTENNM1__c;
        this.BUTENNM2__c = BUTENNM2__c;
        this.BUTENNM3__c = BUTENNM3__c;
        this.BUTENNMRENKETSU__c = BUTENNMRENKETSU__c;
        this.c000_042_CIF_PROPERTY_CHANGE_INFO_01__r = c000_042_CIF_PROPERTY_CHANGE_INFO_01__r;
        this.c000_042_CIF_PROPERTY_CHANGE_INFO_03__r = c000_042_CIF_PROPERTY_CHANGE_INFO_03__r;
        this.c000_CIFZOKUSEIINFO_03__r = c000_CIFZOKUSEIINFO_03__r;
        this.c002_Users_01__r = c002_Users_01__r;
        this.c002_Users_02__r = c002_Users_02__r;
        this.c002_Users_03__r = c002_Users_03__r;
        this.c002_Users_04__r = c002_Users_04__r;
        this.c002_Users_05__r = c002_Users_05__r;
        this.c002_Users_06__r = c002_Users_06__r;
        this.c002_Users_07__r = c002_Users_07__r;
        this.c002_Users_08__r = c002_Users_08__r;
        this.c002_Users_09__r = c002_Users_09__r;
        this.CHAKUNINBI_WAREKI__c = CHAKUNINBI_WAREKI__c;
        this.CHAKUNINNENGOU_WAREKI__c = CHAKUNINNENGOU_WAREKI__c;
        this.COURSECD__c = COURSECD__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.d002_001__r = d002_001__r;
        this.d002_002__r = d002_002__r;
        this.d003_001__r = d003_001__r;
        this.d003_002__r = d003_002__r;
        this.d004_ToDoSnaps__r = d004_ToDoSnaps__r;
        this.d004_ToDos__r = d004_ToDos__r;
        this.DELFLG__c = DELFLG__c;
        this.duplicateRecordItems = duplicateRecordItems;
        this.events = events;
        this.FUNINHINENGOU_WAREKI__c = FUNINHINENGOU_WAREKI__c;
        this.FUNINHI_WAREKI__c = FUNINHI_WAREKI__c;
        this.FUZAIKBN__c = FUZAIKBN__c;
        this.GAPPEIKBN__c = GAPPEIKBN__c;
        this.GRADEGRP__c = GRADEGRP__c;
        this.GYOUMUCD__c = GYOUMUCD__c;
        this.HAKENMOTOBANGOU__c = HAKENMOTOBANGOU__c;
        this.histories = histories;
        this.IDOUHATSUREIBI_WAREKI__c = IDOUHATSUREIBI_WAREKI__c;
        this.IDOUNENGOU_WAREKI__c = IDOUNENGOU_WAREKI__c;
        this.isDeleted = isDeleted;
        this.JITAKURENRAKUSAKI__c = JITAKURENRAKUSAKI__c;
        this.JOUCHUUBUTENBANGOU__c = JOUCHUUBUTENBANGOU__c;
        this.JOUCHUUBUTENNM__c = JOUCHUUBUTENNM__c;
        this.KAIGAIFLG__c = KAIGAIFLG__c;
        this.KAISHACD__c = KAISHACD__c;
        this.KAISHANM__c = KAISHANM__c;
        this.KANASHIMEI__c = KANASHIMEI__c;
        this.KANJISHIMEISEARCH__c = KANJISHIMEISEARCH__c;
        this.KANJISHIMEI__c = KANJISHIMEI__c;
        this.KANRENKAISHAKBN__c = KANRENKAISHAKBN__c;
        this.KA_GRCD__c = KA_GRCD__c;
        this.KA_GROUPNM__c = KA_GROUPNM__c;
        this.KENMUBUTENBANGOU1__c = KENMUBUTENBANGOU1__c;
        this.KENMUBUTENBANGOU2__c = KENMUBUTENBANGOU2__c;
        this.KENMUBUTENBANGOU3__c = KENMUBUTENBANGOU3__c;
        this.KENMUBUTENBANGOU4__c = KENMUBUTENBANGOU4__c;
        this.KENMUBUTENBANGOU5__c = KENMUBUTENBANGOU5__c;
        this.KENMUKA_GRCD1__c = KENMUKA_GRCD1__c;
        this.KENMUKA_GRCD2__c = KENMUKA_GRCD2__c;
        this.KENMUKA_GRCD3__c = KENMUKA_GRCD3__c;
        this.KENMUKA_GRCD4__c = KENMUKA_GRCD4__c;
        this.KENMUKA_GRCD5__c = KENMUKA_GRCD5__c;
        this.KENMUSHISHANAIHOUJINBUCD1__c = KENMUSHISHANAIHOUJINBUCD1__c;
        this.KENMUSHISHANAIHOUJINBUCD2__c = KENMUSHISHANAIHOUJINBUCD2__c;
        this.KENMUSHISHANAIHOUJINBUCD3__c = KENMUSHISHANAIHOUJINBUCD3__c;
        this.KENMUSHISHANAIHOUJINBUCD4__c = KENMUSHISHANAIHOUJINBUCD4__c;
        this.KENMUSHISHANAIHOUJINBUCD5__c = KENMUSHISHANAIHOUJINBUCD5__c;
        this.KENMUYAKUSHOKUCD1__c = KENMUYAKUSHOKUCD1__c;
        this.KENMUYAKUSHOKUCD2__c = KENMUYAKUSHOKUCD2__c;
        this.KENMUYAKUSHOKUCD3__c = KENMUYAKUSHOKUCD3__c;
        this.KENMUYAKUSHOKUCD4__c = KENMUYAKUSHOKUCD4__c;
        this.KENMUYAKUSHOKUCD5__c = KENMUYAKUSHOKUCD5__c;
        this.KIJUNBI_SEIREKI__c = KIJUNBI_SEIREKI__c;
        this.KOUINBANGOU__c = KOUINBANGOU__c;
        this.KOUINGAIUCHIWAKEKBN__c = KOUINGAIUCHIWAKEKBN__c;
        this.KOUINKBN__c = KOUINKBN__c;
        this.KOUINUCHIWAKEKBN__c = KOUINUCHIWAKEKBN__c;
        this.KYOUTSUUNINSHOKOUININFO__r = KYOUTSUUNINSHOKOUININFO__r;
        this.KYOUTSUUNINSHOUKOUININFOs__r = KYOUTSUUNINSHOUKOUININFOs__r;
        this.lastActivityDate = lastActivityDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.o49_FLG__c = o49_FLG__c;
        this.openActivities = openActivities;
        this.owner = owner;
        this.ownerId = ownerId;
        this.POSTCDNM1__c = POSTCDNM1__c;
        this.POSTCDNM2__c = POSTCDNM2__c;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.QN_FLG__c = QN_FLG__c;
        this.RANKKBN__c = RANKKBN__c;
        this.ROMEJISHIMEI__c = ROMEJISHIMEI__c;
        this.SENNINKBN__c = SENNINKBN__c;
        this.SHIKAKUCD__c = SHIKAKUCD__c;
        this.SHISHANAIHOUJINBUCD__c = SHISHANAIHOUJINBUCD__c;
        this.SHOKUMUHATSUREIBI__c = SHOKUMUHATSUREIBI__c;
        this.SHOKUMUHENKOUNENGOU_WAREKI__c = SHOKUMUHENKOUNENGOU_WAREKI__c;
        this.SHOKUMUTANTOUCD1__c = SHOKUMUTANTOUCD1__c;
        this.SHOKUMUTANTOUCD2__c = SHOKUMUTANTOUCD2__c;
        this.SHOKUMUTANTOUCD3__c = SHOKUMUTANTOUCD3__c;
        this.SHOKUSHU1__c = SHOKUSHU1__c;
        this.SHOKUSHU2__c = SHOKUSHU2__c;
        this.SHOKUSHU3__c = SHOKUSHU3__c;
        this.SHUKKOUCD__c = SHUKKOUCD__c;
        this.SHUKKOUSAKIBANGOU__c = SHUKKOUSAKIBANGOU__c;
        this.SMTPADDRESS__c = SMTPADDRESS__c;
        this.saikenJotoTsuchi_Cifkouininfo__r = saikenJotoTsuchi_Cifkouininfo__r;
        this.saikenJotoTsuchi_kouininfo__r = saikenJotoTsuchi_kouininfo__r;
        this.shares = shares;
        this.systemModstamp = systemModstamp;
        this.tasks = tasks;
        this.topicAssignments = topicAssignments;
        this.USERID__c = USERID__c;
        this.userRecordAccess = userRecordAccess;
        this.YAKUDUKEKBN__c = YAKUDUKEKBN__c;
        this.YAKUSHOKUCD__c = YAKUSHOKUCD__c;
        this.YAKUSHOKUNM_RYAKU__c = YAKUSHOKUNM_RYAKU__c;
        this.YAKUSHOKUNM_SEISHIKI__c = YAKUSHOKUNM_SEISHIKI__c;
    }


    /**
     * Gets the a001_ANKEN_TorikomiJoho_05__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return a001_ANKEN_TorikomiJoho_05__r
     */
    public com.sforce.soap.enterprise.QueryResult getA001_ANKEN_TorikomiJoho_05__r() {
        return a001_ANKEN_TorikomiJoho_05__r;
    }


    /**
     * Sets the a001_ANKEN_TorikomiJoho_05__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param a001_ANKEN_TorikomiJoho_05__r
     */
    public void setA001_ANKEN_TorikomiJoho_05__r(com.sforce.soap.enterprise.QueryResult a001_ANKEN_TorikomiJoho_05__r) {
        this.a001_ANKEN_TorikomiJoho_05__r = a001_ANKEN_TorikomiJoho_05__r;
    }


    /**
     * Gets the a002_ANKEN_Zairyou_003__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return a002_ANKEN_Zairyou_003__r
     */
    public com.sforce.soap.enterprise.QueryResult getA002_ANKEN_Zairyou_003__r() {
        return a002_ANKEN_Zairyou_003__r;
    }


    /**
     * Sets the a002_ANKEN_Zairyou_003__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param a002_ANKEN_Zairyou_003__r
     */
    public void setA002_ANKEN_Zairyou_003__r(com.sforce.soap.enterprise.QueryResult a002_ANKEN_Zairyou_003__r) {
        this.a002_ANKEN_Zairyou_003__r = a002_ANKEN_Zairyou_003__r;
    }


    /**
     * Gets the AREAPOSTCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return AREAPOSTCD__c
     */
    public java.lang.String getAREAPOSTCD__c() {
        return AREAPOSTCD__c;
    }


    /**
     * Sets the AREAPOSTCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param AREAPOSTCD__c
     */
    public void setAREAPOSTCD__c(java.lang.String AREAPOSTCD__c) {
        this.AREAPOSTCD__c = AREAPOSTCD__c;
    }


    /**
     * Gets the AREATENBAN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return AREATENBAN__c
     */
    public java.lang.String getAREATENBAN__c() {
        return AREATENBAN__c;
    }


    /**
     * Sets the AREATENBAN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param AREATENBAN__c
     */
    public void setAREATENBAN__c(java.lang.String AREATENBAN__c) {
        this.AREATENBAN__c = AREATENBAN__c;
    }


    /**
     * Gets the activityHistories value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return activityHistories
     */
    public com.sforce.soap.enterprise.QueryResult getActivityHistories() {
        return activityHistories;
    }


    /**
     * Sets the activityHistories value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param activityHistories
     */
    public void setActivityHistories(com.sforce.soap.enterprise.QueryResult activityHistories) {
        this.activityHistories = activityHistories;
    }


    /**
     * Gets the attachments value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the BUTENBANGOUSHIYOUFLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return BUTENBANGOUSHIYOUFLG__c
     */
    public java.lang.String getBUTENBANGOUSHIYOUFLG__c() {
        return BUTENBANGOUSHIYOUFLG__c;
    }


    /**
     * Sets the BUTENBANGOUSHIYOUFLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param BUTENBANGOUSHIYOUFLG__c
     */
    public void setBUTENBANGOUSHIYOUFLG__c(java.lang.String BUTENBANGOUSHIYOUFLG__c) {
        this.BUTENBANGOUSHIYOUFLG__c = BUTENBANGOUSHIYOUFLG__c;
    }


    /**
     * Gets the BUTENBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return BUTENBANGOU__c
     */
    public java.lang.String getBUTENBANGOU__c() {
        return BUTENBANGOU__c;
    }


    /**
     * Sets the BUTENBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param BUTENBANGOU__c
     */
    public void setBUTENBANGOU__c(java.lang.String BUTENBANGOU__c) {
        this.BUTENBANGOU__c = BUTENBANGOU__c;
    }


    /**
     * Gets the BUTENNM1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return BUTENNM1__c
     */
    public java.lang.String getBUTENNM1__c() {
        return BUTENNM1__c;
    }


    /**
     * Sets the BUTENNM1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param BUTENNM1__c
     */
    public void setBUTENNM1__c(java.lang.String BUTENNM1__c) {
        this.BUTENNM1__c = BUTENNM1__c;
    }


    /**
     * Gets the BUTENNM2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return BUTENNM2__c
     */
    public java.lang.String getBUTENNM2__c() {
        return BUTENNM2__c;
    }


    /**
     * Sets the BUTENNM2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param BUTENNM2__c
     */
    public void setBUTENNM2__c(java.lang.String BUTENNM2__c) {
        this.BUTENNM2__c = BUTENNM2__c;
    }


    /**
     * Gets the BUTENNM3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return BUTENNM3__c
     */
    public java.lang.String getBUTENNM3__c() {
        return BUTENNM3__c;
    }


    /**
     * Sets the BUTENNM3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param BUTENNM3__c
     */
    public void setBUTENNM3__c(java.lang.String BUTENNM3__c) {
        this.BUTENNM3__c = BUTENNM3__c;
    }


    /**
     * Gets the BUTENNMRENKETSU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return BUTENNMRENKETSU__c
     */
    public java.lang.String getBUTENNMRENKETSU__c() {
        return BUTENNMRENKETSU__c;
    }


    /**
     * Sets the BUTENNMRENKETSU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param BUTENNMRENKETSU__c
     */
    public void setBUTENNMRENKETSU__c(java.lang.String BUTENNMRENKETSU__c) {
        this.BUTENNMRENKETSU__c = BUTENNMRENKETSU__c;
    }


    /**
     * Gets the c000_042_CIF_PROPERTY_CHANGE_INFO_01__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c000_042_CIF_PROPERTY_CHANGE_INFO_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_042_CIF_PROPERTY_CHANGE_INFO_01__r() {
        return c000_042_CIF_PROPERTY_CHANGE_INFO_01__r;
    }


    /**
     * Sets the c000_042_CIF_PROPERTY_CHANGE_INFO_01__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c000_042_CIF_PROPERTY_CHANGE_INFO_01__r
     */
    public void setC000_042_CIF_PROPERTY_CHANGE_INFO_01__r(com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_01__r) {
        this.c000_042_CIF_PROPERTY_CHANGE_INFO_01__r = c000_042_CIF_PROPERTY_CHANGE_INFO_01__r;
    }


    /**
     * Gets the c000_042_CIF_PROPERTY_CHANGE_INFO_03__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c000_042_CIF_PROPERTY_CHANGE_INFO_03__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_042_CIF_PROPERTY_CHANGE_INFO_03__r() {
        return c000_042_CIF_PROPERTY_CHANGE_INFO_03__r;
    }


    /**
     * Sets the c000_042_CIF_PROPERTY_CHANGE_INFO_03__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c000_042_CIF_PROPERTY_CHANGE_INFO_03__r
     */
    public void setC000_042_CIF_PROPERTY_CHANGE_INFO_03__r(com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_03__r) {
        this.c000_042_CIF_PROPERTY_CHANGE_INFO_03__r = c000_042_CIF_PROPERTY_CHANGE_INFO_03__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_03__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c000_CIFZOKUSEIINFO_03__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_03__r() {
        return c000_CIFZOKUSEIINFO_03__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_03__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c000_CIFZOKUSEIINFO_03__r
     */
    public void setC000_CIFZOKUSEIINFO_03__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_03__r) {
        this.c000_CIFZOKUSEIINFO_03__r = c000_CIFZOKUSEIINFO_03__r;
    }


    /**
     * Gets the c002_Users_01__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c002_Users_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Users_01__r() {
        return c002_Users_01__r;
    }


    /**
     * Sets the c002_Users_01__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c002_Users_01__r
     */
    public void setC002_Users_01__r(com.sforce.soap.enterprise.QueryResult c002_Users_01__r) {
        this.c002_Users_01__r = c002_Users_01__r;
    }


    /**
     * Gets the c002_Users_02__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c002_Users_02__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Users_02__r() {
        return c002_Users_02__r;
    }


    /**
     * Sets the c002_Users_02__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c002_Users_02__r
     */
    public void setC002_Users_02__r(com.sforce.soap.enterprise.QueryResult c002_Users_02__r) {
        this.c002_Users_02__r = c002_Users_02__r;
    }


    /**
     * Gets the c002_Users_03__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c002_Users_03__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Users_03__r() {
        return c002_Users_03__r;
    }


    /**
     * Sets the c002_Users_03__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c002_Users_03__r
     */
    public void setC002_Users_03__r(com.sforce.soap.enterprise.QueryResult c002_Users_03__r) {
        this.c002_Users_03__r = c002_Users_03__r;
    }


    /**
     * Gets the c002_Users_04__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c002_Users_04__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Users_04__r() {
        return c002_Users_04__r;
    }


    /**
     * Sets the c002_Users_04__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c002_Users_04__r
     */
    public void setC002_Users_04__r(com.sforce.soap.enterprise.QueryResult c002_Users_04__r) {
        this.c002_Users_04__r = c002_Users_04__r;
    }


    /**
     * Gets the c002_Users_05__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c002_Users_05__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Users_05__r() {
        return c002_Users_05__r;
    }


    /**
     * Sets the c002_Users_05__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c002_Users_05__r
     */
    public void setC002_Users_05__r(com.sforce.soap.enterprise.QueryResult c002_Users_05__r) {
        this.c002_Users_05__r = c002_Users_05__r;
    }


    /**
     * Gets the c002_Users_06__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c002_Users_06__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Users_06__r() {
        return c002_Users_06__r;
    }


    /**
     * Sets the c002_Users_06__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c002_Users_06__r
     */
    public void setC002_Users_06__r(com.sforce.soap.enterprise.QueryResult c002_Users_06__r) {
        this.c002_Users_06__r = c002_Users_06__r;
    }


    /**
     * Gets the c002_Users_07__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c002_Users_07__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Users_07__r() {
        return c002_Users_07__r;
    }


    /**
     * Sets the c002_Users_07__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c002_Users_07__r
     */
    public void setC002_Users_07__r(com.sforce.soap.enterprise.QueryResult c002_Users_07__r) {
        this.c002_Users_07__r = c002_Users_07__r;
    }


    /**
     * Gets the c002_Users_08__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c002_Users_08__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Users_08__r() {
        return c002_Users_08__r;
    }


    /**
     * Sets the c002_Users_08__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c002_Users_08__r
     */
    public void setC002_Users_08__r(com.sforce.soap.enterprise.QueryResult c002_Users_08__r) {
        this.c002_Users_08__r = c002_Users_08__r;
    }


    /**
     * Gets the c002_Users_09__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return c002_Users_09__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Users_09__r() {
        return c002_Users_09__r;
    }


    /**
     * Sets the c002_Users_09__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param c002_Users_09__r
     */
    public void setC002_Users_09__r(com.sforce.soap.enterprise.QueryResult c002_Users_09__r) {
        this.c002_Users_09__r = c002_Users_09__r;
    }


    /**
     * Gets the CHAKUNINBI_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return CHAKUNINBI_WAREKI__c
     */
    public java.lang.String getCHAKUNINBI_WAREKI__c() {
        return CHAKUNINBI_WAREKI__c;
    }


    /**
     * Sets the CHAKUNINBI_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param CHAKUNINBI_WAREKI__c
     */
    public void setCHAKUNINBI_WAREKI__c(java.lang.String CHAKUNINBI_WAREKI__c) {
        this.CHAKUNINBI_WAREKI__c = CHAKUNINBI_WAREKI__c;
    }


    /**
     * Gets the CHAKUNINNENGOU_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return CHAKUNINNENGOU_WAREKI__c
     */
    public java.lang.String getCHAKUNINNENGOU_WAREKI__c() {
        return CHAKUNINNENGOU_WAREKI__c;
    }


    /**
     * Sets the CHAKUNINNENGOU_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param CHAKUNINNENGOU_WAREKI__c
     */
    public void setCHAKUNINNENGOU_WAREKI__c(java.lang.String CHAKUNINNENGOU_WAREKI__c) {
        this.CHAKUNINNENGOU_WAREKI__c = CHAKUNINNENGOU_WAREKI__c;
    }


    /**
     * Gets the COURSECD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return COURSECD__c
     */
    public java.lang.String getCOURSECD__c() {
        return COURSECD__c;
    }


    /**
     * Sets the COURSECD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param COURSECD__c
     */
    public void setCOURSECD__c(java.lang.String COURSECD__c) {
        this.COURSECD__c = COURSECD__c;
    }


    /**
     * Gets the combinedAttachments value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the d002_001__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return d002_001__r
     */
    public com.sforce.soap.enterprise.QueryResult getD002_001__r() {
        return d002_001__r;
    }


    /**
     * Sets the d002_001__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param d002_001__r
     */
    public void setD002_001__r(com.sforce.soap.enterprise.QueryResult d002_001__r) {
        this.d002_001__r = d002_001__r;
    }


    /**
     * Gets the d002_002__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return d002_002__r
     */
    public com.sforce.soap.enterprise.QueryResult getD002_002__r() {
        return d002_002__r;
    }


    /**
     * Sets the d002_002__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param d002_002__r
     */
    public void setD002_002__r(com.sforce.soap.enterprise.QueryResult d002_002__r) {
        this.d002_002__r = d002_002__r;
    }


    /**
     * Gets the d003_001__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return d003_001__r
     */
    public com.sforce.soap.enterprise.QueryResult getD003_001__r() {
        return d003_001__r;
    }


    /**
     * Sets the d003_001__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param d003_001__r
     */
    public void setD003_001__r(com.sforce.soap.enterprise.QueryResult d003_001__r) {
        this.d003_001__r = d003_001__r;
    }


    /**
     * Gets the d003_002__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return d003_002__r
     */
    public com.sforce.soap.enterprise.QueryResult getD003_002__r() {
        return d003_002__r;
    }


    /**
     * Sets the d003_002__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param d003_002__r
     */
    public void setD003_002__r(com.sforce.soap.enterprise.QueryResult d003_002__r) {
        this.d003_002__r = d003_002__r;
    }


    /**
     * Gets the d004_ToDoSnaps__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return d004_ToDoSnaps__r
     */
    public com.sforce.soap.enterprise.QueryResult getD004_ToDoSnaps__r() {
        return d004_ToDoSnaps__r;
    }


    /**
     * Sets the d004_ToDoSnaps__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param d004_ToDoSnaps__r
     */
    public void setD004_ToDoSnaps__r(com.sforce.soap.enterprise.QueryResult d004_ToDoSnaps__r) {
        this.d004_ToDoSnaps__r = d004_ToDoSnaps__r;
    }


    /**
     * Gets the d004_ToDos__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return d004_ToDos__r
     */
    public com.sforce.soap.enterprise.QueryResult getD004_ToDos__r() {
        return d004_ToDos__r;
    }


    /**
     * Sets the d004_ToDos__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param d004_ToDos__r
     */
    public void setD004_ToDos__r(com.sforce.soap.enterprise.QueryResult d004_ToDos__r) {
        this.d004_ToDos__r = d004_ToDos__r;
    }


    /**
     * Gets the DELFLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return DELFLG__c
     */
    public java.lang.Boolean getDELFLG__c() {
        return DELFLG__c;
    }


    /**
     * Sets the DELFLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param DELFLG__c
     */
    public void setDELFLG__c(java.lang.Boolean DELFLG__c) {
        this.DELFLG__c = DELFLG__c;
    }


    /**
     * Gets the duplicateRecordItems value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the events value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return events
     */
    public com.sforce.soap.enterprise.QueryResult getEvents() {
        return events;
    }


    /**
     * Sets the events value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param events
     */
    public void setEvents(com.sforce.soap.enterprise.QueryResult events) {
        this.events = events;
    }


    /**
     * Gets the FUNINHINENGOU_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return FUNINHINENGOU_WAREKI__c
     */
    public java.lang.String getFUNINHINENGOU_WAREKI__c() {
        return FUNINHINENGOU_WAREKI__c;
    }


    /**
     * Sets the FUNINHINENGOU_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param FUNINHINENGOU_WAREKI__c
     */
    public void setFUNINHINENGOU_WAREKI__c(java.lang.String FUNINHINENGOU_WAREKI__c) {
        this.FUNINHINENGOU_WAREKI__c = FUNINHINENGOU_WAREKI__c;
    }


    /**
     * Gets the FUNINHI_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return FUNINHI_WAREKI__c
     */
    public java.lang.String getFUNINHI_WAREKI__c() {
        return FUNINHI_WAREKI__c;
    }


    /**
     * Sets the FUNINHI_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param FUNINHI_WAREKI__c
     */
    public void setFUNINHI_WAREKI__c(java.lang.String FUNINHI_WAREKI__c) {
        this.FUNINHI_WAREKI__c = FUNINHI_WAREKI__c;
    }


    /**
     * Gets the FUZAIKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return FUZAIKBN__c
     */
    public java.lang.String getFUZAIKBN__c() {
        return FUZAIKBN__c;
    }


    /**
     * Sets the FUZAIKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param FUZAIKBN__c
     */
    public void setFUZAIKBN__c(java.lang.String FUZAIKBN__c) {
        this.FUZAIKBN__c = FUZAIKBN__c;
    }


    /**
     * Gets the GAPPEIKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return GAPPEIKBN__c
     */
    public java.lang.String getGAPPEIKBN__c() {
        return GAPPEIKBN__c;
    }


    /**
     * Sets the GAPPEIKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param GAPPEIKBN__c
     */
    public void setGAPPEIKBN__c(java.lang.String GAPPEIKBN__c) {
        this.GAPPEIKBN__c = GAPPEIKBN__c;
    }


    /**
     * Gets the GRADEGRP__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return GRADEGRP__c
     */
    public java.lang.String getGRADEGRP__c() {
        return GRADEGRP__c;
    }


    /**
     * Sets the GRADEGRP__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param GRADEGRP__c
     */
    public void setGRADEGRP__c(java.lang.String GRADEGRP__c) {
        this.GRADEGRP__c = GRADEGRP__c;
    }


    /**
     * Gets the GYOUMUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return GYOUMUCD__c
     */
    public java.lang.String getGYOUMUCD__c() {
        return GYOUMUCD__c;
    }


    /**
     * Sets the GYOUMUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param GYOUMUCD__c
     */
    public void setGYOUMUCD__c(java.lang.String GYOUMUCD__c) {
        this.GYOUMUCD__c = GYOUMUCD__c;
    }


    /**
     * Gets the HAKENMOTOBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return HAKENMOTOBANGOU__c
     */
    public java.lang.String getHAKENMOTOBANGOU__c() {
        return HAKENMOTOBANGOU__c;
    }


    /**
     * Sets the HAKENMOTOBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param HAKENMOTOBANGOU__c
     */
    public void setHAKENMOTOBANGOU__c(java.lang.String HAKENMOTOBANGOU__c) {
        this.HAKENMOTOBANGOU__c = HAKENMOTOBANGOU__c;
    }


    /**
     * Gets the histories value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the IDOUHATSUREIBI_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return IDOUHATSUREIBI_WAREKI__c
     */
    public java.lang.String getIDOUHATSUREIBI_WAREKI__c() {
        return IDOUHATSUREIBI_WAREKI__c;
    }


    /**
     * Sets the IDOUHATSUREIBI_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param IDOUHATSUREIBI_WAREKI__c
     */
    public void setIDOUHATSUREIBI_WAREKI__c(java.lang.String IDOUHATSUREIBI_WAREKI__c) {
        this.IDOUHATSUREIBI_WAREKI__c = IDOUHATSUREIBI_WAREKI__c;
    }


    /**
     * Gets the IDOUNENGOU_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return IDOUNENGOU_WAREKI__c
     */
    public java.lang.String getIDOUNENGOU_WAREKI__c() {
        return IDOUNENGOU_WAREKI__c;
    }


    /**
     * Sets the IDOUNENGOU_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param IDOUNENGOU_WAREKI__c
     */
    public void setIDOUNENGOU_WAREKI__c(java.lang.String IDOUNENGOU_WAREKI__c) {
        this.IDOUNENGOU_WAREKI__c = IDOUNENGOU_WAREKI__c;
    }


    /**
     * Gets the isDeleted value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the JITAKURENRAKUSAKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return JITAKURENRAKUSAKI__c
     */
    public java.lang.String getJITAKURENRAKUSAKI__c() {
        return JITAKURENRAKUSAKI__c;
    }


    /**
     * Sets the JITAKURENRAKUSAKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param JITAKURENRAKUSAKI__c
     */
    public void setJITAKURENRAKUSAKI__c(java.lang.String JITAKURENRAKUSAKI__c) {
        this.JITAKURENRAKUSAKI__c = JITAKURENRAKUSAKI__c;
    }


    /**
     * Gets the JOUCHUUBUTENBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return JOUCHUUBUTENBANGOU__c
     */
    public java.lang.String getJOUCHUUBUTENBANGOU__c() {
        return JOUCHUUBUTENBANGOU__c;
    }


    /**
     * Sets the JOUCHUUBUTENBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param JOUCHUUBUTENBANGOU__c
     */
    public void setJOUCHUUBUTENBANGOU__c(java.lang.String JOUCHUUBUTENBANGOU__c) {
        this.JOUCHUUBUTENBANGOU__c = JOUCHUUBUTENBANGOU__c;
    }


    /**
     * Gets the JOUCHUUBUTENNM__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return JOUCHUUBUTENNM__c
     */
    public java.lang.String getJOUCHUUBUTENNM__c() {
        return JOUCHUUBUTENNM__c;
    }


    /**
     * Sets the JOUCHUUBUTENNM__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param JOUCHUUBUTENNM__c
     */
    public void setJOUCHUUBUTENNM__c(java.lang.String JOUCHUUBUTENNM__c) {
        this.JOUCHUUBUTENNM__c = JOUCHUUBUTENNM__c;
    }


    /**
     * Gets the KAIGAIFLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KAIGAIFLG__c
     */
    public java.lang.String getKAIGAIFLG__c() {
        return KAIGAIFLG__c;
    }


    /**
     * Sets the KAIGAIFLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KAIGAIFLG__c
     */
    public void setKAIGAIFLG__c(java.lang.String KAIGAIFLG__c) {
        this.KAIGAIFLG__c = KAIGAIFLG__c;
    }


    /**
     * Gets the KAISHACD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KAISHACD__c
     */
    public java.lang.String getKAISHACD__c() {
        return KAISHACD__c;
    }


    /**
     * Sets the KAISHACD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KAISHACD__c
     */
    public void setKAISHACD__c(java.lang.String KAISHACD__c) {
        this.KAISHACD__c = KAISHACD__c;
    }


    /**
     * Gets the KAISHANM__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KAISHANM__c
     */
    public java.lang.String getKAISHANM__c() {
        return KAISHANM__c;
    }


    /**
     * Sets the KAISHANM__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KAISHANM__c
     */
    public void setKAISHANM__c(java.lang.String KAISHANM__c) {
        this.KAISHANM__c = KAISHANM__c;
    }


    /**
     * Gets the KANASHIMEI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KANASHIMEI__c
     */
    public java.lang.String getKANASHIMEI__c() {
        return KANASHIMEI__c;
    }


    /**
     * Sets the KANASHIMEI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KANASHIMEI__c
     */
    public void setKANASHIMEI__c(java.lang.String KANASHIMEI__c) {
        this.KANASHIMEI__c = KANASHIMEI__c;
    }


    /**
     * Gets the KANJISHIMEISEARCH__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KANJISHIMEISEARCH__c
     */
    public java.lang.String getKANJISHIMEISEARCH__c() {
        return KANJISHIMEISEARCH__c;
    }


    /**
     * Sets the KANJISHIMEISEARCH__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KANJISHIMEISEARCH__c
     */
    public void setKANJISHIMEISEARCH__c(java.lang.String KANJISHIMEISEARCH__c) {
        this.KANJISHIMEISEARCH__c = KANJISHIMEISEARCH__c;
    }


    /**
     * Gets the KANJISHIMEI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KANJISHIMEI__c
     */
    public java.lang.String getKANJISHIMEI__c() {
        return KANJISHIMEI__c;
    }


    /**
     * Sets the KANJISHIMEI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KANJISHIMEI__c
     */
    public void setKANJISHIMEI__c(java.lang.String KANJISHIMEI__c) {
        this.KANJISHIMEI__c = KANJISHIMEI__c;
    }


    /**
     * Gets the KANRENKAISHAKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KANRENKAISHAKBN__c
     */
    public java.lang.String getKANRENKAISHAKBN__c() {
        return KANRENKAISHAKBN__c;
    }


    /**
     * Sets the KANRENKAISHAKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KANRENKAISHAKBN__c
     */
    public void setKANRENKAISHAKBN__c(java.lang.String KANRENKAISHAKBN__c) {
        this.KANRENKAISHAKBN__c = KANRENKAISHAKBN__c;
    }


    /**
     * Gets the KA_GRCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KA_GRCD__c
     */
    public java.lang.String getKA_GRCD__c() {
        return KA_GRCD__c;
    }


    /**
     * Sets the KA_GRCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KA_GRCD__c
     */
    public void setKA_GRCD__c(java.lang.String KA_GRCD__c) {
        this.KA_GRCD__c = KA_GRCD__c;
    }


    /**
     * Gets the KA_GROUPNM__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KA_GROUPNM__c
     */
    public java.lang.String getKA_GROUPNM__c() {
        return KA_GROUPNM__c;
    }


    /**
     * Sets the KA_GROUPNM__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KA_GROUPNM__c
     */
    public void setKA_GROUPNM__c(java.lang.String KA_GROUPNM__c) {
        this.KA_GROUPNM__c = KA_GROUPNM__c;
    }


    /**
     * Gets the KENMUBUTENBANGOU1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUBUTENBANGOU1__c
     */
    public java.lang.String getKENMUBUTENBANGOU1__c() {
        return KENMUBUTENBANGOU1__c;
    }


    /**
     * Sets the KENMUBUTENBANGOU1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUBUTENBANGOU1__c
     */
    public void setKENMUBUTENBANGOU1__c(java.lang.String KENMUBUTENBANGOU1__c) {
        this.KENMUBUTENBANGOU1__c = KENMUBUTENBANGOU1__c;
    }


    /**
     * Gets the KENMUBUTENBANGOU2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUBUTENBANGOU2__c
     */
    public java.lang.String getKENMUBUTENBANGOU2__c() {
        return KENMUBUTENBANGOU2__c;
    }


    /**
     * Sets the KENMUBUTENBANGOU2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUBUTENBANGOU2__c
     */
    public void setKENMUBUTENBANGOU2__c(java.lang.String KENMUBUTENBANGOU2__c) {
        this.KENMUBUTENBANGOU2__c = KENMUBUTENBANGOU2__c;
    }


    /**
     * Gets the KENMUBUTENBANGOU3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUBUTENBANGOU3__c
     */
    public java.lang.String getKENMUBUTENBANGOU3__c() {
        return KENMUBUTENBANGOU3__c;
    }


    /**
     * Sets the KENMUBUTENBANGOU3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUBUTENBANGOU3__c
     */
    public void setKENMUBUTENBANGOU3__c(java.lang.String KENMUBUTENBANGOU3__c) {
        this.KENMUBUTENBANGOU3__c = KENMUBUTENBANGOU3__c;
    }


    /**
     * Gets the KENMUBUTENBANGOU4__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUBUTENBANGOU4__c
     */
    public java.lang.String getKENMUBUTENBANGOU4__c() {
        return KENMUBUTENBANGOU4__c;
    }


    /**
     * Sets the KENMUBUTENBANGOU4__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUBUTENBANGOU4__c
     */
    public void setKENMUBUTENBANGOU4__c(java.lang.String KENMUBUTENBANGOU4__c) {
        this.KENMUBUTENBANGOU4__c = KENMUBUTENBANGOU4__c;
    }


    /**
     * Gets the KENMUBUTENBANGOU5__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUBUTENBANGOU5__c
     */
    public java.lang.String getKENMUBUTENBANGOU5__c() {
        return KENMUBUTENBANGOU5__c;
    }


    /**
     * Sets the KENMUBUTENBANGOU5__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUBUTENBANGOU5__c
     */
    public void setKENMUBUTENBANGOU5__c(java.lang.String KENMUBUTENBANGOU5__c) {
        this.KENMUBUTENBANGOU5__c = KENMUBUTENBANGOU5__c;
    }


    /**
     * Gets the KENMUKA_GRCD1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUKA_GRCD1__c
     */
    public java.lang.String getKENMUKA_GRCD1__c() {
        return KENMUKA_GRCD1__c;
    }


    /**
     * Sets the KENMUKA_GRCD1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUKA_GRCD1__c
     */
    public void setKENMUKA_GRCD1__c(java.lang.String KENMUKA_GRCD1__c) {
        this.KENMUKA_GRCD1__c = KENMUKA_GRCD1__c;
    }


    /**
     * Gets the KENMUKA_GRCD2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUKA_GRCD2__c
     */
    public java.lang.String getKENMUKA_GRCD2__c() {
        return KENMUKA_GRCD2__c;
    }


    /**
     * Sets the KENMUKA_GRCD2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUKA_GRCD2__c
     */
    public void setKENMUKA_GRCD2__c(java.lang.String KENMUKA_GRCD2__c) {
        this.KENMUKA_GRCD2__c = KENMUKA_GRCD2__c;
    }


    /**
     * Gets the KENMUKA_GRCD3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUKA_GRCD3__c
     */
    public java.lang.String getKENMUKA_GRCD3__c() {
        return KENMUKA_GRCD3__c;
    }


    /**
     * Sets the KENMUKA_GRCD3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUKA_GRCD3__c
     */
    public void setKENMUKA_GRCD3__c(java.lang.String KENMUKA_GRCD3__c) {
        this.KENMUKA_GRCD3__c = KENMUKA_GRCD3__c;
    }


    /**
     * Gets the KENMUKA_GRCD4__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUKA_GRCD4__c
     */
    public java.lang.String getKENMUKA_GRCD4__c() {
        return KENMUKA_GRCD4__c;
    }


    /**
     * Sets the KENMUKA_GRCD4__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUKA_GRCD4__c
     */
    public void setKENMUKA_GRCD4__c(java.lang.String KENMUKA_GRCD4__c) {
        this.KENMUKA_GRCD4__c = KENMUKA_GRCD4__c;
    }


    /**
     * Gets the KENMUKA_GRCD5__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUKA_GRCD5__c
     */
    public java.lang.String getKENMUKA_GRCD5__c() {
        return KENMUKA_GRCD5__c;
    }


    /**
     * Sets the KENMUKA_GRCD5__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUKA_GRCD5__c
     */
    public void setKENMUKA_GRCD5__c(java.lang.String KENMUKA_GRCD5__c) {
        this.KENMUKA_GRCD5__c = KENMUKA_GRCD5__c;
    }


    /**
     * Gets the KENMUSHISHANAIHOUJINBUCD1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUSHISHANAIHOUJINBUCD1__c
     */
    public java.lang.String getKENMUSHISHANAIHOUJINBUCD1__c() {
        return KENMUSHISHANAIHOUJINBUCD1__c;
    }


    /**
     * Sets the KENMUSHISHANAIHOUJINBUCD1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUSHISHANAIHOUJINBUCD1__c
     */
    public void setKENMUSHISHANAIHOUJINBUCD1__c(java.lang.String KENMUSHISHANAIHOUJINBUCD1__c) {
        this.KENMUSHISHANAIHOUJINBUCD1__c = KENMUSHISHANAIHOUJINBUCD1__c;
    }


    /**
     * Gets the KENMUSHISHANAIHOUJINBUCD2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUSHISHANAIHOUJINBUCD2__c
     */
    public java.lang.String getKENMUSHISHANAIHOUJINBUCD2__c() {
        return KENMUSHISHANAIHOUJINBUCD2__c;
    }


    /**
     * Sets the KENMUSHISHANAIHOUJINBUCD2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUSHISHANAIHOUJINBUCD2__c
     */
    public void setKENMUSHISHANAIHOUJINBUCD2__c(java.lang.String KENMUSHISHANAIHOUJINBUCD2__c) {
        this.KENMUSHISHANAIHOUJINBUCD2__c = KENMUSHISHANAIHOUJINBUCD2__c;
    }


    /**
     * Gets the KENMUSHISHANAIHOUJINBUCD3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUSHISHANAIHOUJINBUCD3__c
     */
    public java.lang.String getKENMUSHISHANAIHOUJINBUCD3__c() {
        return KENMUSHISHANAIHOUJINBUCD3__c;
    }


    /**
     * Sets the KENMUSHISHANAIHOUJINBUCD3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUSHISHANAIHOUJINBUCD3__c
     */
    public void setKENMUSHISHANAIHOUJINBUCD3__c(java.lang.String KENMUSHISHANAIHOUJINBUCD3__c) {
        this.KENMUSHISHANAIHOUJINBUCD3__c = KENMUSHISHANAIHOUJINBUCD3__c;
    }


    /**
     * Gets the KENMUSHISHANAIHOUJINBUCD4__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUSHISHANAIHOUJINBUCD4__c
     */
    public java.lang.String getKENMUSHISHANAIHOUJINBUCD4__c() {
        return KENMUSHISHANAIHOUJINBUCD4__c;
    }


    /**
     * Sets the KENMUSHISHANAIHOUJINBUCD4__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUSHISHANAIHOUJINBUCD4__c
     */
    public void setKENMUSHISHANAIHOUJINBUCD4__c(java.lang.String KENMUSHISHANAIHOUJINBUCD4__c) {
        this.KENMUSHISHANAIHOUJINBUCD4__c = KENMUSHISHANAIHOUJINBUCD4__c;
    }


    /**
     * Gets the KENMUSHISHANAIHOUJINBUCD5__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUSHISHANAIHOUJINBUCD5__c
     */
    public java.lang.String getKENMUSHISHANAIHOUJINBUCD5__c() {
        return KENMUSHISHANAIHOUJINBUCD5__c;
    }


    /**
     * Sets the KENMUSHISHANAIHOUJINBUCD5__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUSHISHANAIHOUJINBUCD5__c
     */
    public void setKENMUSHISHANAIHOUJINBUCD5__c(java.lang.String KENMUSHISHANAIHOUJINBUCD5__c) {
        this.KENMUSHISHANAIHOUJINBUCD5__c = KENMUSHISHANAIHOUJINBUCD5__c;
    }


    /**
     * Gets the KENMUYAKUSHOKUCD1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUYAKUSHOKUCD1__c
     */
    public java.lang.String getKENMUYAKUSHOKUCD1__c() {
        return KENMUYAKUSHOKUCD1__c;
    }


    /**
     * Sets the KENMUYAKUSHOKUCD1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUYAKUSHOKUCD1__c
     */
    public void setKENMUYAKUSHOKUCD1__c(java.lang.String KENMUYAKUSHOKUCD1__c) {
        this.KENMUYAKUSHOKUCD1__c = KENMUYAKUSHOKUCD1__c;
    }


    /**
     * Gets the KENMUYAKUSHOKUCD2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUYAKUSHOKUCD2__c
     */
    public java.lang.String getKENMUYAKUSHOKUCD2__c() {
        return KENMUYAKUSHOKUCD2__c;
    }


    /**
     * Sets the KENMUYAKUSHOKUCD2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUYAKUSHOKUCD2__c
     */
    public void setKENMUYAKUSHOKUCD2__c(java.lang.String KENMUYAKUSHOKUCD2__c) {
        this.KENMUYAKUSHOKUCD2__c = KENMUYAKUSHOKUCD2__c;
    }


    /**
     * Gets the KENMUYAKUSHOKUCD3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUYAKUSHOKUCD3__c
     */
    public java.lang.String getKENMUYAKUSHOKUCD3__c() {
        return KENMUYAKUSHOKUCD3__c;
    }


    /**
     * Sets the KENMUYAKUSHOKUCD3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUYAKUSHOKUCD3__c
     */
    public void setKENMUYAKUSHOKUCD3__c(java.lang.String KENMUYAKUSHOKUCD3__c) {
        this.KENMUYAKUSHOKUCD3__c = KENMUYAKUSHOKUCD3__c;
    }


    /**
     * Gets the KENMUYAKUSHOKUCD4__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUYAKUSHOKUCD4__c
     */
    public java.lang.String getKENMUYAKUSHOKUCD4__c() {
        return KENMUYAKUSHOKUCD4__c;
    }


    /**
     * Sets the KENMUYAKUSHOKUCD4__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUYAKUSHOKUCD4__c
     */
    public void setKENMUYAKUSHOKUCD4__c(java.lang.String KENMUYAKUSHOKUCD4__c) {
        this.KENMUYAKUSHOKUCD4__c = KENMUYAKUSHOKUCD4__c;
    }


    /**
     * Gets the KENMUYAKUSHOKUCD5__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KENMUYAKUSHOKUCD5__c
     */
    public java.lang.String getKENMUYAKUSHOKUCD5__c() {
        return KENMUYAKUSHOKUCD5__c;
    }


    /**
     * Sets the KENMUYAKUSHOKUCD5__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KENMUYAKUSHOKUCD5__c
     */
    public void setKENMUYAKUSHOKUCD5__c(java.lang.String KENMUYAKUSHOKUCD5__c) {
        this.KENMUYAKUSHOKUCD5__c = KENMUYAKUSHOKUCD5__c;
    }


    /**
     * Gets the KIJUNBI_SEIREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KIJUNBI_SEIREKI__c
     */
    public java.lang.String getKIJUNBI_SEIREKI__c() {
        return KIJUNBI_SEIREKI__c;
    }


    /**
     * Sets the KIJUNBI_SEIREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KIJUNBI_SEIREKI__c
     */
    public void setKIJUNBI_SEIREKI__c(java.lang.String KIJUNBI_SEIREKI__c) {
        this.KIJUNBI_SEIREKI__c = KIJUNBI_SEIREKI__c;
    }


    /**
     * Gets the KOUINBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KOUINBANGOU__c
     */
    public java.lang.String getKOUINBANGOU__c() {
        return KOUINBANGOU__c;
    }


    /**
     * Sets the KOUINBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KOUINBANGOU__c
     */
    public void setKOUINBANGOU__c(java.lang.String KOUINBANGOU__c) {
        this.KOUINBANGOU__c = KOUINBANGOU__c;
    }


    /**
     * Gets the KOUINGAIUCHIWAKEKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KOUINGAIUCHIWAKEKBN__c
     */
    public java.lang.String getKOUINGAIUCHIWAKEKBN__c() {
        return KOUINGAIUCHIWAKEKBN__c;
    }


    /**
     * Sets the KOUINGAIUCHIWAKEKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KOUINGAIUCHIWAKEKBN__c
     */
    public void setKOUINGAIUCHIWAKEKBN__c(java.lang.String KOUINGAIUCHIWAKEKBN__c) {
        this.KOUINGAIUCHIWAKEKBN__c = KOUINGAIUCHIWAKEKBN__c;
    }


    /**
     * Gets the KOUINKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KOUINKBN__c
     */
    public java.lang.String getKOUINKBN__c() {
        return KOUINKBN__c;
    }


    /**
     * Sets the KOUINKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KOUINKBN__c
     */
    public void setKOUINKBN__c(java.lang.String KOUINKBN__c) {
        this.KOUINKBN__c = KOUINKBN__c;
    }


    /**
     * Gets the KOUINUCHIWAKEKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KOUINUCHIWAKEKBN__c
     */
    public java.lang.String getKOUINUCHIWAKEKBN__c() {
        return KOUINUCHIWAKEKBN__c;
    }


    /**
     * Sets the KOUINUCHIWAKEKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KOUINUCHIWAKEKBN__c
     */
    public void setKOUINUCHIWAKEKBN__c(java.lang.String KOUINUCHIWAKEKBN__c) {
        this.KOUINUCHIWAKEKBN__c = KOUINUCHIWAKEKBN__c;
    }


    /**
     * Gets the KYOUTSUUNINSHOKOUININFO__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KYOUTSUUNINSHOKOUININFO__r
     */
    public com.sforce.soap.enterprise.QueryResult getKYOUTSUUNINSHOKOUININFO__r() {
        return KYOUTSUUNINSHOKOUININFO__r;
    }


    /**
     * Sets the KYOUTSUUNINSHOKOUININFO__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KYOUTSUUNINSHOKOUININFO__r
     */
    public void setKYOUTSUUNINSHOKOUININFO__r(com.sforce.soap.enterprise.QueryResult KYOUTSUUNINSHOKOUININFO__r) {
        this.KYOUTSUUNINSHOKOUININFO__r = KYOUTSUUNINSHOKOUININFO__r;
    }


    /**
     * Gets the KYOUTSUUNINSHOUKOUININFOs__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return KYOUTSUUNINSHOUKOUININFOs__r
     */
    public com.sforce.soap.enterprise.QueryResult getKYOUTSUUNINSHOUKOUININFOs__r() {
        return KYOUTSUUNINSHOUKOUININFOs__r;
    }


    /**
     * Sets the KYOUTSUUNINSHOUKOUININFOs__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param KYOUTSUUNINSHOUKOUININFOs__r
     */
    public void setKYOUTSUUNINSHOUKOUININFOs__r(com.sforce.soap.enterprise.QueryResult KYOUTSUUNINSHOUKOUININFOs__r) {
        this.KYOUTSUUNINSHOUKOUININFOs__r = KYOUTSUUNINSHOUKOUININFOs__r;
    }


    /**
     * Gets the lastActivityDate value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return lastActivityDate
     */
    public java.util.Date getLastActivityDate() {
        return lastActivityDate;
    }


    /**
     * Sets the lastActivityDate value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param lastActivityDate
     */
    public void setLastActivityDate(java.util.Date lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }


    /**
     * Gets the lastModifiedBy value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the o49_FLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return o49_FLG__c
     */
    public java.lang.String getO49_FLG__c() {
        return o49_FLG__c;
    }


    /**
     * Sets the o49_FLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param o49_FLG__c
     */
    public void setO49_FLG__c(java.lang.String o49_FLG__c) {
        this.o49_FLG__c = o49_FLG__c;
    }


    /**
     * Gets the openActivities value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return openActivities
     */
    public com.sforce.soap.enterprise.QueryResult getOpenActivities() {
        return openActivities;
    }


    /**
     * Sets the openActivities value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param openActivities
     */
    public void setOpenActivities(com.sforce.soap.enterprise.QueryResult openActivities) {
        this.openActivities = openActivities;
    }


    /**
     * Gets the owner value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the POSTCDNM1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return POSTCDNM1__c
     */
    public java.lang.String getPOSTCDNM1__c() {
        return POSTCDNM1__c;
    }


    /**
     * Sets the POSTCDNM1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param POSTCDNM1__c
     */
    public void setPOSTCDNM1__c(java.lang.String POSTCDNM1__c) {
        this.POSTCDNM1__c = POSTCDNM1__c;
    }


    /**
     * Gets the POSTCDNM2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return POSTCDNM2__c
     */
    public java.lang.String getPOSTCDNM2__c() {
        return POSTCDNM2__c;
    }


    /**
     * Sets the POSTCDNM2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param POSTCDNM2__c
     */
    public void setPOSTCDNM2__c(java.lang.String POSTCDNM2__c) {
        this.POSTCDNM2__c = POSTCDNM2__c;
    }


    /**
     * Gets the processInstances value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the QN_FLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return QN_FLG__c
     */
    public java.lang.String getQN_FLG__c() {
        return QN_FLG__c;
    }


    /**
     * Sets the QN_FLG__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param QN_FLG__c
     */
    public void setQN_FLG__c(java.lang.String QN_FLG__c) {
        this.QN_FLG__c = QN_FLG__c;
    }


    /**
     * Gets the RANKKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return RANKKBN__c
     */
    public java.lang.String getRANKKBN__c() {
        return RANKKBN__c;
    }


    /**
     * Sets the RANKKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param RANKKBN__c
     */
    public void setRANKKBN__c(java.lang.String RANKKBN__c) {
        this.RANKKBN__c = RANKKBN__c;
    }


    /**
     * Gets the ROMEJISHIMEI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return ROMEJISHIMEI__c
     */
    public java.lang.String getROMEJISHIMEI__c() {
        return ROMEJISHIMEI__c;
    }


    /**
     * Sets the ROMEJISHIMEI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param ROMEJISHIMEI__c
     */
    public void setROMEJISHIMEI__c(java.lang.String ROMEJISHIMEI__c) {
        this.ROMEJISHIMEI__c = ROMEJISHIMEI__c;
    }


    /**
     * Gets the SENNINKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SENNINKBN__c
     */
    public java.lang.String getSENNINKBN__c() {
        return SENNINKBN__c;
    }


    /**
     * Sets the SENNINKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SENNINKBN__c
     */
    public void setSENNINKBN__c(java.lang.String SENNINKBN__c) {
        this.SENNINKBN__c = SENNINKBN__c;
    }


    /**
     * Gets the SHIKAKUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHIKAKUCD__c
     */
    public java.lang.String getSHIKAKUCD__c() {
        return SHIKAKUCD__c;
    }


    /**
     * Sets the SHIKAKUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHIKAKUCD__c
     */
    public void setSHIKAKUCD__c(java.lang.String SHIKAKUCD__c) {
        this.SHIKAKUCD__c = SHIKAKUCD__c;
    }


    /**
     * Gets the SHISHANAIHOUJINBUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHISHANAIHOUJINBUCD__c
     */
    public java.lang.String getSHISHANAIHOUJINBUCD__c() {
        return SHISHANAIHOUJINBUCD__c;
    }


    /**
     * Sets the SHISHANAIHOUJINBUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHISHANAIHOUJINBUCD__c
     */
    public void setSHISHANAIHOUJINBUCD__c(java.lang.String SHISHANAIHOUJINBUCD__c) {
        this.SHISHANAIHOUJINBUCD__c = SHISHANAIHOUJINBUCD__c;
    }


    /**
     * Gets the SHOKUMUHATSUREIBI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHOKUMUHATSUREIBI__c
     */
    public java.lang.String getSHOKUMUHATSUREIBI__c() {
        return SHOKUMUHATSUREIBI__c;
    }


    /**
     * Sets the SHOKUMUHATSUREIBI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHOKUMUHATSUREIBI__c
     */
    public void setSHOKUMUHATSUREIBI__c(java.lang.String SHOKUMUHATSUREIBI__c) {
        this.SHOKUMUHATSUREIBI__c = SHOKUMUHATSUREIBI__c;
    }


    /**
     * Gets the SHOKUMUHENKOUNENGOU_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHOKUMUHENKOUNENGOU_WAREKI__c
     */
    public java.lang.String getSHOKUMUHENKOUNENGOU_WAREKI__c() {
        return SHOKUMUHENKOUNENGOU_WAREKI__c;
    }


    /**
     * Sets the SHOKUMUHENKOUNENGOU_WAREKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHOKUMUHENKOUNENGOU_WAREKI__c
     */
    public void setSHOKUMUHENKOUNENGOU_WAREKI__c(java.lang.String SHOKUMUHENKOUNENGOU_WAREKI__c) {
        this.SHOKUMUHENKOUNENGOU_WAREKI__c = SHOKUMUHENKOUNENGOU_WAREKI__c;
    }


    /**
     * Gets the SHOKUMUTANTOUCD1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHOKUMUTANTOUCD1__c
     */
    public java.lang.String getSHOKUMUTANTOUCD1__c() {
        return SHOKUMUTANTOUCD1__c;
    }


    /**
     * Sets the SHOKUMUTANTOUCD1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHOKUMUTANTOUCD1__c
     */
    public void setSHOKUMUTANTOUCD1__c(java.lang.String SHOKUMUTANTOUCD1__c) {
        this.SHOKUMUTANTOUCD1__c = SHOKUMUTANTOUCD1__c;
    }


    /**
     * Gets the SHOKUMUTANTOUCD2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHOKUMUTANTOUCD2__c
     */
    public java.lang.String getSHOKUMUTANTOUCD2__c() {
        return SHOKUMUTANTOUCD2__c;
    }


    /**
     * Sets the SHOKUMUTANTOUCD2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHOKUMUTANTOUCD2__c
     */
    public void setSHOKUMUTANTOUCD2__c(java.lang.String SHOKUMUTANTOUCD2__c) {
        this.SHOKUMUTANTOUCD2__c = SHOKUMUTANTOUCD2__c;
    }


    /**
     * Gets the SHOKUMUTANTOUCD3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHOKUMUTANTOUCD3__c
     */
    public java.lang.String getSHOKUMUTANTOUCD3__c() {
        return SHOKUMUTANTOUCD3__c;
    }


    /**
     * Sets the SHOKUMUTANTOUCD3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHOKUMUTANTOUCD3__c
     */
    public void setSHOKUMUTANTOUCD3__c(java.lang.String SHOKUMUTANTOUCD3__c) {
        this.SHOKUMUTANTOUCD3__c = SHOKUMUTANTOUCD3__c;
    }


    /**
     * Gets the SHOKUSHU1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHOKUSHU1__c
     */
    public java.lang.String getSHOKUSHU1__c() {
        return SHOKUSHU1__c;
    }


    /**
     * Sets the SHOKUSHU1__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHOKUSHU1__c
     */
    public void setSHOKUSHU1__c(java.lang.String SHOKUSHU1__c) {
        this.SHOKUSHU1__c = SHOKUSHU1__c;
    }


    /**
     * Gets the SHOKUSHU2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHOKUSHU2__c
     */
    public java.lang.String getSHOKUSHU2__c() {
        return SHOKUSHU2__c;
    }


    /**
     * Sets the SHOKUSHU2__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHOKUSHU2__c
     */
    public void setSHOKUSHU2__c(java.lang.String SHOKUSHU2__c) {
        this.SHOKUSHU2__c = SHOKUSHU2__c;
    }


    /**
     * Gets the SHOKUSHU3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHOKUSHU3__c
     */
    public java.lang.String getSHOKUSHU3__c() {
        return SHOKUSHU3__c;
    }


    /**
     * Sets the SHOKUSHU3__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHOKUSHU3__c
     */
    public void setSHOKUSHU3__c(java.lang.String SHOKUSHU3__c) {
        this.SHOKUSHU3__c = SHOKUSHU3__c;
    }


    /**
     * Gets the SHUKKOUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHUKKOUCD__c
     */
    public java.lang.String getSHUKKOUCD__c() {
        return SHUKKOUCD__c;
    }


    /**
     * Sets the SHUKKOUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHUKKOUCD__c
     */
    public void setSHUKKOUCD__c(java.lang.String SHUKKOUCD__c) {
        this.SHUKKOUCD__c = SHUKKOUCD__c;
    }


    /**
     * Gets the SHUKKOUSAKIBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SHUKKOUSAKIBANGOU__c
     */
    public java.lang.String getSHUKKOUSAKIBANGOU__c() {
        return SHUKKOUSAKIBANGOU__c;
    }


    /**
     * Sets the SHUKKOUSAKIBANGOU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SHUKKOUSAKIBANGOU__c
     */
    public void setSHUKKOUSAKIBANGOU__c(java.lang.String SHUKKOUSAKIBANGOU__c) {
        this.SHUKKOUSAKIBANGOU__c = SHUKKOUSAKIBANGOU__c;
    }


    /**
     * Gets the SMTPADDRESS__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return SMTPADDRESS__c
     */
    public java.lang.String getSMTPADDRESS__c() {
        return SMTPADDRESS__c;
    }


    /**
     * Sets the SMTPADDRESS__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param SMTPADDRESS__c
     */
    public void setSMTPADDRESS__c(java.lang.String SMTPADDRESS__c) {
        this.SMTPADDRESS__c = SMTPADDRESS__c;
    }


    /**
     * Gets the saikenJotoTsuchi_Cifkouininfo__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return saikenJotoTsuchi_Cifkouininfo__r
     */
    public com.sforce.soap.enterprise.QueryResult getSaikenJotoTsuchi_Cifkouininfo__r() {
        return saikenJotoTsuchi_Cifkouininfo__r;
    }


    /**
     * Sets the saikenJotoTsuchi_Cifkouininfo__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param saikenJotoTsuchi_Cifkouininfo__r
     */
    public void setSaikenJotoTsuchi_Cifkouininfo__r(com.sforce.soap.enterprise.QueryResult saikenJotoTsuchi_Cifkouininfo__r) {
        this.saikenJotoTsuchi_Cifkouininfo__r = saikenJotoTsuchi_Cifkouininfo__r;
    }


    /**
     * Gets the saikenJotoTsuchi_kouininfo__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return saikenJotoTsuchi_kouininfo__r
     */
    public com.sforce.soap.enterprise.QueryResult getSaikenJotoTsuchi_kouininfo__r() {
        return saikenJotoTsuchi_kouininfo__r;
    }


    /**
     * Sets the saikenJotoTsuchi_kouininfo__r value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param saikenJotoTsuchi_kouininfo__r
     */
    public void setSaikenJotoTsuchi_kouininfo__r(com.sforce.soap.enterprise.QueryResult saikenJotoTsuchi_kouininfo__r) {
        this.saikenJotoTsuchi_kouininfo__r = saikenJotoTsuchi_kouininfo__r;
    }


    /**
     * Gets the shares value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return shares
     */
    public com.sforce.soap.enterprise.QueryResult getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param shares
     */
    public void setShares(com.sforce.soap.enterprise.QueryResult shares) {
        this.shares = shares;
    }


    /**
     * Gets the systemModstamp value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the tasks value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return tasks
     */
    public com.sforce.soap.enterprise.QueryResult getTasks() {
        return tasks;
    }


    /**
     * Sets the tasks value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param tasks
     */
    public void setTasks(com.sforce.soap.enterprise.QueryResult tasks) {
        this.tasks = tasks;
    }


    /**
     * Gets the topicAssignments value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the USERID__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return USERID__c
     */
    public java.lang.String getUSERID__c() {
        return USERID__c;
    }


    /**
     * Sets the USERID__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param USERID__c
     */
    public void setUSERID__c(java.lang.String USERID__c) {
        this.USERID__c = USERID__c;
    }


    /**
     * Gets the userRecordAccess value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the YAKUDUKEKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return YAKUDUKEKBN__c
     */
    public java.lang.String getYAKUDUKEKBN__c() {
        return YAKUDUKEKBN__c;
    }


    /**
     * Sets the YAKUDUKEKBN__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param YAKUDUKEKBN__c
     */
    public void setYAKUDUKEKBN__c(java.lang.String YAKUDUKEKBN__c) {
        this.YAKUDUKEKBN__c = YAKUDUKEKBN__c;
    }


    /**
     * Gets the YAKUSHOKUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return YAKUSHOKUCD__c
     */
    public java.lang.String getYAKUSHOKUCD__c() {
        return YAKUSHOKUCD__c;
    }


    /**
     * Sets the YAKUSHOKUCD__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param YAKUSHOKUCD__c
     */
    public void setYAKUSHOKUCD__c(java.lang.String YAKUSHOKUCD__c) {
        this.YAKUSHOKUCD__c = YAKUSHOKUCD__c;
    }


    /**
     * Gets the YAKUSHOKUNM_RYAKU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return YAKUSHOKUNM_RYAKU__c
     */
    public java.lang.String getYAKUSHOKUNM_RYAKU__c() {
        return YAKUSHOKUNM_RYAKU__c;
    }


    /**
     * Sets the YAKUSHOKUNM_RYAKU__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param YAKUSHOKUNM_RYAKU__c
     */
    public void setYAKUSHOKUNM_RYAKU__c(java.lang.String YAKUSHOKUNM_RYAKU__c) {
        this.YAKUSHOKUNM_RYAKU__c = YAKUSHOKUNM_RYAKU__c;
    }


    /**
     * Gets the YAKUSHOKUNM_SEISHIKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @return YAKUSHOKUNM_SEISHIKI__c
     */
    public java.lang.String getYAKUSHOKUNM_SEISHIKI__c() {
        return YAKUSHOKUNM_SEISHIKI__c;
    }


    /**
     * Sets the YAKUSHOKUNM_SEISHIKI__c value for this C000_KYOUTSUUNINSHOUKOUININFO__c.
     * 
     * @param YAKUSHOKUNM_SEISHIKI__c
     */
    public void setYAKUSHOKUNM_SEISHIKI__c(java.lang.String YAKUSHOKUNM_SEISHIKI__c) {
        this.YAKUSHOKUNM_SEISHIKI__c = YAKUSHOKUNM_SEISHIKI__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C000_KYOUTSUUNINSHOUKOUININFO__c)) return false;
        C000_KYOUTSUUNINSHOUKOUININFO__c other = (C000_KYOUTSUUNINSHOUKOUININFO__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.a001_ANKEN_TorikomiJoho_05__r==null && other.getA001_ANKEN_TorikomiJoho_05__r()==null) || 
             (this.a001_ANKEN_TorikomiJoho_05__r!=null &&
              this.a001_ANKEN_TorikomiJoho_05__r.equals(other.getA001_ANKEN_TorikomiJoho_05__r()))) &&
            ((this.a002_ANKEN_Zairyou_003__r==null && other.getA002_ANKEN_Zairyou_003__r()==null) || 
             (this.a002_ANKEN_Zairyou_003__r!=null &&
              this.a002_ANKEN_Zairyou_003__r.equals(other.getA002_ANKEN_Zairyou_003__r()))) &&
            ((this.AREAPOSTCD__c==null && other.getAREAPOSTCD__c()==null) || 
             (this.AREAPOSTCD__c!=null &&
              this.AREAPOSTCD__c.equals(other.getAREAPOSTCD__c()))) &&
            ((this.AREATENBAN__c==null && other.getAREATENBAN__c()==null) || 
             (this.AREATENBAN__c!=null &&
              this.AREATENBAN__c.equals(other.getAREATENBAN__c()))) &&
            ((this.activityHistories==null && other.getActivityHistories()==null) || 
             (this.activityHistories!=null &&
              this.activityHistories.equals(other.getActivityHistories()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.BUTENBANGOUSHIYOUFLG__c==null && other.getBUTENBANGOUSHIYOUFLG__c()==null) || 
             (this.BUTENBANGOUSHIYOUFLG__c!=null &&
              this.BUTENBANGOUSHIYOUFLG__c.equals(other.getBUTENBANGOUSHIYOUFLG__c()))) &&
            ((this.BUTENBANGOU__c==null && other.getBUTENBANGOU__c()==null) || 
             (this.BUTENBANGOU__c!=null &&
              this.BUTENBANGOU__c.equals(other.getBUTENBANGOU__c()))) &&
            ((this.BUTENNM1__c==null && other.getBUTENNM1__c()==null) || 
             (this.BUTENNM1__c!=null &&
              this.BUTENNM1__c.equals(other.getBUTENNM1__c()))) &&
            ((this.BUTENNM2__c==null && other.getBUTENNM2__c()==null) || 
             (this.BUTENNM2__c!=null &&
              this.BUTENNM2__c.equals(other.getBUTENNM2__c()))) &&
            ((this.BUTENNM3__c==null && other.getBUTENNM3__c()==null) || 
             (this.BUTENNM3__c!=null &&
              this.BUTENNM3__c.equals(other.getBUTENNM3__c()))) &&
            ((this.BUTENNMRENKETSU__c==null && other.getBUTENNMRENKETSU__c()==null) || 
             (this.BUTENNMRENKETSU__c!=null &&
              this.BUTENNMRENKETSU__c.equals(other.getBUTENNMRENKETSU__c()))) &&
            ((this.c000_042_CIF_PROPERTY_CHANGE_INFO_01__r==null && other.getC000_042_CIF_PROPERTY_CHANGE_INFO_01__r()==null) || 
             (this.c000_042_CIF_PROPERTY_CHANGE_INFO_01__r!=null &&
              this.c000_042_CIF_PROPERTY_CHANGE_INFO_01__r.equals(other.getC000_042_CIF_PROPERTY_CHANGE_INFO_01__r()))) &&
            ((this.c000_042_CIF_PROPERTY_CHANGE_INFO_03__r==null && other.getC000_042_CIF_PROPERTY_CHANGE_INFO_03__r()==null) || 
             (this.c000_042_CIF_PROPERTY_CHANGE_INFO_03__r!=null &&
              this.c000_042_CIF_PROPERTY_CHANGE_INFO_03__r.equals(other.getC000_042_CIF_PROPERTY_CHANGE_INFO_03__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_03__r==null && other.getC000_CIFZOKUSEIINFO_03__r()==null) || 
             (this.c000_CIFZOKUSEIINFO_03__r!=null &&
              this.c000_CIFZOKUSEIINFO_03__r.equals(other.getC000_CIFZOKUSEIINFO_03__r()))) &&
            ((this.c002_Users_01__r==null && other.getC002_Users_01__r()==null) || 
             (this.c002_Users_01__r!=null &&
              this.c002_Users_01__r.equals(other.getC002_Users_01__r()))) &&
            ((this.c002_Users_02__r==null && other.getC002_Users_02__r()==null) || 
             (this.c002_Users_02__r!=null &&
              this.c002_Users_02__r.equals(other.getC002_Users_02__r()))) &&
            ((this.c002_Users_03__r==null && other.getC002_Users_03__r()==null) || 
             (this.c002_Users_03__r!=null &&
              this.c002_Users_03__r.equals(other.getC002_Users_03__r()))) &&
            ((this.c002_Users_04__r==null && other.getC002_Users_04__r()==null) || 
             (this.c002_Users_04__r!=null &&
              this.c002_Users_04__r.equals(other.getC002_Users_04__r()))) &&
            ((this.c002_Users_05__r==null && other.getC002_Users_05__r()==null) || 
             (this.c002_Users_05__r!=null &&
              this.c002_Users_05__r.equals(other.getC002_Users_05__r()))) &&
            ((this.c002_Users_06__r==null && other.getC002_Users_06__r()==null) || 
             (this.c002_Users_06__r!=null &&
              this.c002_Users_06__r.equals(other.getC002_Users_06__r()))) &&
            ((this.c002_Users_07__r==null && other.getC002_Users_07__r()==null) || 
             (this.c002_Users_07__r!=null &&
              this.c002_Users_07__r.equals(other.getC002_Users_07__r()))) &&
            ((this.c002_Users_08__r==null && other.getC002_Users_08__r()==null) || 
             (this.c002_Users_08__r!=null &&
              this.c002_Users_08__r.equals(other.getC002_Users_08__r()))) &&
            ((this.c002_Users_09__r==null && other.getC002_Users_09__r()==null) || 
             (this.c002_Users_09__r!=null &&
              this.c002_Users_09__r.equals(other.getC002_Users_09__r()))) &&
            ((this.CHAKUNINBI_WAREKI__c==null && other.getCHAKUNINBI_WAREKI__c()==null) || 
             (this.CHAKUNINBI_WAREKI__c!=null &&
              this.CHAKUNINBI_WAREKI__c.equals(other.getCHAKUNINBI_WAREKI__c()))) &&
            ((this.CHAKUNINNENGOU_WAREKI__c==null && other.getCHAKUNINNENGOU_WAREKI__c()==null) || 
             (this.CHAKUNINNENGOU_WAREKI__c!=null &&
              this.CHAKUNINNENGOU_WAREKI__c.equals(other.getCHAKUNINNENGOU_WAREKI__c()))) &&
            ((this.COURSECD__c==null && other.getCOURSECD__c()==null) || 
             (this.COURSECD__c!=null &&
              this.COURSECD__c.equals(other.getCOURSECD__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.d002_001__r==null && other.getD002_001__r()==null) || 
             (this.d002_001__r!=null &&
              this.d002_001__r.equals(other.getD002_001__r()))) &&
            ((this.d002_002__r==null && other.getD002_002__r()==null) || 
             (this.d002_002__r!=null &&
              this.d002_002__r.equals(other.getD002_002__r()))) &&
            ((this.d003_001__r==null && other.getD003_001__r()==null) || 
             (this.d003_001__r!=null &&
              this.d003_001__r.equals(other.getD003_001__r()))) &&
            ((this.d003_002__r==null && other.getD003_002__r()==null) || 
             (this.d003_002__r!=null &&
              this.d003_002__r.equals(other.getD003_002__r()))) &&
            ((this.d004_ToDoSnaps__r==null && other.getD004_ToDoSnaps__r()==null) || 
             (this.d004_ToDoSnaps__r!=null &&
              this.d004_ToDoSnaps__r.equals(other.getD004_ToDoSnaps__r()))) &&
            ((this.d004_ToDos__r==null && other.getD004_ToDos__r()==null) || 
             (this.d004_ToDos__r!=null &&
              this.d004_ToDos__r.equals(other.getD004_ToDos__r()))) &&
            ((this.DELFLG__c==null && other.getDELFLG__c()==null) || 
             (this.DELFLG__c!=null &&
              this.DELFLG__c.equals(other.getDELFLG__c()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.events==null && other.getEvents()==null) || 
             (this.events!=null &&
              this.events.equals(other.getEvents()))) &&
            ((this.FUNINHINENGOU_WAREKI__c==null && other.getFUNINHINENGOU_WAREKI__c()==null) || 
             (this.FUNINHINENGOU_WAREKI__c!=null &&
              this.FUNINHINENGOU_WAREKI__c.equals(other.getFUNINHINENGOU_WAREKI__c()))) &&
            ((this.FUNINHI_WAREKI__c==null && other.getFUNINHI_WAREKI__c()==null) || 
             (this.FUNINHI_WAREKI__c!=null &&
              this.FUNINHI_WAREKI__c.equals(other.getFUNINHI_WAREKI__c()))) &&
            ((this.FUZAIKBN__c==null && other.getFUZAIKBN__c()==null) || 
             (this.FUZAIKBN__c!=null &&
              this.FUZAIKBN__c.equals(other.getFUZAIKBN__c()))) &&
            ((this.GAPPEIKBN__c==null && other.getGAPPEIKBN__c()==null) || 
             (this.GAPPEIKBN__c!=null &&
              this.GAPPEIKBN__c.equals(other.getGAPPEIKBN__c()))) &&
            ((this.GRADEGRP__c==null && other.getGRADEGRP__c()==null) || 
             (this.GRADEGRP__c!=null &&
              this.GRADEGRP__c.equals(other.getGRADEGRP__c()))) &&
            ((this.GYOUMUCD__c==null && other.getGYOUMUCD__c()==null) || 
             (this.GYOUMUCD__c!=null &&
              this.GYOUMUCD__c.equals(other.getGYOUMUCD__c()))) &&
            ((this.HAKENMOTOBANGOU__c==null && other.getHAKENMOTOBANGOU__c()==null) || 
             (this.HAKENMOTOBANGOU__c!=null &&
              this.HAKENMOTOBANGOU__c.equals(other.getHAKENMOTOBANGOU__c()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.IDOUHATSUREIBI_WAREKI__c==null && other.getIDOUHATSUREIBI_WAREKI__c()==null) || 
             (this.IDOUHATSUREIBI_WAREKI__c!=null &&
              this.IDOUHATSUREIBI_WAREKI__c.equals(other.getIDOUHATSUREIBI_WAREKI__c()))) &&
            ((this.IDOUNENGOU_WAREKI__c==null && other.getIDOUNENGOU_WAREKI__c()==null) || 
             (this.IDOUNENGOU_WAREKI__c!=null &&
              this.IDOUNENGOU_WAREKI__c.equals(other.getIDOUNENGOU_WAREKI__c()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.JITAKURENRAKUSAKI__c==null && other.getJITAKURENRAKUSAKI__c()==null) || 
             (this.JITAKURENRAKUSAKI__c!=null &&
              this.JITAKURENRAKUSAKI__c.equals(other.getJITAKURENRAKUSAKI__c()))) &&
            ((this.JOUCHUUBUTENBANGOU__c==null && other.getJOUCHUUBUTENBANGOU__c()==null) || 
             (this.JOUCHUUBUTENBANGOU__c!=null &&
              this.JOUCHUUBUTENBANGOU__c.equals(other.getJOUCHUUBUTENBANGOU__c()))) &&
            ((this.JOUCHUUBUTENNM__c==null && other.getJOUCHUUBUTENNM__c()==null) || 
             (this.JOUCHUUBUTENNM__c!=null &&
              this.JOUCHUUBUTENNM__c.equals(other.getJOUCHUUBUTENNM__c()))) &&
            ((this.KAIGAIFLG__c==null && other.getKAIGAIFLG__c()==null) || 
             (this.KAIGAIFLG__c!=null &&
              this.KAIGAIFLG__c.equals(other.getKAIGAIFLG__c()))) &&
            ((this.KAISHACD__c==null && other.getKAISHACD__c()==null) || 
             (this.KAISHACD__c!=null &&
              this.KAISHACD__c.equals(other.getKAISHACD__c()))) &&
            ((this.KAISHANM__c==null && other.getKAISHANM__c()==null) || 
             (this.KAISHANM__c!=null &&
              this.KAISHANM__c.equals(other.getKAISHANM__c()))) &&
            ((this.KANASHIMEI__c==null && other.getKANASHIMEI__c()==null) || 
             (this.KANASHIMEI__c!=null &&
              this.KANASHIMEI__c.equals(other.getKANASHIMEI__c()))) &&
            ((this.KANJISHIMEISEARCH__c==null && other.getKANJISHIMEISEARCH__c()==null) || 
             (this.KANJISHIMEISEARCH__c!=null &&
              this.KANJISHIMEISEARCH__c.equals(other.getKANJISHIMEISEARCH__c()))) &&
            ((this.KANJISHIMEI__c==null && other.getKANJISHIMEI__c()==null) || 
             (this.KANJISHIMEI__c!=null &&
              this.KANJISHIMEI__c.equals(other.getKANJISHIMEI__c()))) &&
            ((this.KANRENKAISHAKBN__c==null && other.getKANRENKAISHAKBN__c()==null) || 
             (this.KANRENKAISHAKBN__c!=null &&
              this.KANRENKAISHAKBN__c.equals(other.getKANRENKAISHAKBN__c()))) &&
            ((this.KA_GRCD__c==null && other.getKA_GRCD__c()==null) || 
             (this.KA_GRCD__c!=null &&
              this.KA_GRCD__c.equals(other.getKA_GRCD__c()))) &&
            ((this.KA_GROUPNM__c==null && other.getKA_GROUPNM__c()==null) || 
             (this.KA_GROUPNM__c!=null &&
              this.KA_GROUPNM__c.equals(other.getKA_GROUPNM__c()))) &&
            ((this.KENMUBUTENBANGOU1__c==null && other.getKENMUBUTENBANGOU1__c()==null) || 
             (this.KENMUBUTENBANGOU1__c!=null &&
              this.KENMUBUTENBANGOU1__c.equals(other.getKENMUBUTENBANGOU1__c()))) &&
            ((this.KENMUBUTENBANGOU2__c==null && other.getKENMUBUTENBANGOU2__c()==null) || 
             (this.KENMUBUTENBANGOU2__c!=null &&
              this.KENMUBUTENBANGOU2__c.equals(other.getKENMUBUTENBANGOU2__c()))) &&
            ((this.KENMUBUTENBANGOU3__c==null && other.getKENMUBUTENBANGOU3__c()==null) || 
             (this.KENMUBUTENBANGOU3__c!=null &&
              this.KENMUBUTENBANGOU3__c.equals(other.getKENMUBUTENBANGOU3__c()))) &&
            ((this.KENMUBUTENBANGOU4__c==null && other.getKENMUBUTENBANGOU4__c()==null) || 
             (this.KENMUBUTENBANGOU4__c!=null &&
              this.KENMUBUTENBANGOU4__c.equals(other.getKENMUBUTENBANGOU4__c()))) &&
            ((this.KENMUBUTENBANGOU5__c==null && other.getKENMUBUTENBANGOU5__c()==null) || 
             (this.KENMUBUTENBANGOU5__c!=null &&
              this.KENMUBUTENBANGOU5__c.equals(other.getKENMUBUTENBANGOU5__c()))) &&
            ((this.KENMUKA_GRCD1__c==null && other.getKENMUKA_GRCD1__c()==null) || 
             (this.KENMUKA_GRCD1__c!=null &&
              this.KENMUKA_GRCD1__c.equals(other.getKENMUKA_GRCD1__c()))) &&
            ((this.KENMUKA_GRCD2__c==null && other.getKENMUKA_GRCD2__c()==null) || 
             (this.KENMUKA_GRCD2__c!=null &&
              this.KENMUKA_GRCD2__c.equals(other.getKENMUKA_GRCD2__c()))) &&
            ((this.KENMUKA_GRCD3__c==null && other.getKENMUKA_GRCD3__c()==null) || 
             (this.KENMUKA_GRCD3__c!=null &&
              this.KENMUKA_GRCD3__c.equals(other.getKENMUKA_GRCD3__c()))) &&
            ((this.KENMUKA_GRCD4__c==null && other.getKENMUKA_GRCD4__c()==null) || 
             (this.KENMUKA_GRCD4__c!=null &&
              this.KENMUKA_GRCD4__c.equals(other.getKENMUKA_GRCD4__c()))) &&
            ((this.KENMUKA_GRCD5__c==null && other.getKENMUKA_GRCD5__c()==null) || 
             (this.KENMUKA_GRCD5__c!=null &&
              this.KENMUKA_GRCD5__c.equals(other.getKENMUKA_GRCD5__c()))) &&
            ((this.KENMUSHISHANAIHOUJINBUCD1__c==null && other.getKENMUSHISHANAIHOUJINBUCD1__c()==null) || 
             (this.KENMUSHISHANAIHOUJINBUCD1__c!=null &&
              this.KENMUSHISHANAIHOUJINBUCD1__c.equals(other.getKENMUSHISHANAIHOUJINBUCD1__c()))) &&
            ((this.KENMUSHISHANAIHOUJINBUCD2__c==null && other.getKENMUSHISHANAIHOUJINBUCD2__c()==null) || 
             (this.KENMUSHISHANAIHOUJINBUCD2__c!=null &&
              this.KENMUSHISHANAIHOUJINBUCD2__c.equals(other.getKENMUSHISHANAIHOUJINBUCD2__c()))) &&
            ((this.KENMUSHISHANAIHOUJINBUCD3__c==null && other.getKENMUSHISHANAIHOUJINBUCD3__c()==null) || 
             (this.KENMUSHISHANAIHOUJINBUCD3__c!=null &&
              this.KENMUSHISHANAIHOUJINBUCD3__c.equals(other.getKENMUSHISHANAIHOUJINBUCD3__c()))) &&
            ((this.KENMUSHISHANAIHOUJINBUCD4__c==null && other.getKENMUSHISHANAIHOUJINBUCD4__c()==null) || 
             (this.KENMUSHISHANAIHOUJINBUCD4__c!=null &&
              this.KENMUSHISHANAIHOUJINBUCD4__c.equals(other.getKENMUSHISHANAIHOUJINBUCD4__c()))) &&
            ((this.KENMUSHISHANAIHOUJINBUCD5__c==null && other.getKENMUSHISHANAIHOUJINBUCD5__c()==null) || 
             (this.KENMUSHISHANAIHOUJINBUCD5__c!=null &&
              this.KENMUSHISHANAIHOUJINBUCD5__c.equals(other.getKENMUSHISHANAIHOUJINBUCD5__c()))) &&
            ((this.KENMUYAKUSHOKUCD1__c==null && other.getKENMUYAKUSHOKUCD1__c()==null) || 
             (this.KENMUYAKUSHOKUCD1__c!=null &&
              this.KENMUYAKUSHOKUCD1__c.equals(other.getKENMUYAKUSHOKUCD1__c()))) &&
            ((this.KENMUYAKUSHOKUCD2__c==null && other.getKENMUYAKUSHOKUCD2__c()==null) || 
             (this.KENMUYAKUSHOKUCD2__c!=null &&
              this.KENMUYAKUSHOKUCD2__c.equals(other.getKENMUYAKUSHOKUCD2__c()))) &&
            ((this.KENMUYAKUSHOKUCD3__c==null && other.getKENMUYAKUSHOKUCD3__c()==null) || 
             (this.KENMUYAKUSHOKUCD3__c!=null &&
              this.KENMUYAKUSHOKUCD3__c.equals(other.getKENMUYAKUSHOKUCD3__c()))) &&
            ((this.KENMUYAKUSHOKUCD4__c==null && other.getKENMUYAKUSHOKUCD4__c()==null) || 
             (this.KENMUYAKUSHOKUCD4__c!=null &&
              this.KENMUYAKUSHOKUCD4__c.equals(other.getKENMUYAKUSHOKUCD4__c()))) &&
            ((this.KENMUYAKUSHOKUCD5__c==null && other.getKENMUYAKUSHOKUCD5__c()==null) || 
             (this.KENMUYAKUSHOKUCD5__c!=null &&
              this.KENMUYAKUSHOKUCD5__c.equals(other.getKENMUYAKUSHOKUCD5__c()))) &&
            ((this.KIJUNBI_SEIREKI__c==null && other.getKIJUNBI_SEIREKI__c()==null) || 
             (this.KIJUNBI_SEIREKI__c!=null &&
              this.KIJUNBI_SEIREKI__c.equals(other.getKIJUNBI_SEIREKI__c()))) &&
            ((this.KOUINBANGOU__c==null && other.getKOUINBANGOU__c()==null) || 
             (this.KOUINBANGOU__c!=null &&
              this.KOUINBANGOU__c.equals(other.getKOUINBANGOU__c()))) &&
            ((this.KOUINGAIUCHIWAKEKBN__c==null && other.getKOUINGAIUCHIWAKEKBN__c()==null) || 
             (this.KOUINGAIUCHIWAKEKBN__c!=null &&
              this.KOUINGAIUCHIWAKEKBN__c.equals(other.getKOUINGAIUCHIWAKEKBN__c()))) &&
            ((this.KOUINKBN__c==null && other.getKOUINKBN__c()==null) || 
             (this.KOUINKBN__c!=null &&
              this.KOUINKBN__c.equals(other.getKOUINKBN__c()))) &&
            ((this.KOUINUCHIWAKEKBN__c==null && other.getKOUINUCHIWAKEKBN__c()==null) || 
             (this.KOUINUCHIWAKEKBN__c!=null &&
              this.KOUINUCHIWAKEKBN__c.equals(other.getKOUINUCHIWAKEKBN__c()))) &&
            ((this.KYOUTSUUNINSHOKOUININFO__r==null && other.getKYOUTSUUNINSHOKOUININFO__r()==null) || 
             (this.KYOUTSUUNINSHOKOUININFO__r!=null &&
              this.KYOUTSUUNINSHOKOUININFO__r.equals(other.getKYOUTSUUNINSHOKOUININFO__r()))) &&
            ((this.KYOUTSUUNINSHOUKOUININFOs__r==null && other.getKYOUTSUUNINSHOUKOUININFOs__r()==null) || 
             (this.KYOUTSUUNINSHOUKOUININFOs__r!=null &&
              this.KYOUTSUUNINSHOUKOUININFOs__r.equals(other.getKYOUTSUUNINSHOUKOUININFOs__r()))) &&
            ((this.lastActivityDate==null && other.getLastActivityDate()==null) || 
             (this.lastActivityDate!=null &&
              this.lastActivityDate.equals(other.getLastActivityDate()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.o49_FLG__c==null && other.getO49_FLG__c()==null) || 
             (this.o49_FLG__c!=null &&
              this.o49_FLG__c.equals(other.getO49_FLG__c()))) &&
            ((this.openActivities==null && other.getOpenActivities()==null) || 
             (this.openActivities!=null &&
              this.openActivities.equals(other.getOpenActivities()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.POSTCDNM1__c==null && other.getPOSTCDNM1__c()==null) || 
             (this.POSTCDNM1__c!=null &&
              this.POSTCDNM1__c.equals(other.getPOSTCDNM1__c()))) &&
            ((this.POSTCDNM2__c==null && other.getPOSTCDNM2__c()==null) || 
             (this.POSTCDNM2__c!=null &&
              this.POSTCDNM2__c.equals(other.getPOSTCDNM2__c()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.QN_FLG__c==null && other.getQN_FLG__c()==null) || 
             (this.QN_FLG__c!=null &&
              this.QN_FLG__c.equals(other.getQN_FLG__c()))) &&
            ((this.RANKKBN__c==null && other.getRANKKBN__c()==null) || 
             (this.RANKKBN__c!=null &&
              this.RANKKBN__c.equals(other.getRANKKBN__c()))) &&
            ((this.ROMEJISHIMEI__c==null && other.getROMEJISHIMEI__c()==null) || 
             (this.ROMEJISHIMEI__c!=null &&
              this.ROMEJISHIMEI__c.equals(other.getROMEJISHIMEI__c()))) &&
            ((this.SENNINKBN__c==null && other.getSENNINKBN__c()==null) || 
             (this.SENNINKBN__c!=null &&
              this.SENNINKBN__c.equals(other.getSENNINKBN__c()))) &&
            ((this.SHIKAKUCD__c==null && other.getSHIKAKUCD__c()==null) || 
             (this.SHIKAKUCD__c!=null &&
              this.SHIKAKUCD__c.equals(other.getSHIKAKUCD__c()))) &&
            ((this.SHISHANAIHOUJINBUCD__c==null && other.getSHISHANAIHOUJINBUCD__c()==null) || 
             (this.SHISHANAIHOUJINBUCD__c!=null &&
              this.SHISHANAIHOUJINBUCD__c.equals(other.getSHISHANAIHOUJINBUCD__c()))) &&
            ((this.SHOKUMUHATSUREIBI__c==null && other.getSHOKUMUHATSUREIBI__c()==null) || 
             (this.SHOKUMUHATSUREIBI__c!=null &&
              this.SHOKUMUHATSUREIBI__c.equals(other.getSHOKUMUHATSUREIBI__c()))) &&
            ((this.SHOKUMUHENKOUNENGOU_WAREKI__c==null && other.getSHOKUMUHENKOUNENGOU_WAREKI__c()==null) || 
             (this.SHOKUMUHENKOUNENGOU_WAREKI__c!=null &&
              this.SHOKUMUHENKOUNENGOU_WAREKI__c.equals(other.getSHOKUMUHENKOUNENGOU_WAREKI__c()))) &&
            ((this.SHOKUMUTANTOUCD1__c==null && other.getSHOKUMUTANTOUCD1__c()==null) || 
             (this.SHOKUMUTANTOUCD1__c!=null &&
              this.SHOKUMUTANTOUCD1__c.equals(other.getSHOKUMUTANTOUCD1__c()))) &&
            ((this.SHOKUMUTANTOUCD2__c==null && other.getSHOKUMUTANTOUCD2__c()==null) || 
             (this.SHOKUMUTANTOUCD2__c!=null &&
              this.SHOKUMUTANTOUCD2__c.equals(other.getSHOKUMUTANTOUCD2__c()))) &&
            ((this.SHOKUMUTANTOUCD3__c==null && other.getSHOKUMUTANTOUCD3__c()==null) || 
             (this.SHOKUMUTANTOUCD3__c!=null &&
              this.SHOKUMUTANTOUCD3__c.equals(other.getSHOKUMUTANTOUCD3__c()))) &&
            ((this.SHOKUSHU1__c==null && other.getSHOKUSHU1__c()==null) || 
             (this.SHOKUSHU1__c!=null &&
              this.SHOKUSHU1__c.equals(other.getSHOKUSHU1__c()))) &&
            ((this.SHOKUSHU2__c==null && other.getSHOKUSHU2__c()==null) || 
             (this.SHOKUSHU2__c!=null &&
              this.SHOKUSHU2__c.equals(other.getSHOKUSHU2__c()))) &&
            ((this.SHOKUSHU3__c==null && other.getSHOKUSHU3__c()==null) || 
             (this.SHOKUSHU3__c!=null &&
              this.SHOKUSHU3__c.equals(other.getSHOKUSHU3__c()))) &&
            ((this.SHUKKOUCD__c==null && other.getSHUKKOUCD__c()==null) || 
             (this.SHUKKOUCD__c!=null &&
              this.SHUKKOUCD__c.equals(other.getSHUKKOUCD__c()))) &&
            ((this.SHUKKOUSAKIBANGOU__c==null && other.getSHUKKOUSAKIBANGOU__c()==null) || 
             (this.SHUKKOUSAKIBANGOU__c!=null &&
              this.SHUKKOUSAKIBANGOU__c.equals(other.getSHUKKOUSAKIBANGOU__c()))) &&
            ((this.SMTPADDRESS__c==null && other.getSMTPADDRESS__c()==null) || 
             (this.SMTPADDRESS__c!=null &&
              this.SMTPADDRESS__c.equals(other.getSMTPADDRESS__c()))) &&
            ((this.saikenJotoTsuchi_Cifkouininfo__r==null && other.getSaikenJotoTsuchi_Cifkouininfo__r()==null) || 
             (this.saikenJotoTsuchi_Cifkouininfo__r!=null &&
              this.saikenJotoTsuchi_Cifkouininfo__r.equals(other.getSaikenJotoTsuchi_Cifkouininfo__r()))) &&
            ((this.saikenJotoTsuchi_kouininfo__r==null && other.getSaikenJotoTsuchi_kouininfo__r()==null) || 
             (this.saikenJotoTsuchi_kouininfo__r!=null &&
              this.saikenJotoTsuchi_kouininfo__r.equals(other.getSaikenJotoTsuchi_kouininfo__r()))) &&
            ((this.shares==null && other.getShares()==null) || 
             (this.shares!=null &&
              this.shares.equals(other.getShares()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.tasks==null && other.getTasks()==null) || 
             (this.tasks!=null &&
              this.tasks.equals(other.getTasks()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.USERID__c==null && other.getUSERID__c()==null) || 
             (this.USERID__c!=null &&
              this.USERID__c.equals(other.getUSERID__c()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess()))) &&
            ((this.YAKUDUKEKBN__c==null && other.getYAKUDUKEKBN__c()==null) || 
             (this.YAKUDUKEKBN__c!=null &&
              this.YAKUDUKEKBN__c.equals(other.getYAKUDUKEKBN__c()))) &&
            ((this.YAKUSHOKUCD__c==null && other.getYAKUSHOKUCD__c()==null) || 
             (this.YAKUSHOKUCD__c!=null &&
              this.YAKUSHOKUCD__c.equals(other.getYAKUSHOKUCD__c()))) &&
            ((this.YAKUSHOKUNM_RYAKU__c==null && other.getYAKUSHOKUNM_RYAKU__c()==null) || 
             (this.YAKUSHOKUNM_RYAKU__c!=null &&
              this.YAKUSHOKUNM_RYAKU__c.equals(other.getYAKUSHOKUNM_RYAKU__c()))) &&
            ((this.YAKUSHOKUNM_SEISHIKI__c==null && other.getYAKUSHOKUNM_SEISHIKI__c()==null) || 
             (this.YAKUSHOKUNM_SEISHIKI__c!=null &&
              this.YAKUSHOKUNM_SEISHIKI__c.equals(other.getYAKUSHOKUNM_SEISHIKI__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getA001_ANKEN_TorikomiJoho_05__r() != null) {
            _hashCode += getA001_ANKEN_TorikomiJoho_05__r().hashCode();
        }
        if (getA002_ANKEN_Zairyou_003__r() != null) {
            _hashCode += getA002_ANKEN_Zairyou_003__r().hashCode();
        }
        if (getAREAPOSTCD__c() != null) {
            _hashCode += getAREAPOSTCD__c().hashCode();
        }
        if (getAREATENBAN__c() != null) {
            _hashCode += getAREATENBAN__c().hashCode();
        }
        if (getActivityHistories() != null) {
            _hashCode += getActivityHistories().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBUTENBANGOUSHIYOUFLG__c() != null) {
            _hashCode += getBUTENBANGOUSHIYOUFLG__c().hashCode();
        }
        if (getBUTENBANGOU__c() != null) {
            _hashCode += getBUTENBANGOU__c().hashCode();
        }
        if (getBUTENNM1__c() != null) {
            _hashCode += getBUTENNM1__c().hashCode();
        }
        if (getBUTENNM2__c() != null) {
            _hashCode += getBUTENNM2__c().hashCode();
        }
        if (getBUTENNM3__c() != null) {
            _hashCode += getBUTENNM3__c().hashCode();
        }
        if (getBUTENNMRENKETSU__c() != null) {
            _hashCode += getBUTENNMRENKETSU__c().hashCode();
        }
        if (getC000_042_CIF_PROPERTY_CHANGE_INFO_01__r() != null) {
            _hashCode += getC000_042_CIF_PROPERTY_CHANGE_INFO_01__r().hashCode();
        }
        if (getC000_042_CIF_PROPERTY_CHANGE_INFO_03__r() != null) {
            _hashCode += getC000_042_CIF_PROPERTY_CHANGE_INFO_03__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_03__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_03__r().hashCode();
        }
        if (getC002_Users_01__r() != null) {
            _hashCode += getC002_Users_01__r().hashCode();
        }
        if (getC002_Users_02__r() != null) {
            _hashCode += getC002_Users_02__r().hashCode();
        }
        if (getC002_Users_03__r() != null) {
            _hashCode += getC002_Users_03__r().hashCode();
        }
        if (getC002_Users_04__r() != null) {
            _hashCode += getC002_Users_04__r().hashCode();
        }
        if (getC002_Users_05__r() != null) {
            _hashCode += getC002_Users_05__r().hashCode();
        }
        if (getC002_Users_06__r() != null) {
            _hashCode += getC002_Users_06__r().hashCode();
        }
        if (getC002_Users_07__r() != null) {
            _hashCode += getC002_Users_07__r().hashCode();
        }
        if (getC002_Users_08__r() != null) {
            _hashCode += getC002_Users_08__r().hashCode();
        }
        if (getC002_Users_09__r() != null) {
            _hashCode += getC002_Users_09__r().hashCode();
        }
        if (getCHAKUNINBI_WAREKI__c() != null) {
            _hashCode += getCHAKUNINBI_WAREKI__c().hashCode();
        }
        if (getCHAKUNINNENGOU_WAREKI__c() != null) {
            _hashCode += getCHAKUNINNENGOU_WAREKI__c().hashCode();
        }
        if (getCOURSECD__c() != null) {
            _hashCode += getCOURSECD__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getD002_001__r() != null) {
            _hashCode += getD002_001__r().hashCode();
        }
        if (getD002_002__r() != null) {
            _hashCode += getD002_002__r().hashCode();
        }
        if (getD003_001__r() != null) {
            _hashCode += getD003_001__r().hashCode();
        }
        if (getD003_002__r() != null) {
            _hashCode += getD003_002__r().hashCode();
        }
        if (getD004_ToDoSnaps__r() != null) {
            _hashCode += getD004_ToDoSnaps__r().hashCode();
        }
        if (getD004_ToDos__r() != null) {
            _hashCode += getD004_ToDos__r().hashCode();
        }
        if (getDELFLG__c() != null) {
            _hashCode += getDELFLG__c().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getEvents() != null) {
            _hashCode += getEvents().hashCode();
        }
        if (getFUNINHINENGOU_WAREKI__c() != null) {
            _hashCode += getFUNINHINENGOU_WAREKI__c().hashCode();
        }
        if (getFUNINHI_WAREKI__c() != null) {
            _hashCode += getFUNINHI_WAREKI__c().hashCode();
        }
        if (getFUZAIKBN__c() != null) {
            _hashCode += getFUZAIKBN__c().hashCode();
        }
        if (getGAPPEIKBN__c() != null) {
            _hashCode += getGAPPEIKBN__c().hashCode();
        }
        if (getGRADEGRP__c() != null) {
            _hashCode += getGRADEGRP__c().hashCode();
        }
        if (getGYOUMUCD__c() != null) {
            _hashCode += getGYOUMUCD__c().hashCode();
        }
        if (getHAKENMOTOBANGOU__c() != null) {
            _hashCode += getHAKENMOTOBANGOU__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIDOUHATSUREIBI_WAREKI__c() != null) {
            _hashCode += getIDOUHATSUREIBI_WAREKI__c().hashCode();
        }
        if (getIDOUNENGOU_WAREKI__c() != null) {
            _hashCode += getIDOUNENGOU_WAREKI__c().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getJITAKURENRAKUSAKI__c() != null) {
            _hashCode += getJITAKURENRAKUSAKI__c().hashCode();
        }
        if (getJOUCHUUBUTENBANGOU__c() != null) {
            _hashCode += getJOUCHUUBUTENBANGOU__c().hashCode();
        }
        if (getJOUCHUUBUTENNM__c() != null) {
            _hashCode += getJOUCHUUBUTENNM__c().hashCode();
        }
        if (getKAIGAIFLG__c() != null) {
            _hashCode += getKAIGAIFLG__c().hashCode();
        }
        if (getKAISHACD__c() != null) {
            _hashCode += getKAISHACD__c().hashCode();
        }
        if (getKAISHANM__c() != null) {
            _hashCode += getKAISHANM__c().hashCode();
        }
        if (getKANASHIMEI__c() != null) {
            _hashCode += getKANASHIMEI__c().hashCode();
        }
        if (getKANJISHIMEISEARCH__c() != null) {
            _hashCode += getKANJISHIMEISEARCH__c().hashCode();
        }
        if (getKANJISHIMEI__c() != null) {
            _hashCode += getKANJISHIMEI__c().hashCode();
        }
        if (getKANRENKAISHAKBN__c() != null) {
            _hashCode += getKANRENKAISHAKBN__c().hashCode();
        }
        if (getKA_GRCD__c() != null) {
            _hashCode += getKA_GRCD__c().hashCode();
        }
        if (getKA_GROUPNM__c() != null) {
            _hashCode += getKA_GROUPNM__c().hashCode();
        }
        if (getKENMUBUTENBANGOU1__c() != null) {
            _hashCode += getKENMUBUTENBANGOU1__c().hashCode();
        }
        if (getKENMUBUTENBANGOU2__c() != null) {
            _hashCode += getKENMUBUTENBANGOU2__c().hashCode();
        }
        if (getKENMUBUTENBANGOU3__c() != null) {
            _hashCode += getKENMUBUTENBANGOU3__c().hashCode();
        }
        if (getKENMUBUTENBANGOU4__c() != null) {
            _hashCode += getKENMUBUTENBANGOU4__c().hashCode();
        }
        if (getKENMUBUTENBANGOU5__c() != null) {
            _hashCode += getKENMUBUTENBANGOU5__c().hashCode();
        }
        if (getKENMUKA_GRCD1__c() != null) {
            _hashCode += getKENMUKA_GRCD1__c().hashCode();
        }
        if (getKENMUKA_GRCD2__c() != null) {
            _hashCode += getKENMUKA_GRCD2__c().hashCode();
        }
        if (getKENMUKA_GRCD3__c() != null) {
            _hashCode += getKENMUKA_GRCD3__c().hashCode();
        }
        if (getKENMUKA_GRCD4__c() != null) {
            _hashCode += getKENMUKA_GRCD4__c().hashCode();
        }
        if (getKENMUKA_GRCD5__c() != null) {
            _hashCode += getKENMUKA_GRCD5__c().hashCode();
        }
        if (getKENMUSHISHANAIHOUJINBUCD1__c() != null) {
            _hashCode += getKENMUSHISHANAIHOUJINBUCD1__c().hashCode();
        }
        if (getKENMUSHISHANAIHOUJINBUCD2__c() != null) {
            _hashCode += getKENMUSHISHANAIHOUJINBUCD2__c().hashCode();
        }
        if (getKENMUSHISHANAIHOUJINBUCD3__c() != null) {
            _hashCode += getKENMUSHISHANAIHOUJINBUCD3__c().hashCode();
        }
        if (getKENMUSHISHANAIHOUJINBUCD4__c() != null) {
            _hashCode += getKENMUSHISHANAIHOUJINBUCD4__c().hashCode();
        }
        if (getKENMUSHISHANAIHOUJINBUCD5__c() != null) {
            _hashCode += getKENMUSHISHANAIHOUJINBUCD5__c().hashCode();
        }
        if (getKENMUYAKUSHOKUCD1__c() != null) {
            _hashCode += getKENMUYAKUSHOKUCD1__c().hashCode();
        }
        if (getKENMUYAKUSHOKUCD2__c() != null) {
            _hashCode += getKENMUYAKUSHOKUCD2__c().hashCode();
        }
        if (getKENMUYAKUSHOKUCD3__c() != null) {
            _hashCode += getKENMUYAKUSHOKUCD3__c().hashCode();
        }
        if (getKENMUYAKUSHOKUCD4__c() != null) {
            _hashCode += getKENMUYAKUSHOKUCD4__c().hashCode();
        }
        if (getKENMUYAKUSHOKUCD5__c() != null) {
            _hashCode += getKENMUYAKUSHOKUCD5__c().hashCode();
        }
        if (getKIJUNBI_SEIREKI__c() != null) {
            _hashCode += getKIJUNBI_SEIREKI__c().hashCode();
        }
        if (getKOUINBANGOU__c() != null) {
            _hashCode += getKOUINBANGOU__c().hashCode();
        }
        if (getKOUINGAIUCHIWAKEKBN__c() != null) {
            _hashCode += getKOUINGAIUCHIWAKEKBN__c().hashCode();
        }
        if (getKOUINKBN__c() != null) {
            _hashCode += getKOUINKBN__c().hashCode();
        }
        if (getKOUINUCHIWAKEKBN__c() != null) {
            _hashCode += getKOUINUCHIWAKEKBN__c().hashCode();
        }
        if (getKYOUTSUUNINSHOKOUININFO__r() != null) {
            _hashCode += getKYOUTSUUNINSHOKOUININFO__r().hashCode();
        }
        if (getKYOUTSUUNINSHOUKOUININFOs__r() != null) {
            _hashCode += getKYOUTSUUNINSHOUKOUININFOs__r().hashCode();
        }
        if (getLastActivityDate() != null) {
            _hashCode += getLastActivityDate().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getO49_FLG__c() != null) {
            _hashCode += getO49_FLG__c().hashCode();
        }
        if (getOpenActivities() != null) {
            _hashCode += getOpenActivities().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getPOSTCDNM1__c() != null) {
            _hashCode += getPOSTCDNM1__c().hashCode();
        }
        if (getPOSTCDNM2__c() != null) {
            _hashCode += getPOSTCDNM2__c().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getQN_FLG__c() != null) {
            _hashCode += getQN_FLG__c().hashCode();
        }
        if (getRANKKBN__c() != null) {
            _hashCode += getRANKKBN__c().hashCode();
        }
        if (getROMEJISHIMEI__c() != null) {
            _hashCode += getROMEJISHIMEI__c().hashCode();
        }
        if (getSENNINKBN__c() != null) {
            _hashCode += getSENNINKBN__c().hashCode();
        }
        if (getSHIKAKUCD__c() != null) {
            _hashCode += getSHIKAKUCD__c().hashCode();
        }
        if (getSHISHANAIHOUJINBUCD__c() != null) {
            _hashCode += getSHISHANAIHOUJINBUCD__c().hashCode();
        }
        if (getSHOKUMUHATSUREIBI__c() != null) {
            _hashCode += getSHOKUMUHATSUREIBI__c().hashCode();
        }
        if (getSHOKUMUHENKOUNENGOU_WAREKI__c() != null) {
            _hashCode += getSHOKUMUHENKOUNENGOU_WAREKI__c().hashCode();
        }
        if (getSHOKUMUTANTOUCD1__c() != null) {
            _hashCode += getSHOKUMUTANTOUCD1__c().hashCode();
        }
        if (getSHOKUMUTANTOUCD2__c() != null) {
            _hashCode += getSHOKUMUTANTOUCD2__c().hashCode();
        }
        if (getSHOKUMUTANTOUCD3__c() != null) {
            _hashCode += getSHOKUMUTANTOUCD3__c().hashCode();
        }
        if (getSHOKUSHU1__c() != null) {
            _hashCode += getSHOKUSHU1__c().hashCode();
        }
        if (getSHOKUSHU2__c() != null) {
            _hashCode += getSHOKUSHU2__c().hashCode();
        }
        if (getSHOKUSHU3__c() != null) {
            _hashCode += getSHOKUSHU3__c().hashCode();
        }
        if (getSHUKKOUCD__c() != null) {
            _hashCode += getSHUKKOUCD__c().hashCode();
        }
        if (getSHUKKOUSAKIBANGOU__c() != null) {
            _hashCode += getSHUKKOUSAKIBANGOU__c().hashCode();
        }
        if (getSMTPADDRESS__c() != null) {
            _hashCode += getSMTPADDRESS__c().hashCode();
        }
        if (getSaikenJotoTsuchi_Cifkouininfo__r() != null) {
            _hashCode += getSaikenJotoTsuchi_Cifkouininfo__r().hashCode();
        }
        if (getSaikenJotoTsuchi_kouininfo__r() != null) {
            _hashCode += getSaikenJotoTsuchi_kouininfo__r().hashCode();
        }
        if (getShares() != null) {
            _hashCode += getShares().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTasks() != null) {
            _hashCode += getTasks().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUSERID__c() != null) {
            _hashCode += getUSERID__c().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        if (getYAKUDUKEKBN__c() != null) {
            _hashCode += getYAKUDUKEKBN__c().hashCode();
        }
        if (getYAKUSHOKUCD__c() != null) {
            _hashCode += getYAKUSHOKUCD__c().hashCode();
        }
        if (getYAKUSHOKUNM_RYAKU__c() != null) {
            _hashCode += getYAKUSHOKUNM_RYAKU__c().hashCode();
        }
        if (getYAKUSHOKUNM_SEISHIKI__c() != null) {
            _hashCode += getYAKUSHOKUNM_SEISHIKI__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C000_KYOUTSUUNINSHOUKOUININFO__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a001_ANKEN_TorikomiJoho_05__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A001_ANKEN_TorikomiJoho_05__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a002_ANKEN_Zairyou_003__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A002_ANKEN_Zairyou_003__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AREAPOSTCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AREAPOSTCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AREATENBAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AREATENBAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activityHistories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivityHistories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENBANGOUSHIYOUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENBANGOUSHIYOUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNM1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNM1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNM2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNM2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNM3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNM3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNMRENKETSU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNMRENKETSU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_042_CIF_PROPERTY_CHANGE_INFO_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_042_CIF_PROPERTY_CHANGE_INFO_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_042_CIF_PROPERTY_CHANGE_INFO_03__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_042_CIF_PROPERTY_CHANGE_INFO_03__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_03__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_03__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Users_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Users_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Users_02__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Users_02__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Users_03__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Users_03__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Users_04__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Users_04__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Users_05__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Users_05__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Users_06__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Users_06__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Users_07__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Users_07__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Users_08__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Users_08__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Users_09__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Users_09__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHAKUNINBI_WAREKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CHAKUNINBI_WAREKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHAKUNINNENGOU_WAREKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CHAKUNINNENGOU_WAREKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COURSECD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "COURSECD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d002_001__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D002_001__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d002_002__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D002_002__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d003_001__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D003_001__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d003_002__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D003_002__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d004_ToDoSnaps__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D004_ToDoSnaps__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d004_ToDos__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D004_ToDos__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DELFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DELFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("events");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Events"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FUNINHINENGOU_WAREKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FUNINHINENGOU_WAREKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FUNINHI_WAREKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FUNINHI_WAREKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FUZAIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "FUZAIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GAPPEIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GAPPEIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GRADEGRP__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GRADEGRP__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GYOUMUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GYOUMUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HAKENMOTOBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HAKENMOTOBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDOUHATSUREIBI_WAREKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IDOUHATSUREIBI_WAREKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IDOUNENGOU_WAREKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IDOUNENGOU_WAREKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JITAKURENRAKUSAKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JITAKURENRAKUSAKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUCHUUBUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUCHUUBUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUCHUUBUTENNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUCHUUBUTENNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAIGAIFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAIGAIFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAISHACD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAISHACD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAISHANM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAISHANM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KANASHIMEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KANASHIMEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KANJISHIMEISEARCH__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KANJISHIMEISEARCH__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KANJISHIMEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KANJISHIMEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KANRENKAISHAKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KANRENKAISHAKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KA_GRCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KA_GRCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KA_GROUPNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KA_GROUPNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUBUTENBANGOU1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUBUTENBANGOU1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUBUTENBANGOU2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUBUTENBANGOU2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUBUTENBANGOU3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUBUTENBANGOU3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUBUTENBANGOU4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUBUTENBANGOU4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUBUTENBANGOU5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUBUTENBANGOU5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUKA_GRCD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUKA_GRCD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUKA_GRCD2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUKA_GRCD2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUKA_GRCD3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUKA_GRCD3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUKA_GRCD4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUKA_GRCD4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUKA_GRCD5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUKA_GRCD5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUSHISHANAIHOUJINBUCD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUSHISHANAIHOUJINBUCD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUSHISHANAIHOUJINBUCD2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUSHISHANAIHOUJINBUCD2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUSHISHANAIHOUJINBUCD3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUSHISHANAIHOUJINBUCD3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUSHISHANAIHOUJINBUCD4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUSHISHANAIHOUJINBUCD4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUSHISHANAIHOUJINBUCD5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUSHISHANAIHOUJINBUCD5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUYAKUSHOKUCD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUYAKUSHOKUCD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUYAKUSHOKUCD2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUYAKUSHOKUCD2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUYAKUSHOKUCD3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUYAKUSHOKUCD3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUYAKUSHOKUCD4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUYAKUSHOKUCD4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENMUYAKUSHOKUCD5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENMUYAKUSHOKUCD5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KIJUNBI_SEIREKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KIJUNBI_SEIREKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUINBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUINBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUINGAIUCHIWAKEKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUINGAIUCHIWAKEKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUINKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUINKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUINUCHIWAKEKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUINUCHIWAKEKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOUTSUUNINSHOKOUININFO__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOUTSUUNINSHOKOUININFO__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOUTSUUNINSHOUKOUININFOs__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOUTSUUNINSHOUKOUININFOs__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastActivityDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastActivityDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("o49_FLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "O49_FLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpenActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POSTCDNM1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "POSTCDNM1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("POSTCDNM2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "POSTCDNM2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QN_FLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "QN_FLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RANKKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RANKKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ROMEJISHIMEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ROMEJISHIMEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SENNINKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SENNINKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHIKAKUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHIKAKUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHISHANAIHOUJINBUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHISHANAIHOUJINBUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOKUMUHATSUREIBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOKUMUHATSUREIBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOKUMUHENKOUNENGOU_WAREKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOKUMUHENKOUNENGOU_WAREKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOKUMUTANTOUCD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOKUMUTANTOUCD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOKUMUTANTOUCD2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOKUMUTANTOUCD2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOKUMUTANTOUCD3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOKUMUTANTOUCD3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOKUSHU1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOKUSHU1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOKUSHU2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOKUSHU2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOKUSHU3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOKUSHU3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHUKKOUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHUKKOUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHUKKOUSAKIBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHUKKOUSAKIBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SMTPADDRESS__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SMTPADDRESS__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saikenJotoTsuchi_Cifkouininfo__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SaikenJotoTsuchi_Cifkouininfo__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saikenJotoTsuchi_kouininfo__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SaikenJotoTsuchi_kouininfo__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tasks");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Tasks"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("USERID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "USERID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YAKUDUKEKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YAKUDUKEKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YAKUSHOKUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YAKUSHOKUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YAKUSHOKUNM_RYAKU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YAKUSHOKUNM_RYAKU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YAKUSHOKUNM_SEISHIKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YAKUSHOKUNM_SEISHIKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
