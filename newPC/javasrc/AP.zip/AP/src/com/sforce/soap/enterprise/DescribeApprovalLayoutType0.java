/**
 * DescribeApprovalLayoutType0.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise;

public class DescribeApprovalLayoutType0  implements java.io.Serializable {
    private java.lang.String sObjectType;

    private java.lang.String[] approvalProcessNames;

    public DescribeApprovalLayoutType0() {
    }

    public DescribeApprovalLayoutType0(
           java.lang.String sObjectType,
           java.lang.String[] approvalProcessNames) {
           this.sObjectType = sObjectType;
           this.approvalProcessNames = approvalProcessNames;
    }


    /**
     * Gets the sObjectType value for this DescribeApprovalLayoutType0.
     * 
     * @return sObjectType
     */
    public java.lang.String getSObjectType() {
        return sObjectType;
    }


    /**
     * Sets the sObjectType value for this DescribeApprovalLayoutType0.
     * 
     * @param sObjectType
     */
    public void setSObjectType(java.lang.String sObjectType) {
        this.sObjectType = sObjectType;
    }


    /**
     * Gets the approvalProcessNames value for this DescribeApprovalLayoutType0.
     * 
     * @return approvalProcessNames
     */
    public java.lang.String[] getApprovalProcessNames() {
        return approvalProcessNames;
    }


    /**
     * Sets the approvalProcessNames value for this DescribeApprovalLayoutType0.
     * 
     * @param approvalProcessNames
     */
    public void setApprovalProcessNames(java.lang.String[] approvalProcessNames) {
        this.approvalProcessNames = approvalProcessNames;
    }

    public java.lang.String getApprovalProcessNames(int i) {
        return this.approvalProcessNames[i];
    }

    public void setApprovalProcessNames(int i, java.lang.String _value) {
        this.approvalProcessNames[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DescribeApprovalLayoutType0)) return false;
        DescribeApprovalLayoutType0 other = (DescribeApprovalLayoutType0) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.sObjectType==null && other.getSObjectType()==null) || 
             (this.sObjectType!=null &&
              this.sObjectType.equals(other.getSObjectType()))) &&
            ((this.approvalProcessNames==null && other.getApprovalProcessNames()==null) || 
             (this.approvalProcessNames!=null &&
              java.util.Arrays.equals(this.approvalProcessNames, other.getApprovalProcessNames())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSObjectType() != null) {
            _hashCode += getSObjectType().hashCode();
        }
        if (getApprovalProcessNames() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getApprovalProcessNames());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getApprovalProcessNames(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DescribeApprovalLayoutType0.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", ">describeApprovalLayout"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SObjectType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "sObjectType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("approvalProcessNames");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "approvalProcessNames"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
