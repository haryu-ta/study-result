/**
 * C000_BORINGIINFO__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C000_BORINGIINFO__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult activityHistories;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.util.Date BUNKATUJIKKOUKIGEN__c;

    private java.lang.String CCYCD__c;

    private java.lang.String CCYHENKANUNIT__c;

    private java.lang.String CCY__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Boolean DELFLG__c;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult events;

    private java.util.Date HENSAI_KIGEN__c;

    private java.lang.String HENSAI_KIKAN__c;

    private java.lang.String HONBUTANTOUBUMONCD__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private java.lang.String JIKKOUKBNNM__c;

    private java.lang.String JIKKOUKBN__c;

    private java.lang.String KETEISHOKANBU__c;

    private java.lang.String KINGAKUHENKANUNIT__c;

    private java.lang.String KOKYAKUBANGOU__c;

    private java.lang.String KOKYAKUNM__c;

    private java.lang.String KYOKUDO_TSUDOKBNNM__c;

    private java.lang.String KYOKUDO_TSUDOKBN__c;

    private java.util.Date lastActivityDate;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String NMKBNNM__c;

    private java.lang.String NMKBN__c;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.QueryResult openActivities;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.Double RINGIKINGAKU__c;

    private java.util.Date RINGIYUKOKIGEN__c;

    private java.lang.String RINSABANGOU__c;

    private java.lang.String RINSAKOBANGOU__c;

    private java.lang.String SHIKINSHITOCD__c;

    private java.lang.String SHIKINSHITONAIYOU__c;

    private java.lang.String SHIKINSHITONM__c;

    private java.lang.String SHOKANBUTENBAN__c;

    private com.sforce.soap.enterprise.QueryResult shares;

    private java.util.Calendar systemModstamp;

    private java.lang.String TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c;

    private java.lang.String TENBAN__c;

    private java.util.Date TORIHIKIJIKKOUBI__c;

    private java.lang.String TORIHIKIKAMOKUCD__c;

    private java.lang.String TORIHIKIKAMOKUNM__c;

    private com.sforce.soap.enterprise.QueryResult tasks;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    private java.lang.String YOSHINSHOKANBUCD__c;

    private java.lang.String YOSHINSHOKANBUNM__c;

    public C000_BORINGIINFO__c() {
    }

    public C000_BORINGIINFO__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult activityHistories,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.util.Date BUNKATUJIKKOUKIGEN__c,
           java.lang.String CCYCD__c,
           java.lang.String CCYHENKANUNIT__c,
           java.lang.String CCY__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Boolean DELFLG__c,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult events,
           java.util.Date HENSAI_KIGEN__c,
           java.lang.String HENSAI_KIKAN__c,
           java.lang.String HONBUTANTOUBUMONCD__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           java.lang.String JIKKOUKBNNM__c,
           java.lang.String JIKKOUKBN__c,
           java.lang.String KETEISHOKANBU__c,
           java.lang.String KINGAKUHENKANUNIT__c,
           java.lang.String KOKYAKUBANGOU__c,
           java.lang.String KOKYAKUNM__c,
           java.lang.String KYOKUDO_TSUDOKBNNM__c,
           java.lang.String KYOKUDO_TSUDOKBN__c,
           java.util.Date lastActivityDate,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String NMKBNNM__c,
           java.lang.String NMKBN__c,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.QueryResult openActivities,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.Double RINGIKINGAKU__c,
           java.util.Date RINGIYUKOKIGEN__c,
           java.lang.String RINSABANGOU__c,
           java.lang.String RINSAKOBANGOU__c,
           java.lang.String SHIKINSHITOCD__c,
           java.lang.String SHIKINSHITONAIYOU__c,
           java.lang.String SHIKINSHITONM__c,
           java.lang.String SHOKANBUTENBAN__c,
           com.sforce.soap.enterprise.QueryResult shares,
           java.util.Calendar systemModstamp,
           java.lang.String TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c,
           java.lang.String TENBAN__c,
           java.util.Date TORIHIKIJIKKOUBI__c,
           java.lang.String TORIHIKIKAMOKUCD__c,
           java.lang.String TORIHIKIKAMOKUNM__c,
           com.sforce.soap.enterprise.QueryResult tasks,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess,
           java.lang.String YOSHINSHOKANBUCD__c,
           java.lang.String YOSHINSHOKANBUNM__c) {
        super(
            fieldsToNull,
            id);
        this.activityHistories = activityHistories;
        this.attachments = attachments;
        this.BUNKATUJIKKOUKIGEN__c = BUNKATUJIKKOUKIGEN__c;
        this.CCYCD__c = CCYCD__c;
        this.CCYHENKANUNIT__c = CCYHENKANUNIT__c;
        this.CCY__c = CCY__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.DELFLG__c = DELFLG__c;
        this.duplicateRecordItems = duplicateRecordItems;
        this.events = events;
        this.HENSAI_KIGEN__c = HENSAI_KIGEN__c;
        this.HENSAI_KIKAN__c = HENSAI_KIKAN__c;
        this.HONBUTANTOUBUMONCD__c = HONBUTANTOUBUMONCD__c;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.JIKKOUKBNNM__c = JIKKOUKBNNM__c;
        this.JIKKOUKBN__c = JIKKOUKBN__c;
        this.KETEISHOKANBU__c = KETEISHOKANBU__c;
        this.KINGAKUHENKANUNIT__c = KINGAKUHENKANUNIT__c;
        this.KOKYAKUBANGOU__c = KOKYAKUBANGOU__c;
        this.KOKYAKUNM__c = KOKYAKUNM__c;
        this.KYOKUDO_TSUDOKBNNM__c = KYOKUDO_TSUDOKBNNM__c;
        this.KYOKUDO_TSUDOKBN__c = KYOKUDO_TSUDOKBN__c;
        this.lastActivityDate = lastActivityDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.NMKBNNM__c = NMKBNNM__c;
        this.NMKBN__c = NMKBN__c;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.openActivities = openActivities;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.RINGIKINGAKU__c = RINGIKINGAKU__c;
        this.RINGIYUKOKIGEN__c = RINGIYUKOKIGEN__c;
        this.RINSABANGOU__c = RINSABANGOU__c;
        this.RINSAKOBANGOU__c = RINSAKOBANGOU__c;
        this.SHIKINSHITOCD__c = SHIKINSHITOCD__c;
        this.SHIKINSHITONAIYOU__c = SHIKINSHITONAIYOU__c;
        this.SHIKINSHITONM__c = SHIKINSHITONM__c;
        this.SHOKANBUTENBAN__c = SHOKANBUTENBAN__c;
        this.shares = shares;
        this.systemModstamp = systemModstamp;
        this.TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c = TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c;
        this.TENBAN__c = TENBAN__c;
        this.TORIHIKIJIKKOUBI__c = TORIHIKIJIKKOUBI__c;
        this.TORIHIKIKAMOKUCD__c = TORIHIKIKAMOKUCD__c;
        this.TORIHIKIKAMOKUNM__c = TORIHIKIKAMOKUNM__c;
        this.tasks = tasks;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
        this.YOSHINSHOKANBUCD__c = YOSHINSHOKANBUCD__c;
        this.YOSHINSHOKANBUNM__c = YOSHINSHOKANBUNM__c;
    }


    /**
     * Gets the activityHistories value for this C000_BORINGIINFO__c.
     * 
     * @return activityHistories
     */
    public com.sforce.soap.enterprise.QueryResult getActivityHistories() {
        return activityHistories;
    }


    /**
     * Sets the activityHistories value for this C000_BORINGIINFO__c.
     * 
     * @param activityHistories
     */
    public void setActivityHistories(com.sforce.soap.enterprise.QueryResult activityHistories) {
        this.activityHistories = activityHistories;
    }


    /**
     * Gets the attachments value for this C000_BORINGIINFO__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C000_BORINGIINFO__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the BUNKATUJIKKOUKIGEN__c value for this C000_BORINGIINFO__c.
     * 
     * @return BUNKATUJIKKOUKIGEN__c
     */
    public java.util.Date getBUNKATUJIKKOUKIGEN__c() {
        return BUNKATUJIKKOUKIGEN__c;
    }


    /**
     * Sets the BUNKATUJIKKOUKIGEN__c value for this C000_BORINGIINFO__c.
     * 
     * @param BUNKATUJIKKOUKIGEN__c
     */
    public void setBUNKATUJIKKOUKIGEN__c(java.util.Date BUNKATUJIKKOUKIGEN__c) {
        this.BUNKATUJIKKOUKIGEN__c = BUNKATUJIKKOUKIGEN__c;
    }


    /**
     * Gets the CCYCD__c value for this C000_BORINGIINFO__c.
     * 
     * @return CCYCD__c
     */
    public java.lang.String getCCYCD__c() {
        return CCYCD__c;
    }


    /**
     * Sets the CCYCD__c value for this C000_BORINGIINFO__c.
     * 
     * @param CCYCD__c
     */
    public void setCCYCD__c(java.lang.String CCYCD__c) {
        this.CCYCD__c = CCYCD__c;
    }


    /**
     * Gets the CCYHENKANUNIT__c value for this C000_BORINGIINFO__c.
     * 
     * @return CCYHENKANUNIT__c
     */
    public java.lang.String getCCYHENKANUNIT__c() {
        return CCYHENKANUNIT__c;
    }


    /**
     * Sets the CCYHENKANUNIT__c value for this C000_BORINGIINFO__c.
     * 
     * @param CCYHENKANUNIT__c
     */
    public void setCCYHENKANUNIT__c(java.lang.String CCYHENKANUNIT__c) {
        this.CCYHENKANUNIT__c = CCYHENKANUNIT__c;
    }


    /**
     * Gets the CCY__c value for this C000_BORINGIINFO__c.
     * 
     * @return CCY__c
     */
    public java.lang.String getCCY__c() {
        return CCY__c;
    }


    /**
     * Sets the CCY__c value for this C000_BORINGIINFO__c.
     * 
     * @param CCY__c
     */
    public void setCCY__c(java.lang.String CCY__c) {
        this.CCY__c = CCY__c;
    }


    /**
     * Gets the combinedAttachments value for this C000_BORINGIINFO__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C000_BORINGIINFO__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C000_BORINGIINFO__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C000_BORINGIINFO__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C000_BORINGIINFO__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C000_BORINGIINFO__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C000_BORINGIINFO__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C000_BORINGIINFO__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the DELFLG__c value for this C000_BORINGIINFO__c.
     * 
     * @return DELFLG__c
     */
    public java.lang.Boolean getDELFLG__c() {
        return DELFLG__c;
    }


    /**
     * Sets the DELFLG__c value for this C000_BORINGIINFO__c.
     * 
     * @param DELFLG__c
     */
    public void setDELFLG__c(java.lang.Boolean DELFLG__c) {
        this.DELFLG__c = DELFLG__c;
    }


    /**
     * Gets the duplicateRecordItems value for this C000_BORINGIINFO__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C000_BORINGIINFO__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the events value for this C000_BORINGIINFO__c.
     * 
     * @return events
     */
    public com.sforce.soap.enterprise.QueryResult getEvents() {
        return events;
    }


    /**
     * Sets the events value for this C000_BORINGIINFO__c.
     * 
     * @param events
     */
    public void setEvents(com.sforce.soap.enterprise.QueryResult events) {
        this.events = events;
    }


    /**
     * Gets the HENSAI_KIGEN__c value for this C000_BORINGIINFO__c.
     * 
     * @return HENSAI_KIGEN__c
     */
    public java.util.Date getHENSAI_KIGEN__c() {
        return HENSAI_KIGEN__c;
    }


    /**
     * Sets the HENSAI_KIGEN__c value for this C000_BORINGIINFO__c.
     * 
     * @param HENSAI_KIGEN__c
     */
    public void setHENSAI_KIGEN__c(java.util.Date HENSAI_KIGEN__c) {
        this.HENSAI_KIGEN__c = HENSAI_KIGEN__c;
    }


    /**
     * Gets the HENSAI_KIKAN__c value for this C000_BORINGIINFO__c.
     * 
     * @return HENSAI_KIKAN__c
     */
    public java.lang.String getHENSAI_KIKAN__c() {
        return HENSAI_KIKAN__c;
    }


    /**
     * Sets the HENSAI_KIKAN__c value for this C000_BORINGIINFO__c.
     * 
     * @param HENSAI_KIKAN__c
     */
    public void setHENSAI_KIKAN__c(java.lang.String HENSAI_KIKAN__c) {
        this.HENSAI_KIKAN__c = HENSAI_KIKAN__c;
    }


    /**
     * Gets the HONBUTANTOUBUMONCD__c value for this C000_BORINGIINFO__c.
     * 
     * @return HONBUTANTOUBUMONCD__c
     */
    public java.lang.String getHONBUTANTOUBUMONCD__c() {
        return HONBUTANTOUBUMONCD__c;
    }


    /**
     * Sets the HONBUTANTOUBUMONCD__c value for this C000_BORINGIINFO__c.
     * 
     * @param HONBUTANTOUBUMONCD__c
     */
    public void setHONBUTANTOUBUMONCD__c(java.lang.String HONBUTANTOUBUMONCD__c) {
        this.HONBUTANTOUBUMONCD__c = HONBUTANTOUBUMONCD__c;
    }


    /**
     * Gets the histories value for this C000_BORINGIINFO__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this C000_BORINGIINFO__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this C000_BORINGIINFO__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C000_BORINGIINFO__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the JIKKOUKBNNM__c value for this C000_BORINGIINFO__c.
     * 
     * @return JIKKOUKBNNM__c
     */
    public java.lang.String getJIKKOUKBNNM__c() {
        return JIKKOUKBNNM__c;
    }


    /**
     * Sets the JIKKOUKBNNM__c value for this C000_BORINGIINFO__c.
     * 
     * @param JIKKOUKBNNM__c
     */
    public void setJIKKOUKBNNM__c(java.lang.String JIKKOUKBNNM__c) {
        this.JIKKOUKBNNM__c = JIKKOUKBNNM__c;
    }


    /**
     * Gets the JIKKOUKBN__c value for this C000_BORINGIINFO__c.
     * 
     * @return JIKKOUKBN__c
     */
    public java.lang.String getJIKKOUKBN__c() {
        return JIKKOUKBN__c;
    }


    /**
     * Sets the JIKKOUKBN__c value for this C000_BORINGIINFO__c.
     * 
     * @param JIKKOUKBN__c
     */
    public void setJIKKOUKBN__c(java.lang.String JIKKOUKBN__c) {
        this.JIKKOUKBN__c = JIKKOUKBN__c;
    }


    /**
     * Gets the KETEISHOKANBU__c value for this C000_BORINGIINFO__c.
     * 
     * @return KETEISHOKANBU__c
     */
    public java.lang.String getKETEISHOKANBU__c() {
        return KETEISHOKANBU__c;
    }


    /**
     * Sets the KETEISHOKANBU__c value for this C000_BORINGIINFO__c.
     * 
     * @param KETEISHOKANBU__c
     */
    public void setKETEISHOKANBU__c(java.lang.String KETEISHOKANBU__c) {
        this.KETEISHOKANBU__c = KETEISHOKANBU__c;
    }


    /**
     * Gets the KINGAKUHENKANUNIT__c value for this C000_BORINGIINFO__c.
     * 
     * @return KINGAKUHENKANUNIT__c
     */
    public java.lang.String getKINGAKUHENKANUNIT__c() {
        return KINGAKUHENKANUNIT__c;
    }


    /**
     * Sets the KINGAKUHENKANUNIT__c value for this C000_BORINGIINFO__c.
     * 
     * @param KINGAKUHENKANUNIT__c
     */
    public void setKINGAKUHENKANUNIT__c(java.lang.String KINGAKUHENKANUNIT__c) {
        this.KINGAKUHENKANUNIT__c = KINGAKUHENKANUNIT__c;
    }


    /**
     * Gets the KOKYAKUBANGOU__c value for this C000_BORINGIINFO__c.
     * 
     * @return KOKYAKUBANGOU__c
     */
    public java.lang.String getKOKYAKUBANGOU__c() {
        return KOKYAKUBANGOU__c;
    }


    /**
     * Sets the KOKYAKUBANGOU__c value for this C000_BORINGIINFO__c.
     * 
     * @param KOKYAKUBANGOU__c
     */
    public void setKOKYAKUBANGOU__c(java.lang.String KOKYAKUBANGOU__c) {
        this.KOKYAKUBANGOU__c = KOKYAKUBANGOU__c;
    }


    /**
     * Gets the KOKYAKUNM__c value for this C000_BORINGIINFO__c.
     * 
     * @return KOKYAKUNM__c
     */
    public java.lang.String getKOKYAKUNM__c() {
        return KOKYAKUNM__c;
    }


    /**
     * Sets the KOKYAKUNM__c value for this C000_BORINGIINFO__c.
     * 
     * @param KOKYAKUNM__c
     */
    public void setKOKYAKUNM__c(java.lang.String KOKYAKUNM__c) {
        this.KOKYAKUNM__c = KOKYAKUNM__c;
    }


    /**
     * Gets the KYOKUDO_TSUDOKBNNM__c value for this C000_BORINGIINFO__c.
     * 
     * @return KYOKUDO_TSUDOKBNNM__c
     */
    public java.lang.String getKYOKUDO_TSUDOKBNNM__c() {
        return KYOKUDO_TSUDOKBNNM__c;
    }


    /**
     * Sets the KYOKUDO_TSUDOKBNNM__c value for this C000_BORINGIINFO__c.
     * 
     * @param KYOKUDO_TSUDOKBNNM__c
     */
    public void setKYOKUDO_TSUDOKBNNM__c(java.lang.String KYOKUDO_TSUDOKBNNM__c) {
        this.KYOKUDO_TSUDOKBNNM__c = KYOKUDO_TSUDOKBNNM__c;
    }


    /**
     * Gets the KYOKUDO_TSUDOKBN__c value for this C000_BORINGIINFO__c.
     * 
     * @return KYOKUDO_TSUDOKBN__c
     */
    public java.lang.String getKYOKUDO_TSUDOKBN__c() {
        return KYOKUDO_TSUDOKBN__c;
    }


    /**
     * Sets the KYOKUDO_TSUDOKBN__c value for this C000_BORINGIINFO__c.
     * 
     * @param KYOKUDO_TSUDOKBN__c
     */
    public void setKYOKUDO_TSUDOKBN__c(java.lang.String KYOKUDO_TSUDOKBN__c) {
        this.KYOKUDO_TSUDOKBN__c = KYOKUDO_TSUDOKBN__c;
    }


    /**
     * Gets the lastActivityDate value for this C000_BORINGIINFO__c.
     * 
     * @return lastActivityDate
     */
    public java.util.Date getLastActivityDate() {
        return lastActivityDate;
    }


    /**
     * Sets the lastActivityDate value for this C000_BORINGIINFO__c.
     * 
     * @param lastActivityDate
     */
    public void setLastActivityDate(java.util.Date lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }


    /**
     * Gets the lastModifiedBy value for this C000_BORINGIINFO__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C000_BORINGIINFO__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C000_BORINGIINFO__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C000_BORINGIINFO__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C000_BORINGIINFO__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C000_BORINGIINFO__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C000_BORINGIINFO__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C000_BORINGIINFO__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the NMKBNNM__c value for this C000_BORINGIINFO__c.
     * 
     * @return NMKBNNM__c
     */
    public java.lang.String getNMKBNNM__c() {
        return NMKBNNM__c;
    }


    /**
     * Sets the NMKBNNM__c value for this C000_BORINGIINFO__c.
     * 
     * @param NMKBNNM__c
     */
    public void setNMKBNNM__c(java.lang.String NMKBNNM__c) {
        this.NMKBNNM__c = NMKBNNM__c;
    }


    /**
     * Gets the NMKBN__c value for this C000_BORINGIINFO__c.
     * 
     * @return NMKBN__c
     */
    public java.lang.String getNMKBN__c() {
        return NMKBN__c;
    }


    /**
     * Sets the NMKBN__c value for this C000_BORINGIINFO__c.
     * 
     * @param NMKBN__c
     */
    public void setNMKBN__c(java.lang.String NMKBN__c) {
        this.NMKBN__c = NMKBN__c;
    }


    /**
     * Gets the name value for this C000_BORINGIINFO__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C000_BORINGIINFO__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C000_BORINGIINFO__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C000_BORINGIINFO__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C000_BORINGIINFO__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C000_BORINGIINFO__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the openActivities value for this C000_BORINGIINFO__c.
     * 
     * @return openActivities
     */
    public com.sforce.soap.enterprise.QueryResult getOpenActivities() {
        return openActivities;
    }


    /**
     * Sets the openActivities value for this C000_BORINGIINFO__c.
     * 
     * @param openActivities
     */
    public void setOpenActivities(com.sforce.soap.enterprise.QueryResult openActivities) {
        this.openActivities = openActivities;
    }


    /**
     * Gets the owner value for this C000_BORINGIINFO__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this C000_BORINGIINFO__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this C000_BORINGIINFO__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this C000_BORINGIINFO__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this C000_BORINGIINFO__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C000_BORINGIINFO__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C000_BORINGIINFO__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C000_BORINGIINFO__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the RINGIKINGAKU__c value for this C000_BORINGIINFO__c.
     * 
     * @return RINGIKINGAKU__c
     */
    public java.lang.Double getRINGIKINGAKU__c() {
        return RINGIKINGAKU__c;
    }


    /**
     * Sets the RINGIKINGAKU__c value for this C000_BORINGIINFO__c.
     * 
     * @param RINGIKINGAKU__c
     */
    public void setRINGIKINGAKU__c(java.lang.Double RINGIKINGAKU__c) {
        this.RINGIKINGAKU__c = RINGIKINGAKU__c;
    }


    /**
     * Gets the RINGIYUKOKIGEN__c value for this C000_BORINGIINFO__c.
     * 
     * @return RINGIYUKOKIGEN__c
     */
    public java.util.Date getRINGIYUKOKIGEN__c() {
        return RINGIYUKOKIGEN__c;
    }


    /**
     * Sets the RINGIYUKOKIGEN__c value for this C000_BORINGIINFO__c.
     * 
     * @param RINGIYUKOKIGEN__c
     */
    public void setRINGIYUKOKIGEN__c(java.util.Date RINGIYUKOKIGEN__c) {
        this.RINGIYUKOKIGEN__c = RINGIYUKOKIGEN__c;
    }


    /**
     * Gets the RINSABANGOU__c value for this C000_BORINGIINFO__c.
     * 
     * @return RINSABANGOU__c
     */
    public java.lang.String getRINSABANGOU__c() {
        return RINSABANGOU__c;
    }


    /**
     * Sets the RINSABANGOU__c value for this C000_BORINGIINFO__c.
     * 
     * @param RINSABANGOU__c
     */
    public void setRINSABANGOU__c(java.lang.String RINSABANGOU__c) {
        this.RINSABANGOU__c = RINSABANGOU__c;
    }


    /**
     * Gets the RINSAKOBANGOU__c value for this C000_BORINGIINFO__c.
     * 
     * @return RINSAKOBANGOU__c
     */
    public java.lang.String getRINSAKOBANGOU__c() {
        return RINSAKOBANGOU__c;
    }


    /**
     * Sets the RINSAKOBANGOU__c value for this C000_BORINGIINFO__c.
     * 
     * @param RINSAKOBANGOU__c
     */
    public void setRINSAKOBANGOU__c(java.lang.String RINSAKOBANGOU__c) {
        this.RINSAKOBANGOU__c = RINSAKOBANGOU__c;
    }


    /**
     * Gets the SHIKINSHITOCD__c value for this C000_BORINGIINFO__c.
     * 
     * @return SHIKINSHITOCD__c
     */
    public java.lang.String getSHIKINSHITOCD__c() {
        return SHIKINSHITOCD__c;
    }


    /**
     * Sets the SHIKINSHITOCD__c value for this C000_BORINGIINFO__c.
     * 
     * @param SHIKINSHITOCD__c
     */
    public void setSHIKINSHITOCD__c(java.lang.String SHIKINSHITOCD__c) {
        this.SHIKINSHITOCD__c = SHIKINSHITOCD__c;
    }


    /**
     * Gets the SHIKINSHITONAIYOU__c value for this C000_BORINGIINFO__c.
     * 
     * @return SHIKINSHITONAIYOU__c
     */
    public java.lang.String getSHIKINSHITONAIYOU__c() {
        return SHIKINSHITONAIYOU__c;
    }


    /**
     * Sets the SHIKINSHITONAIYOU__c value for this C000_BORINGIINFO__c.
     * 
     * @param SHIKINSHITONAIYOU__c
     */
    public void setSHIKINSHITONAIYOU__c(java.lang.String SHIKINSHITONAIYOU__c) {
        this.SHIKINSHITONAIYOU__c = SHIKINSHITONAIYOU__c;
    }


    /**
     * Gets the SHIKINSHITONM__c value for this C000_BORINGIINFO__c.
     * 
     * @return SHIKINSHITONM__c
     */
    public java.lang.String getSHIKINSHITONM__c() {
        return SHIKINSHITONM__c;
    }


    /**
     * Sets the SHIKINSHITONM__c value for this C000_BORINGIINFO__c.
     * 
     * @param SHIKINSHITONM__c
     */
    public void setSHIKINSHITONM__c(java.lang.String SHIKINSHITONM__c) {
        this.SHIKINSHITONM__c = SHIKINSHITONM__c;
    }


    /**
     * Gets the SHOKANBUTENBAN__c value for this C000_BORINGIINFO__c.
     * 
     * @return SHOKANBUTENBAN__c
     */
    public java.lang.String getSHOKANBUTENBAN__c() {
        return SHOKANBUTENBAN__c;
    }


    /**
     * Sets the SHOKANBUTENBAN__c value for this C000_BORINGIINFO__c.
     * 
     * @param SHOKANBUTENBAN__c
     */
    public void setSHOKANBUTENBAN__c(java.lang.String SHOKANBUTENBAN__c) {
        this.SHOKANBUTENBAN__c = SHOKANBUTENBAN__c;
    }


    /**
     * Gets the shares value for this C000_BORINGIINFO__c.
     * 
     * @return shares
     */
    public com.sforce.soap.enterprise.QueryResult getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this C000_BORINGIINFO__c.
     * 
     * @param shares
     */
    public void setShares(com.sforce.soap.enterprise.QueryResult shares) {
        this.shares = shares;
    }


    /**
     * Gets the systemModstamp value for this C000_BORINGIINFO__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C000_BORINGIINFO__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c value for this C000_BORINGIINFO__c.
     * 
     * @return TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c
     */
    public java.lang.String getTENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c() {
        return TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c;
    }


    /**
     * Sets the TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c value for this C000_BORINGIINFO__c.
     * 
     * @param TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c
     */
    public void setTENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c(java.lang.String TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c) {
        this.TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c = TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c;
    }


    /**
     * Gets the TENBAN__c value for this C000_BORINGIINFO__c.
     * 
     * @return TENBAN__c
     */
    public java.lang.String getTENBAN__c() {
        return TENBAN__c;
    }


    /**
     * Sets the TENBAN__c value for this C000_BORINGIINFO__c.
     * 
     * @param TENBAN__c
     */
    public void setTENBAN__c(java.lang.String TENBAN__c) {
        this.TENBAN__c = TENBAN__c;
    }


    /**
     * Gets the TORIHIKIJIKKOUBI__c value for this C000_BORINGIINFO__c.
     * 
     * @return TORIHIKIJIKKOUBI__c
     */
    public java.util.Date getTORIHIKIJIKKOUBI__c() {
        return TORIHIKIJIKKOUBI__c;
    }


    /**
     * Sets the TORIHIKIJIKKOUBI__c value for this C000_BORINGIINFO__c.
     * 
     * @param TORIHIKIJIKKOUBI__c
     */
    public void setTORIHIKIJIKKOUBI__c(java.util.Date TORIHIKIJIKKOUBI__c) {
        this.TORIHIKIJIKKOUBI__c = TORIHIKIJIKKOUBI__c;
    }


    /**
     * Gets the TORIHIKIKAMOKUCD__c value for this C000_BORINGIINFO__c.
     * 
     * @return TORIHIKIKAMOKUCD__c
     */
    public java.lang.String getTORIHIKIKAMOKUCD__c() {
        return TORIHIKIKAMOKUCD__c;
    }


    /**
     * Sets the TORIHIKIKAMOKUCD__c value for this C000_BORINGIINFO__c.
     * 
     * @param TORIHIKIKAMOKUCD__c
     */
    public void setTORIHIKIKAMOKUCD__c(java.lang.String TORIHIKIKAMOKUCD__c) {
        this.TORIHIKIKAMOKUCD__c = TORIHIKIKAMOKUCD__c;
    }


    /**
     * Gets the TORIHIKIKAMOKUNM__c value for this C000_BORINGIINFO__c.
     * 
     * @return TORIHIKIKAMOKUNM__c
     */
    public java.lang.String getTORIHIKIKAMOKUNM__c() {
        return TORIHIKIKAMOKUNM__c;
    }


    /**
     * Sets the TORIHIKIKAMOKUNM__c value for this C000_BORINGIINFO__c.
     * 
     * @param TORIHIKIKAMOKUNM__c
     */
    public void setTORIHIKIKAMOKUNM__c(java.lang.String TORIHIKIKAMOKUNM__c) {
        this.TORIHIKIKAMOKUNM__c = TORIHIKIKAMOKUNM__c;
    }


    /**
     * Gets the tasks value for this C000_BORINGIINFO__c.
     * 
     * @return tasks
     */
    public com.sforce.soap.enterprise.QueryResult getTasks() {
        return tasks;
    }


    /**
     * Sets the tasks value for this C000_BORINGIINFO__c.
     * 
     * @param tasks
     */
    public void setTasks(com.sforce.soap.enterprise.QueryResult tasks) {
        this.tasks = tasks;
    }


    /**
     * Gets the topicAssignments value for this C000_BORINGIINFO__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C000_BORINGIINFO__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this C000_BORINGIINFO__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C000_BORINGIINFO__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the YOSHINSHOKANBUCD__c value for this C000_BORINGIINFO__c.
     * 
     * @return YOSHINSHOKANBUCD__c
     */
    public java.lang.String getYOSHINSHOKANBUCD__c() {
        return YOSHINSHOKANBUCD__c;
    }


    /**
     * Sets the YOSHINSHOKANBUCD__c value for this C000_BORINGIINFO__c.
     * 
     * @param YOSHINSHOKANBUCD__c
     */
    public void setYOSHINSHOKANBUCD__c(java.lang.String YOSHINSHOKANBUCD__c) {
        this.YOSHINSHOKANBUCD__c = YOSHINSHOKANBUCD__c;
    }


    /**
     * Gets the YOSHINSHOKANBUNM__c value for this C000_BORINGIINFO__c.
     * 
     * @return YOSHINSHOKANBUNM__c
     */
    public java.lang.String getYOSHINSHOKANBUNM__c() {
        return YOSHINSHOKANBUNM__c;
    }


    /**
     * Sets the YOSHINSHOKANBUNM__c value for this C000_BORINGIINFO__c.
     * 
     * @param YOSHINSHOKANBUNM__c
     */
    public void setYOSHINSHOKANBUNM__c(java.lang.String YOSHINSHOKANBUNM__c) {
        this.YOSHINSHOKANBUNM__c = YOSHINSHOKANBUNM__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C000_BORINGIINFO__c)) return false;
        C000_BORINGIINFO__c other = (C000_BORINGIINFO__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.activityHistories==null && other.getActivityHistories()==null) || 
             (this.activityHistories!=null &&
              this.activityHistories.equals(other.getActivityHistories()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.BUNKATUJIKKOUKIGEN__c==null && other.getBUNKATUJIKKOUKIGEN__c()==null) || 
             (this.BUNKATUJIKKOUKIGEN__c!=null &&
              this.BUNKATUJIKKOUKIGEN__c.equals(other.getBUNKATUJIKKOUKIGEN__c()))) &&
            ((this.CCYCD__c==null && other.getCCYCD__c()==null) || 
             (this.CCYCD__c!=null &&
              this.CCYCD__c.equals(other.getCCYCD__c()))) &&
            ((this.CCYHENKANUNIT__c==null && other.getCCYHENKANUNIT__c()==null) || 
             (this.CCYHENKANUNIT__c!=null &&
              this.CCYHENKANUNIT__c.equals(other.getCCYHENKANUNIT__c()))) &&
            ((this.CCY__c==null && other.getCCY__c()==null) || 
             (this.CCY__c!=null &&
              this.CCY__c.equals(other.getCCY__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.DELFLG__c==null && other.getDELFLG__c()==null) || 
             (this.DELFLG__c!=null &&
              this.DELFLG__c.equals(other.getDELFLG__c()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.events==null && other.getEvents()==null) || 
             (this.events!=null &&
              this.events.equals(other.getEvents()))) &&
            ((this.HENSAI_KIGEN__c==null && other.getHENSAI_KIGEN__c()==null) || 
             (this.HENSAI_KIGEN__c!=null &&
              this.HENSAI_KIGEN__c.equals(other.getHENSAI_KIGEN__c()))) &&
            ((this.HENSAI_KIKAN__c==null && other.getHENSAI_KIKAN__c()==null) || 
             (this.HENSAI_KIKAN__c!=null &&
              this.HENSAI_KIKAN__c.equals(other.getHENSAI_KIKAN__c()))) &&
            ((this.HONBUTANTOUBUMONCD__c==null && other.getHONBUTANTOUBUMONCD__c()==null) || 
             (this.HONBUTANTOUBUMONCD__c!=null &&
              this.HONBUTANTOUBUMONCD__c.equals(other.getHONBUTANTOUBUMONCD__c()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.JIKKOUKBNNM__c==null && other.getJIKKOUKBNNM__c()==null) || 
             (this.JIKKOUKBNNM__c!=null &&
              this.JIKKOUKBNNM__c.equals(other.getJIKKOUKBNNM__c()))) &&
            ((this.JIKKOUKBN__c==null && other.getJIKKOUKBN__c()==null) || 
             (this.JIKKOUKBN__c!=null &&
              this.JIKKOUKBN__c.equals(other.getJIKKOUKBN__c()))) &&
            ((this.KETEISHOKANBU__c==null && other.getKETEISHOKANBU__c()==null) || 
             (this.KETEISHOKANBU__c!=null &&
              this.KETEISHOKANBU__c.equals(other.getKETEISHOKANBU__c()))) &&
            ((this.KINGAKUHENKANUNIT__c==null && other.getKINGAKUHENKANUNIT__c()==null) || 
             (this.KINGAKUHENKANUNIT__c!=null &&
              this.KINGAKUHENKANUNIT__c.equals(other.getKINGAKUHENKANUNIT__c()))) &&
            ((this.KOKYAKUBANGOU__c==null && other.getKOKYAKUBANGOU__c()==null) || 
             (this.KOKYAKUBANGOU__c!=null &&
              this.KOKYAKUBANGOU__c.equals(other.getKOKYAKUBANGOU__c()))) &&
            ((this.KOKYAKUNM__c==null && other.getKOKYAKUNM__c()==null) || 
             (this.KOKYAKUNM__c!=null &&
              this.KOKYAKUNM__c.equals(other.getKOKYAKUNM__c()))) &&
            ((this.KYOKUDO_TSUDOKBNNM__c==null && other.getKYOKUDO_TSUDOKBNNM__c()==null) || 
             (this.KYOKUDO_TSUDOKBNNM__c!=null &&
              this.KYOKUDO_TSUDOKBNNM__c.equals(other.getKYOKUDO_TSUDOKBNNM__c()))) &&
            ((this.KYOKUDO_TSUDOKBN__c==null && other.getKYOKUDO_TSUDOKBN__c()==null) || 
             (this.KYOKUDO_TSUDOKBN__c!=null &&
              this.KYOKUDO_TSUDOKBN__c.equals(other.getKYOKUDO_TSUDOKBN__c()))) &&
            ((this.lastActivityDate==null && other.getLastActivityDate()==null) || 
             (this.lastActivityDate!=null &&
              this.lastActivityDate.equals(other.getLastActivityDate()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.NMKBNNM__c==null && other.getNMKBNNM__c()==null) || 
             (this.NMKBNNM__c!=null &&
              this.NMKBNNM__c.equals(other.getNMKBNNM__c()))) &&
            ((this.NMKBN__c==null && other.getNMKBN__c()==null) || 
             (this.NMKBN__c!=null &&
              this.NMKBN__c.equals(other.getNMKBN__c()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.openActivities==null && other.getOpenActivities()==null) || 
             (this.openActivities!=null &&
              this.openActivities.equals(other.getOpenActivities()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.RINGIKINGAKU__c==null && other.getRINGIKINGAKU__c()==null) || 
             (this.RINGIKINGAKU__c!=null &&
              this.RINGIKINGAKU__c.equals(other.getRINGIKINGAKU__c()))) &&
            ((this.RINGIYUKOKIGEN__c==null && other.getRINGIYUKOKIGEN__c()==null) || 
             (this.RINGIYUKOKIGEN__c!=null &&
              this.RINGIYUKOKIGEN__c.equals(other.getRINGIYUKOKIGEN__c()))) &&
            ((this.RINSABANGOU__c==null && other.getRINSABANGOU__c()==null) || 
             (this.RINSABANGOU__c!=null &&
              this.RINSABANGOU__c.equals(other.getRINSABANGOU__c()))) &&
            ((this.RINSAKOBANGOU__c==null && other.getRINSAKOBANGOU__c()==null) || 
             (this.RINSAKOBANGOU__c!=null &&
              this.RINSAKOBANGOU__c.equals(other.getRINSAKOBANGOU__c()))) &&
            ((this.SHIKINSHITOCD__c==null && other.getSHIKINSHITOCD__c()==null) || 
             (this.SHIKINSHITOCD__c!=null &&
              this.SHIKINSHITOCD__c.equals(other.getSHIKINSHITOCD__c()))) &&
            ((this.SHIKINSHITONAIYOU__c==null && other.getSHIKINSHITONAIYOU__c()==null) || 
             (this.SHIKINSHITONAIYOU__c!=null &&
              this.SHIKINSHITONAIYOU__c.equals(other.getSHIKINSHITONAIYOU__c()))) &&
            ((this.SHIKINSHITONM__c==null && other.getSHIKINSHITONM__c()==null) || 
             (this.SHIKINSHITONM__c!=null &&
              this.SHIKINSHITONM__c.equals(other.getSHIKINSHITONM__c()))) &&
            ((this.SHOKANBUTENBAN__c==null && other.getSHOKANBUTENBAN__c()==null) || 
             (this.SHOKANBUTENBAN__c!=null &&
              this.SHOKANBUTENBAN__c.equals(other.getSHOKANBUTENBAN__c()))) &&
            ((this.shares==null && other.getShares()==null) || 
             (this.shares!=null &&
              this.shares.equals(other.getShares()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c==null && other.getTENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c()==null) || 
             (this.TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c!=null &&
              this.TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c.equals(other.getTENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c()))) &&
            ((this.TENBAN__c==null && other.getTENBAN__c()==null) || 
             (this.TENBAN__c!=null &&
              this.TENBAN__c.equals(other.getTENBAN__c()))) &&
            ((this.TORIHIKIJIKKOUBI__c==null && other.getTORIHIKIJIKKOUBI__c()==null) || 
             (this.TORIHIKIJIKKOUBI__c!=null &&
              this.TORIHIKIJIKKOUBI__c.equals(other.getTORIHIKIJIKKOUBI__c()))) &&
            ((this.TORIHIKIKAMOKUCD__c==null && other.getTORIHIKIKAMOKUCD__c()==null) || 
             (this.TORIHIKIKAMOKUCD__c!=null &&
              this.TORIHIKIKAMOKUCD__c.equals(other.getTORIHIKIKAMOKUCD__c()))) &&
            ((this.TORIHIKIKAMOKUNM__c==null && other.getTORIHIKIKAMOKUNM__c()==null) || 
             (this.TORIHIKIKAMOKUNM__c!=null &&
              this.TORIHIKIKAMOKUNM__c.equals(other.getTORIHIKIKAMOKUNM__c()))) &&
            ((this.tasks==null && other.getTasks()==null) || 
             (this.tasks!=null &&
              this.tasks.equals(other.getTasks()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess()))) &&
            ((this.YOSHINSHOKANBUCD__c==null && other.getYOSHINSHOKANBUCD__c()==null) || 
             (this.YOSHINSHOKANBUCD__c!=null &&
              this.YOSHINSHOKANBUCD__c.equals(other.getYOSHINSHOKANBUCD__c()))) &&
            ((this.YOSHINSHOKANBUNM__c==null && other.getYOSHINSHOKANBUNM__c()==null) || 
             (this.YOSHINSHOKANBUNM__c!=null &&
              this.YOSHINSHOKANBUNM__c.equals(other.getYOSHINSHOKANBUNM__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getActivityHistories() != null) {
            _hashCode += getActivityHistories().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBUNKATUJIKKOUKIGEN__c() != null) {
            _hashCode += getBUNKATUJIKKOUKIGEN__c().hashCode();
        }
        if (getCCYCD__c() != null) {
            _hashCode += getCCYCD__c().hashCode();
        }
        if (getCCYHENKANUNIT__c() != null) {
            _hashCode += getCCYHENKANUNIT__c().hashCode();
        }
        if (getCCY__c() != null) {
            _hashCode += getCCY__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDELFLG__c() != null) {
            _hashCode += getDELFLG__c().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getEvents() != null) {
            _hashCode += getEvents().hashCode();
        }
        if (getHENSAI_KIGEN__c() != null) {
            _hashCode += getHENSAI_KIGEN__c().hashCode();
        }
        if (getHENSAI_KIKAN__c() != null) {
            _hashCode += getHENSAI_KIKAN__c().hashCode();
        }
        if (getHONBUTANTOUBUMONCD__c() != null) {
            _hashCode += getHONBUTANTOUBUMONCD__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getJIKKOUKBNNM__c() != null) {
            _hashCode += getJIKKOUKBNNM__c().hashCode();
        }
        if (getJIKKOUKBN__c() != null) {
            _hashCode += getJIKKOUKBN__c().hashCode();
        }
        if (getKETEISHOKANBU__c() != null) {
            _hashCode += getKETEISHOKANBU__c().hashCode();
        }
        if (getKINGAKUHENKANUNIT__c() != null) {
            _hashCode += getKINGAKUHENKANUNIT__c().hashCode();
        }
        if (getKOKYAKUBANGOU__c() != null) {
            _hashCode += getKOKYAKUBANGOU__c().hashCode();
        }
        if (getKOKYAKUNM__c() != null) {
            _hashCode += getKOKYAKUNM__c().hashCode();
        }
        if (getKYOKUDO_TSUDOKBNNM__c() != null) {
            _hashCode += getKYOKUDO_TSUDOKBNNM__c().hashCode();
        }
        if (getKYOKUDO_TSUDOKBN__c() != null) {
            _hashCode += getKYOKUDO_TSUDOKBN__c().hashCode();
        }
        if (getLastActivityDate() != null) {
            _hashCode += getLastActivityDate().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getNMKBNNM__c() != null) {
            _hashCode += getNMKBNNM__c().hashCode();
        }
        if (getNMKBN__c() != null) {
            _hashCode += getNMKBN__c().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOpenActivities() != null) {
            _hashCode += getOpenActivities().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getRINGIKINGAKU__c() != null) {
            _hashCode += getRINGIKINGAKU__c().hashCode();
        }
        if (getRINGIYUKOKIGEN__c() != null) {
            _hashCode += getRINGIYUKOKIGEN__c().hashCode();
        }
        if (getRINSABANGOU__c() != null) {
            _hashCode += getRINSABANGOU__c().hashCode();
        }
        if (getRINSAKOBANGOU__c() != null) {
            _hashCode += getRINSAKOBANGOU__c().hashCode();
        }
        if (getSHIKINSHITOCD__c() != null) {
            _hashCode += getSHIKINSHITOCD__c().hashCode();
        }
        if (getSHIKINSHITONAIYOU__c() != null) {
            _hashCode += getSHIKINSHITONAIYOU__c().hashCode();
        }
        if (getSHIKINSHITONM__c() != null) {
            _hashCode += getSHIKINSHITONM__c().hashCode();
        }
        if (getSHOKANBUTENBAN__c() != null) {
            _hashCode += getSHOKANBUTENBAN__c().hashCode();
        }
        if (getShares() != null) {
            _hashCode += getShares().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c() != null) {
            _hashCode += getTENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c().hashCode();
        }
        if (getTENBAN__c() != null) {
            _hashCode += getTENBAN__c().hashCode();
        }
        if (getTORIHIKIJIKKOUBI__c() != null) {
            _hashCode += getTORIHIKIJIKKOUBI__c().hashCode();
        }
        if (getTORIHIKIKAMOKUCD__c() != null) {
            _hashCode += getTORIHIKIKAMOKUCD__c().hashCode();
        }
        if (getTORIHIKIKAMOKUNM__c() != null) {
            _hashCode += getTORIHIKIKAMOKUNM__c().hashCode();
        }
        if (getTasks() != null) {
            _hashCode += getTasks().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        if (getYOSHINSHOKANBUCD__c() != null) {
            _hashCode += getYOSHINSHOKANBUCD__c().hashCode();
        }
        if (getYOSHINSHOKANBUNM__c() != null) {
            _hashCode += getYOSHINSHOKANBUNM__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C000_BORINGIINFO__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_BORINGIINFO__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activityHistories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivityHistories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUNKATUJIKKOUKIGEN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUNKATUJIKKOUKIGEN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCYCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCYCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCYHENKANUNIT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCYHENKANUNIT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CCY__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CCY__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DELFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DELFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("events");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Events"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HENSAI_KIGEN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HENSAI_KIGEN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HENSAI_KIKAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HENSAI_KIKAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HONBUTANTOUBUMONCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HONBUTANTOUBUMONCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JIKKOUKBNNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JIKKOUKBNNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JIKKOUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JIKKOUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KETEISHOKANBU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KETEISHOKANBU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KINGAKUHENKANUNIT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KINGAKUHENKANUNIT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKYAKUBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKYAKUBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKYAKUNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKYAKUNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOKUDO_TSUDOKBNNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOKUDO_TSUDOKBNNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOKUDO_TSUDOKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOKUDO_TSUDOKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastActivityDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastActivityDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NMKBNNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NMKBNNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NMKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NMKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpenActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RINGIKINGAKU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RINGIKINGAKU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RINGIYUKOKIGEN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RINGIYUKOKIGEN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RINSABANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RINSABANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RINSAKOBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RINSAKOBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHIKINSHITOCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHIKINSHITOCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHIKINSHITONAIYOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHIKINSHITONAIYOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHIKINSHITONM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHIKINSHITONM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOKANBUTENBAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOKANBUTENBAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENBAN_KOKYAKUBANGOU_RBANGOU_RKOBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENBAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENBAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIJIKKOUBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIJIKKOUBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIKAMOKUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIKAMOKUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIKAMOKUNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIKAMOKUNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tasks");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Tasks"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOSHINSHOKANBUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOSHINSHOKANBUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOSHINSHOKANBUNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOSHINSHOKANBUNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
