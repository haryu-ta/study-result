/**
 * C003_Contract__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C003_Contract__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult a020_Contracts_01__r;

    private com.sforce.soap.enterprise.QueryResult a020_Contracts_03__r;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String c003_AccountNo__c;

    private java.lang.String c003_AccountRef__c;

    private com.sforce.soap.enterprise.sobject.Account c003_AccountRef__r;

    private java.lang.String c003_AccountTemban__c;

    private java.lang.String c003_AccountType__c;

    private java.lang.Double c003_Amount__c;

    private java.lang.String c003_Area_01__c;

    private java.lang.String c003_Area_02__c;

    private java.lang.String c003_Area_03__c;

    private java.lang.String c003_Area_04__c;

    private java.lang.String c003_Area_05__c;

    private java.lang.String c003_Area_06__c;

    private java.lang.String c003_Area_07__c;

    private java.lang.String c003_Area_08__c;

    private java.lang.String c003_Area_09__c;

    private java.lang.String c003_Area_10__c;

    private java.lang.Boolean c003_Check_01__c;

    private java.lang.Boolean c003_Check_02__c;

    private java.lang.Boolean c003_Check_03__c;

    private java.lang.Boolean c003_Check_04__c;

    private java.lang.Boolean c003_Check_05__c;

    private java.lang.Boolean c003_Check_06__c;

    private java.lang.Boolean c003_Check_07__c;

    private java.lang.Boolean c003_Check_08__c;

    private java.lang.Boolean c003_Check_09__c;

    private java.lang.Boolean c003_Check_10__c;

    private java.lang.String c003_CommodityRef__c;

    private com.sforce.soap.enterprise.sobject.C003_Commodity__c c003_CommodityRef__r;

    private java.lang.String c003_ContractId__c;

    private com.sforce.soap.enterprise.QueryResult c003_Contracts_01__r;

    private java.lang.String c003_CsvLastModifiedDate__c;

    private java.util.Date c003_Date_01__c;

    private java.util.Date c003_Date_02__c;

    private java.util.Date c003_Date_03__c;

    private java.util.Date c003_Date_04__c;

    private java.util.Date c003_Date_05__c;

    private java.util.Date c003_Date_06__c;

    private java.util.Date c003_Date_07__c;

    private java.util.Date c003_Date_08__c;

    private java.util.Date c003_Date_09__c;

    private java.util.Date c003_Date_10__c;

    private java.util.Date c003_Date__c;

    private java.util.Date c003_EndDate__c;

    private java.lang.String c003_List_01__c;

    private java.lang.String c003_List_02__c;

    private java.lang.String c003_List_03__c;

    private java.lang.String c003_List_04__c;

    private java.lang.String c003_List_05__c;

    private java.lang.String c003_List_06__c;

    private java.lang.String c003_List_07__c;

    private java.lang.String c003_List_08__c;

    private java.lang.String c003_List_09__c;

    private java.lang.String c003_List_10__c;

    private java.lang.String c003_Note__c;

    private java.lang.Double c003_Number_01__c;

    private java.lang.Double c003_Number_02__c;

    private java.lang.Double c003_Number_03__c;

    private java.lang.Double c003_Number_04__c;

    private java.lang.Double c003_Number_05__c;

    private java.lang.Double c003_Number_06__c;

    private java.lang.Double c003_Number_07__c;

    private java.lang.Double c003_Number_08__c;

    private java.lang.Double c003_Number_09__c;

    private java.lang.Double c003_Number_10__c;

    private java.util.Date c003_StartDate__c;

    private java.lang.String c003_Status__c;

    private java.lang.String c003_TembanKokyakubangou__c;

    private java.lang.String c003_Text_01__c;

    private java.lang.String c003_Text_02__c;

    private java.lang.String c003_Text_03__c;

    private java.lang.String c003_Text_04__c;

    private java.lang.String c003_Text_05__c;

    private java.lang.String c003_Text_06__c;

    private java.lang.String c003_Text_07__c;

    private java.lang.String c003_Text_08__c;

    private java.lang.String c003_Text_09__c;

    private java.lang.String c003_Text_10__c;

    private java.lang.String c003_YomikomiNo__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.util.Calendar lastReferencedDate;

    private java.util.Calendar lastViewedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    public C003_Contract__c() {
    }

    public C003_Contract__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult a020_Contracts_01__r,
           com.sforce.soap.enterprise.QueryResult a020_Contracts_03__r,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String c003_AccountNo__c,
           java.lang.String c003_AccountRef__c,
           com.sforce.soap.enterprise.sobject.Account c003_AccountRef__r,
           java.lang.String c003_AccountTemban__c,
           java.lang.String c003_AccountType__c,
           java.lang.Double c003_Amount__c,
           java.lang.String c003_Area_01__c,
           java.lang.String c003_Area_02__c,
           java.lang.String c003_Area_03__c,
           java.lang.String c003_Area_04__c,
           java.lang.String c003_Area_05__c,
           java.lang.String c003_Area_06__c,
           java.lang.String c003_Area_07__c,
           java.lang.String c003_Area_08__c,
           java.lang.String c003_Area_09__c,
           java.lang.String c003_Area_10__c,
           java.lang.Boolean c003_Check_01__c,
           java.lang.Boolean c003_Check_02__c,
           java.lang.Boolean c003_Check_03__c,
           java.lang.Boolean c003_Check_04__c,
           java.lang.Boolean c003_Check_05__c,
           java.lang.Boolean c003_Check_06__c,
           java.lang.Boolean c003_Check_07__c,
           java.lang.Boolean c003_Check_08__c,
           java.lang.Boolean c003_Check_09__c,
           java.lang.Boolean c003_Check_10__c,
           java.lang.String c003_CommodityRef__c,
           com.sforce.soap.enterprise.sobject.C003_Commodity__c c003_CommodityRef__r,
           java.lang.String c003_ContractId__c,
           com.sforce.soap.enterprise.QueryResult c003_Contracts_01__r,
           java.lang.String c003_CsvLastModifiedDate__c,
           java.util.Date c003_Date_01__c,
           java.util.Date c003_Date_02__c,
           java.util.Date c003_Date_03__c,
           java.util.Date c003_Date_04__c,
           java.util.Date c003_Date_05__c,
           java.util.Date c003_Date_06__c,
           java.util.Date c003_Date_07__c,
           java.util.Date c003_Date_08__c,
           java.util.Date c003_Date_09__c,
           java.util.Date c003_Date_10__c,
           java.util.Date c003_Date__c,
           java.util.Date c003_EndDate__c,
           java.lang.String c003_List_01__c,
           java.lang.String c003_List_02__c,
           java.lang.String c003_List_03__c,
           java.lang.String c003_List_04__c,
           java.lang.String c003_List_05__c,
           java.lang.String c003_List_06__c,
           java.lang.String c003_List_07__c,
           java.lang.String c003_List_08__c,
           java.lang.String c003_List_09__c,
           java.lang.String c003_List_10__c,
           java.lang.String c003_Note__c,
           java.lang.Double c003_Number_01__c,
           java.lang.Double c003_Number_02__c,
           java.lang.Double c003_Number_03__c,
           java.lang.Double c003_Number_04__c,
           java.lang.Double c003_Number_05__c,
           java.lang.Double c003_Number_06__c,
           java.lang.Double c003_Number_07__c,
           java.lang.Double c003_Number_08__c,
           java.lang.Double c003_Number_09__c,
           java.lang.Double c003_Number_10__c,
           java.util.Date c003_StartDate__c,
           java.lang.String c003_Status__c,
           java.lang.String c003_TembanKokyakubangou__c,
           java.lang.String c003_Text_01__c,
           java.lang.String c003_Text_02__c,
           java.lang.String c003_Text_03__c,
           java.lang.String c003_Text_04__c,
           java.lang.String c003_Text_05__c,
           java.lang.String c003_Text_06__c,
           java.lang.String c003_Text_07__c,
           java.lang.String c003_Text_08__c,
           java.lang.String c003_Text_09__c,
           java.lang.String c003_Text_10__c,
           java.lang.String c003_YomikomiNo__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.util.Calendar lastReferencedDate,
           java.util.Calendar lastViewedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        super(
            fieldsToNull,
            id);
        this.a020_Contracts_01__r = a020_Contracts_01__r;
        this.a020_Contracts_03__r = a020_Contracts_03__r;
        this.attachments = attachments;
        this.c003_AccountNo__c = c003_AccountNo__c;
        this.c003_AccountRef__c = c003_AccountRef__c;
        this.c003_AccountRef__r = c003_AccountRef__r;
        this.c003_AccountTemban__c = c003_AccountTemban__c;
        this.c003_AccountType__c = c003_AccountType__c;
        this.c003_Amount__c = c003_Amount__c;
        this.c003_Area_01__c = c003_Area_01__c;
        this.c003_Area_02__c = c003_Area_02__c;
        this.c003_Area_03__c = c003_Area_03__c;
        this.c003_Area_04__c = c003_Area_04__c;
        this.c003_Area_05__c = c003_Area_05__c;
        this.c003_Area_06__c = c003_Area_06__c;
        this.c003_Area_07__c = c003_Area_07__c;
        this.c003_Area_08__c = c003_Area_08__c;
        this.c003_Area_09__c = c003_Area_09__c;
        this.c003_Area_10__c = c003_Area_10__c;
        this.c003_Check_01__c = c003_Check_01__c;
        this.c003_Check_02__c = c003_Check_02__c;
        this.c003_Check_03__c = c003_Check_03__c;
        this.c003_Check_04__c = c003_Check_04__c;
        this.c003_Check_05__c = c003_Check_05__c;
        this.c003_Check_06__c = c003_Check_06__c;
        this.c003_Check_07__c = c003_Check_07__c;
        this.c003_Check_08__c = c003_Check_08__c;
        this.c003_Check_09__c = c003_Check_09__c;
        this.c003_Check_10__c = c003_Check_10__c;
        this.c003_CommodityRef__c = c003_CommodityRef__c;
        this.c003_CommodityRef__r = c003_CommodityRef__r;
        this.c003_ContractId__c = c003_ContractId__c;
        this.c003_Contracts_01__r = c003_Contracts_01__r;
        this.c003_CsvLastModifiedDate__c = c003_CsvLastModifiedDate__c;
        this.c003_Date_01__c = c003_Date_01__c;
        this.c003_Date_02__c = c003_Date_02__c;
        this.c003_Date_03__c = c003_Date_03__c;
        this.c003_Date_04__c = c003_Date_04__c;
        this.c003_Date_05__c = c003_Date_05__c;
        this.c003_Date_06__c = c003_Date_06__c;
        this.c003_Date_07__c = c003_Date_07__c;
        this.c003_Date_08__c = c003_Date_08__c;
        this.c003_Date_09__c = c003_Date_09__c;
        this.c003_Date_10__c = c003_Date_10__c;
        this.c003_Date__c = c003_Date__c;
        this.c003_EndDate__c = c003_EndDate__c;
        this.c003_List_01__c = c003_List_01__c;
        this.c003_List_02__c = c003_List_02__c;
        this.c003_List_03__c = c003_List_03__c;
        this.c003_List_04__c = c003_List_04__c;
        this.c003_List_05__c = c003_List_05__c;
        this.c003_List_06__c = c003_List_06__c;
        this.c003_List_07__c = c003_List_07__c;
        this.c003_List_08__c = c003_List_08__c;
        this.c003_List_09__c = c003_List_09__c;
        this.c003_List_10__c = c003_List_10__c;
        this.c003_Note__c = c003_Note__c;
        this.c003_Number_01__c = c003_Number_01__c;
        this.c003_Number_02__c = c003_Number_02__c;
        this.c003_Number_03__c = c003_Number_03__c;
        this.c003_Number_04__c = c003_Number_04__c;
        this.c003_Number_05__c = c003_Number_05__c;
        this.c003_Number_06__c = c003_Number_06__c;
        this.c003_Number_07__c = c003_Number_07__c;
        this.c003_Number_08__c = c003_Number_08__c;
        this.c003_Number_09__c = c003_Number_09__c;
        this.c003_Number_10__c = c003_Number_10__c;
        this.c003_StartDate__c = c003_StartDate__c;
        this.c003_Status__c = c003_Status__c;
        this.c003_TembanKokyakubangou__c = c003_TembanKokyakubangou__c;
        this.c003_Text_01__c = c003_Text_01__c;
        this.c003_Text_02__c = c003_Text_02__c;
        this.c003_Text_03__c = c003_Text_03__c;
        this.c003_Text_04__c = c003_Text_04__c;
        this.c003_Text_05__c = c003_Text_05__c;
        this.c003_Text_06__c = c003_Text_06__c;
        this.c003_Text_07__c = c003_Text_07__c;
        this.c003_Text_08__c = c003_Text_08__c;
        this.c003_Text_09__c = c003_Text_09__c;
        this.c003_Text_10__c = c003_Text_10__c;
        this.c003_YomikomiNo__c = c003_YomikomiNo__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.duplicateRecordItems = duplicateRecordItems;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lastReferencedDate = lastReferencedDate;
        this.lastViewedDate = lastViewedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.systemModstamp = systemModstamp;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the a020_Contracts_01__r value for this C003_Contract__c.
     * 
     * @return a020_Contracts_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getA020_Contracts_01__r() {
        return a020_Contracts_01__r;
    }


    /**
     * Sets the a020_Contracts_01__r value for this C003_Contract__c.
     * 
     * @param a020_Contracts_01__r
     */
    public void setA020_Contracts_01__r(com.sforce.soap.enterprise.QueryResult a020_Contracts_01__r) {
        this.a020_Contracts_01__r = a020_Contracts_01__r;
    }


    /**
     * Gets the a020_Contracts_03__r value for this C003_Contract__c.
     * 
     * @return a020_Contracts_03__r
     */
    public com.sforce.soap.enterprise.QueryResult getA020_Contracts_03__r() {
        return a020_Contracts_03__r;
    }


    /**
     * Sets the a020_Contracts_03__r value for this C003_Contract__c.
     * 
     * @param a020_Contracts_03__r
     */
    public void setA020_Contracts_03__r(com.sforce.soap.enterprise.QueryResult a020_Contracts_03__r) {
        this.a020_Contracts_03__r = a020_Contracts_03__r;
    }


    /**
     * Gets the attachments value for this C003_Contract__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C003_Contract__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the c003_AccountNo__c value for this C003_Contract__c.
     * 
     * @return c003_AccountNo__c
     */
    public java.lang.String getC003_AccountNo__c() {
        return c003_AccountNo__c;
    }


    /**
     * Sets the c003_AccountNo__c value for this C003_Contract__c.
     * 
     * @param c003_AccountNo__c
     */
    public void setC003_AccountNo__c(java.lang.String c003_AccountNo__c) {
        this.c003_AccountNo__c = c003_AccountNo__c;
    }


    /**
     * Gets the c003_AccountRef__c value for this C003_Contract__c.
     * 
     * @return c003_AccountRef__c
     */
    public java.lang.String getC003_AccountRef__c() {
        return c003_AccountRef__c;
    }


    /**
     * Sets the c003_AccountRef__c value for this C003_Contract__c.
     * 
     * @param c003_AccountRef__c
     */
    public void setC003_AccountRef__c(java.lang.String c003_AccountRef__c) {
        this.c003_AccountRef__c = c003_AccountRef__c;
    }


    /**
     * Gets the c003_AccountRef__r value for this C003_Contract__c.
     * 
     * @return c003_AccountRef__r
     */
    public com.sforce.soap.enterprise.sobject.Account getC003_AccountRef__r() {
        return c003_AccountRef__r;
    }


    /**
     * Sets the c003_AccountRef__r value for this C003_Contract__c.
     * 
     * @param c003_AccountRef__r
     */
    public void setC003_AccountRef__r(com.sforce.soap.enterprise.sobject.Account c003_AccountRef__r) {
        this.c003_AccountRef__r = c003_AccountRef__r;
    }


    /**
     * Gets the c003_AccountTemban__c value for this C003_Contract__c.
     * 
     * @return c003_AccountTemban__c
     */
    public java.lang.String getC003_AccountTemban__c() {
        return c003_AccountTemban__c;
    }


    /**
     * Sets the c003_AccountTemban__c value for this C003_Contract__c.
     * 
     * @param c003_AccountTemban__c
     */
    public void setC003_AccountTemban__c(java.lang.String c003_AccountTemban__c) {
        this.c003_AccountTemban__c = c003_AccountTemban__c;
    }


    /**
     * Gets the c003_AccountType__c value for this C003_Contract__c.
     * 
     * @return c003_AccountType__c
     */
    public java.lang.String getC003_AccountType__c() {
        return c003_AccountType__c;
    }


    /**
     * Sets the c003_AccountType__c value for this C003_Contract__c.
     * 
     * @param c003_AccountType__c
     */
    public void setC003_AccountType__c(java.lang.String c003_AccountType__c) {
        this.c003_AccountType__c = c003_AccountType__c;
    }


    /**
     * Gets the c003_Amount__c value for this C003_Contract__c.
     * 
     * @return c003_Amount__c
     */
    public java.lang.Double getC003_Amount__c() {
        return c003_Amount__c;
    }


    /**
     * Sets the c003_Amount__c value for this C003_Contract__c.
     * 
     * @param c003_Amount__c
     */
    public void setC003_Amount__c(java.lang.Double c003_Amount__c) {
        this.c003_Amount__c = c003_Amount__c;
    }


    /**
     * Gets the c003_Area_01__c value for this C003_Contract__c.
     * 
     * @return c003_Area_01__c
     */
    public java.lang.String getC003_Area_01__c() {
        return c003_Area_01__c;
    }


    /**
     * Sets the c003_Area_01__c value for this C003_Contract__c.
     * 
     * @param c003_Area_01__c
     */
    public void setC003_Area_01__c(java.lang.String c003_Area_01__c) {
        this.c003_Area_01__c = c003_Area_01__c;
    }


    /**
     * Gets the c003_Area_02__c value for this C003_Contract__c.
     * 
     * @return c003_Area_02__c
     */
    public java.lang.String getC003_Area_02__c() {
        return c003_Area_02__c;
    }


    /**
     * Sets the c003_Area_02__c value for this C003_Contract__c.
     * 
     * @param c003_Area_02__c
     */
    public void setC003_Area_02__c(java.lang.String c003_Area_02__c) {
        this.c003_Area_02__c = c003_Area_02__c;
    }


    /**
     * Gets the c003_Area_03__c value for this C003_Contract__c.
     * 
     * @return c003_Area_03__c
     */
    public java.lang.String getC003_Area_03__c() {
        return c003_Area_03__c;
    }


    /**
     * Sets the c003_Area_03__c value for this C003_Contract__c.
     * 
     * @param c003_Area_03__c
     */
    public void setC003_Area_03__c(java.lang.String c003_Area_03__c) {
        this.c003_Area_03__c = c003_Area_03__c;
    }


    /**
     * Gets the c003_Area_04__c value for this C003_Contract__c.
     * 
     * @return c003_Area_04__c
     */
    public java.lang.String getC003_Area_04__c() {
        return c003_Area_04__c;
    }


    /**
     * Sets the c003_Area_04__c value for this C003_Contract__c.
     * 
     * @param c003_Area_04__c
     */
    public void setC003_Area_04__c(java.lang.String c003_Area_04__c) {
        this.c003_Area_04__c = c003_Area_04__c;
    }


    /**
     * Gets the c003_Area_05__c value for this C003_Contract__c.
     * 
     * @return c003_Area_05__c
     */
    public java.lang.String getC003_Area_05__c() {
        return c003_Area_05__c;
    }


    /**
     * Sets the c003_Area_05__c value for this C003_Contract__c.
     * 
     * @param c003_Area_05__c
     */
    public void setC003_Area_05__c(java.lang.String c003_Area_05__c) {
        this.c003_Area_05__c = c003_Area_05__c;
    }


    /**
     * Gets the c003_Area_06__c value for this C003_Contract__c.
     * 
     * @return c003_Area_06__c
     */
    public java.lang.String getC003_Area_06__c() {
        return c003_Area_06__c;
    }


    /**
     * Sets the c003_Area_06__c value for this C003_Contract__c.
     * 
     * @param c003_Area_06__c
     */
    public void setC003_Area_06__c(java.lang.String c003_Area_06__c) {
        this.c003_Area_06__c = c003_Area_06__c;
    }


    /**
     * Gets the c003_Area_07__c value for this C003_Contract__c.
     * 
     * @return c003_Area_07__c
     */
    public java.lang.String getC003_Area_07__c() {
        return c003_Area_07__c;
    }


    /**
     * Sets the c003_Area_07__c value for this C003_Contract__c.
     * 
     * @param c003_Area_07__c
     */
    public void setC003_Area_07__c(java.lang.String c003_Area_07__c) {
        this.c003_Area_07__c = c003_Area_07__c;
    }


    /**
     * Gets the c003_Area_08__c value for this C003_Contract__c.
     * 
     * @return c003_Area_08__c
     */
    public java.lang.String getC003_Area_08__c() {
        return c003_Area_08__c;
    }


    /**
     * Sets the c003_Area_08__c value for this C003_Contract__c.
     * 
     * @param c003_Area_08__c
     */
    public void setC003_Area_08__c(java.lang.String c003_Area_08__c) {
        this.c003_Area_08__c = c003_Area_08__c;
    }


    /**
     * Gets the c003_Area_09__c value for this C003_Contract__c.
     * 
     * @return c003_Area_09__c
     */
    public java.lang.String getC003_Area_09__c() {
        return c003_Area_09__c;
    }


    /**
     * Sets the c003_Area_09__c value for this C003_Contract__c.
     * 
     * @param c003_Area_09__c
     */
    public void setC003_Area_09__c(java.lang.String c003_Area_09__c) {
        this.c003_Area_09__c = c003_Area_09__c;
    }


    /**
     * Gets the c003_Area_10__c value for this C003_Contract__c.
     * 
     * @return c003_Area_10__c
     */
    public java.lang.String getC003_Area_10__c() {
        return c003_Area_10__c;
    }


    /**
     * Sets the c003_Area_10__c value for this C003_Contract__c.
     * 
     * @param c003_Area_10__c
     */
    public void setC003_Area_10__c(java.lang.String c003_Area_10__c) {
        this.c003_Area_10__c = c003_Area_10__c;
    }


    /**
     * Gets the c003_Check_01__c value for this C003_Contract__c.
     * 
     * @return c003_Check_01__c
     */
    public java.lang.Boolean getC003_Check_01__c() {
        return c003_Check_01__c;
    }


    /**
     * Sets the c003_Check_01__c value for this C003_Contract__c.
     * 
     * @param c003_Check_01__c
     */
    public void setC003_Check_01__c(java.lang.Boolean c003_Check_01__c) {
        this.c003_Check_01__c = c003_Check_01__c;
    }


    /**
     * Gets the c003_Check_02__c value for this C003_Contract__c.
     * 
     * @return c003_Check_02__c
     */
    public java.lang.Boolean getC003_Check_02__c() {
        return c003_Check_02__c;
    }


    /**
     * Sets the c003_Check_02__c value for this C003_Contract__c.
     * 
     * @param c003_Check_02__c
     */
    public void setC003_Check_02__c(java.lang.Boolean c003_Check_02__c) {
        this.c003_Check_02__c = c003_Check_02__c;
    }


    /**
     * Gets the c003_Check_03__c value for this C003_Contract__c.
     * 
     * @return c003_Check_03__c
     */
    public java.lang.Boolean getC003_Check_03__c() {
        return c003_Check_03__c;
    }


    /**
     * Sets the c003_Check_03__c value for this C003_Contract__c.
     * 
     * @param c003_Check_03__c
     */
    public void setC003_Check_03__c(java.lang.Boolean c003_Check_03__c) {
        this.c003_Check_03__c = c003_Check_03__c;
    }


    /**
     * Gets the c003_Check_04__c value for this C003_Contract__c.
     * 
     * @return c003_Check_04__c
     */
    public java.lang.Boolean getC003_Check_04__c() {
        return c003_Check_04__c;
    }


    /**
     * Sets the c003_Check_04__c value for this C003_Contract__c.
     * 
     * @param c003_Check_04__c
     */
    public void setC003_Check_04__c(java.lang.Boolean c003_Check_04__c) {
        this.c003_Check_04__c = c003_Check_04__c;
    }


    /**
     * Gets the c003_Check_05__c value for this C003_Contract__c.
     * 
     * @return c003_Check_05__c
     */
    public java.lang.Boolean getC003_Check_05__c() {
        return c003_Check_05__c;
    }


    /**
     * Sets the c003_Check_05__c value for this C003_Contract__c.
     * 
     * @param c003_Check_05__c
     */
    public void setC003_Check_05__c(java.lang.Boolean c003_Check_05__c) {
        this.c003_Check_05__c = c003_Check_05__c;
    }


    /**
     * Gets the c003_Check_06__c value for this C003_Contract__c.
     * 
     * @return c003_Check_06__c
     */
    public java.lang.Boolean getC003_Check_06__c() {
        return c003_Check_06__c;
    }


    /**
     * Sets the c003_Check_06__c value for this C003_Contract__c.
     * 
     * @param c003_Check_06__c
     */
    public void setC003_Check_06__c(java.lang.Boolean c003_Check_06__c) {
        this.c003_Check_06__c = c003_Check_06__c;
    }


    /**
     * Gets the c003_Check_07__c value for this C003_Contract__c.
     * 
     * @return c003_Check_07__c
     */
    public java.lang.Boolean getC003_Check_07__c() {
        return c003_Check_07__c;
    }


    /**
     * Sets the c003_Check_07__c value for this C003_Contract__c.
     * 
     * @param c003_Check_07__c
     */
    public void setC003_Check_07__c(java.lang.Boolean c003_Check_07__c) {
        this.c003_Check_07__c = c003_Check_07__c;
    }


    /**
     * Gets the c003_Check_08__c value for this C003_Contract__c.
     * 
     * @return c003_Check_08__c
     */
    public java.lang.Boolean getC003_Check_08__c() {
        return c003_Check_08__c;
    }


    /**
     * Sets the c003_Check_08__c value for this C003_Contract__c.
     * 
     * @param c003_Check_08__c
     */
    public void setC003_Check_08__c(java.lang.Boolean c003_Check_08__c) {
        this.c003_Check_08__c = c003_Check_08__c;
    }


    /**
     * Gets the c003_Check_09__c value for this C003_Contract__c.
     * 
     * @return c003_Check_09__c
     */
    public java.lang.Boolean getC003_Check_09__c() {
        return c003_Check_09__c;
    }


    /**
     * Sets the c003_Check_09__c value for this C003_Contract__c.
     * 
     * @param c003_Check_09__c
     */
    public void setC003_Check_09__c(java.lang.Boolean c003_Check_09__c) {
        this.c003_Check_09__c = c003_Check_09__c;
    }


    /**
     * Gets the c003_Check_10__c value for this C003_Contract__c.
     * 
     * @return c003_Check_10__c
     */
    public java.lang.Boolean getC003_Check_10__c() {
        return c003_Check_10__c;
    }


    /**
     * Sets the c003_Check_10__c value for this C003_Contract__c.
     * 
     * @param c003_Check_10__c
     */
    public void setC003_Check_10__c(java.lang.Boolean c003_Check_10__c) {
        this.c003_Check_10__c = c003_Check_10__c;
    }


    /**
     * Gets the c003_CommodityRef__c value for this C003_Contract__c.
     * 
     * @return c003_CommodityRef__c
     */
    public java.lang.String getC003_CommodityRef__c() {
        return c003_CommodityRef__c;
    }


    /**
     * Sets the c003_CommodityRef__c value for this C003_Contract__c.
     * 
     * @param c003_CommodityRef__c
     */
    public void setC003_CommodityRef__c(java.lang.String c003_CommodityRef__c) {
        this.c003_CommodityRef__c = c003_CommodityRef__c;
    }


    /**
     * Gets the c003_CommodityRef__r value for this C003_Contract__c.
     * 
     * @return c003_CommodityRef__r
     */
    public com.sforce.soap.enterprise.sobject.C003_Commodity__c getC003_CommodityRef__r() {
        return c003_CommodityRef__r;
    }


    /**
     * Sets the c003_CommodityRef__r value for this C003_Contract__c.
     * 
     * @param c003_CommodityRef__r
     */
    public void setC003_CommodityRef__r(com.sforce.soap.enterprise.sobject.C003_Commodity__c c003_CommodityRef__r) {
        this.c003_CommodityRef__r = c003_CommodityRef__r;
    }


    /**
     * Gets the c003_ContractId__c value for this C003_Contract__c.
     * 
     * @return c003_ContractId__c
     */
    public java.lang.String getC003_ContractId__c() {
        return c003_ContractId__c;
    }


    /**
     * Sets the c003_ContractId__c value for this C003_Contract__c.
     * 
     * @param c003_ContractId__c
     */
    public void setC003_ContractId__c(java.lang.String c003_ContractId__c) {
        this.c003_ContractId__c = c003_ContractId__c;
    }


    /**
     * Gets the c003_Contracts_01__r value for this C003_Contract__c.
     * 
     * @return c003_Contracts_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC003_Contracts_01__r() {
        return c003_Contracts_01__r;
    }


    /**
     * Sets the c003_Contracts_01__r value for this C003_Contract__c.
     * 
     * @param c003_Contracts_01__r
     */
    public void setC003_Contracts_01__r(com.sforce.soap.enterprise.QueryResult c003_Contracts_01__r) {
        this.c003_Contracts_01__r = c003_Contracts_01__r;
    }


    /**
     * Gets the c003_CsvLastModifiedDate__c value for this C003_Contract__c.
     * 
     * @return c003_CsvLastModifiedDate__c
     */
    public java.lang.String getC003_CsvLastModifiedDate__c() {
        return c003_CsvLastModifiedDate__c;
    }


    /**
     * Sets the c003_CsvLastModifiedDate__c value for this C003_Contract__c.
     * 
     * @param c003_CsvLastModifiedDate__c
     */
    public void setC003_CsvLastModifiedDate__c(java.lang.String c003_CsvLastModifiedDate__c) {
        this.c003_CsvLastModifiedDate__c = c003_CsvLastModifiedDate__c;
    }


    /**
     * Gets the c003_Date_01__c value for this C003_Contract__c.
     * 
     * @return c003_Date_01__c
     */
    public java.util.Date getC003_Date_01__c() {
        return c003_Date_01__c;
    }


    /**
     * Sets the c003_Date_01__c value for this C003_Contract__c.
     * 
     * @param c003_Date_01__c
     */
    public void setC003_Date_01__c(java.util.Date c003_Date_01__c) {
        this.c003_Date_01__c = c003_Date_01__c;
    }


    /**
     * Gets the c003_Date_02__c value for this C003_Contract__c.
     * 
     * @return c003_Date_02__c
     */
    public java.util.Date getC003_Date_02__c() {
        return c003_Date_02__c;
    }


    /**
     * Sets the c003_Date_02__c value for this C003_Contract__c.
     * 
     * @param c003_Date_02__c
     */
    public void setC003_Date_02__c(java.util.Date c003_Date_02__c) {
        this.c003_Date_02__c = c003_Date_02__c;
    }


    /**
     * Gets the c003_Date_03__c value for this C003_Contract__c.
     * 
     * @return c003_Date_03__c
     */
    public java.util.Date getC003_Date_03__c() {
        return c003_Date_03__c;
    }


    /**
     * Sets the c003_Date_03__c value for this C003_Contract__c.
     * 
     * @param c003_Date_03__c
     */
    public void setC003_Date_03__c(java.util.Date c003_Date_03__c) {
        this.c003_Date_03__c = c003_Date_03__c;
    }


    /**
     * Gets the c003_Date_04__c value for this C003_Contract__c.
     * 
     * @return c003_Date_04__c
     */
    public java.util.Date getC003_Date_04__c() {
        return c003_Date_04__c;
    }


    /**
     * Sets the c003_Date_04__c value for this C003_Contract__c.
     * 
     * @param c003_Date_04__c
     */
    public void setC003_Date_04__c(java.util.Date c003_Date_04__c) {
        this.c003_Date_04__c = c003_Date_04__c;
    }


    /**
     * Gets the c003_Date_05__c value for this C003_Contract__c.
     * 
     * @return c003_Date_05__c
     */
    public java.util.Date getC003_Date_05__c() {
        return c003_Date_05__c;
    }


    /**
     * Sets the c003_Date_05__c value for this C003_Contract__c.
     * 
     * @param c003_Date_05__c
     */
    public void setC003_Date_05__c(java.util.Date c003_Date_05__c) {
        this.c003_Date_05__c = c003_Date_05__c;
    }


    /**
     * Gets the c003_Date_06__c value for this C003_Contract__c.
     * 
     * @return c003_Date_06__c
     */
    public java.util.Date getC003_Date_06__c() {
        return c003_Date_06__c;
    }


    /**
     * Sets the c003_Date_06__c value for this C003_Contract__c.
     * 
     * @param c003_Date_06__c
     */
    public void setC003_Date_06__c(java.util.Date c003_Date_06__c) {
        this.c003_Date_06__c = c003_Date_06__c;
    }


    /**
     * Gets the c003_Date_07__c value for this C003_Contract__c.
     * 
     * @return c003_Date_07__c
     */
    public java.util.Date getC003_Date_07__c() {
        return c003_Date_07__c;
    }


    /**
     * Sets the c003_Date_07__c value for this C003_Contract__c.
     * 
     * @param c003_Date_07__c
     */
    public void setC003_Date_07__c(java.util.Date c003_Date_07__c) {
        this.c003_Date_07__c = c003_Date_07__c;
    }


    /**
     * Gets the c003_Date_08__c value for this C003_Contract__c.
     * 
     * @return c003_Date_08__c
     */
    public java.util.Date getC003_Date_08__c() {
        return c003_Date_08__c;
    }


    /**
     * Sets the c003_Date_08__c value for this C003_Contract__c.
     * 
     * @param c003_Date_08__c
     */
    public void setC003_Date_08__c(java.util.Date c003_Date_08__c) {
        this.c003_Date_08__c = c003_Date_08__c;
    }


    /**
     * Gets the c003_Date_09__c value for this C003_Contract__c.
     * 
     * @return c003_Date_09__c
     */
    public java.util.Date getC003_Date_09__c() {
        return c003_Date_09__c;
    }


    /**
     * Sets the c003_Date_09__c value for this C003_Contract__c.
     * 
     * @param c003_Date_09__c
     */
    public void setC003_Date_09__c(java.util.Date c003_Date_09__c) {
        this.c003_Date_09__c = c003_Date_09__c;
    }


    /**
     * Gets the c003_Date_10__c value for this C003_Contract__c.
     * 
     * @return c003_Date_10__c
     */
    public java.util.Date getC003_Date_10__c() {
        return c003_Date_10__c;
    }


    /**
     * Sets the c003_Date_10__c value for this C003_Contract__c.
     * 
     * @param c003_Date_10__c
     */
    public void setC003_Date_10__c(java.util.Date c003_Date_10__c) {
        this.c003_Date_10__c = c003_Date_10__c;
    }


    /**
     * Gets the c003_Date__c value for this C003_Contract__c.
     * 
     * @return c003_Date__c
     */
    public java.util.Date getC003_Date__c() {
        return c003_Date__c;
    }


    /**
     * Sets the c003_Date__c value for this C003_Contract__c.
     * 
     * @param c003_Date__c
     */
    public void setC003_Date__c(java.util.Date c003_Date__c) {
        this.c003_Date__c = c003_Date__c;
    }


    /**
     * Gets the c003_EndDate__c value for this C003_Contract__c.
     * 
     * @return c003_EndDate__c
     */
    public java.util.Date getC003_EndDate__c() {
        return c003_EndDate__c;
    }


    /**
     * Sets the c003_EndDate__c value for this C003_Contract__c.
     * 
     * @param c003_EndDate__c
     */
    public void setC003_EndDate__c(java.util.Date c003_EndDate__c) {
        this.c003_EndDate__c = c003_EndDate__c;
    }


    /**
     * Gets the c003_List_01__c value for this C003_Contract__c.
     * 
     * @return c003_List_01__c
     */
    public java.lang.String getC003_List_01__c() {
        return c003_List_01__c;
    }


    /**
     * Sets the c003_List_01__c value for this C003_Contract__c.
     * 
     * @param c003_List_01__c
     */
    public void setC003_List_01__c(java.lang.String c003_List_01__c) {
        this.c003_List_01__c = c003_List_01__c;
    }


    /**
     * Gets the c003_List_02__c value for this C003_Contract__c.
     * 
     * @return c003_List_02__c
     */
    public java.lang.String getC003_List_02__c() {
        return c003_List_02__c;
    }


    /**
     * Sets the c003_List_02__c value for this C003_Contract__c.
     * 
     * @param c003_List_02__c
     */
    public void setC003_List_02__c(java.lang.String c003_List_02__c) {
        this.c003_List_02__c = c003_List_02__c;
    }


    /**
     * Gets the c003_List_03__c value for this C003_Contract__c.
     * 
     * @return c003_List_03__c
     */
    public java.lang.String getC003_List_03__c() {
        return c003_List_03__c;
    }


    /**
     * Sets the c003_List_03__c value for this C003_Contract__c.
     * 
     * @param c003_List_03__c
     */
    public void setC003_List_03__c(java.lang.String c003_List_03__c) {
        this.c003_List_03__c = c003_List_03__c;
    }


    /**
     * Gets the c003_List_04__c value for this C003_Contract__c.
     * 
     * @return c003_List_04__c
     */
    public java.lang.String getC003_List_04__c() {
        return c003_List_04__c;
    }


    /**
     * Sets the c003_List_04__c value for this C003_Contract__c.
     * 
     * @param c003_List_04__c
     */
    public void setC003_List_04__c(java.lang.String c003_List_04__c) {
        this.c003_List_04__c = c003_List_04__c;
    }


    /**
     * Gets the c003_List_05__c value for this C003_Contract__c.
     * 
     * @return c003_List_05__c
     */
    public java.lang.String getC003_List_05__c() {
        return c003_List_05__c;
    }


    /**
     * Sets the c003_List_05__c value for this C003_Contract__c.
     * 
     * @param c003_List_05__c
     */
    public void setC003_List_05__c(java.lang.String c003_List_05__c) {
        this.c003_List_05__c = c003_List_05__c;
    }


    /**
     * Gets the c003_List_06__c value for this C003_Contract__c.
     * 
     * @return c003_List_06__c
     */
    public java.lang.String getC003_List_06__c() {
        return c003_List_06__c;
    }


    /**
     * Sets the c003_List_06__c value for this C003_Contract__c.
     * 
     * @param c003_List_06__c
     */
    public void setC003_List_06__c(java.lang.String c003_List_06__c) {
        this.c003_List_06__c = c003_List_06__c;
    }


    /**
     * Gets the c003_List_07__c value for this C003_Contract__c.
     * 
     * @return c003_List_07__c
     */
    public java.lang.String getC003_List_07__c() {
        return c003_List_07__c;
    }


    /**
     * Sets the c003_List_07__c value for this C003_Contract__c.
     * 
     * @param c003_List_07__c
     */
    public void setC003_List_07__c(java.lang.String c003_List_07__c) {
        this.c003_List_07__c = c003_List_07__c;
    }


    /**
     * Gets the c003_List_08__c value for this C003_Contract__c.
     * 
     * @return c003_List_08__c
     */
    public java.lang.String getC003_List_08__c() {
        return c003_List_08__c;
    }


    /**
     * Sets the c003_List_08__c value for this C003_Contract__c.
     * 
     * @param c003_List_08__c
     */
    public void setC003_List_08__c(java.lang.String c003_List_08__c) {
        this.c003_List_08__c = c003_List_08__c;
    }


    /**
     * Gets the c003_List_09__c value for this C003_Contract__c.
     * 
     * @return c003_List_09__c
     */
    public java.lang.String getC003_List_09__c() {
        return c003_List_09__c;
    }


    /**
     * Sets the c003_List_09__c value for this C003_Contract__c.
     * 
     * @param c003_List_09__c
     */
    public void setC003_List_09__c(java.lang.String c003_List_09__c) {
        this.c003_List_09__c = c003_List_09__c;
    }


    /**
     * Gets the c003_List_10__c value for this C003_Contract__c.
     * 
     * @return c003_List_10__c
     */
    public java.lang.String getC003_List_10__c() {
        return c003_List_10__c;
    }


    /**
     * Sets the c003_List_10__c value for this C003_Contract__c.
     * 
     * @param c003_List_10__c
     */
    public void setC003_List_10__c(java.lang.String c003_List_10__c) {
        this.c003_List_10__c = c003_List_10__c;
    }


    /**
     * Gets the c003_Note__c value for this C003_Contract__c.
     * 
     * @return c003_Note__c
     */
    public java.lang.String getC003_Note__c() {
        return c003_Note__c;
    }


    /**
     * Sets the c003_Note__c value for this C003_Contract__c.
     * 
     * @param c003_Note__c
     */
    public void setC003_Note__c(java.lang.String c003_Note__c) {
        this.c003_Note__c = c003_Note__c;
    }


    /**
     * Gets the c003_Number_01__c value for this C003_Contract__c.
     * 
     * @return c003_Number_01__c
     */
    public java.lang.Double getC003_Number_01__c() {
        return c003_Number_01__c;
    }


    /**
     * Sets the c003_Number_01__c value for this C003_Contract__c.
     * 
     * @param c003_Number_01__c
     */
    public void setC003_Number_01__c(java.lang.Double c003_Number_01__c) {
        this.c003_Number_01__c = c003_Number_01__c;
    }


    /**
     * Gets the c003_Number_02__c value for this C003_Contract__c.
     * 
     * @return c003_Number_02__c
     */
    public java.lang.Double getC003_Number_02__c() {
        return c003_Number_02__c;
    }


    /**
     * Sets the c003_Number_02__c value for this C003_Contract__c.
     * 
     * @param c003_Number_02__c
     */
    public void setC003_Number_02__c(java.lang.Double c003_Number_02__c) {
        this.c003_Number_02__c = c003_Number_02__c;
    }


    /**
     * Gets the c003_Number_03__c value for this C003_Contract__c.
     * 
     * @return c003_Number_03__c
     */
    public java.lang.Double getC003_Number_03__c() {
        return c003_Number_03__c;
    }


    /**
     * Sets the c003_Number_03__c value for this C003_Contract__c.
     * 
     * @param c003_Number_03__c
     */
    public void setC003_Number_03__c(java.lang.Double c003_Number_03__c) {
        this.c003_Number_03__c = c003_Number_03__c;
    }


    /**
     * Gets the c003_Number_04__c value for this C003_Contract__c.
     * 
     * @return c003_Number_04__c
     */
    public java.lang.Double getC003_Number_04__c() {
        return c003_Number_04__c;
    }


    /**
     * Sets the c003_Number_04__c value for this C003_Contract__c.
     * 
     * @param c003_Number_04__c
     */
    public void setC003_Number_04__c(java.lang.Double c003_Number_04__c) {
        this.c003_Number_04__c = c003_Number_04__c;
    }


    /**
     * Gets the c003_Number_05__c value for this C003_Contract__c.
     * 
     * @return c003_Number_05__c
     */
    public java.lang.Double getC003_Number_05__c() {
        return c003_Number_05__c;
    }


    /**
     * Sets the c003_Number_05__c value for this C003_Contract__c.
     * 
     * @param c003_Number_05__c
     */
    public void setC003_Number_05__c(java.lang.Double c003_Number_05__c) {
        this.c003_Number_05__c = c003_Number_05__c;
    }


    /**
     * Gets the c003_Number_06__c value for this C003_Contract__c.
     * 
     * @return c003_Number_06__c
     */
    public java.lang.Double getC003_Number_06__c() {
        return c003_Number_06__c;
    }


    /**
     * Sets the c003_Number_06__c value for this C003_Contract__c.
     * 
     * @param c003_Number_06__c
     */
    public void setC003_Number_06__c(java.lang.Double c003_Number_06__c) {
        this.c003_Number_06__c = c003_Number_06__c;
    }


    /**
     * Gets the c003_Number_07__c value for this C003_Contract__c.
     * 
     * @return c003_Number_07__c
     */
    public java.lang.Double getC003_Number_07__c() {
        return c003_Number_07__c;
    }


    /**
     * Sets the c003_Number_07__c value for this C003_Contract__c.
     * 
     * @param c003_Number_07__c
     */
    public void setC003_Number_07__c(java.lang.Double c003_Number_07__c) {
        this.c003_Number_07__c = c003_Number_07__c;
    }


    /**
     * Gets the c003_Number_08__c value for this C003_Contract__c.
     * 
     * @return c003_Number_08__c
     */
    public java.lang.Double getC003_Number_08__c() {
        return c003_Number_08__c;
    }


    /**
     * Sets the c003_Number_08__c value for this C003_Contract__c.
     * 
     * @param c003_Number_08__c
     */
    public void setC003_Number_08__c(java.lang.Double c003_Number_08__c) {
        this.c003_Number_08__c = c003_Number_08__c;
    }


    /**
     * Gets the c003_Number_09__c value for this C003_Contract__c.
     * 
     * @return c003_Number_09__c
     */
    public java.lang.Double getC003_Number_09__c() {
        return c003_Number_09__c;
    }


    /**
     * Sets the c003_Number_09__c value for this C003_Contract__c.
     * 
     * @param c003_Number_09__c
     */
    public void setC003_Number_09__c(java.lang.Double c003_Number_09__c) {
        this.c003_Number_09__c = c003_Number_09__c;
    }


    /**
     * Gets the c003_Number_10__c value for this C003_Contract__c.
     * 
     * @return c003_Number_10__c
     */
    public java.lang.Double getC003_Number_10__c() {
        return c003_Number_10__c;
    }


    /**
     * Sets the c003_Number_10__c value for this C003_Contract__c.
     * 
     * @param c003_Number_10__c
     */
    public void setC003_Number_10__c(java.lang.Double c003_Number_10__c) {
        this.c003_Number_10__c = c003_Number_10__c;
    }


    /**
     * Gets the c003_StartDate__c value for this C003_Contract__c.
     * 
     * @return c003_StartDate__c
     */
    public java.util.Date getC003_StartDate__c() {
        return c003_StartDate__c;
    }


    /**
     * Sets the c003_StartDate__c value for this C003_Contract__c.
     * 
     * @param c003_StartDate__c
     */
    public void setC003_StartDate__c(java.util.Date c003_StartDate__c) {
        this.c003_StartDate__c = c003_StartDate__c;
    }


    /**
     * Gets the c003_Status__c value for this C003_Contract__c.
     * 
     * @return c003_Status__c
     */
    public java.lang.String getC003_Status__c() {
        return c003_Status__c;
    }


    /**
     * Sets the c003_Status__c value for this C003_Contract__c.
     * 
     * @param c003_Status__c
     */
    public void setC003_Status__c(java.lang.String c003_Status__c) {
        this.c003_Status__c = c003_Status__c;
    }


    /**
     * Gets the c003_TembanKokyakubangou__c value for this C003_Contract__c.
     * 
     * @return c003_TembanKokyakubangou__c
     */
    public java.lang.String getC003_TembanKokyakubangou__c() {
        return c003_TembanKokyakubangou__c;
    }


    /**
     * Sets the c003_TembanKokyakubangou__c value for this C003_Contract__c.
     * 
     * @param c003_TembanKokyakubangou__c
     */
    public void setC003_TembanKokyakubangou__c(java.lang.String c003_TembanKokyakubangou__c) {
        this.c003_TembanKokyakubangou__c = c003_TembanKokyakubangou__c;
    }


    /**
     * Gets the c003_Text_01__c value for this C003_Contract__c.
     * 
     * @return c003_Text_01__c
     */
    public java.lang.String getC003_Text_01__c() {
        return c003_Text_01__c;
    }


    /**
     * Sets the c003_Text_01__c value for this C003_Contract__c.
     * 
     * @param c003_Text_01__c
     */
    public void setC003_Text_01__c(java.lang.String c003_Text_01__c) {
        this.c003_Text_01__c = c003_Text_01__c;
    }


    /**
     * Gets the c003_Text_02__c value for this C003_Contract__c.
     * 
     * @return c003_Text_02__c
     */
    public java.lang.String getC003_Text_02__c() {
        return c003_Text_02__c;
    }


    /**
     * Sets the c003_Text_02__c value for this C003_Contract__c.
     * 
     * @param c003_Text_02__c
     */
    public void setC003_Text_02__c(java.lang.String c003_Text_02__c) {
        this.c003_Text_02__c = c003_Text_02__c;
    }


    /**
     * Gets the c003_Text_03__c value for this C003_Contract__c.
     * 
     * @return c003_Text_03__c
     */
    public java.lang.String getC003_Text_03__c() {
        return c003_Text_03__c;
    }


    /**
     * Sets the c003_Text_03__c value for this C003_Contract__c.
     * 
     * @param c003_Text_03__c
     */
    public void setC003_Text_03__c(java.lang.String c003_Text_03__c) {
        this.c003_Text_03__c = c003_Text_03__c;
    }


    /**
     * Gets the c003_Text_04__c value for this C003_Contract__c.
     * 
     * @return c003_Text_04__c
     */
    public java.lang.String getC003_Text_04__c() {
        return c003_Text_04__c;
    }


    /**
     * Sets the c003_Text_04__c value for this C003_Contract__c.
     * 
     * @param c003_Text_04__c
     */
    public void setC003_Text_04__c(java.lang.String c003_Text_04__c) {
        this.c003_Text_04__c = c003_Text_04__c;
    }


    /**
     * Gets the c003_Text_05__c value for this C003_Contract__c.
     * 
     * @return c003_Text_05__c
     */
    public java.lang.String getC003_Text_05__c() {
        return c003_Text_05__c;
    }


    /**
     * Sets the c003_Text_05__c value for this C003_Contract__c.
     * 
     * @param c003_Text_05__c
     */
    public void setC003_Text_05__c(java.lang.String c003_Text_05__c) {
        this.c003_Text_05__c = c003_Text_05__c;
    }


    /**
     * Gets the c003_Text_06__c value for this C003_Contract__c.
     * 
     * @return c003_Text_06__c
     */
    public java.lang.String getC003_Text_06__c() {
        return c003_Text_06__c;
    }


    /**
     * Sets the c003_Text_06__c value for this C003_Contract__c.
     * 
     * @param c003_Text_06__c
     */
    public void setC003_Text_06__c(java.lang.String c003_Text_06__c) {
        this.c003_Text_06__c = c003_Text_06__c;
    }


    /**
     * Gets the c003_Text_07__c value for this C003_Contract__c.
     * 
     * @return c003_Text_07__c
     */
    public java.lang.String getC003_Text_07__c() {
        return c003_Text_07__c;
    }


    /**
     * Sets the c003_Text_07__c value for this C003_Contract__c.
     * 
     * @param c003_Text_07__c
     */
    public void setC003_Text_07__c(java.lang.String c003_Text_07__c) {
        this.c003_Text_07__c = c003_Text_07__c;
    }


    /**
     * Gets the c003_Text_08__c value for this C003_Contract__c.
     * 
     * @return c003_Text_08__c
     */
    public java.lang.String getC003_Text_08__c() {
        return c003_Text_08__c;
    }


    /**
     * Sets the c003_Text_08__c value for this C003_Contract__c.
     * 
     * @param c003_Text_08__c
     */
    public void setC003_Text_08__c(java.lang.String c003_Text_08__c) {
        this.c003_Text_08__c = c003_Text_08__c;
    }


    /**
     * Gets the c003_Text_09__c value for this C003_Contract__c.
     * 
     * @return c003_Text_09__c
     */
    public java.lang.String getC003_Text_09__c() {
        return c003_Text_09__c;
    }


    /**
     * Sets the c003_Text_09__c value for this C003_Contract__c.
     * 
     * @param c003_Text_09__c
     */
    public void setC003_Text_09__c(java.lang.String c003_Text_09__c) {
        this.c003_Text_09__c = c003_Text_09__c;
    }


    /**
     * Gets the c003_Text_10__c value for this C003_Contract__c.
     * 
     * @return c003_Text_10__c
     */
    public java.lang.String getC003_Text_10__c() {
        return c003_Text_10__c;
    }


    /**
     * Sets the c003_Text_10__c value for this C003_Contract__c.
     * 
     * @param c003_Text_10__c
     */
    public void setC003_Text_10__c(java.lang.String c003_Text_10__c) {
        this.c003_Text_10__c = c003_Text_10__c;
    }


    /**
     * Gets the c003_YomikomiNo__c value for this C003_Contract__c.
     * 
     * @return c003_YomikomiNo__c
     */
    public java.lang.String getC003_YomikomiNo__c() {
        return c003_YomikomiNo__c;
    }


    /**
     * Sets the c003_YomikomiNo__c value for this C003_Contract__c.
     * 
     * @param c003_YomikomiNo__c
     */
    public void setC003_YomikomiNo__c(java.lang.String c003_YomikomiNo__c) {
        this.c003_YomikomiNo__c = c003_YomikomiNo__c;
    }


    /**
     * Gets the combinedAttachments value for this C003_Contract__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C003_Contract__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C003_Contract__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C003_Contract__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C003_Contract__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C003_Contract__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C003_Contract__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C003_Contract__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the duplicateRecordItems value for this C003_Contract__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C003_Contract__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the histories value for this C003_Contract__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this C003_Contract__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this C003_Contract__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C003_Contract__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the lastModifiedBy value for this C003_Contract__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C003_Contract__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C003_Contract__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C003_Contract__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C003_Contract__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C003_Contract__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lastReferencedDate value for this C003_Contract__c.
     * 
     * @return lastReferencedDate
     */
    public java.util.Calendar getLastReferencedDate() {
        return lastReferencedDate;
    }


    /**
     * Sets the lastReferencedDate value for this C003_Contract__c.
     * 
     * @param lastReferencedDate
     */
    public void setLastReferencedDate(java.util.Calendar lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }


    /**
     * Gets the lastViewedDate value for this C003_Contract__c.
     * 
     * @return lastViewedDate
     */
    public java.util.Calendar getLastViewedDate() {
        return lastViewedDate;
    }


    /**
     * Sets the lastViewedDate value for this C003_Contract__c.
     * 
     * @param lastViewedDate
     */
    public void setLastViewedDate(java.util.Calendar lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C003_Contract__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C003_Contract__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this C003_Contract__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C003_Contract__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C003_Contract__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C003_Contract__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C003_Contract__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C003_Contract__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the processInstances value for this C003_Contract__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C003_Contract__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C003_Contract__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C003_Contract__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the systemModstamp value for this C003_Contract__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C003_Contract__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the topicAssignments value for this C003_Contract__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C003_Contract__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this C003_Contract__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C003_Contract__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C003_Contract__c)) return false;
        C003_Contract__c other = (C003_Contract__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.a020_Contracts_01__r==null && other.getA020_Contracts_01__r()==null) || 
             (this.a020_Contracts_01__r!=null &&
              this.a020_Contracts_01__r.equals(other.getA020_Contracts_01__r()))) &&
            ((this.a020_Contracts_03__r==null && other.getA020_Contracts_03__r()==null) || 
             (this.a020_Contracts_03__r!=null &&
              this.a020_Contracts_03__r.equals(other.getA020_Contracts_03__r()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.c003_AccountNo__c==null && other.getC003_AccountNo__c()==null) || 
             (this.c003_AccountNo__c!=null &&
              this.c003_AccountNo__c.equals(other.getC003_AccountNo__c()))) &&
            ((this.c003_AccountRef__c==null && other.getC003_AccountRef__c()==null) || 
             (this.c003_AccountRef__c!=null &&
              this.c003_AccountRef__c.equals(other.getC003_AccountRef__c()))) &&
            ((this.c003_AccountRef__r==null && other.getC003_AccountRef__r()==null) || 
             (this.c003_AccountRef__r!=null &&
              this.c003_AccountRef__r.equals(other.getC003_AccountRef__r()))) &&
            ((this.c003_AccountTemban__c==null && other.getC003_AccountTemban__c()==null) || 
             (this.c003_AccountTemban__c!=null &&
              this.c003_AccountTemban__c.equals(other.getC003_AccountTemban__c()))) &&
            ((this.c003_AccountType__c==null && other.getC003_AccountType__c()==null) || 
             (this.c003_AccountType__c!=null &&
              this.c003_AccountType__c.equals(other.getC003_AccountType__c()))) &&
            ((this.c003_Amount__c==null && other.getC003_Amount__c()==null) || 
             (this.c003_Amount__c!=null &&
              this.c003_Amount__c.equals(other.getC003_Amount__c()))) &&
            ((this.c003_Area_01__c==null && other.getC003_Area_01__c()==null) || 
             (this.c003_Area_01__c!=null &&
              this.c003_Area_01__c.equals(other.getC003_Area_01__c()))) &&
            ((this.c003_Area_02__c==null && other.getC003_Area_02__c()==null) || 
             (this.c003_Area_02__c!=null &&
              this.c003_Area_02__c.equals(other.getC003_Area_02__c()))) &&
            ((this.c003_Area_03__c==null && other.getC003_Area_03__c()==null) || 
             (this.c003_Area_03__c!=null &&
              this.c003_Area_03__c.equals(other.getC003_Area_03__c()))) &&
            ((this.c003_Area_04__c==null && other.getC003_Area_04__c()==null) || 
             (this.c003_Area_04__c!=null &&
              this.c003_Area_04__c.equals(other.getC003_Area_04__c()))) &&
            ((this.c003_Area_05__c==null && other.getC003_Area_05__c()==null) || 
             (this.c003_Area_05__c!=null &&
              this.c003_Area_05__c.equals(other.getC003_Area_05__c()))) &&
            ((this.c003_Area_06__c==null && other.getC003_Area_06__c()==null) || 
             (this.c003_Area_06__c!=null &&
              this.c003_Area_06__c.equals(other.getC003_Area_06__c()))) &&
            ((this.c003_Area_07__c==null && other.getC003_Area_07__c()==null) || 
             (this.c003_Area_07__c!=null &&
              this.c003_Area_07__c.equals(other.getC003_Area_07__c()))) &&
            ((this.c003_Area_08__c==null && other.getC003_Area_08__c()==null) || 
             (this.c003_Area_08__c!=null &&
              this.c003_Area_08__c.equals(other.getC003_Area_08__c()))) &&
            ((this.c003_Area_09__c==null && other.getC003_Area_09__c()==null) || 
             (this.c003_Area_09__c!=null &&
              this.c003_Area_09__c.equals(other.getC003_Area_09__c()))) &&
            ((this.c003_Area_10__c==null && other.getC003_Area_10__c()==null) || 
             (this.c003_Area_10__c!=null &&
              this.c003_Area_10__c.equals(other.getC003_Area_10__c()))) &&
            ((this.c003_Check_01__c==null && other.getC003_Check_01__c()==null) || 
             (this.c003_Check_01__c!=null &&
              this.c003_Check_01__c.equals(other.getC003_Check_01__c()))) &&
            ((this.c003_Check_02__c==null && other.getC003_Check_02__c()==null) || 
             (this.c003_Check_02__c!=null &&
              this.c003_Check_02__c.equals(other.getC003_Check_02__c()))) &&
            ((this.c003_Check_03__c==null && other.getC003_Check_03__c()==null) || 
             (this.c003_Check_03__c!=null &&
              this.c003_Check_03__c.equals(other.getC003_Check_03__c()))) &&
            ((this.c003_Check_04__c==null && other.getC003_Check_04__c()==null) || 
             (this.c003_Check_04__c!=null &&
              this.c003_Check_04__c.equals(other.getC003_Check_04__c()))) &&
            ((this.c003_Check_05__c==null && other.getC003_Check_05__c()==null) || 
             (this.c003_Check_05__c!=null &&
              this.c003_Check_05__c.equals(other.getC003_Check_05__c()))) &&
            ((this.c003_Check_06__c==null && other.getC003_Check_06__c()==null) || 
             (this.c003_Check_06__c!=null &&
              this.c003_Check_06__c.equals(other.getC003_Check_06__c()))) &&
            ((this.c003_Check_07__c==null && other.getC003_Check_07__c()==null) || 
             (this.c003_Check_07__c!=null &&
              this.c003_Check_07__c.equals(other.getC003_Check_07__c()))) &&
            ((this.c003_Check_08__c==null && other.getC003_Check_08__c()==null) || 
             (this.c003_Check_08__c!=null &&
              this.c003_Check_08__c.equals(other.getC003_Check_08__c()))) &&
            ((this.c003_Check_09__c==null && other.getC003_Check_09__c()==null) || 
             (this.c003_Check_09__c!=null &&
              this.c003_Check_09__c.equals(other.getC003_Check_09__c()))) &&
            ((this.c003_Check_10__c==null && other.getC003_Check_10__c()==null) || 
             (this.c003_Check_10__c!=null &&
              this.c003_Check_10__c.equals(other.getC003_Check_10__c()))) &&
            ((this.c003_CommodityRef__c==null && other.getC003_CommodityRef__c()==null) || 
             (this.c003_CommodityRef__c!=null &&
              this.c003_CommodityRef__c.equals(other.getC003_CommodityRef__c()))) &&
            ((this.c003_CommodityRef__r==null && other.getC003_CommodityRef__r()==null) || 
             (this.c003_CommodityRef__r!=null &&
              this.c003_CommodityRef__r.equals(other.getC003_CommodityRef__r()))) &&
            ((this.c003_ContractId__c==null && other.getC003_ContractId__c()==null) || 
             (this.c003_ContractId__c!=null &&
              this.c003_ContractId__c.equals(other.getC003_ContractId__c()))) &&
            ((this.c003_Contracts_01__r==null && other.getC003_Contracts_01__r()==null) || 
             (this.c003_Contracts_01__r!=null &&
              this.c003_Contracts_01__r.equals(other.getC003_Contracts_01__r()))) &&
            ((this.c003_CsvLastModifiedDate__c==null && other.getC003_CsvLastModifiedDate__c()==null) || 
             (this.c003_CsvLastModifiedDate__c!=null &&
              this.c003_CsvLastModifiedDate__c.equals(other.getC003_CsvLastModifiedDate__c()))) &&
            ((this.c003_Date_01__c==null && other.getC003_Date_01__c()==null) || 
             (this.c003_Date_01__c!=null &&
              this.c003_Date_01__c.equals(other.getC003_Date_01__c()))) &&
            ((this.c003_Date_02__c==null && other.getC003_Date_02__c()==null) || 
             (this.c003_Date_02__c!=null &&
              this.c003_Date_02__c.equals(other.getC003_Date_02__c()))) &&
            ((this.c003_Date_03__c==null && other.getC003_Date_03__c()==null) || 
             (this.c003_Date_03__c!=null &&
              this.c003_Date_03__c.equals(other.getC003_Date_03__c()))) &&
            ((this.c003_Date_04__c==null && other.getC003_Date_04__c()==null) || 
             (this.c003_Date_04__c!=null &&
              this.c003_Date_04__c.equals(other.getC003_Date_04__c()))) &&
            ((this.c003_Date_05__c==null && other.getC003_Date_05__c()==null) || 
             (this.c003_Date_05__c!=null &&
              this.c003_Date_05__c.equals(other.getC003_Date_05__c()))) &&
            ((this.c003_Date_06__c==null && other.getC003_Date_06__c()==null) || 
             (this.c003_Date_06__c!=null &&
              this.c003_Date_06__c.equals(other.getC003_Date_06__c()))) &&
            ((this.c003_Date_07__c==null && other.getC003_Date_07__c()==null) || 
             (this.c003_Date_07__c!=null &&
              this.c003_Date_07__c.equals(other.getC003_Date_07__c()))) &&
            ((this.c003_Date_08__c==null && other.getC003_Date_08__c()==null) || 
             (this.c003_Date_08__c!=null &&
              this.c003_Date_08__c.equals(other.getC003_Date_08__c()))) &&
            ((this.c003_Date_09__c==null && other.getC003_Date_09__c()==null) || 
             (this.c003_Date_09__c!=null &&
              this.c003_Date_09__c.equals(other.getC003_Date_09__c()))) &&
            ((this.c003_Date_10__c==null && other.getC003_Date_10__c()==null) || 
             (this.c003_Date_10__c!=null &&
              this.c003_Date_10__c.equals(other.getC003_Date_10__c()))) &&
            ((this.c003_Date__c==null && other.getC003_Date__c()==null) || 
             (this.c003_Date__c!=null &&
              this.c003_Date__c.equals(other.getC003_Date__c()))) &&
            ((this.c003_EndDate__c==null && other.getC003_EndDate__c()==null) || 
             (this.c003_EndDate__c!=null &&
              this.c003_EndDate__c.equals(other.getC003_EndDate__c()))) &&
            ((this.c003_List_01__c==null && other.getC003_List_01__c()==null) || 
             (this.c003_List_01__c!=null &&
              this.c003_List_01__c.equals(other.getC003_List_01__c()))) &&
            ((this.c003_List_02__c==null && other.getC003_List_02__c()==null) || 
             (this.c003_List_02__c!=null &&
              this.c003_List_02__c.equals(other.getC003_List_02__c()))) &&
            ((this.c003_List_03__c==null && other.getC003_List_03__c()==null) || 
             (this.c003_List_03__c!=null &&
              this.c003_List_03__c.equals(other.getC003_List_03__c()))) &&
            ((this.c003_List_04__c==null && other.getC003_List_04__c()==null) || 
             (this.c003_List_04__c!=null &&
              this.c003_List_04__c.equals(other.getC003_List_04__c()))) &&
            ((this.c003_List_05__c==null && other.getC003_List_05__c()==null) || 
             (this.c003_List_05__c!=null &&
              this.c003_List_05__c.equals(other.getC003_List_05__c()))) &&
            ((this.c003_List_06__c==null && other.getC003_List_06__c()==null) || 
             (this.c003_List_06__c!=null &&
              this.c003_List_06__c.equals(other.getC003_List_06__c()))) &&
            ((this.c003_List_07__c==null && other.getC003_List_07__c()==null) || 
             (this.c003_List_07__c!=null &&
              this.c003_List_07__c.equals(other.getC003_List_07__c()))) &&
            ((this.c003_List_08__c==null && other.getC003_List_08__c()==null) || 
             (this.c003_List_08__c!=null &&
              this.c003_List_08__c.equals(other.getC003_List_08__c()))) &&
            ((this.c003_List_09__c==null && other.getC003_List_09__c()==null) || 
             (this.c003_List_09__c!=null &&
              this.c003_List_09__c.equals(other.getC003_List_09__c()))) &&
            ((this.c003_List_10__c==null && other.getC003_List_10__c()==null) || 
             (this.c003_List_10__c!=null &&
              this.c003_List_10__c.equals(other.getC003_List_10__c()))) &&
            ((this.c003_Note__c==null && other.getC003_Note__c()==null) || 
             (this.c003_Note__c!=null &&
              this.c003_Note__c.equals(other.getC003_Note__c()))) &&
            ((this.c003_Number_01__c==null && other.getC003_Number_01__c()==null) || 
             (this.c003_Number_01__c!=null &&
              this.c003_Number_01__c.equals(other.getC003_Number_01__c()))) &&
            ((this.c003_Number_02__c==null && other.getC003_Number_02__c()==null) || 
             (this.c003_Number_02__c!=null &&
              this.c003_Number_02__c.equals(other.getC003_Number_02__c()))) &&
            ((this.c003_Number_03__c==null && other.getC003_Number_03__c()==null) || 
             (this.c003_Number_03__c!=null &&
              this.c003_Number_03__c.equals(other.getC003_Number_03__c()))) &&
            ((this.c003_Number_04__c==null && other.getC003_Number_04__c()==null) || 
             (this.c003_Number_04__c!=null &&
              this.c003_Number_04__c.equals(other.getC003_Number_04__c()))) &&
            ((this.c003_Number_05__c==null && other.getC003_Number_05__c()==null) || 
             (this.c003_Number_05__c!=null &&
              this.c003_Number_05__c.equals(other.getC003_Number_05__c()))) &&
            ((this.c003_Number_06__c==null && other.getC003_Number_06__c()==null) || 
             (this.c003_Number_06__c!=null &&
              this.c003_Number_06__c.equals(other.getC003_Number_06__c()))) &&
            ((this.c003_Number_07__c==null && other.getC003_Number_07__c()==null) || 
             (this.c003_Number_07__c!=null &&
              this.c003_Number_07__c.equals(other.getC003_Number_07__c()))) &&
            ((this.c003_Number_08__c==null && other.getC003_Number_08__c()==null) || 
             (this.c003_Number_08__c!=null &&
              this.c003_Number_08__c.equals(other.getC003_Number_08__c()))) &&
            ((this.c003_Number_09__c==null && other.getC003_Number_09__c()==null) || 
             (this.c003_Number_09__c!=null &&
              this.c003_Number_09__c.equals(other.getC003_Number_09__c()))) &&
            ((this.c003_Number_10__c==null && other.getC003_Number_10__c()==null) || 
             (this.c003_Number_10__c!=null &&
              this.c003_Number_10__c.equals(other.getC003_Number_10__c()))) &&
            ((this.c003_StartDate__c==null && other.getC003_StartDate__c()==null) || 
             (this.c003_StartDate__c!=null &&
              this.c003_StartDate__c.equals(other.getC003_StartDate__c()))) &&
            ((this.c003_Status__c==null && other.getC003_Status__c()==null) || 
             (this.c003_Status__c!=null &&
              this.c003_Status__c.equals(other.getC003_Status__c()))) &&
            ((this.c003_TembanKokyakubangou__c==null && other.getC003_TembanKokyakubangou__c()==null) || 
             (this.c003_TembanKokyakubangou__c!=null &&
              this.c003_TembanKokyakubangou__c.equals(other.getC003_TembanKokyakubangou__c()))) &&
            ((this.c003_Text_01__c==null && other.getC003_Text_01__c()==null) || 
             (this.c003_Text_01__c!=null &&
              this.c003_Text_01__c.equals(other.getC003_Text_01__c()))) &&
            ((this.c003_Text_02__c==null && other.getC003_Text_02__c()==null) || 
             (this.c003_Text_02__c!=null &&
              this.c003_Text_02__c.equals(other.getC003_Text_02__c()))) &&
            ((this.c003_Text_03__c==null && other.getC003_Text_03__c()==null) || 
             (this.c003_Text_03__c!=null &&
              this.c003_Text_03__c.equals(other.getC003_Text_03__c()))) &&
            ((this.c003_Text_04__c==null && other.getC003_Text_04__c()==null) || 
             (this.c003_Text_04__c!=null &&
              this.c003_Text_04__c.equals(other.getC003_Text_04__c()))) &&
            ((this.c003_Text_05__c==null && other.getC003_Text_05__c()==null) || 
             (this.c003_Text_05__c!=null &&
              this.c003_Text_05__c.equals(other.getC003_Text_05__c()))) &&
            ((this.c003_Text_06__c==null && other.getC003_Text_06__c()==null) || 
             (this.c003_Text_06__c!=null &&
              this.c003_Text_06__c.equals(other.getC003_Text_06__c()))) &&
            ((this.c003_Text_07__c==null && other.getC003_Text_07__c()==null) || 
             (this.c003_Text_07__c!=null &&
              this.c003_Text_07__c.equals(other.getC003_Text_07__c()))) &&
            ((this.c003_Text_08__c==null && other.getC003_Text_08__c()==null) || 
             (this.c003_Text_08__c!=null &&
              this.c003_Text_08__c.equals(other.getC003_Text_08__c()))) &&
            ((this.c003_Text_09__c==null && other.getC003_Text_09__c()==null) || 
             (this.c003_Text_09__c!=null &&
              this.c003_Text_09__c.equals(other.getC003_Text_09__c()))) &&
            ((this.c003_Text_10__c==null && other.getC003_Text_10__c()==null) || 
             (this.c003_Text_10__c!=null &&
              this.c003_Text_10__c.equals(other.getC003_Text_10__c()))) &&
            ((this.c003_YomikomiNo__c==null && other.getC003_YomikomiNo__c()==null) || 
             (this.c003_YomikomiNo__c!=null &&
              this.c003_YomikomiNo__c.equals(other.getC003_YomikomiNo__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lastReferencedDate==null && other.getLastReferencedDate()==null) || 
             (this.lastReferencedDate!=null &&
              this.lastReferencedDate.equals(other.getLastReferencedDate()))) &&
            ((this.lastViewedDate==null && other.getLastViewedDate()==null) || 
             (this.lastViewedDate!=null &&
              this.lastViewedDate.equals(other.getLastViewedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getA020_Contracts_01__r() != null) {
            _hashCode += getA020_Contracts_01__r().hashCode();
        }
        if (getA020_Contracts_03__r() != null) {
            _hashCode += getA020_Contracts_03__r().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getC003_AccountNo__c() != null) {
            _hashCode += getC003_AccountNo__c().hashCode();
        }
        if (getC003_AccountRef__c() != null) {
            _hashCode += getC003_AccountRef__c().hashCode();
        }
        if (getC003_AccountRef__r() != null) {
            _hashCode += getC003_AccountRef__r().hashCode();
        }
        if (getC003_AccountTemban__c() != null) {
            _hashCode += getC003_AccountTemban__c().hashCode();
        }
        if (getC003_AccountType__c() != null) {
            _hashCode += getC003_AccountType__c().hashCode();
        }
        if (getC003_Amount__c() != null) {
            _hashCode += getC003_Amount__c().hashCode();
        }
        if (getC003_Area_01__c() != null) {
            _hashCode += getC003_Area_01__c().hashCode();
        }
        if (getC003_Area_02__c() != null) {
            _hashCode += getC003_Area_02__c().hashCode();
        }
        if (getC003_Area_03__c() != null) {
            _hashCode += getC003_Area_03__c().hashCode();
        }
        if (getC003_Area_04__c() != null) {
            _hashCode += getC003_Area_04__c().hashCode();
        }
        if (getC003_Area_05__c() != null) {
            _hashCode += getC003_Area_05__c().hashCode();
        }
        if (getC003_Area_06__c() != null) {
            _hashCode += getC003_Area_06__c().hashCode();
        }
        if (getC003_Area_07__c() != null) {
            _hashCode += getC003_Area_07__c().hashCode();
        }
        if (getC003_Area_08__c() != null) {
            _hashCode += getC003_Area_08__c().hashCode();
        }
        if (getC003_Area_09__c() != null) {
            _hashCode += getC003_Area_09__c().hashCode();
        }
        if (getC003_Area_10__c() != null) {
            _hashCode += getC003_Area_10__c().hashCode();
        }
        if (getC003_Check_01__c() != null) {
            _hashCode += getC003_Check_01__c().hashCode();
        }
        if (getC003_Check_02__c() != null) {
            _hashCode += getC003_Check_02__c().hashCode();
        }
        if (getC003_Check_03__c() != null) {
            _hashCode += getC003_Check_03__c().hashCode();
        }
        if (getC003_Check_04__c() != null) {
            _hashCode += getC003_Check_04__c().hashCode();
        }
        if (getC003_Check_05__c() != null) {
            _hashCode += getC003_Check_05__c().hashCode();
        }
        if (getC003_Check_06__c() != null) {
            _hashCode += getC003_Check_06__c().hashCode();
        }
        if (getC003_Check_07__c() != null) {
            _hashCode += getC003_Check_07__c().hashCode();
        }
        if (getC003_Check_08__c() != null) {
            _hashCode += getC003_Check_08__c().hashCode();
        }
        if (getC003_Check_09__c() != null) {
            _hashCode += getC003_Check_09__c().hashCode();
        }
        if (getC003_Check_10__c() != null) {
            _hashCode += getC003_Check_10__c().hashCode();
        }
        if (getC003_CommodityRef__c() != null) {
            _hashCode += getC003_CommodityRef__c().hashCode();
        }
        if (getC003_CommodityRef__r() != null) {
            _hashCode += getC003_CommodityRef__r().hashCode();
        }
        if (getC003_ContractId__c() != null) {
            _hashCode += getC003_ContractId__c().hashCode();
        }
        if (getC003_Contracts_01__r() != null) {
            _hashCode += getC003_Contracts_01__r().hashCode();
        }
        if (getC003_CsvLastModifiedDate__c() != null) {
            _hashCode += getC003_CsvLastModifiedDate__c().hashCode();
        }
        if (getC003_Date_01__c() != null) {
            _hashCode += getC003_Date_01__c().hashCode();
        }
        if (getC003_Date_02__c() != null) {
            _hashCode += getC003_Date_02__c().hashCode();
        }
        if (getC003_Date_03__c() != null) {
            _hashCode += getC003_Date_03__c().hashCode();
        }
        if (getC003_Date_04__c() != null) {
            _hashCode += getC003_Date_04__c().hashCode();
        }
        if (getC003_Date_05__c() != null) {
            _hashCode += getC003_Date_05__c().hashCode();
        }
        if (getC003_Date_06__c() != null) {
            _hashCode += getC003_Date_06__c().hashCode();
        }
        if (getC003_Date_07__c() != null) {
            _hashCode += getC003_Date_07__c().hashCode();
        }
        if (getC003_Date_08__c() != null) {
            _hashCode += getC003_Date_08__c().hashCode();
        }
        if (getC003_Date_09__c() != null) {
            _hashCode += getC003_Date_09__c().hashCode();
        }
        if (getC003_Date_10__c() != null) {
            _hashCode += getC003_Date_10__c().hashCode();
        }
        if (getC003_Date__c() != null) {
            _hashCode += getC003_Date__c().hashCode();
        }
        if (getC003_EndDate__c() != null) {
            _hashCode += getC003_EndDate__c().hashCode();
        }
        if (getC003_List_01__c() != null) {
            _hashCode += getC003_List_01__c().hashCode();
        }
        if (getC003_List_02__c() != null) {
            _hashCode += getC003_List_02__c().hashCode();
        }
        if (getC003_List_03__c() != null) {
            _hashCode += getC003_List_03__c().hashCode();
        }
        if (getC003_List_04__c() != null) {
            _hashCode += getC003_List_04__c().hashCode();
        }
        if (getC003_List_05__c() != null) {
            _hashCode += getC003_List_05__c().hashCode();
        }
        if (getC003_List_06__c() != null) {
            _hashCode += getC003_List_06__c().hashCode();
        }
        if (getC003_List_07__c() != null) {
            _hashCode += getC003_List_07__c().hashCode();
        }
        if (getC003_List_08__c() != null) {
            _hashCode += getC003_List_08__c().hashCode();
        }
        if (getC003_List_09__c() != null) {
            _hashCode += getC003_List_09__c().hashCode();
        }
        if (getC003_List_10__c() != null) {
            _hashCode += getC003_List_10__c().hashCode();
        }
        if (getC003_Note__c() != null) {
            _hashCode += getC003_Note__c().hashCode();
        }
        if (getC003_Number_01__c() != null) {
            _hashCode += getC003_Number_01__c().hashCode();
        }
        if (getC003_Number_02__c() != null) {
            _hashCode += getC003_Number_02__c().hashCode();
        }
        if (getC003_Number_03__c() != null) {
            _hashCode += getC003_Number_03__c().hashCode();
        }
        if (getC003_Number_04__c() != null) {
            _hashCode += getC003_Number_04__c().hashCode();
        }
        if (getC003_Number_05__c() != null) {
            _hashCode += getC003_Number_05__c().hashCode();
        }
        if (getC003_Number_06__c() != null) {
            _hashCode += getC003_Number_06__c().hashCode();
        }
        if (getC003_Number_07__c() != null) {
            _hashCode += getC003_Number_07__c().hashCode();
        }
        if (getC003_Number_08__c() != null) {
            _hashCode += getC003_Number_08__c().hashCode();
        }
        if (getC003_Number_09__c() != null) {
            _hashCode += getC003_Number_09__c().hashCode();
        }
        if (getC003_Number_10__c() != null) {
            _hashCode += getC003_Number_10__c().hashCode();
        }
        if (getC003_StartDate__c() != null) {
            _hashCode += getC003_StartDate__c().hashCode();
        }
        if (getC003_Status__c() != null) {
            _hashCode += getC003_Status__c().hashCode();
        }
        if (getC003_TembanKokyakubangou__c() != null) {
            _hashCode += getC003_TembanKokyakubangou__c().hashCode();
        }
        if (getC003_Text_01__c() != null) {
            _hashCode += getC003_Text_01__c().hashCode();
        }
        if (getC003_Text_02__c() != null) {
            _hashCode += getC003_Text_02__c().hashCode();
        }
        if (getC003_Text_03__c() != null) {
            _hashCode += getC003_Text_03__c().hashCode();
        }
        if (getC003_Text_04__c() != null) {
            _hashCode += getC003_Text_04__c().hashCode();
        }
        if (getC003_Text_05__c() != null) {
            _hashCode += getC003_Text_05__c().hashCode();
        }
        if (getC003_Text_06__c() != null) {
            _hashCode += getC003_Text_06__c().hashCode();
        }
        if (getC003_Text_07__c() != null) {
            _hashCode += getC003_Text_07__c().hashCode();
        }
        if (getC003_Text_08__c() != null) {
            _hashCode += getC003_Text_08__c().hashCode();
        }
        if (getC003_Text_09__c() != null) {
            _hashCode += getC003_Text_09__c().hashCode();
        }
        if (getC003_Text_10__c() != null) {
            _hashCode += getC003_Text_10__c().hashCode();
        }
        if (getC003_YomikomiNo__c() != null) {
            _hashCode += getC003_YomikomiNo__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLastReferencedDate() != null) {
            _hashCode += getLastReferencedDate().hashCode();
        }
        if (getLastViewedDate() != null) {
            _hashCode += getLastViewedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C003_Contract__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Contract__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a020_Contracts_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A020_Contracts_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a020_Contracts_03__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A020_Contracts_03__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_AccountNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_AccountNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_AccountRef__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_AccountRef__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_AccountRef__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_AccountRef__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Account"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_AccountTemban__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_AccountTemban__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_AccountType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_AccountType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Amount__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Amount__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_02__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_02__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_03__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_03__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_04__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_04__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_05__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_05__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_06__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_06__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_07__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_07__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_08__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_08__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_09__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_09__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_02__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_02__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_03__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_03__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_04__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_04__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_05__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_05__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_06__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_06__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_07__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_07__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_08__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_08__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_09__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_09__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Check_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Check_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_CommodityRef__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_CommodityRef__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_CommodityRef__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_CommodityRef__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Commodity__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_ContractId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_ContractId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Contracts_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Contracts_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_CsvLastModifiedDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_CsvLastModifiedDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_02__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_02__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_03__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_03__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_04__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_04__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_05__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_05__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_06__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_06__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_07__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_07__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_08__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_08__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_09__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_09__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Date__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Date__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_EndDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_EndDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_02__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_02__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_03__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_03__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_04__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_04__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_05__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_05__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_06__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_06__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_07__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_07__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_08__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_08__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_09__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_09__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_List_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_List_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Note__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Note__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_02__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_02__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_03__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_03__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_04__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_04__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_05__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_05__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_06__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_06__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_07__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_07__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_08__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_08__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_09__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_09__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Number_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Number_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_StartDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_StartDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Status__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Status__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_TembanKokyakubangou__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_TembanKokyakubangou__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_02__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_02__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_03__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_03__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_04__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_04__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_05__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_05__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_06__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_06__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_07__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_07__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_08__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_08__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_09__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_09__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_YomikomiNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_YomikomiNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastReferencedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastReferencedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastViewedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastViewedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
