/**
 * C000_059_CIF_RATING_HISTORY__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C000_059_CIF_RATING_HISTORY__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String CIFZOKUSEIINFO__c;

    private com.sforce.soap.enterprise.sobject.C000_CIFZOKUSEIINFO__c CIFZOKUSEIINFO__r;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Boolean DELFLG__c;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private java.lang.Boolean isDeleted;

    private java.util.Date KAKUDUKEKOUSHINBI__c;

    private java.lang.String KOKYAKUBANGOU__c;

    private java.lang.String KOUNAIKAKUDUKE_10MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_11MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_12MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_13MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_14MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_15MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_16MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_17MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_18MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_1MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_2MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_3MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_4MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_5MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_6MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_7MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_8MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_9MONTH_BEFORE__c;

    private java.lang.String KOUNAIKAKUDUKE_CURENT__c;

    private java.lang.String LAST_BATCH_DATE__c;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String NENGETSU_10MONTH_BEFORE__c;

    private java.lang.String NENGETSU_11MONTH_BEFORE__c;

    private java.lang.String NENGETSU_12MONTH_BEFORE__c;

    private java.lang.String NENGETSU_13MONTH_BEFORE__c;

    private java.lang.String NENGETSU_14MONTH_BEFORE__c;

    private java.lang.String NENGETSU_15MONTH_BEFORE__c;

    private java.lang.String NENGETSU_16MONTH_BEFORE__c;

    private java.lang.String NENGETSU_17MONTH_BEFORE__c;

    private java.lang.String NENGETSU_18MONTH_BEFORE__c;

    private java.lang.String NENGETSU_1MONTH_BEFORE__c;

    private java.lang.String NENGETSU_2MONTH_BEFORE__c;

    private java.lang.String NENGETSU_3MONTH_BEFORE__c;

    private java.lang.String NENGETSU_4MONTH_BEFORE__c;

    private java.lang.String NENGETSU_5MONTH_BEFORE__c;

    private java.lang.String NENGETSU_6MONTH_BEFORE__c;

    private java.lang.String NENGETSU_7MONTH_BEFORE__c;

    private java.lang.String NENGETSU_8MONTH_BEFORE__c;

    private java.lang.String NENGETSU_9MONTH_BEFORE__c;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.util.Calendar systemModstamp;

    private java.lang.String TENBAN_3__c;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    public C000_059_CIF_RATING_HISTORY__c() {
    }

    public C000_059_CIF_RATING_HISTORY__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String CIFZOKUSEIINFO__c,
           com.sforce.soap.enterprise.sobject.C000_CIFZOKUSEIINFO__c CIFZOKUSEIINFO__r,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Boolean DELFLG__c,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           java.lang.Boolean isDeleted,
           java.util.Date KAKUDUKEKOUSHINBI__c,
           java.lang.String KOKYAKUBANGOU__c,
           java.lang.String KOUNAIKAKUDUKE_10MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_11MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_12MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_13MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_14MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_15MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_16MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_17MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_18MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_1MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_2MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_3MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_4MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_5MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_6MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_7MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_8MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_9MONTH_BEFORE__c,
           java.lang.String KOUNAIKAKUDUKE_CURENT__c,
           java.lang.String LAST_BATCH_DATE__c,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String NENGETSU_10MONTH_BEFORE__c,
           java.lang.String NENGETSU_11MONTH_BEFORE__c,
           java.lang.String NENGETSU_12MONTH_BEFORE__c,
           java.lang.String NENGETSU_13MONTH_BEFORE__c,
           java.lang.String NENGETSU_14MONTH_BEFORE__c,
           java.lang.String NENGETSU_15MONTH_BEFORE__c,
           java.lang.String NENGETSU_16MONTH_BEFORE__c,
           java.lang.String NENGETSU_17MONTH_BEFORE__c,
           java.lang.String NENGETSU_18MONTH_BEFORE__c,
           java.lang.String NENGETSU_1MONTH_BEFORE__c,
           java.lang.String NENGETSU_2MONTH_BEFORE__c,
           java.lang.String NENGETSU_3MONTH_BEFORE__c,
           java.lang.String NENGETSU_4MONTH_BEFORE__c,
           java.lang.String NENGETSU_5MONTH_BEFORE__c,
           java.lang.String NENGETSU_6MONTH_BEFORE__c,
           java.lang.String NENGETSU_7MONTH_BEFORE__c,
           java.lang.String NENGETSU_8MONTH_BEFORE__c,
           java.lang.String NENGETSU_9MONTH_BEFORE__c,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.util.Calendar systemModstamp,
           java.lang.String TENBAN_3__c,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        super(
            fieldsToNull,
            id);
        this.attachments = attachments;
        this.CIFZOKUSEIINFO__c = CIFZOKUSEIINFO__c;
        this.CIFZOKUSEIINFO__r = CIFZOKUSEIINFO__r;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.DELFLG__c = DELFLG__c;
        this.duplicateRecordItems = duplicateRecordItems;
        this.isDeleted = isDeleted;
        this.KAKUDUKEKOUSHINBI__c = KAKUDUKEKOUSHINBI__c;
        this.KOKYAKUBANGOU__c = KOKYAKUBANGOU__c;
        this.KOUNAIKAKUDUKE_10MONTH_BEFORE__c = KOUNAIKAKUDUKE_10MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_11MONTH_BEFORE__c = KOUNAIKAKUDUKE_11MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_12MONTH_BEFORE__c = KOUNAIKAKUDUKE_12MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_13MONTH_BEFORE__c = KOUNAIKAKUDUKE_13MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_14MONTH_BEFORE__c = KOUNAIKAKUDUKE_14MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_15MONTH_BEFORE__c = KOUNAIKAKUDUKE_15MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_16MONTH_BEFORE__c = KOUNAIKAKUDUKE_16MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_17MONTH_BEFORE__c = KOUNAIKAKUDUKE_17MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_18MONTH_BEFORE__c = KOUNAIKAKUDUKE_18MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_1MONTH_BEFORE__c = KOUNAIKAKUDUKE_1MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_2MONTH_BEFORE__c = KOUNAIKAKUDUKE_2MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_3MONTH_BEFORE__c = KOUNAIKAKUDUKE_3MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_4MONTH_BEFORE__c = KOUNAIKAKUDUKE_4MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_5MONTH_BEFORE__c = KOUNAIKAKUDUKE_5MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_6MONTH_BEFORE__c = KOUNAIKAKUDUKE_6MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_7MONTH_BEFORE__c = KOUNAIKAKUDUKE_7MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_8MONTH_BEFORE__c = KOUNAIKAKUDUKE_8MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_9MONTH_BEFORE__c = KOUNAIKAKUDUKE_9MONTH_BEFORE__c;
        this.KOUNAIKAKUDUKE_CURENT__c = KOUNAIKAKUDUKE_CURENT__c;
        this.LAST_BATCH_DATE__c = LAST_BATCH_DATE__c;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.NENGETSU_10MONTH_BEFORE__c = NENGETSU_10MONTH_BEFORE__c;
        this.NENGETSU_11MONTH_BEFORE__c = NENGETSU_11MONTH_BEFORE__c;
        this.NENGETSU_12MONTH_BEFORE__c = NENGETSU_12MONTH_BEFORE__c;
        this.NENGETSU_13MONTH_BEFORE__c = NENGETSU_13MONTH_BEFORE__c;
        this.NENGETSU_14MONTH_BEFORE__c = NENGETSU_14MONTH_BEFORE__c;
        this.NENGETSU_15MONTH_BEFORE__c = NENGETSU_15MONTH_BEFORE__c;
        this.NENGETSU_16MONTH_BEFORE__c = NENGETSU_16MONTH_BEFORE__c;
        this.NENGETSU_17MONTH_BEFORE__c = NENGETSU_17MONTH_BEFORE__c;
        this.NENGETSU_18MONTH_BEFORE__c = NENGETSU_18MONTH_BEFORE__c;
        this.NENGETSU_1MONTH_BEFORE__c = NENGETSU_1MONTH_BEFORE__c;
        this.NENGETSU_2MONTH_BEFORE__c = NENGETSU_2MONTH_BEFORE__c;
        this.NENGETSU_3MONTH_BEFORE__c = NENGETSU_3MONTH_BEFORE__c;
        this.NENGETSU_4MONTH_BEFORE__c = NENGETSU_4MONTH_BEFORE__c;
        this.NENGETSU_5MONTH_BEFORE__c = NENGETSU_5MONTH_BEFORE__c;
        this.NENGETSU_6MONTH_BEFORE__c = NENGETSU_6MONTH_BEFORE__c;
        this.NENGETSU_7MONTH_BEFORE__c = NENGETSU_7MONTH_BEFORE__c;
        this.NENGETSU_8MONTH_BEFORE__c = NENGETSU_8MONTH_BEFORE__c;
        this.NENGETSU_9MONTH_BEFORE__c = NENGETSU_9MONTH_BEFORE__c;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.systemModstamp = systemModstamp;
        this.TENBAN_3__c = TENBAN_3__c;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the attachments value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the CIFZOKUSEIINFO__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return CIFZOKUSEIINFO__c
     */
    public java.lang.String getCIFZOKUSEIINFO__c() {
        return CIFZOKUSEIINFO__c;
    }


    /**
     * Sets the CIFZOKUSEIINFO__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param CIFZOKUSEIINFO__c
     */
    public void setCIFZOKUSEIINFO__c(java.lang.String CIFZOKUSEIINFO__c) {
        this.CIFZOKUSEIINFO__c = CIFZOKUSEIINFO__c;
    }


    /**
     * Gets the CIFZOKUSEIINFO__r value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return CIFZOKUSEIINFO__r
     */
    public com.sforce.soap.enterprise.sobject.C000_CIFZOKUSEIINFO__c getCIFZOKUSEIINFO__r() {
        return CIFZOKUSEIINFO__r;
    }


    /**
     * Sets the CIFZOKUSEIINFO__r value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param CIFZOKUSEIINFO__r
     */
    public void setCIFZOKUSEIINFO__r(com.sforce.soap.enterprise.sobject.C000_CIFZOKUSEIINFO__c CIFZOKUSEIINFO__r) {
        this.CIFZOKUSEIINFO__r = CIFZOKUSEIINFO__r;
    }


    /**
     * Gets the combinedAttachments value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the DELFLG__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return DELFLG__c
     */
    public java.lang.Boolean getDELFLG__c() {
        return DELFLG__c;
    }


    /**
     * Sets the DELFLG__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param DELFLG__c
     */
    public void setDELFLG__c(java.lang.Boolean DELFLG__c) {
        this.DELFLG__c = DELFLG__c;
    }


    /**
     * Gets the duplicateRecordItems value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the isDeleted value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the KAKUDUKEKOUSHINBI__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KAKUDUKEKOUSHINBI__c
     */
    public java.util.Date getKAKUDUKEKOUSHINBI__c() {
        return KAKUDUKEKOUSHINBI__c;
    }


    /**
     * Sets the KAKUDUKEKOUSHINBI__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KAKUDUKEKOUSHINBI__c
     */
    public void setKAKUDUKEKOUSHINBI__c(java.util.Date KAKUDUKEKOUSHINBI__c) {
        this.KAKUDUKEKOUSHINBI__c = KAKUDUKEKOUSHINBI__c;
    }


    /**
     * Gets the KOKYAKUBANGOU__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOKYAKUBANGOU__c
     */
    public java.lang.String getKOKYAKUBANGOU__c() {
        return KOKYAKUBANGOU__c;
    }


    /**
     * Sets the KOKYAKUBANGOU__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOKYAKUBANGOU__c
     */
    public void setKOKYAKUBANGOU__c(java.lang.String KOKYAKUBANGOU__c) {
        this.KOKYAKUBANGOU__c = KOKYAKUBANGOU__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_10MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_10MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_10MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_10MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_10MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_10MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_10MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_10MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_10MONTH_BEFORE__c = KOUNAIKAKUDUKE_10MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_11MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_11MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_11MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_11MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_11MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_11MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_11MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_11MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_11MONTH_BEFORE__c = KOUNAIKAKUDUKE_11MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_12MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_12MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_12MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_12MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_12MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_12MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_12MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_12MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_12MONTH_BEFORE__c = KOUNAIKAKUDUKE_12MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_13MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_13MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_13MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_13MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_13MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_13MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_13MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_13MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_13MONTH_BEFORE__c = KOUNAIKAKUDUKE_13MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_14MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_14MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_14MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_14MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_14MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_14MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_14MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_14MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_14MONTH_BEFORE__c = KOUNAIKAKUDUKE_14MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_15MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_15MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_15MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_15MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_15MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_15MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_15MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_15MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_15MONTH_BEFORE__c = KOUNAIKAKUDUKE_15MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_16MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_16MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_16MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_16MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_16MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_16MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_16MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_16MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_16MONTH_BEFORE__c = KOUNAIKAKUDUKE_16MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_17MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_17MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_17MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_17MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_17MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_17MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_17MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_17MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_17MONTH_BEFORE__c = KOUNAIKAKUDUKE_17MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_18MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_18MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_18MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_18MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_18MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_18MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_18MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_18MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_18MONTH_BEFORE__c = KOUNAIKAKUDUKE_18MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_1MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_1MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_1MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_1MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_1MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_1MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_1MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_1MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_1MONTH_BEFORE__c = KOUNAIKAKUDUKE_1MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_2MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_2MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_2MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_2MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_2MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_2MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_2MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_2MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_2MONTH_BEFORE__c = KOUNAIKAKUDUKE_2MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_3MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_3MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_3MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_3MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_3MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_3MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_3MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_3MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_3MONTH_BEFORE__c = KOUNAIKAKUDUKE_3MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_4MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_4MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_4MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_4MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_4MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_4MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_4MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_4MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_4MONTH_BEFORE__c = KOUNAIKAKUDUKE_4MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_5MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_5MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_5MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_5MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_5MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_5MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_5MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_5MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_5MONTH_BEFORE__c = KOUNAIKAKUDUKE_5MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_6MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_6MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_6MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_6MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_6MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_6MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_6MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_6MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_6MONTH_BEFORE__c = KOUNAIKAKUDUKE_6MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_7MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_7MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_7MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_7MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_7MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_7MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_7MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_7MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_7MONTH_BEFORE__c = KOUNAIKAKUDUKE_7MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_8MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_8MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_8MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_8MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_8MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_8MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_8MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_8MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_8MONTH_BEFORE__c = KOUNAIKAKUDUKE_8MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_9MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_9MONTH_BEFORE__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_9MONTH_BEFORE__c() {
        return KOUNAIKAKUDUKE_9MONTH_BEFORE__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_9MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_9MONTH_BEFORE__c
     */
    public void setKOUNAIKAKUDUKE_9MONTH_BEFORE__c(java.lang.String KOUNAIKAKUDUKE_9MONTH_BEFORE__c) {
        this.KOUNAIKAKUDUKE_9MONTH_BEFORE__c = KOUNAIKAKUDUKE_9MONTH_BEFORE__c;
    }


    /**
     * Gets the KOUNAIKAKUDUKE_CURENT__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return KOUNAIKAKUDUKE_CURENT__c
     */
    public java.lang.String getKOUNAIKAKUDUKE_CURENT__c() {
        return KOUNAIKAKUDUKE_CURENT__c;
    }


    /**
     * Sets the KOUNAIKAKUDUKE_CURENT__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param KOUNAIKAKUDUKE_CURENT__c
     */
    public void setKOUNAIKAKUDUKE_CURENT__c(java.lang.String KOUNAIKAKUDUKE_CURENT__c) {
        this.KOUNAIKAKUDUKE_CURENT__c = KOUNAIKAKUDUKE_CURENT__c;
    }


    /**
     * Gets the LAST_BATCH_DATE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return LAST_BATCH_DATE__c
     */
    public java.lang.String getLAST_BATCH_DATE__c() {
        return LAST_BATCH_DATE__c;
    }


    /**
     * Sets the LAST_BATCH_DATE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param LAST_BATCH_DATE__c
     */
    public void setLAST_BATCH_DATE__c(java.lang.String LAST_BATCH_DATE__c) {
        this.LAST_BATCH_DATE__c = LAST_BATCH_DATE__c;
    }


    /**
     * Gets the lastModifiedBy value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the NENGETSU_10MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_10MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_10MONTH_BEFORE__c() {
        return NENGETSU_10MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_10MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_10MONTH_BEFORE__c
     */
    public void setNENGETSU_10MONTH_BEFORE__c(java.lang.String NENGETSU_10MONTH_BEFORE__c) {
        this.NENGETSU_10MONTH_BEFORE__c = NENGETSU_10MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_11MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_11MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_11MONTH_BEFORE__c() {
        return NENGETSU_11MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_11MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_11MONTH_BEFORE__c
     */
    public void setNENGETSU_11MONTH_BEFORE__c(java.lang.String NENGETSU_11MONTH_BEFORE__c) {
        this.NENGETSU_11MONTH_BEFORE__c = NENGETSU_11MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_12MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_12MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_12MONTH_BEFORE__c() {
        return NENGETSU_12MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_12MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_12MONTH_BEFORE__c
     */
    public void setNENGETSU_12MONTH_BEFORE__c(java.lang.String NENGETSU_12MONTH_BEFORE__c) {
        this.NENGETSU_12MONTH_BEFORE__c = NENGETSU_12MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_13MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_13MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_13MONTH_BEFORE__c() {
        return NENGETSU_13MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_13MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_13MONTH_BEFORE__c
     */
    public void setNENGETSU_13MONTH_BEFORE__c(java.lang.String NENGETSU_13MONTH_BEFORE__c) {
        this.NENGETSU_13MONTH_BEFORE__c = NENGETSU_13MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_14MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_14MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_14MONTH_BEFORE__c() {
        return NENGETSU_14MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_14MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_14MONTH_BEFORE__c
     */
    public void setNENGETSU_14MONTH_BEFORE__c(java.lang.String NENGETSU_14MONTH_BEFORE__c) {
        this.NENGETSU_14MONTH_BEFORE__c = NENGETSU_14MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_15MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_15MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_15MONTH_BEFORE__c() {
        return NENGETSU_15MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_15MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_15MONTH_BEFORE__c
     */
    public void setNENGETSU_15MONTH_BEFORE__c(java.lang.String NENGETSU_15MONTH_BEFORE__c) {
        this.NENGETSU_15MONTH_BEFORE__c = NENGETSU_15MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_16MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_16MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_16MONTH_BEFORE__c() {
        return NENGETSU_16MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_16MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_16MONTH_BEFORE__c
     */
    public void setNENGETSU_16MONTH_BEFORE__c(java.lang.String NENGETSU_16MONTH_BEFORE__c) {
        this.NENGETSU_16MONTH_BEFORE__c = NENGETSU_16MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_17MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_17MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_17MONTH_BEFORE__c() {
        return NENGETSU_17MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_17MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_17MONTH_BEFORE__c
     */
    public void setNENGETSU_17MONTH_BEFORE__c(java.lang.String NENGETSU_17MONTH_BEFORE__c) {
        this.NENGETSU_17MONTH_BEFORE__c = NENGETSU_17MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_18MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_18MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_18MONTH_BEFORE__c() {
        return NENGETSU_18MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_18MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_18MONTH_BEFORE__c
     */
    public void setNENGETSU_18MONTH_BEFORE__c(java.lang.String NENGETSU_18MONTH_BEFORE__c) {
        this.NENGETSU_18MONTH_BEFORE__c = NENGETSU_18MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_1MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_1MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_1MONTH_BEFORE__c() {
        return NENGETSU_1MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_1MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_1MONTH_BEFORE__c
     */
    public void setNENGETSU_1MONTH_BEFORE__c(java.lang.String NENGETSU_1MONTH_BEFORE__c) {
        this.NENGETSU_1MONTH_BEFORE__c = NENGETSU_1MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_2MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_2MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_2MONTH_BEFORE__c() {
        return NENGETSU_2MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_2MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_2MONTH_BEFORE__c
     */
    public void setNENGETSU_2MONTH_BEFORE__c(java.lang.String NENGETSU_2MONTH_BEFORE__c) {
        this.NENGETSU_2MONTH_BEFORE__c = NENGETSU_2MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_3MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_3MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_3MONTH_BEFORE__c() {
        return NENGETSU_3MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_3MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_3MONTH_BEFORE__c
     */
    public void setNENGETSU_3MONTH_BEFORE__c(java.lang.String NENGETSU_3MONTH_BEFORE__c) {
        this.NENGETSU_3MONTH_BEFORE__c = NENGETSU_3MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_4MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_4MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_4MONTH_BEFORE__c() {
        return NENGETSU_4MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_4MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_4MONTH_BEFORE__c
     */
    public void setNENGETSU_4MONTH_BEFORE__c(java.lang.String NENGETSU_4MONTH_BEFORE__c) {
        this.NENGETSU_4MONTH_BEFORE__c = NENGETSU_4MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_5MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_5MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_5MONTH_BEFORE__c() {
        return NENGETSU_5MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_5MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_5MONTH_BEFORE__c
     */
    public void setNENGETSU_5MONTH_BEFORE__c(java.lang.String NENGETSU_5MONTH_BEFORE__c) {
        this.NENGETSU_5MONTH_BEFORE__c = NENGETSU_5MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_6MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_6MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_6MONTH_BEFORE__c() {
        return NENGETSU_6MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_6MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_6MONTH_BEFORE__c
     */
    public void setNENGETSU_6MONTH_BEFORE__c(java.lang.String NENGETSU_6MONTH_BEFORE__c) {
        this.NENGETSU_6MONTH_BEFORE__c = NENGETSU_6MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_7MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_7MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_7MONTH_BEFORE__c() {
        return NENGETSU_7MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_7MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_7MONTH_BEFORE__c
     */
    public void setNENGETSU_7MONTH_BEFORE__c(java.lang.String NENGETSU_7MONTH_BEFORE__c) {
        this.NENGETSU_7MONTH_BEFORE__c = NENGETSU_7MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_8MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_8MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_8MONTH_BEFORE__c() {
        return NENGETSU_8MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_8MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_8MONTH_BEFORE__c
     */
    public void setNENGETSU_8MONTH_BEFORE__c(java.lang.String NENGETSU_8MONTH_BEFORE__c) {
        this.NENGETSU_8MONTH_BEFORE__c = NENGETSU_8MONTH_BEFORE__c;
    }


    /**
     * Gets the NENGETSU_9MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return NENGETSU_9MONTH_BEFORE__c
     */
    public java.lang.String getNENGETSU_9MONTH_BEFORE__c() {
        return NENGETSU_9MONTH_BEFORE__c;
    }


    /**
     * Sets the NENGETSU_9MONTH_BEFORE__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param NENGETSU_9MONTH_BEFORE__c
     */
    public void setNENGETSU_9MONTH_BEFORE__c(java.lang.String NENGETSU_9MONTH_BEFORE__c) {
        this.NENGETSU_9MONTH_BEFORE__c = NENGETSU_9MONTH_BEFORE__c;
    }


    /**
     * Gets the name value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the processInstances value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the systemModstamp value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the TENBAN_3__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return TENBAN_3__c
     */
    public java.lang.String getTENBAN_3__c() {
        return TENBAN_3__c;
    }


    /**
     * Sets the TENBAN_3__c value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param TENBAN_3__c
     */
    public void setTENBAN_3__c(java.lang.String TENBAN_3__c) {
        this.TENBAN_3__c = TENBAN_3__c;
    }


    /**
     * Gets the topicAssignments value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C000_059_CIF_RATING_HISTORY__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C000_059_CIF_RATING_HISTORY__c)) return false;
        C000_059_CIF_RATING_HISTORY__c other = (C000_059_CIF_RATING_HISTORY__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.CIFZOKUSEIINFO__c==null && other.getCIFZOKUSEIINFO__c()==null) || 
             (this.CIFZOKUSEIINFO__c!=null &&
              this.CIFZOKUSEIINFO__c.equals(other.getCIFZOKUSEIINFO__c()))) &&
            ((this.CIFZOKUSEIINFO__r==null && other.getCIFZOKUSEIINFO__r()==null) || 
             (this.CIFZOKUSEIINFO__r!=null &&
              this.CIFZOKUSEIINFO__r.equals(other.getCIFZOKUSEIINFO__r()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.DELFLG__c==null && other.getDELFLG__c()==null) || 
             (this.DELFLG__c!=null &&
              this.DELFLG__c.equals(other.getDELFLG__c()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.KAKUDUKEKOUSHINBI__c==null && other.getKAKUDUKEKOUSHINBI__c()==null) || 
             (this.KAKUDUKEKOUSHINBI__c!=null &&
              this.KAKUDUKEKOUSHINBI__c.equals(other.getKAKUDUKEKOUSHINBI__c()))) &&
            ((this.KOKYAKUBANGOU__c==null && other.getKOKYAKUBANGOU__c()==null) || 
             (this.KOKYAKUBANGOU__c!=null &&
              this.KOKYAKUBANGOU__c.equals(other.getKOKYAKUBANGOU__c()))) &&
            ((this.KOUNAIKAKUDUKE_10MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_10MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_10MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_10MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_10MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_11MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_11MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_11MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_11MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_11MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_12MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_12MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_12MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_12MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_12MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_13MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_13MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_13MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_13MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_13MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_14MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_14MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_14MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_14MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_14MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_15MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_15MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_15MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_15MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_15MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_16MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_16MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_16MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_16MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_16MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_17MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_17MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_17MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_17MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_17MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_18MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_18MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_18MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_18MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_18MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_1MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_1MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_1MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_1MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_1MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_2MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_2MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_2MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_2MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_2MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_3MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_3MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_3MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_3MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_3MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_4MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_4MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_4MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_4MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_4MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_5MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_5MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_5MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_5MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_5MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_6MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_6MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_6MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_6MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_6MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_7MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_7MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_7MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_7MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_7MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_8MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_8MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_8MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_8MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_8MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_9MONTH_BEFORE__c==null && other.getKOUNAIKAKUDUKE_9MONTH_BEFORE__c()==null) || 
             (this.KOUNAIKAKUDUKE_9MONTH_BEFORE__c!=null &&
              this.KOUNAIKAKUDUKE_9MONTH_BEFORE__c.equals(other.getKOUNAIKAKUDUKE_9MONTH_BEFORE__c()))) &&
            ((this.KOUNAIKAKUDUKE_CURENT__c==null && other.getKOUNAIKAKUDUKE_CURENT__c()==null) || 
             (this.KOUNAIKAKUDUKE_CURENT__c!=null &&
              this.KOUNAIKAKUDUKE_CURENT__c.equals(other.getKOUNAIKAKUDUKE_CURENT__c()))) &&
            ((this.LAST_BATCH_DATE__c==null && other.getLAST_BATCH_DATE__c()==null) || 
             (this.LAST_BATCH_DATE__c!=null &&
              this.LAST_BATCH_DATE__c.equals(other.getLAST_BATCH_DATE__c()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.NENGETSU_10MONTH_BEFORE__c==null && other.getNENGETSU_10MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_10MONTH_BEFORE__c!=null &&
              this.NENGETSU_10MONTH_BEFORE__c.equals(other.getNENGETSU_10MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_11MONTH_BEFORE__c==null && other.getNENGETSU_11MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_11MONTH_BEFORE__c!=null &&
              this.NENGETSU_11MONTH_BEFORE__c.equals(other.getNENGETSU_11MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_12MONTH_BEFORE__c==null && other.getNENGETSU_12MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_12MONTH_BEFORE__c!=null &&
              this.NENGETSU_12MONTH_BEFORE__c.equals(other.getNENGETSU_12MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_13MONTH_BEFORE__c==null && other.getNENGETSU_13MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_13MONTH_BEFORE__c!=null &&
              this.NENGETSU_13MONTH_BEFORE__c.equals(other.getNENGETSU_13MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_14MONTH_BEFORE__c==null && other.getNENGETSU_14MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_14MONTH_BEFORE__c!=null &&
              this.NENGETSU_14MONTH_BEFORE__c.equals(other.getNENGETSU_14MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_15MONTH_BEFORE__c==null && other.getNENGETSU_15MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_15MONTH_BEFORE__c!=null &&
              this.NENGETSU_15MONTH_BEFORE__c.equals(other.getNENGETSU_15MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_16MONTH_BEFORE__c==null && other.getNENGETSU_16MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_16MONTH_BEFORE__c!=null &&
              this.NENGETSU_16MONTH_BEFORE__c.equals(other.getNENGETSU_16MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_17MONTH_BEFORE__c==null && other.getNENGETSU_17MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_17MONTH_BEFORE__c!=null &&
              this.NENGETSU_17MONTH_BEFORE__c.equals(other.getNENGETSU_17MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_18MONTH_BEFORE__c==null && other.getNENGETSU_18MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_18MONTH_BEFORE__c!=null &&
              this.NENGETSU_18MONTH_BEFORE__c.equals(other.getNENGETSU_18MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_1MONTH_BEFORE__c==null && other.getNENGETSU_1MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_1MONTH_BEFORE__c!=null &&
              this.NENGETSU_1MONTH_BEFORE__c.equals(other.getNENGETSU_1MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_2MONTH_BEFORE__c==null && other.getNENGETSU_2MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_2MONTH_BEFORE__c!=null &&
              this.NENGETSU_2MONTH_BEFORE__c.equals(other.getNENGETSU_2MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_3MONTH_BEFORE__c==null && other.getNENGETSU_3MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_3MONTH_BEFORE__c!=null &&
              this.NENGETSU_3MONTH_BEFORE__c.equals(other.getNENGETSU_3MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_4MONTH_BEFORE__c==null && other.getNENGETSU_4MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_4MONTH_BEFORE__c!=null &&
              this.NENGETSU_4MONTH_BEFORE__c.equals(other.getNENGETSU_4MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_5MONTH_BEFORE__c==null && other.getNENGETSU_5MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_5MONTH_BEFORE__c!=null &&
              this.NENGETSU_5MONTH_BEFORE__c.equals(other.getNENGETSU_5MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_6MONTH_BEFORE__c==null && other.getNENGETSU_6MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_6MONTH_BEFORE__c!=null &&
              this.NENGETSU_6MONTH_BEFORE__c.equals(other.getNENGETSU_6MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_7MONTH_BEFORE__c==null && other.getNENGETSU_7MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_7MONTH_BEFORE__c!=null &&
              this.NENGETSU_7MONTH_BEFORE__c.equals(other.getNENGETSU_7MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_8MONTH_BEFORE__c==null && other.getNENGETSU_8MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_8MONTH_BEFORE__c!=null &&
              this.NENGETSU_8MONTH_BEFORE__c.equals(other.getNENGETSU_8MONTH_BEFORE__c()))) &&
            ((this.NENGETSU_9MONTH_BEFORE__c==null && other.getNENGETSU_9MONTH_BEFORE__c()==null) || 
             (this.NENGETSU_9MONTH_BEFORE__c!=null &&
              this.NENGETSU_9MONTH_BEFORE__c.equals(other.getNENGETSU_9MONTH_BEFORE__c()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.TENBAN_3__c==null && other.getTENBAN_3__c()==null) || 
             (this.TENBAN_3__c!=null &&
              this.TENBAN_3__c.equals(other.getTENBAN_3__c()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getCIFZOKUSEIINFO__c() != null) {
            _hashCode += getCIFZOKUSEIINFO__c().hashCode();
        }
        if (getCIFZOKUSEIINFO__r() != null) {
            _hashCode += getCIFZOKUSEIINFO__r().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDELFLG__c() != null) {
            _hashCode += getDELFLG__c().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getKAKUDUKEKOUSHINBI__c() != null) {
            _hashCode += getKAKUDUKEKOUSHINBI__c().hashCode();
        }
        if (getKOKYAKUBANGOU__c() != null) {
            _hashCode += getKOKYAKUBANGOU__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_10MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_10MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_11MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_11MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_12MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_12MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_13MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_13MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_14MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_14MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_15MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_15MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_16MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_16MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_17MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_17MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_18MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_18MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_1MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_1MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_2MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_2MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_3MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_3MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_4MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_4MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_5MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_5MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_6MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_6MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_7MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_7MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_8MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_8MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_9MONTH_BEFORE__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_9MONTH_BEFORE__c().hashCode();
        }
        if (getKOUNAIKAKUDUKE_CURENT__c() != null) {
            _hashCode += getKOUNAIKAKUDUKE_CURENT__c().hashCode();
        }
        if (getLAST_BATCH_DATE__c() != null) {
            _hashCode += getLAST_BATCH_DATE__c().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getNENGETSU_10MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_10MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_11MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_11MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_12MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_12MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_13MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_13MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_14MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_14MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_15MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_15MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_16MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_16MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_17MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_17MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_18MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_18MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_1MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_1MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_2MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_2MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_3MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_3MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_4MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_4MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_5MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_5MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_6MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_6MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_7MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_7MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_8MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_8MONTH_BEFORE__c().hashCode();
        }
        if (getNENGETSU_9MONTH_BEFORE__c() != null) {
            _hashCode += getNENGETSU_9MONTH_BEFORE__c().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTENBAN_3__c() != null) {
            _hashCode += getTENBAN_3__c().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C000_059_CIF_RATING_HISTORY__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_059_CIF_RATING_HISTORY__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIFZOKUSEIINFO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIFZOKUSEIINFO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIFZOKUSEIINFO__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIFZOKUSEIINFO__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DELFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DELFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAKUDUKEKOUSHINBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAKUDUKEKOUSHINBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKYAKUBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKYAKUBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_10MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_10MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_11MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_11MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_12MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_12MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_13MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_13MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_14MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_14MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_15MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_15MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_16MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_16MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_17MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_17MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_18MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_18MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_1MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_1MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_2MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_2MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_3MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_3MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_4MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_4MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_5MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_5MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_6MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_6MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_7MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_7MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_8MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_8MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_9MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_9MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUNAIKAKUDUKE_CURENT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUNAIKAKUDUKE_CURENT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LAST_BATCH_DATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LAST_BATCH_DATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_10MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_10MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_11MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_11MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_12MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_12MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_13MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_13MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_14MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_14MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_15MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_15MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_16MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_16MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_17MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_17MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_18MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_18MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_1MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_1MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_2MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_2MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_3MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_3MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_4MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_4MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_5MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_5MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_6MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_6MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_7MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_7MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_8MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_8MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NENGETSU_9MONTH_BEFORE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NENGETSU_9MONTH_BEFORE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENBAN_3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENBAN_3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
