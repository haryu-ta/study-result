/**
 * AMWFBNK__Unit__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class AMWFBNK__Unit__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String AMWFBNK__AppliCode__c;

    private java.lang.String AMWFBNK__AppliName__c;

    private java.lang.String AMWFBNK__CheckPoint1_10__c;

    private java.lang.String AMWFBNK__CheckPoint1_11__c;

    private java.lang.String AMWFBNK__CheckPoint1_12__c;

    private java.lang.String AMWFBNK__CheckPoint1_13__c;

    private java.lang.String AMWFBNK__CheckPoint1_14__c;

    private java.lang.String AMWFBNK__CheckPoint1_15__c;

    private java.lang.String AMWFBNK__CheckPoint1_16__c;

    private java.lang.String AMWFBNK__CheckPoint1_17__c;

    private java.lang.String AMWFBNK__CheckPoint1_18__c;

    private java.lang.String AMWFBNK__CheckPoint1_19__c;

    private java.lang.String AMWFBNK__CheckPoint1_1__c;

    private java.lang.String AMWFBNK__CheckPoint1_20__c;

    private java.lang.String AMWFBNK__CheckPoint1_2__c;

    private java.lang.String AMWFBNK__CheckPoint1_3__c;

    private java.lang.String AMWFBNK__CheckPoint1_4__c;

    private java.lang.String AMWFBNK__CheckPoint1_5__c;

    private java.lang.String AMWFBNK__CheckPoint1_6__c;

    private java.lang.String AMWFBNK__CheckPoint1_7__c;

    private java.lang.String AMWFBNK__CheckPoint1_8__c;

    private java.lang.String AMWFBNK__CheckPoint1_9__c;

    private java.lang.String AMWFBNK__CheckPoint2_10__c;

    private java.lang.String AMWFBNK__CheckPoint2_11__c;

    private java.lang.String AMWFBNK__CheckPoint2_12__c;

    private java.lang.String AMWFBNK__CheckPoint2_13__c;

    private java.lang.String AMWFBNK__CheckPoint2_14__c;

    private java.lang.String AMWFBNK__CheckPoint2_15__c;

    private java.lang.String AMWFBNK__CheckPoint2_16__c;

    private java.lang.String AMWFBNK__CheckPoint2_17__c;

    private java.lang.String AMWFBNK__CheckPoint2_18__c;

    private java.lang.String AMWFBNK__CheckPoint2_19__c;

    private java.lang.String AMWFBNK__CheckPoint2_1__c;

    private java.lang.String AMWFBNK__CheckPoint2_20__c;

    private java.lang.String AMWFBNK__CheckPoint2_2__c;

    private java.lang.String AMWFBNK__CheckPoint2_3__c;

    private java.lang.String AMWFBNK__CheckPoint2_4__c;

    private java.lang.String AMWFBNK__CheckPoint2_5__c;

    private java.lang.String AMWFBNK__CheckPoint2_6__c;

    private java.lang.String AMWFBNK__CheckPoint2_7__c;

    private java.lang.String AMWFBNK__CheckPoint2_8__c;

    private java.lang.String AMWFBNK__CheckPoint2_9__c;

    private java.lang.Boolean AMWFBNK__Checked1_10__c;

    private java.lang.Boolean AMWFBNK__Checked1_11__c;

    private java.lang.Boolean AMWFBNK__Checked1_12__c;

    private java.lang.Boolean AMWFBNK__Checked1_13__c;

    private java.lang.Boolean AMWFBNK__Checked1_14__c;

    private java.lang.Boolean AMWFBNK__Checked1_15__c;

    private java.lang.Boolean AMWFBNK__Checked1_16__c;

    private java.lang.Boolean AMWFBNK__Checked1_17__c;

    private java.lang.Boolean AMWFBNK__Checked1_18__c;

    private java.lang.Boolean AMWFBNK__Checked1_19__c;

    private java.lang.Boolean AMWFBNK__Checked1_1__c;

    private java.lang.Boolean AMWFBNK__Checked1_20__c;

    private java.lang.Boolean AMWFBNK__Checked1_2__c;

    private java.lang.Boolean AMWFBNK__Checked1_3__c;

    private java.lang.Boolean AMWFBNK__Checked1_4__c;

    private java.lang.Boolean AMWFBNK__Checked1_5__c;

    private java.lang.Boolean AMWFBNK__Checked1_6__c;

    private java.lang.Boolean AMWFBNK__Checked1_7__c;

    private java.lang.Boolean AMWFBNK__Checked1_8__c;

    private java.lang.Boolean AMWFBNK__Checked1_9__c;

    private java.lang.Boolean AMWFBNK__Checked2_10__c;

    private java.lang.Boolean AMWFBNK__Checked2_11__c;

    private java.lang.Boolean AMWFBNK__Checked2_12__c;

    private java.lang.Boolean AMWFBNK__Checked2_13__c;

    private java.lang.Boolean AMWFBNK__Checked2_14__c;

    private java.lang.Boolean AMWFBNK__Checked2_15__c;

    private java.lang.Boolean AMWFBNK__Checked2_16__c;

    private java.lang.Boolean AMWFBNK__Checked2_17__c;

    private java.lang.Boolean AMWFBNK__Checked2_18__c;

    private java.lang.Boolean AMWFBNK__Checked2_19__c;

    private java.lang.Boolean AMWFBNK__Checked2_1__c;

    private java.lang.Boolean AMWFBNK__Checked2_20__c;

    private java.lang.Boolean AMWFBNK__Checked2_2__c;

    private java.lang.Boolean AMWFBNK__Checked2_3__c;

    private java.lang.Boolean AMWFBNK__Checked2_4__c;

    private java.lang.Boolean AMWFBNK__Checked2_5__c;

    private java.lang.Boolean AMWFBNK__Checked2_6__c;

    private java.lang.Boolean AMWFBNK__Checked2_7__c;

    private java.lang.Boolean AMWFBNK__Checked2_8__c;

    private java.lang.Boolean AMWFBNK__Checked2_9__c;

    private java.lang.String AMWFBNK__FlowCode__c;

    private java.lang.String AMWFBNK__FlowType__c;

    private java.lang.Boolean AMWFBNK__FreeCheck1__c;

    private java.lang.Boolean AMWFBNK__FreeCheck2__c;

    private java.lang.Boolean AMWFBNK__FreeCheck3__c;

    private java.lang.Boolean AMWFBNK__FreeCheck4__c;

    private java.lang.Boolean AMWFBNK__FreeCheck5__c;

    private java.lang.String AMWFBNK__FreeText1__c;

    private java.lang.String AMWFBNK__FreeText2__c;

    private java.lang.String AMWFBNK__FreeText3__c;

    private java.lang.String AMWFBNK__FreeText4__c;

    private java.lang.String AMWFBNK__FreeText5__c;

    private java.lang.String AMWFBNK__GroupId1__c;

    private java.lang.String AMWFBNK__GroupId2__c;

    private java.lang.String AMWFBNK__GroupName1__c;

    private java.lang.String AMWFBNK__GroupName2__c;

    private java.lang.String AMWFBNK__ObjectName__c;

    private java.lang.String AMWFBNK__RecordId__c;

    private java.lang.String AMWFBNK__Status__c;

    private com.sforce.soap.enterprise.QueryResult AMWFBNK__SttnUnit__r;

    private java.lang.String AMWFBNK__URL__c;

    private java.lang.Boolean AMWFBNK__UpsertedByAPI__c;

    private java.lang.String AMWFBNK__User__c;

    private com.sforce.soap.enterprise.sobject.User AMWFBNK__User__r;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.util.Calendar CIRCULATEDLASTDATE__c;

    private java.lang.String CIRCULATEDNAME__c;

    private java.lang.String CIRCULATEDPOST__c;

    private java.lang.String CIRCULATEDSETID__c;

    private java.lang.String CIRCULATEDTOUSER__c;

    private com.sforce.soap.enterprise.sobject.User CIRCULATEDTOUSER__r;

    private java.lang.String CIRCULATEDUNIT__c;

    private java.lang.Boolean CONCURRENTFLAG1__c;

    private java.lang.Boolean CONCURRENTFLAG2__c;

    private java.lang.Boolean CONCURRENTFLAG__c;

    private java.lang.String CONDITIONSTEXT__c;

    private java.lang.Boolean CONDITIONS__c;

    private java.lang.String CONINDICATREPORT_TEXT__c;

    private java.lang.Boolean CONINDICATREPORT__c;

    private java.lang.String CONLASTMODIFIEDBY__c;

    private com.sforce.soap.enterprise.sobject.User CONLASTMODIFIEDBY__r;

    private java.util.Calendar CONLASTMODIFIEDDATE__c;

    private java.lang.String CONLASTMODIFIEDINFO__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Boolean DAIKO_FLG__c;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private java.lang.String IMPORTANT_TEXT__c;

    private java.lang.Boolean IMPORTANT__c;

    private java.lang.String INDICATIONTEXT__c;

    private java.lang.Boolean INDICATION__c;

    private java.lang.String INLASTMODIFIEDBY__c;

    private com.sforce.soap.enterprise.sobject.User INLASTMODIFIEDBY__r;

    private java.util.Calendar INLASTMODIFIEDDATE__c;

    private java.lang.String INLASTMODIFIEDINFO__c;

    private java.lang.Boolean isDeleted;

    private java.lang.String KAIFUSAKI_BUSHO__c;

    private java.lang.String KAIFUSAKI_SHIMEI__c;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.Boolean NON_DISPLAYFLAG__c;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.Boolean RATIFICATIONCHECK__c;

    private java.lang.String RATIFICATIONLIST__c;

    private java.lang.Boolean REFERENCECONCHECK__c;

    private java.lang.String REFERENCECONLIST__c;

    private java.lang.Boolean REPORTABLE__c;

    private java.lang.String SEARCH_TEXT__c;

    private java.lang.Double SORT_ORDER_STATUSCONFIRM__c;

    private java.lang.Double SORT_ORDER_WIDCIRCULATED__c;

    private java.util.Calendar systemModstamp;

    private java.lang.String TANTOSHA_BUSHO__c;

    private java.lang.String TANTOSHA_SHIMEI__c;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    public AMWFBNK__Unit__c() {
    }

    public AMWFBNK__Unit__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String AMWFBNK__AppliCode__c,
           java.lang.String AMWFBNK__AppliName__c,
           java.lang.String AMWFBNK__CheckPoint1_10__c,
           java.lang.String AMWFBNK__CheckPoint1_11__c,
           java.lang.String AMWFBNK__CheckPoint1_12__c,
           java.lang.String AMWFBNK__CheckPoint1_13__c,
           java.lang.String AMWFBNK__CheckPoint1_14__c,
           java.lang.String AMWFBNK__CheckPoint1_15__c,
           java.lang.String AMWFBNK__CheckPoint1_16__c,
           java.lang.String AMWFBNK__CheckPoint1_17__c,
           java.lang.String AMWFBNK__CheckPoint1_18__c,
           java.lang.String AMWFBNK__CheckPoint1_19__c,
           java.lang.String AMWFBNK__CheckPoint1_1__c,
           java.lang.String AMWFBNK__CheckPoint1_20__c,
           java.lang.String AMWFBNK__CheckPoint1_2__c,
           java.lang.String AMWFBNK__CheckPoint1_3__c,
           java.lang.String AMWFBNK__CheckPoint1_4__c,
           java.lang.String AMWFBNK__CheckPoint1_5__c,
           java.lang.String AMWFBNK__CheckPoint1_6__c,
           java.lang.String AMWFBNK__CheckPoint1_7__c,
           java.lang.String AMWFBNK__CheckPoint1_8__c,
           java.lang.String AMWFBNK__CheckPoint1_9__c,
           java.lang.String AMWFBNK__CheckPoint2_10__c,
           java.lang.String AMWFBNK__CheckPoint2_11__c,
           java.lang.String AMWFBNK__CheckPoint2_12__c,
           java.lang.String AMWFBNK__CheckPoint2_13__c,
           java.lang.String AMWFBNK__CheckPoint2_14__c,
           java.lang.String AMWFBNK__CheckPoint2_15__c,
           java.lang.String AMWFBNK__CheckPoint2_16__c,
           java.lang.String AMWFBNK__CheckPoint2_17__c,
           java.lang.String AMWFBNK__CheckPoint2_18__c,
           java.lang.String AMWFBNK__CheckPoint2_19__c,
           java.lang.String AMWFBNK__CheckPoint2_1__c,
           java.lang.String AMWFBNK__CheckPoint2_20__c,
           java.lang.String AMWFBNK__CheckPoint2_2__c,
           java.lang.String AMWFBNK__CheckPoint2_3__c,
           java.lang.String AMWFBNK__CheckPoint2_4__c,
           java.lang.String AMWFBNK__CheckPoint2_5__c,
           java.lang.String AMWFBNK__CheckPoint2_6__c,
           java.lang.String AMWFBNK__CheckPoint2_7__c,
           java.lang.String AMWFBNK__CheckPoint2_8__c,
           java.lang.String AMWFBNK__CheckPoint2_9__c,
           java.lang.Boolean AMWFBNK__Checked1_10__c,
           java.lang.Boolean AMWFBNK__Checked1_11__c,
           java.lang.Boolean AMWFBNK__Checked1_12__c,
           java.lang.Boolean AMWFBNK__Checked1_13__c,
           java.lang.Boolean AMWFBNK__Checked1_14__c,
           java.lang.Boolean AMWFBNK__Checked1_15__c,
           java.lang.Boolean AMWFBNK__Checked1_16__c,
           java.lang.Boolean AMWFBNK__Checked1_17__c,
           java.lang.Boolean AMWFBNK__Checked1_18__c,
           java.lang.Boolean AMWFBNK__Checked1_19__c,
           java.lang.Boolean AMWFBNK__Checked1_1__c,
           java.lang.Boolean AMWFBNK__Checked1_20__c,
           java.lang.Boolean AMWFBNK__Checked1_2__c,
           java.lang.Boolean AMWFBNK__Checked1_3__c,
           java.lang.Boolean AMWFBNK__Checked1_4__c,
           java.lang.Boolean AMWFBNK__Checked1_5__c,
           java.lang.Boolean AMWFBNK__Checked1_6__c,
           java.lang.Boolean AMWFBNK__Checked1_7__c,
           java.lang.Boolean AMWFBNK__Checked1_8__c,
           java.lang.Boolean AMWFBNK__Checked1_9__c,
           java.lang.Boolean AMWFBNK__Checked2_10__c,
           java.lang.Boolean AMWFBNK__Checked2_11__c,
           java.lang.Boolean AMWFBNK__Checked2_12__c,
           java.lang.Boolean AMWFBNK__Checked2_13__c,
           java.lang.Boolean AMWFBNK__Checked2_14__c,
           java.lang.Boolean AMWFBNK__Checked2_15__c,
           java.lang.Boolean AMWFBNK__Checked2_16__c,
           java.lang.Boolean AMWFBNK__Checked2_17__c,
           java.lang.Boolean AMWFBNK__Checked2_18__c,
           java.lang.Boolean AMWFBNK__Checked2_19__c,
           java.lang.Boolean AMWFBNK__Checked2_1__c,
           java.lang.Boolean AMWFBNK__Checked2_20__c,
           java.lang.Boolean AMWFBNK__Checked2_2__c,
           java.lang.Boolean AMWFBNK__Checked2_3__c,
           java.lang.Boolean AMWFBNK__Checked2_4__c,
           java.lang.Boolean AMWFBNK__Checked2_5__c,
           java.lang.Boolean AMWFBNK__Checked2_6__c,
           java.lang.Boolean AMWFBNK__Checked2_7__c,
           java.lang.Boolean AMWFBNK__Checked2_8__c,
           java.lang.Boolean AMWFBNK__Checked2_9__c,
           java.lang.String AMWFBNK__FlowCode__c,
           java.lang.String AMWFBNK__FlowType__c,
           java.lang.Boolean AMWFBNK__FreeCheck1__c,
           java.lang.Boolean AMWFBNK__FreeCheck2__c,
           java.lang.Boolean AMWFBNK__FreeCheck3__c,
           java.lang.Boolean AMWFBNK__FreeCheck4__c,
           java.lang.Boolean AMWFBNK__FreeCheck5__c,
           java.lang.String AMWFBNK__FreeText1__c,
           java.lang.String AMWFBNK__FreeText2__c,
           java.lang.String AMWFBNK__FreeText3__c,
           java.lang.String AMWFBNK__FreeText4__c,
           java.lang.String AMWFBNK__FreeText5__c,
           java.lang.String AMWFBNK__GroupId1__c,
           java.lang.String AMWFBNK__GroupId2__c,
           java.lang.String AMWFBNK__GroupName1__c,
           java.lang.String AMWFBNK__GroupName2__c,
           java.lang.String AMWFBNK__ObjectName__c,
           java.lang.String AMWFBNK__RecordId__c,
           java.lang.String AMWFBNK__Status__c,
           com.sforce.soap.enterprise.QueryResult AMWFBNK__SttnUnit__r,
           java.lang.String AMWFBNK__URL__c,
           java.lang.Boolean AMWFBNK__UpsertedByAPI__c,
           java.lang.String AMWFBNK__User__c,
           com.sforce.soap.enterprise.sobject.User AMWFBNK__User__r,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.util.Calendar CIRCULATEDLASTDATE__c,
           java.lang.String CIRCULATEDNAME__c,
           java.lang.String CIRCULATEDPOST__c,
           java.lang.String CIRCULATEDSETID__c,
           java.lang.String CIRCULATEDTOUSER__c,
           com.sforce.soap.enterprise.sobject.User CIRCULATEDTOUSER__r,
           java.lang.String CIRCULATEDUNIT__c,
           java.lang.Boolean CONCURRENTFLAG1__c,
           java.lang.Boolean CONCURRENTFLAG2__c,
           java.lang.Boolean CONCURRENTFLAG__c,
           java.lang.String CONDITIONSTEXT__c,
           java.lang.Boolean CONDITIONS__c,
           java.lang.String CONINDICATREPORT_TEXT__c,
           java.lang.Boolean CONINDICATREPORT__c,
           java.lang.String CONLASTMODIFIEDBY__c,
           com.sforce.soap.enterprise.sobject.User CONLASTMODIFIEDBY__r,
           java.util.Calendar CONLASTMODIFIEDDATE__c,
           java.lang.String CONLASTMODIFIEDINFO__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Boolean DAIKO_FLG__c,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           java.lang.String IMPORTANT_TEXT__c,
           java.lang.Boolean IMPORTANT__c,
           java.lang.String INDICATIONTEXT__c,
           java.lang.Boolean INDICATION__c,
           java.lang.String INLASTMODIFIEDBY__c,
           com.sforce.soap.enterprise.sobject.User INLASTMODIFIEDBY__r,
           java.util.Calendar INLASTMODIFIEDDATE__c,
           java.lang.String INLASTMODIFIEDINFO__c,
           java.lang.Boolean isDeleted,
           java.lang.String KAIFUSAKI_BUSHO__c,
           java.lang.String KAIFUSAKI_SHIMEI__c,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.Boolean NON_DISPLAYFLAG__c,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.Boolean RATIFICATIONCHECK__c,
           java.lang.String RATIFICATIONLIST__c,
           java.lang.Boolean REFERENCECONCHECK__c,
           java.lang.String REFERENCECONLIST__c,
           java.lang.Boolean REPORTABLE__c,
           java.lang.String SEARCH_TEXT__c,
           java.lang.Double SORT_ORDER_STATUSCONFIRM__c,
           java.lang.Double SORT_ORDER_WIDCIRCULATED__c,
           java.util.Calendar systemModstamp,
           java.lang.String TANTOSHA_BUSHO__c,
           java.lang.String TANTOSHA_SHIMEI__c,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        super(
            fieldsToNull,
            id);
        this.AMWFBNK__AppliCode__c = AMWFBNK__AppliCode__c;
        this.AMWFBNK__AppliName__c = AMWFBNK__AppliName__c;
        this.AMWFBNK__CheckPoint1_10__c = AMWFBNK__CheckPoint1_10__c;
        this.AMWFBNK__CheckPoint1_11__c = AMWFBNK__CheckPoint1_11__c;
        this.AMWFBNK__CheckPoint1_12__c = AMWFBNK__CheckPoint1_12__c;
        this.AMWFBNK__CheckPoint1_13__c = AMWFBNK__CheckPoint1_13__c;
        this.AMWFBNK__CheckPoint1_14__c = AMWFBNK__CheckPoint1_14__c;
        this.AMWFBNK__CheckPoint1_15__c = AMWFBNK__CheckPoint1_15__c;
        this.AMWFBNK__CheckPoint1_16__c = AMWFBNK__CheckPoint1_16__c;
        this.AMWFBNK__CheckPoint1_17__c = AMWFBNK__CheckPoint1_17__c;
        this.AMWFBNK__CheckPoint1_18__c = AMWFBNK__CheckPoint1_18__c;
        this.AMWFBNK__CheckPoint1_19__c = AMWFBNK__CheckPoint1_19__c;
        this.AMWFBNK__CheckPoint1_1__c = AMWFBNK__CheckPoint1_1__c;
        this.AMWFBNK__CheckPoint1_20__c = AMWFBNK__CheckPoint1_20__c;
        this.AMWFBNK__CheckPoint1_2__c = AMWFBNK__CheckPoint1_2__c;
        this.AMWFBNK__CheckPoint1_3__c = AMWFBNK__CheckPoint1_3__c;
        this.AMWFBNK__CheckPoint1_4__c = AMWFBNK__CheckPoint1_4__c;
        this.AMWFBNK__CheckPoint1_5__c = AMWFBNK__CheckPoint1_5__c;
        this.AMWFBNK__CheckPoint1_6__c = AMWFBNK__CheckPoint1_6__c;
        this.AMWFBNK__CheckPoint1_7__c = AMWFBNK__CheckPoint1_7__c;
        this.AMWFBNK__CheckPoint1_8__c = AMWFBNK__CheckPoint1_8__c;
        this.AMWFBNK__CheckPoint1_9__c = AMWFBNK__CheckPoint1_9__c;
        this.AMWFBNK__CheckPoint2_10__c = AMWFBNK__CheckPoint2_10__c;
        this.AMWFBNK__CheckPoint2_11__c = AMWFBNK__CheckPoint2_11__c;
        this.AMWFBNK__CheckPoint2_12__c = AMWFBNK__CheckPoint2_12__c;
        this.AMWFBNK__CheckPoint2_13__c = AMWFBNK__CheckPoint2_13__c;
        this.AMWFBNK__CheckPoint2_14__c = AMWFBNK__CheckPoint2_14__c;
        this.AMWFBNK__CheckPoint2_15__c = AMWFBNK__CheckPoint2_15__c;
        this.AMWFBNK__CheckPoint2_16__c = AMWFBNK__CheckPoint2_16__c;
        this.AMWFBNK__CheckPoint2_17__c = AMWFBNK__CheckPoint2_17__c;
        this.AMWFBNK__CheckPoint2_18__c = AMWFBNK__CheckPoint2_18__c;
        this.AMWFBNK__CheckPoint2_19__c = AMWFBNK__CheckPoint2_19__c;
        this.AMWFBNK__CheckPoint2_1__c = AMWFBNK__CheckPoint2_1__c;
        this.AMWFBNK__CheckPoint2_20__c = AMWFBNK__CheckPoint2_20__c;
        this.AMWFBNK__CheckPoint2_2__c = AMWFBNK__CheckPoint2_2__c;
        this.AMWFBNK__CheckPoint2_3__c = AMWFBNK__CheckPoint2_3__c;
        this.AMWFBNK__CheckPoint2_4__c = AMWFBNK__CheckPoint2_4__c;
        this.AMWFBNK__CheckPoint2_5__c = AMWFBNK__CheckPoint2_5__c;
        this.AMWFBNK__CheckPoint2_6__c = AMWFBNK__CheckPoint2_6__c;
        this.AMWFBNK__CheckPoint2_7__c = AMWFBNK__CheckPoint2_7__c;
        this.AMWFBNK__CheckPoint2_8__c = AMWFBNK__CheckPoint2_8__c;
        this.AMWFBNK__CheckPoint2_9__c = AMWFBNK__CheckPoint2_9__c;
        this.AMWFBNK__Checked1_10__c = AMWFBNK__Checked1_10__c;
        this.AMWFBNK__Checked1_11__c = AMWFBNK__Checked1_11__c;
        this.AMWFBNK__Checked1_12__c = AMWFBNK__Checked1_12__c;
        this.AMWFBNK__Checked1_13__c = AMWFBNK__Checked1_13__c;
        this.AMWFBNK__Checked1_14__c = AMWFBNK__Checked1_14__c;
        this.AMWFBNK__Checked1_15__c = AMWFBNK__Checked1_15__c;
        this.AMWFBNK__Checked1_16__c = AMWFBNK__Checked1_16__c;
        this.AMWFBNK__Checked1_17__c = AMWFBNK__Checked1_17__c;
        this.AMWFBNK__Checked1_18__c = AMWFBNK__Checked1_18__c;
        this.AMWFBNK__Checked1_19__c = AMWFBNK__Checked1_19__c;
        this.AMWFBNK__Checked1_1__c = AMWFBNK__Checked1_1__c;
        this.AMWFBNK__Checked1_20__c = AMWFBNK__Checked1_20__c;
        this.AMWFBNK__Checked1_2__c = AMWFBNK__Checked1_2__c;
        this.AMWFBNK__Checked1_3__c = AMWFBNK__Checked1_3__c;
        this.AMWFBNK__Checked1_4__c = AMWFBNK__Checked1_4__c;
        this.AMWFBNK__Checked1_5__c = AMWFBNK__Checked1_5__c;
        this.AMWFBNK__Checked1_6__c = AMWFBNK__Checked1_6__c;
        this.AMWFBNK__Checked1_7__c = AMWFBNK__Checked1_7__c;
        this.AMWFBNK__Checked1_8__c = AMWFBNK__Checked1_8__c;
        this.AMWFBNK__Checked1_9__c = AMWFBNK__Checked1_9__c;
        this.AMWFBNK__Checked2_10__c = AMWFBNK__Checked2_10__c;
        this.AMWFBNK__Checked2_11__c = AMWFBNK__Checked2_11__c;
        this.AMWFBNK__Checked2_12__c = AMWFBNK__Checked2_12__c;
        this.AMWFBNK__Checked2_13__c = AMWFBNK__Checked2_13__c;
        this.AMWFBNK__Checked2_14__c = AMWFBNK__Checked2_14__c;
        this.AMWFBNK__Checked2_15__c = AMWFBNK__Checked2_15__c;
        this.AMWFBNK__Checked2_16__c = AMWFBNK__Checked2_16__c;
        this.AMWFBNK__Checked2_17__c = AMWFBNK__Checked2_17__c;
        this.AMWFBNK__Checked2_18__c = AMWFBNK__Checked2_18__c;
        this.AMWFBNK__Checked2_19__c = AMWFBNK__Checked2_19__c;
        this.AMWFBNK__Checked2_1__c = AMWFBNK__Checked2_1__c;
        this.AMWFBNK__Checked2_20__c = AMWFBNK__Checked2_20__c;
        this.AMWFBNK__Checked2_2__c = AMWFBNK__Checked2_2__c;
        this.AMWFBNK__Checked2_3__c = AMWFBNK__Checked2_3__c;
        this.AMWFBNK__Checked2_4__c = AMWFBNK__Checked2_4__c;
        this.AMWFBNK__Checked2_5__c = AMWFBNK__Checked2_5__c;
        this.AMWFBNK__Checked2_6__c = AMWFBNK__Checked2_6__c;
        this.AMWFBNK__Checked2_7__c = AMWFBNK__Checked2_7__c;
        this.AMWFBNK__Checked2_8__c = AMWFBNK__Checked2_8__c;
        this.AMWFBNK__Checked2_9__c = AMWFBNK__Checked2_9__c;
        this.AMWFBNK__FlowCode__c = AMWFBNK__FlowCode__c;
        this.AMWFBNK__FlowType__c = AMWFBNK__FlowType__c;
        this.AMWFBNK__FreeCheck1__c = AMWFBNK__FreeCheck1__c;
        this.AMWFBNK__FreeCheck2__c = AMWFBNK__FreeCheck2__c;
        this.AMWFBNK__FreeCheck3__c = AMWFBNK__FreeCheck3__c;
        this.AMWFBNK__FreeCheck4__c = AMWFBNK__FreeCheck4__c;
        this.AMWFBNK__FreeCheck5__c = AMWFBNK__FreeCheck5__c;
        this.AMWFBNK__FreeText1__c = AMWFBNK__FreeText1__c;
        this.AMWFBNK__FreeText2__c = AMWFBNK__FreeText2__c;
        this.AMWFBNK__FreeText3__c = AMWFBNK__FreeText3__c;
        this.AMWFBNK__FreeText4__c = AMWFBNK__FreeText4__c;
        this.AMWFBNK__FreeText5__c = AMWFBNK__FreeText5__c;
        this.AMWFBNK__GroupId1__c = AMWFBNK__GroupId1__c;
        this.AMWFBNK__GroupId2__c = AMWFBNK__GroupId2__c;
        this.AMWFBNK__GroupName1__c = AMWFBNK__GroupName1__c;
        this.AMWFBNK__GroupName2__c = AMWFBNK__GroupName2__c;
        this.AMWFBNK__ObjectName__c = AMWFBNK__ObjectName__c;
        this.AMWFBNK__RecordId__c = AMWFBNK__RecordId__c;
        this.AMWFBNK__Status__c = AMWFBNK__Status__c;
        this.AMWFBNK__SttnUnit__r = AMWFBNK__SttnUnit__r;
        this.AMWFBNK__URL__c = AMWFBNK__URL__c;
        this.AMWFBNK__UpsertedByAPI__c = AMWFBNK__UpsertedByAPI__c;
        this.AMWFBNK__User__c = AMWFBNK__User__c;
        this.AMWFBNK__User__r = AMWFBNK__User__r;
        this.attachments = attachments;
        this.CIRCULATEDLASTDATE__c = CIRCULATEDLASTDATE__c;
        this.CIRCULATEDNAME__c = CIRCULATEDNAME__c;
        this.CIRCULATEDPOST__c = CIRCULATEDPOST__c;
        this.CIRCULATEDSETID__c = CIRCULATEDSETID__c;
        this.CIRCULATEDTOUSER__c = CIRCULATEDTOUSER__c;
        this.CIRCULATEDTOUSER__r = CIRCULATEDTOUSER__r;
        this.CIRCULATEDUNIT__c = CIRCULATEDUNIT__c;
        this.CONCURRENTFLAG1__c = CONCURRENTFLAG1__c;
        this.CONCURRENTFLAG2__c = CONCURRENTFLAG2__c;
        this.CONCURRENTFLAG__c = CONCURRENTFLAG__c;
        this.CONDITIONSTEXT__c = CONDITIONSTEXT__c;
        this.CONDITIONS__c = CONDITIONS__c;
        this.CONINDICATREPORT_TEXT__c = CONINDICATREPORT_TEXT__c;
        this.CONINDICATREPORT__c = CONINDICATREPORT__c;
        this.CONLASTMODIFIEDBY__c = CONLASTMODIFIEDBY__c;
        this.CONLASTMODIFIEDBY__r = CONLASTMODIFIEDBY__r;
        this.CONLASTMODIFIEDDATE__c = CONLASTMODIFIEDDATE__c;
        this.CONLASTMODIFIEDINFO__c = CONLASTMODIFIEDINFO__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.DAIKO_FLG__c = DAIKO_FLG__c;
        this.duplicateRecordItems = duplicateRecordItems;
        this.IMPORTANT_TEXT__c = IMPORTANT_TEXT__c;
        this.IMPORTANT__c = IMPORTANT__c;
        this.INDICATIONTEXT__c = INDICATIONTEXT__c;
        this.INDICATION__c = INDICATION__c;
        this.INLASTMODIFIEDBY__c = INLASTMODIFIEDBY__c;
        this.INLASTMODIFIEDBY__r = INLASTMODIFIEDBY__r;
        this.INLASTMODIFIEDDATE__c = INLASTMODIFIEDDATE__c;
        this.INLASTMODIFIEDINFO__c = INLASTMODIFIEDINFO__c;
        this.isDeleted = isDeleted;
        this.KAIFUSAKI_BUSHO__c = KAIFUSAKI_BUSHO__c;
        this.KAIFUSAKI_SHIMEI__c = KAIFUSAKI_SHIMEI__c;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.NON_DISPLAYFLAG__c = NON_DISPLAYFLAG__c;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.RATIFICATIONCHECK__c = RATIFICATIONCHECK__c;
        this.RATIFICATIONLIST__c = RATIFICATIONLIST__c;
        this.REFERENCECONCHECK__c = REFERENCECONCHECK__c;
        this.REFERENCECONLIST__c = REFERENCECONLIST__c;
        this.REPORTABLE__c = REPORTABLE__c;
        this.SEARCH_TEXT__c = SEARCH_TEXT__c;
        this.SORT_ORDER_STATUSCONFIRM__c = SORT_ORDER_STATUSCONFIRM__c;
        this.SORT_ORDER_WIDCIRCULATED__c = SORT_ORDER_WIDCIRCULATED__c;
        this.systemModstamp = systemModstamp;
        this.TANTOSHA_BUSHO__c = TANTOSHA_BUSHO__c;
        this.TANTOSHA_SHIMEI__c = TANTOSHA_SHIMEI__c;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the AMWFBNK__AppliCode__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__AppliCode__c
     */
    public java.lang.String getAMWFBNK__AppliCode__c() {
        return AMWFBNK__AppliCode__c;
    }


    /**
     * Sets the AMWFBNK__AppliCode__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__AppliCode__c
     */
    public void setAMWFBNK__AppliCode__c(java.lang.String AMWFBNK__AppliCode__c) {
        this.AMWFBNK__AppliCode__c = AMWFBNK__AppliCode__c;
    }


    /**
     * Gets the AMWFBNK__AppliName__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__AppliName__c
     */
    public java.lang.String getAMWFBNK__AppliName__c() {
        return AMWFBNK__AppliName__c;
    }


    /**
     * Sets the AMWFBNK__AppliName__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__AppliName__c
     */
    public void setAMWFBNK__AppliName__c(java.lang.String AMWFBNK__AppliName__c) {
        this.AMWFBNK__AppliName__c = AMWFBNK__AppliName__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_10__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_10__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_10__c() {
        return AMWFBNK__CheckPoint1_10__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_10__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_10__c
     */
    public void setAMWFBNK__CheckPoint1_10__c(java.lang.String AMWFBNK__CheckPoint1_10__c) {
        this.AMWFBNK__CheckPoint1_10__c = AMWFBNK__CheckPoint1_10__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_11__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_11__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_11__c() {
        return AMWFBNK__CheckPoint1_11__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_11__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_11__c
     */
    public void setAMWFBNK__CheckPoint1_11__c(java.lang.String AMWFBNK__CheckPoint1_11__c) {
        this.AMWFBNK__CheckPoint1_11__c = AMWFBNK__CheckPoint1_11__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_12__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_12__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_12__c() {
        return AMWFBNK__CheckPoint1_12__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_12__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_12__c
     */
    public void setAMWFBNK__CheckPoint1_12__c(java.lang.String AMWFBNK__CheckPoint1_12__c) {
        this.AMWFBNK__CheckPoint1_12__c = AMWFBNK__CheckPoint1_12__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_13__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_13__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_13__c() {
        return AMWFBNK__CheckPoint1_13__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_13__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_13__c
     */
    public void setAMWFBNK__CheckPoint1_13__c(java.lang.String AMWFBNK__CheckPoint1_13__c) {
        this.AMWFBNK__CheckPoint1_13__c = AMWFBNK__CheckPoint1_13__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_14__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_14__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_14__c() {
        return AMWFBNK__CheckPoint1_14__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_14__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_14__c
     */
    public void setAMWFBNK__CheckPoint1_14__c(java.lang.String AMWFBNK__CheckPoint1_14__c) {
        this.AMWFBNK__CheckPoint1_14__c = AMWFBNK__CheckPoint1_14__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_15__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_15__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_15__c() {
        return AMWFBNK__CheckPoint1_15__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_15__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_15__c
     */
    public void setAMWFBNK__CheckPoint1_15__c(java.lang.String AMWFBNK__CheckPoint1_15__c) {
        this.AMWFBNK__CheckPoint1_15__c = AMWFBNK__CheckPoint1_15__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_16__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_16__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_16__c() {
        return AMWFBNK__CheckPoint1_16__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_16__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_16__c
     */
    public void setAMWFBNK__CheckPoint1_16__c(java.lang.String AMWFBNK__CheckPoint1_16__c) {
        this.AMWFBNK__CheckPoint1_16__c = AMWFBNK__CheckPoint1_16__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_17__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_17__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_17__c() {
        return AMWFBNK__CheckPoint1_17__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_17__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_17__c
     */
    public void setAMWFBNK__CheckPoint1_17__c(java.lang.String AMWFBNK__CheckPoint1_17__c) {
        this.AMWFBNK__CheckPoint1_17__c = AMWFBNK__CheckPoint1_17__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_18__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_18__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_18__c() {
        return AMWFBNK__CheckPoint1_18__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_18__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_18__c
     */
    public void setAMWFBNK__CheckPoint1_18__c(java.lang.String AMWFBNK__CheckPoint1_18__c) {
        this.AMWFBNK__CheckPoint1_18__c = AMWFBNK__CheckPoint1_18__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_19__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_19__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_19__c() {
        return AMWFBNK__CheckPoint1_19__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_19__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_19__c
     */
    public void setAMWFBNK__CheckPoint1_19__c(java.lang.String AMWFBNK__CheckPoint1_19__c) {
        this.AMWFBNK__CheckPoint1_19__c = AMWFBNK__CheckPoint1_19__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_1__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_1__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_1__c() {
        return AMWFBNK__CheckPoint1_1__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_1__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_1__c
     */
    public void setAMWFBNK__CheckPoint1_1__c(java.lang.String AMWFBNK__CheckPoint1_1__c) {
        this.AMWFBNK__CheckPoint1_1__c = AMWFBNK__CheckPoint1_1__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_20__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_20__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_20__c() {
        return AMWFBNK__CheckPoint1_20__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_20__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_20__c
     */
    public void setAMWFBNK__CheckPoint1_20__c(java.lang.String AMWFBNK__CheckPoint1_20__c) {
        this.AMWFBNK__CheckPoint1_20__c = AMWFBNK__CheckPoint1_20__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_2__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_2__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_2__c() {
        return AMWFBNK__CheckPoint1_2__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_2__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_2__c
     */
    public void setAMWFBNK__CheckPoint1_2__c(java.lang.String AMWFBNK__CheckPoint1_2__c) {
        this.AMWFBNK__CheckPoint1_2__c = AMWFBNK__CheckPoint1_2__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_3__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_3__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_3__c() {
        return AMWFBNK__CheckPoint1_3__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_3__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_3__c
     */
    public void setAMWFBNK__CheckPoint1_3__c(java.lang.String AMWFBNK__CheckPoint1_3__c) {
        this.AMWFBNK__CheckPoint1_3__c = AMWFBNK__CheckPoint1_3__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_4__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_4__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_4__c() {
        return AMWFBNK__CheckPoint1_4__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_4__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_4__c
     */
    public void setAMWFBNK__CheckPoint1_4__c(java.lang.String AMWFBNK__CheckPoint1_4__c) {
        this.AMWFBNK__CheckPoint1_4__c = AMWFBNK__CheckPoint1_4__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_5__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_5__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_5__c() {
        return AMWFBNK__CheckPoint1_5__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_5__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_5__c
     */
    public void setAMWFBNK__CheckPoint1_5__c(java.lang.String AMWFBNK__CheckPoint1_5__c) {
        this.AMWFBNK__CheckPoint1_5__c = AMWFBNK__CheckPoint1_5__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_6__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_6__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_6__c() {
        return AMWFBNK__CheckPoint1_6__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_6__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_6__c
     */
    public void setAMWFBNK__CheckPoint1_6__c(java.lang.String AMWFBNK__CheckPoint1_6__c) {
        this.AMWFBNK__CheckPoint1_6__c = AMWFBNK__CheckPoint1_6__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_7__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_7__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_7__c() {
        return AMWFBNK__CheckPoint1_7__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_7__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_7__c
     */
    public void setAMWFBNK__CheckPoint1_7__c(java.lang.String AMWFBNK__CheckPoint1_7__c) {
        this.AMWFBNK__CheckPoint1_7__c = AMWFBNK__CheckPoint1_7__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_8__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_8__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_8__c() {
        return AMWFBNK__CheckPoint1_8__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_8__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_8__c
     */
    public void setAMWFBNK__CheckPoint1_8__c(java.lang.String AMWFBNK__CheckPoint1_8__c) {
        this.AMWFBNK__CheckPoint1_8__c = AMWFBNK__CheckPoint1_8__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint1_9__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint1_9__c
     */
    public java.lang.String getAMWFBNK__CheckPoint1_9__c() {
        return AMWFBNK__CheckPoint1_9__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint1_9__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint1_9__c
     */
    public void setAMWFBNK__CheckPoint1_9__c(java.lang.String AMWFBNK__CheckPoint1_9__c) {
        this.AMWFBNK__CheckPoint1_9__c = AMWFBNK__CheckPoint1_9__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_10__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_10__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_10__c() {
        return AMWFBNK__CheckPoint2_10__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_10__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_10__c
     */
    public void setAMWFBNK__CheckPoint2_10__c(java.lang.String AMWFBNK__CheckPoint2_10__c) {
        this.AMWFBNK__CheckPoint2_10__c = AMWFBNK__CheckPoint2_10__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_11__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_11__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_11__c() {
        return AMWFBNK__CheckPoint2_11__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_11__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_11__c
     */
    public void setAMWFBNK__CheckPoint2_11__c(java.lang.String AMWFBNK__CheckPoint2_11__c) {
        this.AMWFBNK__CheckPoint2_11__c = AMWFBNK__CheckPoint2_11__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_12__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_12__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_12__c() {
        return AMWFBNK__CheckPoint2_12__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_12__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_12__c
     */
    public void setAMWFBNK__CheckPoint2_12__c(java.lang.String AMWFBNK__CheckPoint2_12__c) {
        this.AMWFBNK__CheckPoint2_12__c = AMWFBNK__CheckPoint2_12__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_13__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_13__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_13__c() {
        return AMWFBNK__CheckPoint2_13__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_13__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_13__c
     */
    public void setAMWFBNK__CheckPoint2_13__c(java.lang.String AMWFBNK__CheckPoint2_13__c) {
        this.AMWFBNK__CheckPoint2_13__c = AMWFBNK__CheckPoint2_13__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_14__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_14__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_14__c() {
        return AMWFBNK__CheckPoint2_14__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_14__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_14__c
     */
    public void setAMWFBNK__CheckPoint2_14__c(java.lang.String AMWFBNK__CheckPoint2_14__c) {
        this.AMWFBNK__CheckPoint2_14__c = AMWFBNK__CheckPoint2_14__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_15__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_15__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_15__c() {
        return AMWFBNK__CheckPoint2_15__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_15__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_15__c
     */
    public void setAMWFBNK__CheckPoint2_15__c(java.lang.String AMWFBNK__CheckPoint2_15__c) {
        this.AMWFBNK__CheckPoint2_15__c = AMWFBNK__CheckPoint2_15__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_16__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_16__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_16__c() {
        return AMWFBNK__CheckPoint2_16__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_16__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_16__c
     */
    public void setAMWFBNK__CheckPoint2_16__c(java.lang.String AMWFBNK__CheckPoint2_16__c) {
        this.AMWFBNK__CheckPoint2_16__c = AMWFBNK__CheckPoint2_16__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_17__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_17__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_17__c() {
        return AMWFBNK__CheckPoint2_17__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_17__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_17__c
     */
    public void setAMWFBNK__CheckPoint2_17__c(java.lang.String AMWFBNK__CheckPoint2_17__c) {
        this.AMWFBNK__CheckPoint2_17__c = AMWFBNK__CheckPoint2_17__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_18__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_18__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_18__c() {
        return AMWFBNK__CheckPoint2_18__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_18__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_18__c
     */
    public void setAMWFBNK__CheckPoint2_18__c(java.lang.String AMWFBNK__CheckPoint2_18__c) {
        this.AMWFBNK__CheckPoint2_18__c = AMWFBNK__CheckPoint2_18__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_19__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_19__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_19__c() {
        return AMWFBNK__CheckPoint2_19__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_19__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_19__c
     */
    public void setAMWFBNK__CheckPoint2_19__c(java.lang.String AMWFBNK__CheckPoint2_19__c) {
        this.AMWFBNK__CheckPoint2_19__c = AMWFBNK__CheckPoint2_19__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_1__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_1__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_1__c() {
        return AMWFBNK__CheckPoint2_1__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_1__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_1__c
     */
    public void setAMWFBNK__CheckPoint2_1__c(java.lang.String AMWFBNK__CheckPoint2_1__c) {
        this.AMWFBNK__CheckPoint2_1__c = AMWFBNK__CheckPoint2_1__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_20__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_20__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_20__c() {
        return AMWFBNK__CheckPoint2_20__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_20__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_20__c
     */
    public void setAMWFBNK__CheckPoint2_20__c(java.lang.String AMWFBNK__CheckPoint2_20__c) {
        this.AMWFBNK__CheckPoint2_20__c = AMWFBNK__CheckPoint2_20__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_2__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_2__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_2__c() {
        return AMWFBNK__CheckPoint2_2__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_2__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_2__c
     */
    public void setAMWFBNK__CheckPoint2_2__c(java.lang.String AMWFBNK__CheckPoint2_2__c) {
        this.AMWFBNK__CheckPoint2_2__c = AMWFBNK__CheckPoint2_2__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_3__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_3__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_3__c() {
        return AMWFBNK__CheckPoint2_3__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_3__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_3__c
     */
    public void setAMWFBNK__CheckPoint2_3__c(java.lang.String AMWFBNK__CheckPoint2_3__c) {
        this.AMWFBNK__CheckPoint2_3__c = AMWFBNK__CheckPoint2_3__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_4__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_4__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_4__c() {
        return AMWFBNK__CheckPoint2_4__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_4__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_4__c
     */
    public void setAMWFBNK__CheckPoint2_4__c(java.lang.String AMWFBNK__CheckPoint2_4__c) {
        this.AMWFBNK__CheckPoint2_4__c = AMWFBNK__CheckPoint2_4__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_5__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_5__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_5__c() {
        return AMWFBNK__CheckPoint2_5__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_5__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_5__c
     */
    public void setAMWFBNK__CheckPoint2_5__c(java.lang.String AMWFBNK__CheckPoint2_5__c) {
        this.AMWFBNK__CheckPoint2_5__c = AMWFBNK__CheckPoint2_5__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_6__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_6__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_6__c() {
        return AMWFBNK__CheckPoint2_6__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_6__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_6__c
     */
    public void setAMWFBNK__CheckPoint2_6__c(java.lang.String AMWFBNK__CheckPoint2_6__c) {
        this.AMWFBNK__CheckPoint2_6__c = AMWFBNK__CheckPoint2_6__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_7__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_7__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_7__c() {
        return AMWFBNK__CheckPoint2_7__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_7__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_7__c
     */
    public void setAMWFBNK__CheckPoint2_7__c(java.lang.String AMWFBNK__CheckPoint2_7__c) {
        this.AMWFBNK__CheckPoint2_7__c = AMWFBNK__CheckPoint2_7__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_8__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_8__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_8__c() {
        return AMWFBNK__CheckPoint2_8__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_8__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_8__c
     */
    public void setAMWFBNK__CheckPoint2_8__c(java.lang.String AMWFBNK__CheckPoint2_8__c) {
        this.AMWFBNK__CheckPoint2_8__c = AMWFBNK__CheckPoint2_8__c;
    }


    /**
     * Gets the AMWFBNK__CheckPoint2_9__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__CheckPoint2_9__c
     */
    public java.lang.String getAMWFBNK__CheckPoint2_9__c() {
        return AMWFBNK__CheckPoint2_9__c;
    }


    /**
     * Sets the AMWFBNK__CheckPoint2_9__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__CheckPoint2_9__c
     */
    public void setAMWFBNK__CheckPoint2_9__c(java.lang.String AMWFBNK__CheckPoint2_9__c) {
        this.AMWFBNK__CheckPoint2_9__c = AMWFBNK__CheckPoint2_9__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_10__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_10__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_10__c() {
        return AMWFBNK__Checked1_10__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_10__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_10__c
     */
    public void setAMWFBNK__Checked1_10__c(java.lang.Boolean AMWFBNK__Checked1_10__c) {
        this.AMWFBNK__Checked1_10__c = AMWFBNK__Checked1_10__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_11__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_11__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_11__c() {
        return AMWFBNK__Checked1_11__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_11__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_11__c
     */
    public void setAMWFBNK__Checked1_11__c(java.lang.Boolean AMWFBNK__Checked1_11__c) {
        this.AMWFBNK__Checked1_11__c = AMWFBNK__Checked1_11__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_12__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_12__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_12__c() {
        return AMWFBNK__Checked1_12__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_12__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_12__c
     */
    public void setAMWFBNK__Checked1_12__c(java.lang.Boolean AMWFBNK__Checked1_12__c) {
        this.AMWFBNK__Checked1_12__c = AMWFBNK__Checked1_12__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_13__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_13__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_13__c() {
        return AMWFBNK__Checked1_13__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_13__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_13__c
     */
    public void setAMWFBNK__Checked1_13__c(java.lang.Boolean AMWFBNK__Checked1_13__c) {
        this.AMWFBNK__Checked1_13__c = AMWFBNK__Checked1_13__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_14__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_14__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_14__c() {
        return AMWFBNK__Checked1_14__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_14__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_14__c
     */
    public void setAMWFBNK__Checked1_14__c(java.lang.Boolean AMWFBNK__Checked1_14__c) {
        this.AMWFBNK__Checked1_14__c = AMWFBNK__Checked1_14__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_15__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_15__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_15__c() {
        return AMWFBNK__Checked1_15__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_15__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_15__c
     */
    public void setAMWFBNK__Checked1_15__c(java.lang.Boolean AMWFBNK__Checked1_15__c) {
        this.AMWFBNK__Checked1_15__c = AMWFBNK__Checked1_15__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_16__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_16__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_16__c() {
        return AMWFBNK__Checked1_16__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_16__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_16__c
     */
    public void setAMWFBNK__Checked1_16__c(java.lang.Boolean AMWFBNK__Checked1_16__c) {
        this.AMWFBNK__Checked1_16__c = AMWFBNK__Checked1_16__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_17__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_17__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_17__c() {
        return AMWFBNK__Checked1_17__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_17__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_17__c
     */
    public void setAMWFBNK__Checked1_17__c(java.lang.Boolean AMWFBNK__Checked1_17__c) {
        this.AMWFBNK__Checked1_17__c = AMWFBNK__Checked1_17__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_18__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_18__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_18__c() {
        return AMWFBNK__Checked1_18__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_18__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_18__c
     */
    public void setAMWFBNK__Checked1_18__c(java.lang.Boolean AMWFBNK__Checked1_18__c) {
        this.AMWFBNK__Checked1_18__c = AMWFBNK__Checked1_18__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_19__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_19__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_19__c() {
        return AMWFBNK__Checked1_19__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_19__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_19__c
     */
    public void setAMWFBNK__Checked1_19__c(java.lang.Boolean AMWFBNK__Checked1_19__c) {
        this.AMWFBNK__Checked1_19__c = AMWFBNK__Checked1_19__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_1__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_1__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_1__c() {
        return AMWFBNK__Checked1_1__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_1__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_1__c
     */
    public void setAMWFBNK__Checked1_1__c(java.lang.Boolean AMWFBNK__Checked1_1__c) {
        this.AMWFBNK__Checked1_1__c = AMWFBNK__Checked1_1__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_20__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_20__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_20__c() {
        return AMWFBNK__Checked1_20__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_20__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_20__c
     */
    public void setAMWFBNK__Checked1_20__c(java.lang.Boolean AMWFBNK__Checked1_20__c) {
        this.AMWFBNK__Checked1_20__c = AMWFBNK__Checked1_20__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_2__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_2__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_2__c() {
        return AMWFBNK__Checked1_2__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_2__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_2__c
     */
    public void setAMWFBNK__Checked1_2__c(java.lang.Boolean AMWFBNK__Checked1_2__c) {
        this.AMWFBNK__Checked1_2__c = AMWFBNK__Checked1_2__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_3__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_3__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_3__c() {
        return AMWFBNK__Checked1_3__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_3__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_3__c
     */
    public void setAMWFBNK__Checked1_3__c(java.lang.Boolean AMWFBNK__Checked1_3__c) {
        this.AMWFBNK__Checked1_3__c = AMWFBNK__Checked1_3__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_4__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_4__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_4__c() {
        return AMWFBNK__Checked1_4__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_4__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_4__c
     */
    public void setAMWFBNK__Checked1_4__c(java.lang.Boolean AMWFBNK__Checked1_4__c) {
        this.AMWFBNK__Checked1_4__c = AMWFBNK__Checked1_4__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_5__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_5__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_5__c() {
        return AMWFBNK__Checked1_5__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_5__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_5__c
     */
    public void setAMWFBNK__Checked1_5__c(java.lang.Boolean AMWFBNK__Checked1_5__c) {
        this.AMWFBNK__Checked1_5__c = AMWFBNK__Checked1_5__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_6__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_6__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_6__c() {
        return AMWFBNK__Checked1_6__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_6__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_6__c
     */
    public void setAMWFBNK__Checked1_6__c(java.lang.Boolean AMWFBNK__Checked1_6__c) {
        this.AMWFBNK__Checked1_6__c = AMWFBNK__Checked1_6__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_7__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_7__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_7__c() {
        return AMWFBNK__Checked1_7__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_7__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_7__c
     */
    public void setAMWFBNK__Checked1_7__c(java.lang.Boolean AMWFBNK__Checked1_7__c) {
        this.AMWFBNK__Checked1_7__c = AMWFBNK__Checked1_7__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_8__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_8__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_8__c() {
        return AMWFBNK__Checked1_8__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_8__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_8__c
     */
    public void setAMWFBNK__Checked1_8__c(java.lang.Boolean AMWFBNK__Checked1_8__c) {
        this.AMWFBNK__Checked1_8__c = AMWFBNK__Checked1_8__c;
    }


    /**
     * Gets the AMWFBNK__Checked1_9__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked1_9__c
     */
    public java.lang.Boolean getAMWFBNK__Checked1_9__c() {
        return AMWFBNK__Checked1_9__c;
    }


    /**
     * Sets the AMWFBNK__Checked1_9__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked1_9__c
     */
    public void setAMWFBNK__Checked1_9__c(java.lang.Boolean AMWFBNK__Checked1_9__c) {
        this.AMWFBNK__Checked1_9__c = AMWFBNK__Checked1_9__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_10__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_10__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_10__c() {
        return AMWFBNK__Checked2_10__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_10__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_10__c
     */
    public void setAMWFBNK__Checked2_10__c(java.lang.Boolean AMWFBNK__Checked2_10__c) {
        this.AMWFBNK__Checked2_10__c = AMWFBNK__Checked2_10__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_11__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_11__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_11__c() {
        return AMWFBNK__Checked2_11__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_11__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_11__c
     */
    public void setAMWFBNK__Checked2_11__c(java.lang.Boolean AMWFBNK__Checked2_11__c) {
        this.AMWFBNK__Checked2_11__c = AMWFBNK__Checked2_11__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_12__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_12__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_12__c() {
        return AMWFBNK__Checked2_12__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_12__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_12__c
     */
    public void setAMWFBNK__Checked2_12__c(java.lang.Boolean AMWFBNK__Checked2_12__c) {
        this.AMWFBNK__Checked2_12__c = AMWFBNK__Checked2_12__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_13__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_13__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_13__c() {
        return AMWFBNK__Checked2_13__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_13__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_13__c
     */
    public void setAMWFBNK__Checked2_13__c(java.lang.Boolean AMWFBNK__Checked2_13__c) {
        this.AMWFBNK__Checked2_13__c = AMWFBNK__Checked2_13__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_14__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_14__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_14__c() {
        return AMWFBNK__Checked2_14__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_14__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_14__c
     */
    public void setAMWFBNK__Checked2_14__c(java.lang.Boolean AMWFBNK__Checked2_14__c) {
        this.AMWFBNK__Checked2_14__c = AMWFBNK__Checked2_14__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_15__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_15__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_15__c() {
        return AMWFBNK__Checked2_15__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_15__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_15__c
     */
    public void setAMWFBNK__Checked2_15__c(java.lang.Boolean AMWFBNK__Checked2_15__c) {
        this.AMWFBNK__Checked2_15__c = AMWFBNK__Checked2_15__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_16__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_16__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_16__c() {
        return AMWFBNK__Checked2_16__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_16__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_16__c
     */
    public void setAMWFBNK__Checked2_16__c(java.lang.Boolean AMWFBNK__Checked2_16__c) {
        this.AMWFBNK__Checked2_16__c = AMWFBNK__Checked2_16__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_17__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_17__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_17__c() {
        return AMWFBNK__Checked2_17__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_17__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_17__c
     */
    public void setAMWFBNK__Checked2_17__c(java.lang.Boolean AMWFBNK__Checked2_17__c) {
        this.AMWFBNK__Checked2_17__c = AMWFBNK__Checked2_17__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_18__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_18__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_18__c() {
        return AMWFBNK__Checked2_18__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_18__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_18__c
     */
    public void setAMWFBNK__Checked2_18__c(java.lang.Boolean AMWFBNK__Checked2_18__c) {
        this.AMWFBNK__Checked2_18__c = AMWFBNK__Checked2_18__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_19__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_19__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_19__c() {
        return AMWFBNK__Checked2_19__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_19__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_19__c
     */
    public void setAMWFBNK__Checked2_19__c(java.lang.Boolean AMWFBNK__Checked2_19__c) {
        this.AMWFBNK__Checked2_19__c = AMWFBNK__Checked2_19__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_1__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_1__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_1__c() {
        return AMWFBNK__Checked2_1__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_1__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_1__c
     */
    public void setAMWFBNK__Checked2_1__c(java.lang.Boolean AMWFBNK__Checked2_1__c) {
        this.AMWFBNK__Checked2_1__c = AMWFBNK__Checked2_1__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_20__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_20__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_20__c() {
        return AMWFBNK__Checked2_20__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_20__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_20__c
     */
    public void setAMWFBNK__Checked2_20__c(java.lang.Boolean AMWFBNK__Checked2_20__c) {
        this.AMWFBNK__Checked2_20__c = AMWFBNK__Checked2_20__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_2__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_2__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_2__c() {
        return AMWFBNK__Checked2_2__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_2__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_2__c
     */
    public void setAMWFBNK__Checked2_2__c(java.lang.Boolean AMWFBNK__Checked2_2__c) {
        this.AMWFBNK__Checked2_2__c = AMWFBNK__Checked2_2__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_3__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_3__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_3__c() {
        return AMWFBNK__Checked2_3__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_3__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_3__c
     */
    public void setAMWFBNK__Checked2_3__c(java.lang.Boolean AMWFBNK__Checked2_3__c) {
        this.AMWFBNK__Checked2_3__c = AMWFBNK__Checked2_3__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_4__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_4__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_4__c() {
        return AMWFBNK__Checked2_4__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_4__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_4__c
     */
    public void setAMWFBNK__Checked2_4__c(java.lang.Boolean AMWFBNK__Checked2_4__c) {
        this.AMWFBNK__Checked2_4__c = AMWFBNK__Checked2_4__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_5__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_5__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_5__c() {
        return AMWFBNK__Checked2_5__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_5__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_5__c
     */
    public void setAMWFBNK__Checked2_5__c(java.lang.Boolean AMWFBNK__Checked2_5__c) {
        this.AMWFBNK__Checked2_5__c = AMWFBNK__Checked2_5__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_6__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_6__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_6__c() {
        return AMWFBNK__Checked2_6__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_6__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_6__c
     */
    public void setAMWFBNK__Checked2_6__c(java.lang.Boolean AMWFBNK__Checked2_6__c) {
        this.AMWFBNK__Checked2_6__c = AMWFBNK__Checked2_6__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_7__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_7__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_7__c() {
        return AMWFBNK__Checked2_7__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_7__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_7__c
     */
    public void setAMWFBNK__Checked2_7__c(java.lang.Boolean AMWFBNK__Checked2_7__c) {
        this.AMWFBNK__Checked2_7__c = AMWFBNK__Checked2_7__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_8__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_8__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_8__c() {
        return AMWFBNK__Checked2_8__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_8__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_8__c
     */
    public void setAMWFBNK__Checked2_8__c(java.lang.Boolean AMWFBNK__Checked2_8__c) {
        this.AMWFBNK__Checked2_8__c = AMWFBNK__Checked2_8__c;
    }


    /**
     * Gets the AMWFBNK__Checked2_9__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Checked2_9__c
     */
    public java.lang.Boolean getAMWFBNK__Checked2_9__c() {
        return AMWFBNK__Checked2_9__c;
    }


    /**
     * Sets the AMWFBNK__Checked2_9__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Checked2_9__c
     */
    public void setAMWFBNK__Checked2_9__c(java.lang.Boolean AMWFBNK__Checked2_9__c) {
        this.AMWFBNK__Checked2_9__c = AMWFBNK__Checked2_9__c;
    }


    /**
     * Gets the AMWFBNK__FlowCode__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FlowCode__c
     */
    public java.lang.String getAMWFBNK__FlowCode__c() {
        return AMWFBNK__FlowCode__c;
    }


    /**
     * Sets the AMWFBNK__FlowCode__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FlowCode__c
     */
    public void setAMWFBNK__FlowCode__c(java.lang.String AMWFBNK__FlowCode__c) {
        this.AMWFBNK__FlowCode__c = AMWFBNK__FlowCode__c;
    }


    /**
     * Gets the AMWFBNK__FlowType__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FlowType__c
     */
    public java.lang.String getAMWFBNK__FlowType__c() {
        return AMWFBNK__FlowType__c;
    }


    /**
     * Sets the AMWFBNK__FlowType__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FlowType__c
     */
    public void setAMWFBNK__FlowType__c(java.lang.String AMWFBNK__FlowType__c) {
        this.AMWFBNK__FlowType__c = AMWFBNK__FlowType__c;
    }


    /**
     * Gets the AMWFBNK__FreeCheck1__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeCheck1__c
     */
    public java.lang.Boolean getAMWFBNK__FreeCheck1__c() {
        return AMWFBNK__FreeCheck1__c;
    }


    /**
     * Sets the AMWFBNK__FreeCheck1__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeCheck1__c
     */
    public void setAMWFBNK__FreeCheck1__c(java.lang.Boolean AMWFBNK__FreeCheck1__c) {
        this.AMWFBNK__FreeCheck1__c = AMWFBNK__FreeCheck1__c;
    }


    /**
     * Gets the AMWFBNK__FreeCheck2__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeCheck2__c
     */
    public java.lang.Boolean getAMWFBNK__FreeCheck2__c() {
        return AMWFBNK__FreeCheck2__c;
    }


    /**
     * Sets the AMWFBNK__FreeCheck2__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeCheck2__c
     */
    public void setAMWFBNK__FreeCheck2__c(java.lang.Boolean AMWFBNK__FreeCheck2__c) {
        this.AMWFBNK__FreeCheck2__c = AMWFBNK__FreeCheck2__c;
    }


    /**
     * Gets the AMWFBNK__FreeCheck3__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeCheck3__c
     */
    public java.lang.Boolean getAMWFBNK__FreeCheck3__c() {
        return AMWFBNK__FreeCheck3__c;
    }


    /**
     * Sets the AMWFBNK__FreeCheck3__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeCheck3__c
     */
    public void setAMWFBNK__FreeCheck3__c(java.lang.Boolean AMWFBNK__FreeCheck3__c) {
        this.AMWFBNK__FreeCheck3__c = AMWFBNK__FreeCheck3__c;
    }


    /**
     * Gets the AMWFBNK__FreeCheck4__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeCheck4__c
     */
    public java.lang.Boolean getAMWFBNK__FreeCheck4__c() {
        return AMWFBNK__FreeCheck4__c;
    }


    /**
     * Sets the AMWFBNK__FreeCheck4__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeCheck4__c
     */
    public void setAMWFBNK__FreeCheck4__c(java.lang.Boolean AMWFBNK__FreeCheck4__c) {
        this.AMWFBNK__FreeCheck4__c = AMWFBNK__FreeCheck4__c;
    }


    /**
     * Gets the AMWFBNK__FreeCheck5__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeCheck5__c
     */
    public java.lang.Boolean getAMWFBNK__FreeCheck5__c() {
        return AMWFBNK__FreeCheck5__c;
    }


    /**
     * Sets the AMWFBNK__FreeCheck5__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeCheck5__c
     */
    public void setAMWFBNK__FreeCheck5__c(java.lang.Boolean AMWFBNK__FreeCheck5__c) {
        this.AMWFBNK__FreeCheck5__c = AMWFBNK__FreeCheck5__c;
    }


    /**
     * Gets the AMWFBNK__FreeText1__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeText1__c
     */
    public java.lang.String getAMWFBNK__FreeText1__c() {
        return AMWFBNK__FreeText1__c;
    }


    /**
     * Sets the AMWFBNK__FreeText1__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeText1__c
     */
    public void setAMWFBNK__FreeText1__c(java.lang.String AMWFBNK__FreeText1__c) {
        this.AMWFBNK__FreeText1__c = AMWFBNK__FreeText1__c;
    }


    /**
     * Gets the AMWFBNK__FreeText2__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeText2__c
     */
    public java.lang.String getAMWFBNK__FreeText2__c() {
        return AMWFBNK__FreeText2__c;
    }


    /**
     * Sets the AMWFBNK__FreeText2__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeText2__c
     */
    public void setAMWFBNK__FreeText2__c(java.lang.String AMWFBNK__FreeText2__c) {
        this.AMWFBNK__FreeText2__c = AMWFBNK__FreeText2__c;
    }


    /**
     * Gets the AMWFBNK__FreeText3__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeText3__c
     */
    public java.lang.String getAMWFBNK__FreeText3__c() {
        return AMWFBNK__FreeText3__c;
    }


    /**
     * Sets the AMWFBNK__FreeText3__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeText3__c
     */
    public void setAMWFBNK__FreeText3__c(java.lang.String AMWFBNK__FreeText3__c) {
        this.AMWFBNK__FreeText3__c = AMWFBNK__FreeText3__c;
    }


    /**
     * Gets the AMWFBNK__FreeText4__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeText4__c
     */
    public java.lang.String getAMWFBNK__FreeText4__c() {
        return AMWFBNK__FreeText4__c;
    }


    /**
     * Sets the AMWFBNK__FreeText4__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeText4__c
     */
    public void setAMWFBNK__FreeText4__c(java.lang.String AMWFBNK__FreeText4__c) {
        this.AMWFBNK__FreeText4__c = AMWFBNK__FreeText4__c;
    }


    /**
     * Gets the AMWFBNK__FreeText5__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__FreeText5__c
     */
    public java.lang.String getAMWFBNK__FreeText5__c() {
        return AMWFBNK__FreeText5__c;
    }


    /**
     * Sets the AMWFBNK__FreeText5__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__FreeText5__c
     */
    public void setAMWFBNK__FreeText5__c(java.lang.String AMWFBNK__FreeText5__c) {
        this.AMWFBNK__FreeText5__c = AMWFBNK__FreeText5__c;
    }


    /**
     * Gets the AMWFBNK__GroupId1__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__GroupId1__c
     */
    public java.lang.String getAMWFBNK__GroupId1__c() {
        return AMWFBNK__GroupId1__c;
    }


    /**
     * Sets the AMWFBNK__GroupId1__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__GroupId1__c
     */
    public void setAMWFBNK__GroupId1__c(java.lang.String AMWFBNK__GroupId1__c) {
        this.AMWFBNK__GroupId1__c = AMWFBNK__GroupId1__c;
    }


    /**
     * Gets the AMWFBNK__GroupId2__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__GroupId2__c
     */
    public java.lang.String getAMWFBNK__GroupId2__c() {
        return AMWFBNK__GroupId2__c;
    }


    /**
     * Sets the AMWFBNK__GroupId2__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__GroupId2__c
     */
    public void setAMWFBNK__GroupId2__c(java.lang.String AMWFBNK__GroupId2__c) {
        this.AMWFBNK__GroupId2__c = AMWFBNK__GroupId2__c;
    }


    /**
     * Gets the AMWFBNK__GroupName1__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__GroupName1__c
     */
    public java.lang.String getAMWFBNK__GroupName1__c() {
        return AMWFBNK__GroupName1__c;
    }


    /**
     * Sets the AMWFBNK__GroupName1__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__GroupName1__c
     */
    public void setAMWFBNK__GroupName1__c(java.lang.String AMWFBNK__GroupName1__c) {
        this.AMWFBNK__GroupName1__c = AMWFBNK__GroupName1__c;
    }


    /**
     * Gets the AMWFBNK__GroupName2__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__GroupName2__c
     */
    public java.lang.String getAMWFBNK__GroupName2__c() {
        return AMWFBNK__GroupName2__c;
    }


    /**
     * Sets the AMWFBNK__GroupName2__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__GroupName2__c
     */
    public void setAMWFBNK__GroupName2__c(java.lang.String AMWFBNK__GroupName2__c) {
        this.AMWFBNK__GroupName2__c = AMWFBNK__GroupName2__c;
    }


    /**
     * Gets the AMWFBNK__ObjectName__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__ObjectName__c
     */
    public java.lang.String getAMWFBNK__ObjectName__c() {
        return AMWFBNK__ObjectName__c;
    }


    /**
     * Sets the AMWFBNK__ObjectName__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__ObjectName__c
     */
    public void setAMWFBNK__ObjectName__c(java.lang.String AMWFBNK__ObjectName__c) {
        this.AMWFBNK__ObjectName__c = AMWFBNK__ObjectName__c;
    }


    /**
     * Gets the AMWFBNK__RecordId__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__RecordId__c
     */
    public java.lang.String getAMWFBNK__RecordId__c() {
        return AMWFBNK__RecordId__c;
    }


    /**
     * Sets the AMWFBNK__RecordId__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__RecordId__c
     */
    public void setAMWFBNK__RecordId__c(java.lang.String AMWFBNK__RecordId__c) {
        this.AMWFBNK__RecordId__c = AMWFBNK__RecordId__c;
    }


    /**
     * Gets the AMWFBNK__Status__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__Status__c
     */
    public java.lang.String getAMWFBNK__Status__c() {
        return AMWFBNK__Status__c;
    }


    /**
     * Sets the AMWFBNK__Status__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__Status__c
     */
    public void setAMWFBNK__Status__c(java.lang.String AMWFBNK__Status__c) {
        this.AMWFBNK__Status__c = AMWFBNK__Status__c;
    }


    /**
     * Gets the AMWFBNK__SttnUnit__r value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__SttnUnit__r
     */
    public com.sforce.soap.enterprise.QueryResult getAMWFBNK__SttnUnit__r() {
        return AMWFBNK__SttnUnit__r;
    }


    /**
     * Sets the AMWFBNK__SttnUnit__r value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__SttnUnit__r
     */
    public void setAMWFBNK__SttnUnit__r(com.sforce.soap.enterprise.QueryResult AMWFBNK__SttnUnit__r) {
        this.AMWFBNK__SttnUnit__r = AMWFBNK__SttnUnit__r;
    }


    /**
     * Gets the AMWFBNK__URL__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__URL__c
     */
    public java.lang.String getAMWFBNK__URL__c() {
        return AMWFBNK__URL__c;
    }


    /**
     * Sets the AMWFBNK__URL__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__URL__c
     */
    public void setAMWFBNK__URL__c(java.lang.String AMWFBNK__URL__c) {
        this.AMWFBNK__URL__c = AMWFBNK__URL__c;
    }


    /**
     * Gets the AMWFBNK__UpsertedByAPI__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__UpsertedByAPI__c
     */
    public java.lang.Boolean getAMWFBNK__UpsertedByAPI__c() {
        return AMWFBNK__UpsertedByAPI__c;
    }


    /**
     * Sets the AMWFBNK__UpsertedByAPI__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__UpsertedByAPI__c
     */
    public void setAMWFBNK__UpsertedByAPI__c(java.lang.Boolean AMWFBNK__UpsertedByAPI__c) {
        this.AMWFBNK__UpsertedByAPI__c = AMWFBNK__UpsertedByAPI__c;
    }


    /**
     * Gets the AMWFBNK__User__c value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__User__c
     */
    public java.lang.String getAMWFBNK__User__c() {
        return AMWFBNK__User__c;
    }


    /**
     * Sets the AMWFBNK__User__c value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__User__c
     */
    public void setAMWFBNK__User__c(java.lang.String AMWFBNK__User__c) {
        this.AMWFBNK__User__c = AMWFBNK__User__c;
    }


    /**
     * Gets the AMWFBNK__User__r value for this AMWFBNK__Unit__c.
     * 
     * @return AMWFBNK__User__r
     */
    public com.sforce.soap.enterprise.sobject.User getAMWFBNK__User__r() {
        return AMWFBNK__User__r;
    }


    /**
     * Sets the AMWFBNK__User__r value for this AMWFBNK__Unit__c.
     * 
     * @param AMWFBNK__User__r
     */
    public void setAMWFBNK__User__r(com.sforce.soap.enterprise.sobject.User AMWFBNK__User__r) {
        this.AMWFBNK__User__r = AMWFBNK__User__r;
    }


    /**
     * Gets the attachments value for this AMWFBNK__Unit__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this AMWFBNK__Unit__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the CIRCULATEDLASTDATE__c value for this AMWFBNK__Unit__c.
     * 
     * @return CIRCULATEDLASTDATE__c
     */
    public java.util.Calendar getCIRCULATEDLASTDATE__c() {
        return CIRCULATEDLASTDATE__c;
    }


    /**
     * Sets the CIRCULATEDLASTDATE__c value for this AMWFBNK__Unit__c.
     * 
     * @param CIRCULATEDLASTDATE__c
     */
    public void setCIRCULATEDLASTDATE__c(java.util.Calendar CIRCULATEDLASTDATE__c) {
        this.CIRCULATEDLASTDATE__c = CIRCULATEDLASTDATE__c;
    }


    /**
     * Gets the CIRCULATEDNAME__c value for this AMWFBNK__Unit__c.
     * 
     * @return CIRCULATEDNAME__c
     */
    public java.lang.String getCIRCULATEDNAME__c() {
        return CIRCULATEDNAME__c;
    }


    /**
     * Sets the CIRCULATEDNAME__c value for this AMWFBNK__Unit__c.
     * 
     * @param CIRCULATEDNAME__c
     */
    public void setCIRCULATEDNAME__c(java.lang.String CIRCULATEDNAME__c) {
        this.CIRCULATEDNAME__c = CIRCULATEDNAME__c;
    }


    /**
     * Gets the CIRCULATEDPOST__c value for this AMWFBNK__Unit__c.
     * 
     * @return CIRCULATEDPOST__c
     */
    public java.lang.String getCIRCULATEDPOST__c() {
        return CIRCULATEDPOST__c;
    }


    /**
     * Sets the CIRCULATEDPOST__c value for this AMWFBNK__Unit__c.
     * 
     * @param CIRCULATEDPOST__c
     */
    public void setCIRCULATEDPOST__c(java.lang.String CIRCULATEDPOST__c) {
        this.CIRCULATEDPOST__c = CIRCULATEDPOST__c;
    }


    /**
     * Gets the CIRCULATEDSETID__c value for this AMWFBNK__Unit__c.
     * 
     * @return CIRCULATEDSETID__c
     */
    public java.lang.String getCIRCULATEDSETID__c() {
        return CIRCULATEDSETID__c;
    }


    /**
     * Sets the CIRCULATEDSETID__c value for this AMWFBNK__Unit__c.
     * 
     * @param CIRCULATEDSETID__c
     */
    public void setCIRCULATEDSETID__c(java.lang.String CIRCULATEDSETID__c) {
        this.CIRCULATEDSETID__c = CIRCULATEDSETID__c;
    }


    /**
     * Gets the CIRCULATEDTOUSER__c value for this AMWFBNK__Unit__c.
     * 
     * @return CIRCULATEDTOUSER__c
     */
    public java.lang.String getCIRCULATEDTOUSER__c() {
        return CIRCULATEDTOUSER__c;
    }


    /**
     * Sets the CIRCULATEDTOUSER__c value for this AMWFBNK__Unit__c.
     * 
     * @param CIRCULATEDTOUSER__c
     */
    public void setCIRCULATEDTOUSER__c(java.lang.String CIRCULATEDTOUSER__c) {
        this.CIRCULATEDTOUSER__c = CIRCULATEDTOUSER__c;
    }


    /**
     * Gets the CIRCULATEDTOUSER__r value for this AMWFBNK__Unit__c.
     * 
     * @return CIRCULATEDTOUSER__r
     */
    public com.sforce.soap.enterprise.sobject.User getCIRCULATEDTOUSER__r() {
        return CIRCULATEDTOUSER__r;
    }


    /**
     * Sets the CIRCULATEDTOUSER__r value for this AMWFBNK__Unit__c.
     * 
     * @param CIRCULATEDTOUSER__r
     */
    public void setCIRCULATEDTOUSER__r(com.sforce.soap.enterprise.sobject.User CIRCULATEDTOUSER__r) {
        this.CIRCULATEDTOUSER__r = CIRCULATEDTOUSER__r;
    }


    /**
     * Gets the CIRCULATEDUNIT__c value for this AMWFBNK__Unit__c.
     * 
     * @return CIRCULATEDUNIT__c
     */
    public java.lang.String getCIRCULATEDUNIT__c() {
        return CIRCULATEDUNIT__c;
    }


    /**
     * Sets the CIRCULATEDUNIT__c value for this AMWFBNK__Unit__c.
     * 
     * @param CIRCULATEDUNIT__c
     */
    public void setCIRCULATEDUNIT__c(java.lang.String CIRCULATEDUNIT__c) {
        this.CIRCULATEDUNIT__c = CIRCULATEDUNIT__c;
    }


    /**
     * Gets the CONCURRENTFLAG1__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONCURRENTFLAG1__c
     */
    public java.lang.Boolean getCONCURRENTFLAG1__c() {
        return CONCURRENTFLAG1__c;
    }


    /**
     * Sets the CONCURRENTFLAG1__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONCURRENTFLAG1__c
     */
    public void setCONCURRENTFLAG1__c(java.lang.Boolean CONCURRENTFLAG1__c) {
        this.CONCURRENTFLAG1__c = CONCURRENTFLAG1__c;
    }


    /**
     * Gets the CONCURRENTFLAG2__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONCURRENTFLAG2__c
     */
    public java.lang.Boolean getCONCURRENTFLAG2__c() {
        return CONCURRENTFLAG2__c;
    }


    /**
     * Sets the CONCURRENTFLAG2__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONCURRENTFLAG2__c
     */
    public void setCONCURRENTFLAG2__c(java.lang.Boolean CONCURRENTFLAG2__c) {
        this.CONCURRENTFLAG2__c = CONCURRENTFLAG2__c;
    }


    /**
     * Gets the CONCURRENTFLAG__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONCURRENTFLAG__c
     */
    public java.lang.Boolean getCONCURRENTFLAG__c() {
        return CONCURRENTFLAG__c;
    }


    /**
     * Sets the CONCURRENTFLAG__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONCURRENTFLAG__c
     */
    public void setCONCURRENTFLAG__c(java.lang.Boolean CONCURRENTFLAG__c) {
        this.CONCURRENTFLAG__c = CONCURRENTFLAG__c;
    }


    /**
     * Gets the CONDITIONSTEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONDITIONSTEXT__c
     */
    public java.lang.String getCONDITIONSTEXT__c() {
        return CONDITIONSTEXT__c;
    }


    /**
     * Sets the CONDITIONSTEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONDITIONSTEXT__c
     */
    public void setCONDITIONSTEXT__c(java.lang.String CONDITIONSTEXT__c) {
        this.CONDITIONSTEXT__c = CONDITIONSTEXT__c;
    }


    /**
     * Gets the CONDITIONS__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONDITIONS__c
     */
    public java.lang.Boolean getCONDITIONS__c() {
        return CONDITIONS__c;
    }


    /**
     * Sets the CONDITIONS__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONDITIONS__c
     */
    public void setCONDITIONS__c(java.lang.Boolean CONDITIONS__c) {
        this.CONDITIONS__c = CONDITIONS__c;
    }


    /**
     * Gets the CONINDICATREPORT_TEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONINDICATREPORT_TEXT__c
     */
    public java.lang.String getCONINDICATREPORT_TEXT__c() {
        return CONINDICATREPORT_TEXT__c;
    }


    /**
     * Sets the CONINDICATREPORT_TEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONINDICATREPORT_TEXT__c
     */
    public void setCONINDICATREPORT_TEXT__c(java.lang.String CONINDICATREPORT_TEXT__c) {
        this.CONINDICATREPORT_TEXT__c = CONINDICATREPORT_TEXT__c;
    }


    /**
     * Gets the CONINDICATREPORT__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONINDICATREPORT__c
     */
    public java.lang.Boolean getCONINDICATREPORT__c() {
        return CONINDICATREPORT__c;
    }


    /**
     * Sets the CONINDICATREPORT__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONINDICATREPORT__c
     */
    public void setCONINDICATREPORT__c(java.lang.Boolean CONINDICATREPORT__c) {
        this.CONINDICATREPORT__c = CONINDICATREPORT__c;
    }


    /**
     * Gets the CONLASTMODIFIEDBY__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONLASTMODIFIEDBY__c
     */
    public java.lang.String getCONLASTMODIFIEDBY__c() {
        return CONLASTMODIFIEDBY__c;
    }


    /**
     * Sets the CONLASTMODIFIEDBY__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONLASTMODIFIEDBY__c
     */
    public void setCONLASTMODIFIEDBY__c(java.lang.String CONLASTMODIFIEDBY__c) {
        this.CONLASTMODIFIEDBY__c = CONLASTMODIFIEDBY__c;
    }


    /**
     * Gets the CONLASTMODIFIEDBY__r value for this AMWFBNK__Unit__c.
     * 
     * @return CONLASTMODIFIEDBY__r
     */
    public com.sforce.soap.enterprise.sobject.User getCONLASTMODIFIEDBY__r() {
        return CONLASTMODIFIEDBY__r;
    }


    /**
     * Sets the CONLASTMODIFIEDBY__r value for this AMWFBNK__Unit__c.
     * 
     * @param CONLASTMODIFIEDBY__r
     */
    public void setCONLASTMODIFIEDBY__r(com.sforce.soap.enterprise.sobject.User CONLASTMODIFIEDBY__r) {
        this.CONLASTMODIFIEDBY__r = CONLASTMODIFIEDBY__r;
    }


    /**
     * Gets the CONLASTMODIFIEDDATE__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONLASTMODIFIEDDATE__c
     */
    public java.util.Calendar getCONLASTMODIFIEDDATE__c() {
        return CONLASTMODIFIEDDATE__c;
    }


    /**
     * Sets the CONLASTMODIFIEDDATE__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONLASTMODIFIEDDATE__c
     */
    public void setCONLASTMODIFIEDDATE__c(java.util.Calendar CONLASTMODIFIEDDATE__c) {
        this.CONLASTMODIFIEDDATE__c = CONLASTMODIFIEDDATE__c;
    }


    /**
     * Gets the CONLASTMODIFIEDINFO__c value for this AMWFBNK__Unit__c.
     * 
     * @return CONLASTMODIFIEDINFO__c
     */
    public java.lang.String getCONLASTMODIFIEDINFO__c() {
        return CONLASTMODIFIEDINFO__c;
    }


    /**
     * Sets the CONLASTMODIFIEDINFO__c value for this AMWFBNK__Unit__c.
     * 
     * @param CONLASTMODIFIEDINFO__c
     */
    public void setCONLASTMODIFIEDINFO__c(java.lang.String CONLASTMODIFIEDINFO__c) {
        this.CONLASTMODIFIEDINFO__c = CONLASTMODIFIEDINFO__c;
    }


    /**
     * Gets the combinedAttachments value for this AMWFBNK__Unit__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this AMWFBNK__Unit__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this AMWFBNK__Unit__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this AMWFBNK__Unit__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this AMWFBNK__Unit__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this AMWFBNK__Unit__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this AMWFBNK__Unit__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this AMWFBNK__Unit__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the DAIKO_FLG__c value for this AMWFBNK__Unit__c.
     * 
     * @return DAIKO_FLG__c
     */
    public java.lang.Boolean getDAIKO_FLG__c() {
        return DAIKO_FLG__c;
    }


    /**
     * Sets the DAIKO_FLG__c value for this AMWFBNK__Unit__c.
     * 
     * @param DAIKO_FLG__c
     */
    public void setDAIKO_FLG__c(java.lang.Boolean DAIKO_FLG__c) {
        this.DAIKO_FLG__c = DAIKO_FLG__c;
    }


    /**
     * Gets the duplicateRecordItems value for this AMWFBNK__Unit__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this AMWFBNK__Unit__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the IMPORTANT_TEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @return IMPORTANT_TEXT__c
     */
    public java.lang.String getIMPORTANT_TEXT__c() {
        return IMPORTANT_TEXT__c;
    }


    /**
     * Sets the IMPORTANT_TEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @param IMPORTANT_TEXT__c
     */
    public void setIMPORTANT_TEXT__c(java.lang.String IMPORTANT_TEXT__c) {
        this.IMPORTANT_TEXT__c = IMPORTANT_TEXT__c;
    }


    /**
     * Gets the IMPORTANT__c value for this AMWFBNK__Unit__c.
     * 
     * @return IMPORTANT__c
     */
    public java.lang.Boolean getIMPORTANT__c() {
        return IMPORTANT__c;
    }


    /**
     * Sets the IMPORTANT__c value for this AMWFBNK__Unit__c.
     * 
     * @param IMPORTANT__c
     */
    public void setIMPORTANT__c(java.lang.Boolean IMPORTANT__c) {
        this.IMPORTANT__c = IMPORTANT__c;
    }


    /**
     * Gets the INDICATIONTEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @return INDICATIONTEXT__c
     */
    public java.lang.String getINDICATIONTEXT__c() {
        return INDICATIONTEXT__c;
    }


    /**
     * Sets the INDICATIONTEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @param INDICATIONTEXT__c
     */
    public void setINDICATIONTEXT__c(java.lang.String INDICATIONTEXT__c) {
        this.INDICATIONTEXT__c = INDICATIONTEXT__c;
    }


    /**
     * Gets the INDICATION__c value for this AMWFBNK__Unit__c.
     * 
     * @return INDICATION__c
     */
    public java.lang.Boolean getINDICATION__c() {
        return INDICATION__c;
    }


    /**
     * Sets the INDICATION__c value for this AMWFBNK__Unit__c.
     * 
     * @param INDICATION__c
     */
    public void setINDICATION__c(java.lang.Boolean INDICATION__c) {
        this.INDICATION__c = INDICATION__c;
    }


    /**
     * Gets the INLASTMODIFIEDBY__c value for this AMWFBNK__Unit__c.
     * 
     * @return INLASTMODIFIEDBY__c
     */
    public java.lang.String getINLASTMODIFIEDBY__c() {
        return INLASTMODIFIEDBY__c;
    }


    /**
     * Sets the INLASTMODIFIEDBY__c value for this AMWFBNK__Unit__c.
     * 
     * @param INLASTMODIFIEDBY__c
     */
    public void setINLASTMODIFIEDBY__c(java.lang.String INLASTMODIFIEDBY__c) {
        this.INLASTMODIFIEDBY__c = INLASTMODIFIEDBY__c;
    }


    /**
     * Gets the INLASTMODIFIEDBY__r value for this AMWFBNK__Unit__c.
     * 
     * @return INLASTMODIFIEDBY__r
     */
    public com.sforce.soap.enterprise.sobject.User getINLASTMODIFIEDBY__r() {
        return INLASTMODIFIEDBY__r;
    }


    /**
     * Sets the INLASTMODIFIEDBY__r value for this AMWFBNK__Unit__c.
     * 
     * @param INLASTMODIFIEDBY__r
     */
    public void setINLASTMODIFIEDBY__r(com.sforce.soap.enterprise.sobject.User INLASTMODIFIEDBY__r) {
        this.INLASTMODIFIEDBY__r = INLASTMODIFIEDBY__r;
    }


    /**
     * Gets the INLASTMODIFIEDDATE__c value for this AMWFBNK__Unit__c.
     * 
     * @return INLASTMODIFIEDDATE__c
     */
    public java.util.Calendar getINLASTMODIFIEDDATE__c() {
        return INLASTMODIFIEDDATE__c;
    }


    /**
     * Sets the INLASTMODIFIEDDATE__c value for this AMWFBNK__Unit__c.
     * 
     * @param INLASTMODIFIEDDATE__c
     */
    public void setINLASTMODIFIEDDATE__c(java.util.Calendar INLASTMODIFIEDDATE__c) {
        this.INLASTMODIFIEDDATE__c = INLASTMODIFIEDDATE__c;
    }


    /**
     * Gets the INLASTMODIFIEDINFO__c value for this AMWFBNK__Unit__c.
     * 
     * @return INLASTMODIFIEDINFO__c
     */
    public java.lang.String getINLASTMODIFIEDINFO__c() {
        return INLASTMODIFIEDINFO__c;
    }


    /**
     * Sets the INLASTMODIFIEDINFO__c value for this AMWFBNK__Unit__c.
     * 
     * @param INLASTMODIFIEDINFO__c
     */
    public void setINLASTMODIFIEDINFO__c(java.lang.String INLASTMODIFIEDINFO__c) {
        this.INLASTMODIFIEDINFO__c = INLASTMODIFIEDINFO__c;
    }


    /**
     * Gets the isDeleted value for this AMWFBNK__Unit__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this AMWFBNK__Unit__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the KAIFUSAKI_BUSHO__c value for this AMWFBNK__Unit__c.
     * 
     * @return KAIFUSAKI_BUSHO__c
     */
    public java.lang.String getKAIFUSAKI_BUSHO__c() {
        return KAIFUSAKI_BUSHO__c;
    }


    /**
     * Sets the KAIFUSAKI_BUSHO__c value for this AMWFBNK__Unit__c.
     * 
     * @param KAIFUSAKI_BUSHO__c
     */
    public void setKAIFUSAKI_BUSHO__c(java.lang.String KAIFUSAKI_BUSHO__c) {
        this.KAIFUSAKI_BUSHO__c = KAIFUSAKI_BUSHO__c;
    }


    /**
     * Gets the KAIFUSAKI_SHIMEI__c value for this AMWFBNK__Unit__c.
     * 
     * @return KAIFUSAKI_SHIMEI__c
     */
    public java.lang.String getKAIFUSAKI_SHIMEI__c() {
        return KAIFUSAKI_SHIMEI__c;
    }


    /**
     * Sets the KAIFUSAKI_SHIMEI__c value for this AMWFBNK__Unit__c.
     * 
     * @param KAIFUSAKI_SHIMEI__c
     */
    public void setKAIFUSAKI_SHIMEI__c(java.lang.String KAIFUSAKI_SHIMEI__c) {
        this.KAIFUSAKI_SHIMEI__c = KAIFUSAKI_SHIMEI__c;
    }


    /**
     * Gets the lastModifiedBy value for this AMWFBNK__Unit__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this AMWFBNK__Unit__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this AMWFBNK__Unit__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this AMWFBNK__Unit__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this AMWFBNK__Unit__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this AMWFBNK__Unit__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this AMWFBNK__Unit__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this AMWFBNK__Unit__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the NON_DISPLAYFLAG__c value for this AMWFBNK__Unit__c.
     * 
     * @return NON_DISPLAYFLAG__c
     */
    public java.lang.Boolean getNON_DISPLAYFLAG__c() {
        return NON_DISPLAYFLAG__c;
    }


    /**
     * Sets the NON_DISPLAYFLAG__c value for this AMWFBNK__Unit__c.
     * 
     * @param NON_DISPLAYFLAG__c
     */
    public void setNON_DISPLAYFLAG__c(java.lang.Boolean NON_DISPLAYFLAG__c) {
        this.NON_DISPLAYFLAG__c = NON_DISPLAYFLAG__c;
    }


    /**
     * Gets the name value for this AMWFBNK__Unit__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this AMWFBNK__Unit__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this AMWFBNK__Unit__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this AMWFBNK__Unit__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this AMWFBNK__Unit__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this AMWFBNK__Unit__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the owner value for this AMWFBNK__Unit__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this AMWFBNK__Unit__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this AMWFBNK__Unit__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this AMWFBNK__Unit__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this AMWFBNK__Unit__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this AMWFBNK__Unit__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this AMWFBNK__Unit__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this AMWFBNK__Unit__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the RATIFICATIONCHECK__c value for this AMWFBNK__Unit__c.
     * 
     * @return RATIFICATIONCHECK__c
     */
    public java.lang.Boolean getRATIFICATIONCHECK__c() {
        return RATIFICATIONCHECK__c;
    }


    /**
     * Sets the RATIFICATIONCHECK__c value for this AMWFBNK__Unit__c.
     * 
     * @param RATIFICATIONCHECK__c
     */
    public void setRATIFICATIONCHECK__c(java.lang.Boolean RATIFICATIONCHECK__c) {
        this.RATIFICATIONCHECK__c = RATIFICATIONCHECK__c;
    }


    /**
     * Gets the RATIFICATIONLIST__c value for this AMWFBNK__Unit__c.
     * 
     * @return RATIFICATIONLIST__c
     */
    public java.lang.String getRATIFICATIONLIST__c() {
        return RATIFICATIONLIST__c;
    }


    /**
     * Sets the RATIFICATIONLIST__c value for this AMWFBNK__Unit__c.
     * 
     * @param RATIFICATIONLIST__c
     */
    public void setRATIFICATIONLIST__c(java.lang.String RATIFICATIONLIST__c) {
        this.RATIFICATIONLIST__c = RATIFICATIONLIST__c;
    }


    /**
     * Gets the REFERENCECONCHECK__c value for this AMWFBNK__Unit__c.
     * 
     * @return REFERENCECONCHECK__c
     */
    public java.lang.Boolean getREFERENCECONCHECK__c() {
        return REFERENCECONCHECK__c;
    }


    /**
     * Sets the REFERENCECONCHECK__c value for this AMWFBNK__Unit__c.
     * 
     * @param REFERENCECONCHECK__c
     */
    public void setREFERENCECONCHECK__c(java.lang.Boolean REFERENCECONCHECK__c) {
        this.REFERENCECONCHECK__c = REFERENCECONCHECK__c;
    }


    /**
     * Gets the REFERENCECONLIST__c value for this AMWFBNK__Unit__c.
     * 
     * @return REFERENCECONLIST__c
     */
    public java.lang.String getREFERENCECONLIST__c() {
        return REFERENCECONLIST__c;
    }


    /**
     * Sets the REFERENCECONLIST__c value for this AMWFBNK__Unit__c.
     * 
     * @param REFERENCECONLIST__c
     */
    public void setREFERENCECONLIST__c(java.lang.String REFERENCECONLIST__c) {
        this.REFERENCECONLIST__c = REFERENCECONLIST__c;
    }


    /**
     * Gets the REPORTABLE__c value for this AMWFBNK__Unit__c.
     * 
     * @return REPORTABLE__c
     */
    public java.lang.Boolean getREPORTABLE__c() {
        return REPORTABLE__c;
    }


    /**
     * Sets the REPORTABLE__c value for this AMWFBNK__Unit__c.
     * 
     * @param REPORTABLE__c
     */
    public void setREPORTABLE__c(java.lang.Boolean REPORTABLE__c) {
        this.REPORTABLE__c = REPORTABLE__c;
    }


    /**
     * Gets the SEARCH_TEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @return SEARCH_TEXT__c
     */
    public java.lang.String getSEARCH_TEXT__c() {
        return SEARCH_TEXT__c;
    }


    /**
     * Sets the SEARCH_TEXT__c value for this AMWFBNK__Unit__c.
     * 
     * @param SEARCH_TEXT__c
     */
    public void setSEARCH_TEXT__c(java.lang.String SEARCH_TEXT__c) {
        this.SEARCH_TEXT__c = SEARCH_TEXT__c;
    }


    /**
     * Gets the SORT_ORDER_STATUSCONFIRM__c value for this AMWFBNK__Unit__c.
     * 
     * @return SORT_ORDER_STATUSCONFIRM__c
     */
    public java.lang.Double getSORT_ORDER_STATUSCONFIRM__c() {
        return SORT_ORDER_STATUSCONFIRM__c;
    }


    /**
     * Sets the SORT_ORDER_STATUSCONFIRM__c value for this AMWFBNK__Unit__c.
     * 
     * @param SORT_ORDER_STATUSCONFIRM__c
     */
    public void setSORT_ORDER_STATUSCONFIRM__c(java.lang.Double SORT_ORDER_STATUSCONFIRM__c) {
        this.SORT_ORDER_STATUSCONFIRM__c = SORT_ORDER_STATUSCONFIRM__c;
    }


    /**
     * Gets the SORT_ORDER_WIDCIRCULATED__c value for this AMWFBNK__Unit__c.
     * 
     * @return SORT_ORDER_WIDCIRCULATED__c
     */
    public java.lang.Double getSORT_ORDER_WIDCIRCULATED__c() {
        return SORT_ORDER_WIDCIRCULATED__c;
    }


    /**
     * Sets the SORT_ORDER_WIDCIRCULATED__c value for this AMWFBNK__Unit__c.
     * 
     * @param SORT_ORDER_WIDCIRCULATED__c
     */
    public void setSORT_ORDER_WIDCIRCULATED__c(java.lang.Double SORT_ORDER_WIDCIRCULATED__c) {
        this.SORT_ORDER_WIDCIRCULATED__c = SORT_ORDER_WIDCIRCULATED__c;
    }


    /**
     * Gets the systemModstamp value for this AMWFBNK__Unit__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this AMWFBNK__Unit__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the TANTOSHA_BUSHO__c value for this AMWFBNK__Unit__c.
     * 
     * @return TANTOSHA_BUSHO__c
     */
    public java.lang.String getTANTOSHA_BUSHO__c() {
        return TANTOSHA_BUSHO__c;
    }


    /**
     * Sets the TANTOSHA_BUSHO__c value for this AMWFBNK__Unit__c.
     * 
     * @param TANTOSHA_BUSHO__c
     */
    public void setTANTOSHA_BUSHO__c(java.lang.String TANTOSHA_BUSHO__c) {
        this.TANTOSHA_BUSHO__c = TANTOSHA_BUSHO__c;
    }


    /**
     * Gets the TANTOSHA_SHIMEI__c value for this AMWFBNK__Unit__c.
     * 
     * @return TANTOSHA_SHIMEI__c
     */
    public java.lang.String getTANTOSHA_SHIMEI__c() {
        return TANTOSHA_SHIMEI__c;
    }


    /**
     * Sets the TANTOSHA_SHIMEI__c value for this AMWFBNK__Unit__c.
     * 
     * @param TANTOSHA_SHIMEI__c
     */
    public void setTANTOSHA_SHIMEI__c(java.lang.String TANTOSHA_SHIMEI__c) {
        this.TANTOSHA_SHIMEI__c = TANTOSHA_SHIMEI__c;
    }


    /**
     * Gets the topicAssignments value for this AMWFBNK__Unit__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this AMWFBNK__Unit__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this AMWFBNK__Unit__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this AMWFBNK__Unit__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AMWFBNK__Unit__c)) return false;
        AMWFBNK__Unit__c other = (AMWFBNK__Unit__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.AMWFBNK__AppliCode__c==null && other.getAMWFBNK__AppliCode__c()==null) || 
             (this.AMWFBNK__AppliCode__c!=null &&
              this.AMWFBNK__AppliCode__c.equals(other.getAMWFBNK__AppliCode__c()))) &&
            ((this.AMWFBNK__AppliName__c==null && other.getAMWFBNK__AppliName__c()==null) || 
             (this.AMWFBNK__AppliName__c!=null &&
              this.AMWFBNK__AppliName__c.equals(other.getAMWFBNK__AppliName__c()))) &&
            ((this.AMWFBNK__CheckPoint1_10__c==null && other.getAMWFBNK__CheckPoint1_10__c()==null) || 
             (this.AMWFBNK__CheckPoint1_10__c!=null &&
              this.AMWFBNK__CheckPoint1_10__c.equals(other.getAMWFBNK__CheckPoint1_10__c()))) &&
            ((this.AMWFBNK__CheckPoint1_11__c==null && other.getAMWFBNK__CheckPoint1_11__c()==null) || 
             (this.AMWFBNK__CheckPoint1_11__c!=null &&
              this.AMWFBNK__CheckPoint1_11__c.equals(other.getAMWFBNK__CheckPoint1_11__c()))) &&
            ((this.AMWFBNK__CheckPoint1_12__c==null && other.getAMWFBNK__CheckPoint1_12__c()==null) || 
             (this.AMWFBNK__CheckPoint1_12__c!=null &&
              this.AMWFBNK__CheckPoint1_12__c.equals(other.getAMWFBNK__CheckPoint1_12__c()))) &&
            ((this.AMWFBNK__CheckPoint1_13__c==null && other.getAMWFBNK__CheckPoint1_13__c()==null) || 
             (this.AMWFBNK__CheckPoint1_13__c!=null &&
              this.AMWFBNK__CheckPoint1_13__c.equals(other.getAMWFBNK__CheckPoint1_13__c()))) &&
            ((this.AMWFBNK__CheckPoint1_14__c==null && other.getAMWFBNK__CheckPoint1_14__c()==null) || 
             (this.AMWFBNK__CheckPoint1_14__c!=null &&
              this.AMWFBNK__CheckPoint1_14__c.equals(other.getAMWFBNK__CheckPoint1_14__c()))) &&
            ((this.AMWFBNK__CheckPoint1_15__c==null && other.getAMWFBNK__CheckPoint1_15__c()==null) || 
             (this.AMWFBNK__CheckPoint1_15__c!=null &&
              this.AMWFBNK__CheckPoint1_15__c.equals(other.getAMWFBNK__CheckPoint1_15__c()))) &&
            ((this.AMWFBNK__CheckPoint1_16__c==null && other.getAMWFBNK__CheckPoint1_16__c()==null) || 
             (this.AMWFBNK__CheckPoint1_16__c!=null &&
              this.AMWFBNK__CheckPoint1_16__c.equals(other.getAMWFBNK__CheckPoint1_16__c()))) &&
            ((this.AMWFBNK__CheckPoint1_17__c==null && other.getAMWFBNK__CheckPoint1_17__c()==null) || 
             (this.AMWFBNK__CheckPoint1_17__c!=null &&
              this.AMWFBNK__CheckPoint1_17__c.equals(other.getAMWFBNK__CheckPoint1_17__c()))) &&
            ((this.AMWFBNK__CheckPoint1_18__c==null && other.getAMWFBNK__CheckPoint1_18__c()==null) || 
             (this.AMWFBNK__CheckPoint1_18__c!=null &&
              this.AMWFBNK__CheckPoint1_18__c.equals(other.getAMWFBNK__CheckPoint1_18__c()))) &&
            ((this.AMWFBNK__CheckPoint1_19__c==null && other.getAMWFBNK__CheckPoint1_19__c()==null) || 
             (this.AMWFBNK__CheckPoint1_19__c!=null &&
              this.AMWFBNK__CheckPoint1_19__c.equals(other.getAMWFBNK__CheckPoint1_19__c()))) &&
            ((this.AMWFBNK__CheckPoint1_1__c==null && other.getAMWFBNK__CheckPoint1_1__c()==null) || 
             (this.AMWFBNK__CheckPoint1_1__c!=null &&
              this.AMWFBNK__CheckPoint1_1__c.equals(other.getAMWFBNK__CheckPoint1_1__c()))) &&
            ((this.AMWFBNK__CheckPoint1_20__c==null && other.getAMWFBNK__CheckPoint1_20__c()==null) || 
             (this.AMWFBNK__CheckPoint1_20__c!=null &&
              this.AMWFBNK__CheckPoint1_20__c.equals(other.getAMWFBNK__CheckPoint1_20__c()))) &&
            ((this.AMWFBNK__CheckPoint1_2__c==null && other.getAMWFBNK__CheckPoint1_2__c()==null) || 
             (this.AMWFBNK__CheckPoint1_2__c!=null &&
              this.AMWFBNK__CheckPoint1_2__c.equals(other.getAMWFBNK__CheckPoint1_2__c()))) &&
            ((this.AMWFBNK__CheckPoint1_3__c==null && other.getAMWFBNK__CheckPoint1_3__c()==null) || 
             (this.AMWFBNK__CheckPoint1_3__c!=null &&
              this.AMWFBNK__CheckPoint1_3__c.equals(other.getAMWFBNK__CheckPoint1_3__c()))) &&
            ((this.AMWFBNK__CheckPoint1_4__c==null && other.getAMWFBNK__CheckPoint1_4__c()==null) || 
             (this.AMWFBNK__CheckPoint1_4__c!=null &&
              this.AMWFBNK__CheckPoint1_4__c.equals(other.getAMWFBNK__CheckPoint1_4__c()))) &&
            ((this.AMWFBNK__CheckPoint1_5__c==null && other.getAMWFBNK__CheckPoint1_5__c()==null) || 
             (this.AMWFBNK__CheckPoint1_5__c!=null &&
              this.AMWFBNK__CheckPoint1_5__c.equals(other.getAMWFBNK__CheckPoint1_5__c()))) &&
            ((this.AMWFBNK__CheckPoint1_6__c==null && other.getAMWFBNK__CheckPoint1_6__c()==null) || 
             (this.AMWFBNK__CheckPoint1_6__c!=null &&
              this.AMWFBNK__CheckPoint1_6__c.equals(other.getAMWFBNK__CheckPoint1_6__c()))) &&
            ((this.AMWFBNK__CheckPoint1_7__c==null && other.getAMWFBNK__CheckPoint1_7__c()==null) || 
             (this.AMWFBNK__CheckPoint1_7__c!=null &&
              this.AMWFBNK__CheckPoint1_7__c.equals(other.getAMWFBNK__CheckPoint1_7__c()))) &&
            ((this.AMWFBNK__CheckPoint1_8__c==null && other.getAMWFBNK__CheckPoint1_8__c()==null) || 
             (this.AMWFBNK__CheckPoint1_8__c!=null &&
              this.AMWFBNK__CheckPoint1_8__c.equals(other.getAMWFBNK__CheckPoint1_8__c()))) &&
            ((this.AMWFBNK__CheckPoint1_9__c==null && other.getAMWFBNK__CheckPoint1_9__c()==null) || 
             (this.AMWFBNK__CheckPoint1_9__c!=null &&
              this.AMWFBNK__CheckPoint1_9__c.equals(other.getAMWFBNK__CheckPoint1_9__c()))) &&
            ((this.AMWFBNK__CheckPoint2_10__c==null && other.getAMWFBNK__CheckPoint2_10__c()==null) || 
             (this.AMWFBNK__CheckPoint2_10__c!=null &&
              this.AMWFBNK__CheckPoint2_10__c.equals(other.getAMWFBNK__CheckPoint2_10__c()))) &&
            ((this.AMWFBNK__CheckPoint2_11__c==null && other.getAMWFBNK__CheckPoint2_11__c()==null) || 
             (this.AMWFBNK__CheckPoint2_11__c!=null &&
              this.AMWFBNK__CheckPoint2_11__c.equals(other.getAMWFBNK__CheckPoint2_11__c()))) &&
            ((this.AMWFBNK__CheckPoint2_12__c==null && other.getAMWFBNK__CheckPoint2_12__c()==null) || 
             (this.AMWFBNK__CheckPoint2_12__c!=null &&
              this.AMWFBNK__CheckPoint2_12__c.equals(other.getAMWFBNK__CheckPoint2_12__c()))) &&
            ((this.AMWFBNK__CheckPoint2_13__c==null && other.getAMWFBNK__CheckPoint2_13__c()==null) || 
             (this.AMWFBNK__CheckPoint2_13__c!=null &&
              this.AMWFBNK__CheckPoint2_13__c.equals(other.getAMWFBNK__CheckPoint2_13__c()))) &&
            ((this.AMWFBNK__CheckPoint2_14__c==null && other.getAMWFBNK__CheckPoint2_14__c()==null) || 
             (this.AMWFBNK__CheckPoint2_14__c!=null &&
              this.AMWFBNK__CheckPoint2_14__c.equals(other.getAMWFBNK__CheckPoint2_14__c()))) &&
            ((this.AMWFBNK__CheckPoint2_15__c==null && other.getAMWFBNK__CheckPoint2_15__c()==null) || 
             (this.AMWFBNK__CheckPoint2_15__c!=null &&
              this.AMWFBNK__CheckPoint2_15__c.equals(other.getAMWFBNK__CheckPoint2_15__c()))) &&
            ((this.AMWFBNK__CheckPoint2_16__c==null && other.getAMWFBNK__CheckPoint2_16__c()==null) || 
             (this.AMWFBNK__CheckPoint2_16__c!=null &&
              this.AMWFBNK__CheckPoint2_16__c.equals(other.getAMWFBNK__CheckPoint2_16__c()))) &&
            ((this.AMWFBNK__CheckPoint2_17__c==null && other.getAMWFBNK__CheckPoint2_17__c()==null) || 
             (this.AMWFBNK__CheckPoint2_17__c!=null &&
              this.AMWFBNK__CheckPoint2_17__c.equals(other.getAMWFBNK__CheckPoint2_17__c()))) &&
            ((this.AMWFBNK__CheckPoint2_18__c==null && other.getAMWFBNK__CheckPoint2_18__c()==null) || 
             (this.AMWFBNK__CheckPoint2_18__c!=null &&
              this.AMWFBNK__CheckPoint2_18__c.equals(other.getAMWFBNK__CheckPoint2_18__c()))) &&
            ((this.AMWFBNK__CheckPoint2_19__c==null && other.getAMWFBNK__CheckPoint2_19__c()==null) || 
             (this.AMWFBNK__CheckPoint2_19__c!=null &&
              this.AMWFBNK__CheckPoint2_19__c.equals(other.getAMWFBNK__CheckPoint2_19__c()))) &&
            ((this.AMWFBNK__CheckPoint2_1__c==null && other.getAMWFBNK__CheckPoint2_1__c()==null) || 
             (this.AMWFBNK__CheckPoint2_1__c!=null &&
              this.AMWFBNK__CheckPoint2_1__c.equals(other.getAMWFBNK__CheckPoint2_1__c()))) &&
            ((this.AMWFBNK__CheckPoint2_20__c==null && other.getAMWFBNK__CheckPoint2_20__c()==null) || 
             (this.AMWFBNK__CheckPoint2_20__c!=null &&
              this.AMWFBNK__CheckPoint2_20__c.equals(other.getAMWFBNK__CheckPoint2_20__c()))) &&
            ((this.AMWFBNK__CheckPoint2_2__c==null && other.getAMWFBNK__CheckPoint2_2__c()==null) || 
             (this.AMWFBNK__CheckPoint2_2__c!=null &&
              this.AMWFBNK__CheckPoint2_2__c.equals(other.getAMWFBNK__CheckPoint2_2__c()))) &&
            ((this.AMWFBNK__CheckPoint2_3__c==null && other.getAMWFBNK__CheckPoint2_3__c()==null) || 
             (this.AMWFBNK__CheckPoint2_3__c!=null &&
              this.AMWFBNK__CheckPoint2_3__c.equals(other.getAMWFBNK__CheckPoint2_3__c()))) &&
            ((this.AMWFBNK__CheckPoint2_4__c==null && other.getAMWFBNK__CheckPoint2_4__c()==null) || 
             (this.AMWFBNK__CheckPoint2_4__c!=null &&
              this.AMWFBNK__CheckPoint2_4__c.equals(other.getAMWFBNK__CheckPoint2_4__c()))) &&
            ((this.AMWFBNK__CheckPoint2_5__c==null && other.getAMWFBNK__CheckPoint2_5__c()==null) || 
             (this.AMWFBNK__CheckPoint2_5__c!=null &&
              this.AMWFBNK__CheckPoint2_5__c.equals(other.getAMWFBNK__CheckPoint2_5__c()))) &&
            ((this.AMWFBNK__CheckPoint2_6__c==null && other.getAMWFBNK__CheckPoint2_6__c()==null) || 
             (this.AMWFBNK__CheckPoint2_6__c!=null &&
              this.AMWFBNK__CheckPoint2_6__c.equals(other.getAMWFBNK__CheckPoint2_6__c()))) &&
            ((this.AMWFBNK__CheckPoint2_7__c==null && other.getAMWFBNK__CheckPoint2_7__c()==null) || 
             (this.AMWFBNK__CheckPoint2_7__c!=null &&
              this.AMWFBNK__CheckPoint2_7__c.equals(other.getAMWFBNK__CheckPoint2_7__c()))) &&
            ((this.AMWFBNK__CheckPoint2_8__c==null && other.getAMWFBNK__CheckPoint2_8__c()==null) || 
             (this.AMWFBNK__CheckPoint2_8__c!=null &&
              this.AMWFBNK__CheckPoint2_8__c.equals(other.getAMWFBNK__CheckPoint2_8__c()))) &&
            ((this.AMWFBNK__CheckPoint2_9__c==null && other.getAMWFBNK__CheckPoint2_9__c()==null) || 
             (this.AMWFBNK__CheckPoint2_9__c!=null &&
              this.AMWFBNK__CheckPoint2_9__c.equals(other.getAMWFBNK__CheckPoint2_9__c()))) &&
            ((this.AMWFBNK__Checked1_10__c==null && other.getAMWFBNK__Checked1_10__c()==null) || 
             (this.AMWFBNK__Checked1_10__c!=null &&
              this.AMWFBNK__Checked1_10__c.equals(other.getAMWFBNK__Checked1_10__c()))) &&
            ((this.AMWFBNK__Checked1_11__c==null && other.getAMWFBNK__Checked1_11__c()==null) || 
             (this.AMWFBNK__Checked1_11__c!=null &&
              this.AMWFBNK__Checked1_11__c.equals(other.getAMWFBNK__Checked1_11__c()))) &&
            ((this.AMWFBNK__Checked1_12__c==null && other.getAMWFBNK__Checked1_12__c()==null) || 
             (this.AMWFBNK__Checked1_12__c!=null &&
              this.AMWFBNK__Checked1_12__c.equals(other.getAMWFBNK__Checked1_12__c()))) &&
            ((this.AMWFBNK__Checked1_13__c==null && other.getAMWFBNK__Checked1_13__c()==null) || 
             (this.AMWFBNK__Checked1_13__c!=null &&
              this.AMWFBNK__Checked1_13__c.equals(other.getAMWFBNK__Checked1_13__c()))) &&
            ((this.AMWFBNK__Checked1_14__c==null && other.getAMWFBNK__Checked1_14__c()==null) || 
             (this.AMWFBNK__Checked1_14__c!=null &&
              this.AMWFBNK__Checked1_14__c.equals(other.getAMWFBNK__Checked1_14__c()))) &&
            ((this.AMWFBNK__Checked1_15__c==null && other.getAMWFBNK__Checked1_15__c()==null) || 
             (this.AMWFBNK__Checked1_15__c!=null &&
              this.AMWFBNK__Checked1_15__c.equals(other.getAMWFBNK__Checked1_15__c()))) &&
            ((this.AMWFBNK__Checked1_16__c==null && other.getAMWFBNK__Checked1_16__c()==null) || 
             (this.AMWFBNK__Checked1_16__c!=null &&
              this.AMWFBNK__Checked1_16__c.equals(other.getAMWFBNK__Checked1_16__c()))) &&
            ((this.AMWFBNK__Checked1_17__c==null && other.getAMWFBNK__Checked1_17__c()==null) || 
             (this.AMWFBNK__Checked1_17__c!=null &&
              this.AMWFBNK__Checked1_17__c.equals(other.getAMWFBNK__Checked1_17__c()))) &&
            ((this.AMWFBNK__Checked1_18__c==null && other.getAMWFBNK__Checked1_18__c()==null) || 
             (this.AMWFBNK__Checked1_18__c!=null &&
              this.AMWFBNK__Checked1_18__c.equals(other.getAMWFBNK__Checked1_18__c()))) &&
            ((this.AMWFBNK__Checked1_19__c==null && other.getAMWFBNK__Checked1_19__c()==null) || 
             (this.AMWFBNK__Checked1_19__c!=null &&
              this.AMWFBNK__Checked1_19__c.equals(other.getAMWFBNK__Checked1_19__c()))) &&
            ((this.AMWFBNK__Checked1_1__c==null && other.getAMWFBNK__Checked1_1__c()==null) || 
             (this.AMWFBNK__Checked1_1__c!=null &&
              this.AMWFBNK__Checked1_1__c.equals(other.getAMWFBNK__Checked1_1__c()))) &&
            ((this.AMWFBNK__Checked1_20__c==null && other.getAMWFBNK__Checked1_20__c()==null) || 
             (this.AMWFBNK__Checked1_20__c!=null &&
              this.AMWFBNK__Checked1_20__c.equals(other.getAMWFBNK__Checked1_20__c()))) &&
            ((this.AMWFBNK__Checked1_2__c==null && other.getAMWFBNK__Checked1_2__c()==null) || 
             (this.AMWFBNK__Checked1_2__c!=null &&
              this.AMWFBNK__Checked1_2__c.equals(other.getAMWFBNK__Checked1_2__c()))) &&
            ((this.AMWFBNK__Checked1_3__c==null && other.getAMWFBNK__Checked1_3__c()==null) || 
             (this.AMWFBNK__Checked1_3__c!=null &&
              this.AMWFBNK__Checked1_3__c.equals(other.getAMWFBNK__Checked1_3__c()))) &&
            ((this.AMWFBNK__Checked1_4__c==null && other.getAMWFBNK__Checked1_4__c()==null) || 
             (this.AMWFBNK__Checked1_4__c!=null &&
              this.AMWFBNK__Checked1_4__c.equals(other.getAMWFBNK__Checked1_4__c()))) &&
            ((this.AMWFBNK__Checked1_5__c==null && other.getAMWFBNK__Checked1_5__c()==null) || 
             (this.AMWFBNK__Checked1_5__c!=null &&
              this.AMWFBNK__Checked1_5__c.equals(other.getAMWFBNK__Checked1_5__c()))) &&
            ((this.AMWFBNK__Checked1_6__c==null && other.getAMWFBNK__Checked1_6__c()==null) || 
             (this.AMWFBNK__Checked1_6__c!=null &&
              this.AMWFBNK__Checked1_6__c.equals(other.getAMWFBNK__Checked1_6__c()))) &&
            ((this.AMWFBNK__Checked1_7__c==null && other.getAMWFBNK__Checked1_7__c()==null) || 
             (this.AMWFBNK__Checked1_7__c!=null &&
              this.AMWFBNK__Checked1_7__c.equals(other.getAMWFBNK__Checked1_7__c()))) &&
            ((this.AMWFBNK__Checked1_8__c==null && other.getAMWFBNK__Checked1_8__c()==null) || 
             (this.AMWFBNK__Checked1_8__c!=null &&
              this.AMWFBNK__Checked1_8__c.equals(other.getAMWFBNK__Checked1_8__c()))) &&
            ((this.AMWFBNK__Checked1_9__c==null && other.getAMWFBNK__Checked1_9__c()==null) || 
             (this.AMWFBNK__Checked1_9__c!=null &&
              this.AMWFBNK__Checked1_9__c.equals(other.getAMWFBNK__Checked1_9__c()))) &&
            ((this.AMWFBNK__Checked2_10__c==null && other.getAMWFBNK__Checked2_10__c()==null) || 
             (this.AMWFBNK__Checked2_10__c!=null &&
              this.AMWFBNK__Checked2_10__c.equals(other.getAMWFBNK__Checked2_10__c()))) &&
            ((this.AMWFBNK__Checked2_11__c==null && other.getAMWFBNK__Checked2_11__c()==null) || 
             (this.AMWFBNK__Checked2_11__c!=null &&
              this.AMWFBNK__Checked2_11__c.equals(other.getAMWFBNK__Checked2_11__c()))) &&
            ((this.AMWFBNK__Checked2_12__c==null && other.getAMWFBNK__Checked2_12__c()==null) || 
             (this.AMWFBNK__Checked2_12__c!=null &&
              this.AMWFBNK__Checked2_12__c.equals(other.getAMWFBNK__Checked2_12__c()))) &&
            ((this.AMWFBNK__Checked2_13__c==null && other.getAMWFBNK__Checked2_13__c()==null) || 
             (this.AMWFBNK__Checked2_13__c!=null &&
              this.AMWFBNK__Checked2_13__c.equals(other.getAMWFBNK__Checked2_13__c()))) &&
            ((this.AMWFBNK__Checked2_14__c==null && other.getAMWFBNK__Checked2_14__c()==null) || 
             (this.AMWFBNK__Checked2_14__c!=null &&
              this.AMWFBNK__Checked2_14__c.equals(other.getAMWFBNK__Checked2_14__c()))) &&
            ((this.AMWFBNK__Checked2_15__c==null && other.getAMWFBNK__Checked2_15__c()==null) || 
             (this.AMWFBNK__Checked2_15__c!=null &&
              this.AMWFBNK__Checked2_15__c.equals(other.getAMWFBNK__Checked2_15__c()))) &&
            ((this.AMWFBNK__Checked2_16__c==null && other.getAMWFBNK__Checked2_16__c()==null) || 
             (this.AMWFBNK__Checked2_16__c!=null &&
              this.AMWFBNK__Checked2_16__c.equals(other.getAMWFBNK__Checked2_16__c()))) &&
            ((this.AMWFBNK__Checked2_17__c==null && other.getAMWFBNK__Checked2_17__c()==null) || 
             (this.AMWFBNK__Checked2_17__c!=null &&
              this.AMWFBNK__Checked2_17__c.equals(other.getAMWFBNK__Checked2_17__c()))) &&
            ((this.AMWFBNK__Checked2_18__c==null && other.getAMWFBNK__Checked2_18__c()==null) || 
             (this.AMWFBNK__Checked2_18__c!=null &&
              this.AMWFBNK__Checked2_18__c.equals(other.getAMWFBNK__Checked2_18__c()))) &&
            ((this.AMWFBNK__Checked2_19__c==null && other.getAMWFBNK__Checked2_19__c()==null) || 
             (this.AMWFBNK__Checked2_19__c!=null &&
              this.AMWFBNK__Checked2_19__c.equals(other.getAMWFBNK__Checked2_19__c()))) &&
            ((this.AMWFBNK__Checked2_1__c==null && other.getAMWFBNK__Checked2_1__c()==null) || 
             (this.AMWFBNK__Checked2_1__c!=null &&
              this.AMWFBNK__Checked2_1__c.equals(other.getAMWFBNK__Checked2_1__c()))) &&
            ((this.AMWFBNK__Checked2_20__c==null && other.getAMWFBNK__Checked2_20__c()==null) || 
             (this.AMWFBNK__Checked2_20__c!=null &&
              this.AMWFBNK__Checked2_20__c.equals(other.getAMWFBNK__Checked2_20__c()))) &&
            ((this.AMWFBNK__Checked2_2__c==null && other.getAMWFBNK__Checked2_2__c()==null) || 
             (this.AMWFBNK__Checked2_2__c!=null &&
              this.AMWFBNK__Checked2_2__c.equals(other.getAMWFBNK__Checked2_2__c()))) &&
            ((this.AMWFBNK__Checked2_3__c==null && other.getAMWFBNK__Checked2_3__c()==null) || 
             (this.AMWFBNK__Checked2_3__c!=null &&
              this.AMWFBNK__Checked2_3__c.equals(other.getAMWFBNK__Checked2_3__c()))) &&
            ((this.AMWFBNK__Checked2_4__c==null && other.getAMWFBNK__Checked2_4__c()==null) || 
             (this.AMWFBNK__Checked2_4__c!=null &&
              this.AMWFBNK__Checked2_4__c.equals(other.getAMWFBNK__Checked2_4__c()))) &&
            ((this.AMWFBNK__Checked2_5__c==null && other.getAMWFBNK__Checked2_5__c()==null) || 
             (this.AMWFBNK__Checked2_5__c!=null &&
              this.AMWFBNK__Checked2_5__c.equals(other.getAMWFBNK__Checked2_5__c()))) &&
            ((this.AMWFBNK__Checked2_6__c==null && other.getAMWFBNK__Checked2_6__c()==null) || 
             (this.AMWFBNK__Checked2_6__c!=null &&
              this.AMWFBNK__Checked2_6__c.equals(other.getAMWFBNK__Checked2_6__c()))) &&
            ((this.AMWFBNK__Checked2_7__c==null && other.getAMWFBNK__Checked2_7__c()==null) || 
             (this.AMWFBNK__Checked2_7__c!=null &&
              this.AMWFBNK__Checked2_7__c.equals(other.getAMWFBNK__Checked2_7__c()))) &&
            ((this.AMWFBNK__Checked2_8__c==null && other.getAMWFBNK__Checked2_8__c()==null) || 
             (this.AMWFBNK__Checked2_8__c!=null &&
              this.AMWFBNK__Checked2_8__c.equals(other.getAMWFBNK__Checked2_8__c()))) &&
            ((this.AMWFBNK__Checked2_9__c==null && other.getAMWFBNK__Checked2_9__c()==null) || 
             (this.AMWFBNK__Checked2_9__c!=null &&
              this.AMWFBNK__Checked2_9__c.equals(other.getAMWFBNK__Checked2_9__c()))) &&
            ((this.AMWFBNK__FlowCode__c==null && other.getAMWFBNK__FlowCode__c()==null) || 
             (this.AMWFBNK__FlowCode__c!=null &&
              this.AMWFBNK__FlowCode__c.equals(other.getAMWFBNK__FlowCode__c()))) &&
            ((this.AMWFBNK__FlowType__c==null && other.getAMWFBNK__FlowType__c()==null) || 
             (this.AMWFBNK__FlowType__c!=null &&
              this.AMWFBNK__FlowType__c.equals(other.getAMWFBNK__FlowType__c()))) &&
            ((this.AMWFBNK__FreeCheck1__c==null && other.getAMWFBNK__FreeCheck1__c()==null) || 
             (this.AMWFBNK__FreeCheck1__c!=null &&
              this.AMWFBNK__FreeCheck1__c.equals(other.getAMWFBNK__FreeCheck1__c()))) &&
            ((this.AMWFBNK__FreeCheck2__c==null && other.getAMWFBNK__FreeCheck2__c()==null) || 
             (this.AMWFBNK__FreeCheck2__c!=null &&
              this.AMWFBNK__FreeCheck2__c.equals(other.getAMWFBNK__FreeCheck2__c()))) &&
            ((this.AMWFBNK__FreeCheck3__c==null && other.getAMWFBNK__FreeCheck3__c()==null) || 
             (this.AMWFBNK__FreeCheck3__c!=null &&
              this.AMWFBNK__FreeCheck3__c.equals(other.getAMWFBNK__FreeCheck3__c()))) &&
            ((this.AMWFBNK__FreeCheck4__c==null && other.getAMWFBNK__FreeCheck4__c()==null) || 
             (this.AMWFBNK__FreeCheck4__c!=null &&
              this.AMWFBNK__FreeCheck4__c.equals(other.getAMWFBNK__FreeCheck4__c()))) &&
            ((this.AMWFBNK__FreeCheck5__c==null && other.getAMWFBNK__FreeCheck5__c()==null) || 
             (this.AMWFBNK__FreeCheck5__c!=null &&
              this.AMWFBNK__FreeCheck5__c.equals(other.getAMWFBNK__FreeCheck5__c()))) &&
            ((this.AMWFBNK__FreeText1__c==null && other.getAMWFBNK__FreeText1__c()==null) || 
             (this.AMWFBNK__FreeText1__c!=null &&
              this.AMWFBNK__FreeText1__c.equals(other.getAMWFBNK__FreeText1__c()))) &&
            ((this.AMWFBNK__FreeText2__c==null && other.getAMWFBNK__FreeText2__c()==null) || 
             (this.AMWFBNK__FreeText2__c!=null &&
              this.AMWFBNK__FreeText2__c.equals(other.getAMWFBNK__FreeText2__c()))) &&
            ((this.AMWFBNK__FreeText3__c==null && other.getAMWFBNK__FreeText3__c()==null) || 
             (this.AMWFBNK__FreeText3__c!=null &&
              this.AMWFBNK__FreeText3__c.equals(other.getAMWFBNK__FreeText3__c()))) &&
            ((this.AMWFBNK__FreeText4__c==null && other.getAMWFBNK__FreeText4__c()==null) || 
             (this.AMWFBNK__FreeText4__c!=null &&
              this.AMWFBNK__FreeText4__c.equals(other.getAMWFBNK__FreeText4__c()))) &&
            ((this.AMWFBNK__FreeText5__c==null && other.getAMWFBNK__FreeText5__c()==null) || 
             (this.AMWFBNK__FreeText5__c!=null &&
              this.AMWFBNK__FreeText5__c.equals(other.getAMWFBNK__FreeText5__c()))) &&
            ((this.AMWFBNK__GroupId1__c==null && other.getAMWFBNK__GroupId1__c()==null) || 
             (this.AMWFBNK__GroupId1__c!=null &&
              this.AMWFBNK__GroupId1__c.equals(other.getAMWFBNK__GroupId1__c()))) &&
            ((this.AMWFBNK__GroupId2__c==null && other.getAMWFBNK__GroupId2__c()==null) || 
             (this.AMWFBNK__GroupId2__c!=null &&
              this.AMWFBNK__GroupId2__c.equals(other.getAMWFBNK__GroupId2__c()))) &&
            ((this.AMWFBNK__GroupName1__c==null && other.getAMWFBNK__GroupName1__c()==null) || 
             (this.AMWFBNK__GroupName1__c!=null &&
              this.AMWFBNK__GroupName1__c.equals(other.getAMWFBNK__GroupName1__c()))) &&
            ((this.AMWFBNK__GroupName2__c==null && other.getAMWFBNK__GroupName2__c()==null) || 
             (this.AMWFBNK__GroupName2__c!=null &&
              this.AMWFBNK__GroupName2__c.equals(other.getAMWFBNK__GroupName2__c()))) &&
            ((this.AMWFBNK__ObjectName__c==null && other.getAMWFBNK__ObjectName__c()==null) || 
             (this.AMWFBNK__ObjectName__c!=null &&
              this.AMWFBNK__ObjectName__c.equals(other.getAMWFBNK__ObjectName__c()))) &&
            ((this.AMWFBNK__RecordId__c==null && other.getAMWFBNK__RecordId__c()==null) || 
             (this.AMWFBNK__RecordId__c!=null &&
              this.AMWFBNK__RecordId__c.equals(other.getAMWFBNK__RecordId__c()))) &&
            ((this.AMWFBNK__Status__c==null && other.getAMWFBNK__Status__c()==null) || 
             (this.AMWFBNK__Status__c!=null &&
              this.AMWFBNK__Status__c.equals(other.getAMWFBNK__Status__c()))) &&
            ((this.AMWFBNK__SttnUnit__r==null && other.getAMWFBNK__SttnUnit__r()==null) || 
             (this.AMWFBNK__SttnUnit__r!=null &&
              this.AMWFBNK__SttnUnit__r.equals(other.getAMWFBNK__SttnUnit__r()))) &&
            ((this.AMWFBNK__URL__c==null && other.getAMWFBNK__URL__c()==null) || 
             (this.AMWFBNK__URL__c!=null &&
              this.AMWFBNK__URL__c.equals(other.getAMWFBNK__URL__c()))) &&
            ((this.AMWFBNK__UpsertedByAPI__c==null && other.getAMWFBNK__UpsertedByAPI__c()==null) || 
             (this.AMWFBNK__UpsertedByAPI__c!=null &&
              this.AMWFBNK__UpsertedByAPI__c.equals(other.getAMWFBNK__UpsertedByAPI__c()))) &&
            ((this.AMWFBNK__User__c==null && other.getAMWFBNK__User__c()==null) || 
             (this.AMWFBNK__User__c!=null &&
              this.AMWFBNK__User__c.equals(other.getAMWFBNK__User__c()))) &&
            ((this.AMWFBNK__User__r==null && other.getAMWFBNK__User__r()==null) || 
             (this.AMWFBNK__User__r!=null &&
              this.AMWFBNK__User__r.equals(other.getAMWFBNK__User__r()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.CIRCULATEDLASTDATE__c==null && other.getCIRCULATEDLASTDATE__c()==null) || 
             (this.CIRCULATEDLASTDATE__c!=null &&
              this.CIRCULATEDLASTDATE__c.equals(other.getCIRCULATEDLASTDATE__c()))) &&
            ((this.CIRCULATEDNAME__c==null && other.getCIRCULATEDNAME__c()==null) || 
             (this.CIRCULATEDNAME__c!=null &&
              this.CIRCULATEDNAME__c.equals(other.getCIRCULATEDNAME__c()))) &&
            ((this.CIRCULATEDPOST__c==null && other.getCIRCULATEDPOST__c()==null) || 
             (this.CIRCULATEDPOST__c!=null &&
              this.CIRCULATEDPOST__c.equals(other.getCIRCULATEDPOST__c()))) &&
            ((this.CIRCULATEDSETID__c==null && other.getCIRCULATEDSETID__c()==null) || 
             (this.CIRCULATEDSETID__c!=null &&
              this.CIRCULATEDSETID__c.equals(other.getCIRCULATEDSETID__c()))) &&
            ((this.CIRCULATEDTOUSER__c==null && other.getCIRCULATEDTOUSER__c()==null) || 
             (this.CIRCULATEDTOUSER__c!=null &&
              this.CIRCULATEDTOUSER__c.equals(other.getCIRCULATEDTOUSER__c()))) &&
            ((this.CIRCULATEDTOUSER__r==null && other.getCIRCULATEDTOUSER__r()==null) || 
             (this.CIRCULATEDTOUSER__r!=null &&
              this.CIRCULATEDTOUSER__r.equals(other.getCIRCULATEDTOUSER__r()))) &&
            ((this.CIRCULATEDUNIT__c==null && other.getCIRCULATEDUNIT__c()==null) || 
             (this.CIRCULATEDUNIT__c!=null &&
              this.CIRCULATEDUNIT__c.equals(other.getCIRCULATEDUNIT__c()))) &&
            ((this.CONCURRENTFLAG1__c==null && other.getCONCURRENTFLAG1__c()==null) || 
             (this.CONCURRENTFLAG1__c!=null &&
              this.CONCURRENTFLAG1__c.equals(other.getCONCURRENTFLAG1__c()))) &&
            ((this.CONCURRENTFLAG2__c==null && other.getCONCURRENTFLAG2__c()==null) || 
             (this.CONCURRENTFLAG2__c!=null &&
              this.CONCURRENTFLAG2__c.equals(other.getCONCURRENTFLAG2__c()))) &&
            ((this.CONCURRENTFLAG__c==null && other.getCONCURRENTFLAG__c()==null) || 
             (this.CONCURRENTFLAG__c!=null &&
              this.CONCURRENTFLAG__c.equals(other.getCONCURRENTFLAG__c()))) &&
            ((this.CONDITIONSTEXT__c==null && other.getCONDITIONSTEXT__c()==null) || 
             (this.CONDITIONSTEXT__c!=null &&
              this.CONDITIONSTEXT__c.equals(other.getCONDITIONSTEXT__c()))) &&
            ((this.CONDITIONS__c==null && other.getCONDITIONS__c()==null) || 
             (this.CONDITIONS__c!=null &&
              this.CONDITIONS__c.equals(other.getCONDITIONS__c()))) &&
            ((this.CONINDICATREPORT_TEXT__c==null && other.getCONINDICATREPORT_TEXT__c()==null) || 
             (this.CONINDICATREPORT_TEXT__c!=null &&
              this.CONINDICATREPORT_TEXT__c.equals(other.getCONINDICATREPORT_TEXT__c()))) &&
            ((this.CONINDICATREPORT__c==null && other.getCONINDICATREPORT__c()==null) || 
             (this.CONINDICATREPORT__c!=null &&
              this.CONINDICATREPORT__c.equals(other.getCONINDICATREPORT__c()))) &&
            ((this.CONLASTMODIFIEDBY__c==null && other.getCONLASTMODIFIEDBY__c()==null) || 
             (this.CONLASTMODIFIEDBY__c!=null &&
              this.CONLASTMODIFIEDBY__c.equals(other.getCONLASTMODIFIEDBY__c()))) &&
            ((this.CONLASTMODIFIEDBY__r==null && other.getCONLASTMODIFIEDBY__r()==null) || 
             (this.CONLASTMODIFIEDBY__r!=null &&
              this.CONLASTMODIFIEDBY__r.equals(other.getCONLASTMODIFIEDBY__r()))) &&
            ((this.CONLASTMODIFIEDDATE__c==null && other.getCONLASTMODIFIEDDATE__c()==null) || 
             (this.CONLASTMODIFIEDDATE__c!=null &&
              this.CONLASTMODIFIEDDATE__c.equals(other.getCONLASTMODIFIEDDATE__c()))) &&
            ((this.CONLASTMODIFIEDINFO__c==null && other.getCONLASTMODIFIEDINFO__c()==null) || 
             (this.CONLASTMODIFIEDINFO__c!=null &&
              this.CONLASTMODIFIEDINFO__c.equals(other.getCONLASTMODIFIEDINFO__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.DAIKO_FLG__c==null && other.getDAIKO_FLG__c()==null) || 
             (this.DAIKO_FLG__c!=null &&
              this.DAIKO_FLG__c.equals(other.getDAIKO_FLG__c()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.IMPORTANT_TEXT__c==null && other.getIMPORTANT_TEXT__c()==null) || 
             (this.IMPORTANT_TEXT__c!=null &&
              this.IMPORTANT_TEXT__c.equals(other.getIMPORTANT_TEXT__c()))) &&
            ((this.IMPORTANT__c==null && other.getIMPORTANT__c()==null) || 
             (this.IMPORTANT__c!=null &&
              this.IMPORTANT__c.equals(other.getIMPORTANT__c()))) &&
            ((this.INDICATIONTEXT__c==null && other.getINDICATIONTEXT__c()==null) || 
             (this.INDICATIONTEXT__c!=null &&
              this.INDICATIONTEXT__c.equals(other.getINDICATIONTEXT__c()))) &&
            ((this.INDICATION__c==null && other.getINDICATION__c()==null) || 
             (this.INDICATION__c!=null &&
              this.INDICATION__c.equals(other.getINDICATION__c()))) &&
            ((this.INLASTMODIFIEDBY__c==null && other.getINLASTMODIFIEDBY__c()==null) || 
             (this.INLASTMODIFIEDBY__c!=null &&
              this.INLASTMODIFIEDBY__c.equals(other.getINLASTMODIFIEDBY__c()))) &&
            ((this.INLASTMODIFIEDBY__r==null && other.getINLASTMODIFIEDBY__r()==null) || 
             (this.INLASTMODIFIEDBY__r!=null &&
              this.INLASTMODIFIEDBY__r.equals(other.getINLASTMODIFIEDBY__r()))) &&
            ((this.INLASTMODIFIEDDATE__c==null && other.getINLASTMODIFIEDDATE__c()==null) || 
             (this.INLASTMODIFIEDDATE__c!=null &&
              this.INLASTMODIFIEDDATE__c.equals(other.getINLASTMODIFIEDDATE__c()))) &&
            ((this.INLASTMODIFIEDINFO__c==null && other.getINLASTMODIFIEDINFO__c()==null) || 
             (this.INLASTMODIFIEDINFO__c!=null &&
              this.INLASTMODIFIEDINFO__c.equals(other.getINLASTMODIFIEDINFO__c()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.KAIFUSAKI_BUSHO__c==null && other.getKAIFUSAKI_BUSHO__c()==null) || 
             (this.KAIFUSAKI_BUSHO__c!=null &&
              this.KAIFUSAKI_BUSHO__c.equals(other.getKAIFUSAKI_BUSHO__c()))) &&
            ((this.KAIFUSAKI_SHIMEI__c==null && other.getKAIFUSAKI_SHIMEI__c()==null) || 
             (this.KAIFUSAKI_SHIMEI__c!=null &&
              this.KAIFUSAKI_SHIMEI__c.equals(other.getKAIFUSAKI_SHIMEI__c()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.NON_DISPLAYFLAG__c==null && other.getNON_DISPLAYFLAG__c()==null) || 
             (this.NON_DISPLAYFLAG__c!=null &&
              this.NON_DISPLAYFLAG__c.equals(other.getNON_DISPLAYFLAG__c()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.RATIFICATIONCHECK__c==null && other.getRATIFICATIONCHECK__c()==null) || 
             (this.RATIFICATIONCHECK__c!=null &&
              this.RATIFICATIONCHECK__c.equals(other.getRATIFICATIONCHECK__c()))) &&
            ((this.RATIFICATIONLIST__c==null && other.getRATIFICATIONLIST__c()==null) || 
             (this.RATIFICATIONLIST__c!=null &&
              this.RATIFICATIONLIST__c.equals(other.getRATIFICATIONLIST__c()))) &&
            ((this.REFERENCECONCHECK__c==null && other.getREFERENCECONCHECK__c()==null) || 
             (this.REFERENCECONCHECK__c!=null &&
              this.REFERENCECONCHECK__c.equals(other.getREFERENCECONCHECK__c()))) &&
            ((this.REFERENCECONLIST__c==null && other.getREFERENCECONLIST__c()==null) || 
             (this.REFERENCECONLIST__c!=null &&
              this.REFERENCECONLIST__c.equals(other.getREFERENCECONLIST__c()))) &&
            ((this.REPORTABLE__c==null && other.getREPORTABLE__c()==null) || 
             (this.REPORTABLE__c!=null &&
              this.REPORTABLE__c.equals(other.getREPORTABLE__c()))) &&
            ((this.SEARCH_TEXT__c==null && other.getSEARCH_TEXT__c()==null) || 
             (this.SEARCH_TEXT__c!=null &&
              this.SEARCH_TEXT__c.equals(other.getSEARCH_TEXT__c()))) &&
            ((this.SORT_ORDER_STATUSCONFIRM__c==null && other.getSORT_ORDER_STATUSCONFIRM__c()==null) || 
             (this.SORT_ORDER_STATUSCONFIRM__c!=null &&
              this.SORT_ORDER_STATUSCONFIRM__c.equals(other.getSORT_ORDER_STATUSCONFIRM__c()))) &&
            ((this.SORT_ORDER_WIDCIRCULATED__c==null && other.getSORT_ORDER_WIDCIRCULATED__c()==null) || 
             (this.SORT_ORDER_WIDCIRCULATED__c!=null &&
              this.SORT_ORDER_WIDCIRCULATED__c.equals(other.getSORT_ORDER_WIDCIRCULATED__c()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.TANTOSHA_BUSHO__c==null && other.getTANTOSHA_BUSHO__c()==null) || 
             (this.TANTOSHA_BUSHO__c!=null &&
              this.TANTOSHA_BUSHO__c.equals(other.getTANTOSHA_BUSHO__c()))) &&
            ((this.TANTOSHA_SHIMEI__c==null && other.getTANTOSHA_SHIMEI__c()==null) || 
             (this.TANTOSHA_SHIMEI__c!=null &&
              this.TANTOSHA_SHIMEI__c.equals(other.getTANTOSHA_SHIMEI__c()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAMWFBNK__AppliCode__c() != null) {
            _hashCode += getAMWFBNK__AppliCode__c().hashCode();
        }
        if (getAMWFBNK__AppliName__c() != null) {
            _hashCode += getAMWFBNK__AppliName__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_10__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_10__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_11__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_11__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_12__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_12__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_13__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_13__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_14__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_14__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_15__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_15__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_16__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_16__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_17__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_17__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_18__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_18__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_19__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_19__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_1__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_1__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_20__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_20__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_2__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_2__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_3__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_3__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_4__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_4__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_5__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_5__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_6__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_6__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_7__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_7__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_8__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_8__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint1_9__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint1_9__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_10__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_10__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_11__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_11__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_12__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_12__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_13__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_13__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_14__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_14__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_15__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_15__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_16__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_16__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_17__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_17__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_18__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_18__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_19__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_19__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_1__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_1__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_20__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_20__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_2__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_2__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_3__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_3__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_4__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_4__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_5__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_5__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_6__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_6__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_7__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_7__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_8__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_8__c().hashCode();
        }
        if (getAMWFBNK__CheckPoint2_9__c() != null) {
            _hashCode += getAMWFBNK__CheckPoint2_9__c().hashCode();
        }
        if (getAMWFBNK__Checked1_10__c() != null) {
            _hashCode += getAMWFBNK__Checked1_10__c().hashCode();
        }
        if (getAMWFBNK__Checked1_11__c() != null) {
            _hashCode += getAMWFBNK__Checked1_11__c().hashCode();
        }
        if (getAMWFBNK__Checked1_12__c() != null) {
            _hashCode += getAMWFBNK__Checked1_12__c().hashCode();
        }
        if (getAMWFBNK__Checked1_13__c() != null) {
            _hashCode += getAMWFBNK__Checked1_13__c().hashCode();
        }
        if (getAMWFBNK__Checked1_14__c() != null) {
            _hashCode += getAMWFBNK__Checked1_14__c().hashCode();
        }
        if (getAMWFBNK__Checked1_15__c() != null) {
            _hashCode += getAMWFBNK__Checked1_15__c().hashCode();
        }
        if (getAMWFBNK__Checked1_16__c() != null) {
            _hashCode += getAMWFBNK__Checked1_16__c().hashCode();
        }
        if (getAMWFBNK__Checked1_17__c() != null) {
            _hashCode += getAMWFBNK__Checked1_17__c().hashCode();
        }
        if (getAMWFBNK__Checked1_18__c() != null) {
            _hashCode += getAMWFBNK__Checked1_18__c().hashCode();
        }
        if (getAMWFBNK__Checked1_19__c() != null) {
            _hashCode += getAMWFBNK__Checked1_19__c().hashCode();
        }
        if (getAMWFBNK__Checked1_1__c() != null) {
            _hashCode += getAMWFBNK__Checked1_1__c().hashCode();
        }
        if (getAMWFBNK__Checked1_20__c() != null) {
            _hashCode += getAMWFBNK__Checked1_20__c().hashCode();
        }
        if (getAMWFBNK__Checked1_2__c() != null) {
            _hashCode += getAMWFBNK__Checked1_2__c().hashCode();
        }
        if (getAMWFBNK__Checked1_3__c() != null) {
            _hashCode += getAMWFBNK__Checked1_3__c().hashCode();
        }
        if (getAMWFBNK__Checked1_4__c() != null) {
            _hashCode += getAMWFBNK__Checked1_4__c().hashCode();
        }
        if (getAMWFBNK__Checked1_5__c() != null) {
            _hashCode += getAMWFBNK__Checked1_5__c().hashCode();
        }
        if (getAMWFBNK__Checked1_6__c() != null) {
            _hashCode += getAMWFBNK__Checked1_6__c().hashCode();
        }
        if (getAMWFBNK__Checked1_7__c() != null) {
            _hashCode += getAMWFBNK__Checked1_7__c().hashCode();
        }
        if (getAMWFBNK__Checked1_8__c() != null) {
            _hashCode += getAMWFBNK__Checked1_8__c().hashCode();
        }
        if (getAMWFBNK__Checked1_9__c() != null) {
            _hashCode += getAMWFBNK__Checked1_9__c().hashCode();
        }
        if (getAMWFBNK__Checked2_10__c() != null) {
            _hashCode += getAMWFBNK__Checked2_10__c().hashCode();
        }
        if (getAMWFBNK__Checked2_11__c() != null) {
            _hashCode += getAMWFBNK__Checked2_11__c().hashCode();
        }
        if (getAMWFBNK__Checked2_12__c() != null) {
            _hashCode += getAMWFBNK__Checked2_12__c().hashCode();
        }
        if (getAMWFBNK__Checked2_13__c() != null) {
            _hashCode += getAMWFBNK__Checked2_13__c().hashCode();
        }
        if (getAMWFBNK__Checked2_14__c() != null) {
            _hashCode += getAMWFBNK__Checked2_14__c().hashCode();
        }
        if (getAMWFBNK__Checked2_15__c() != null) {
            _hashCode += getAMWFBNK__Checked2_15__c().hashCode();
        }
        if (getAMWFBNK__Checked2_16__c() != null) {
            _hashCode += getAMWFBNK__Checked2_16__c().hashCode();
        }
        if (getAMWFBNK__Checked2_17__c() != null) {
            _hashCode += getAMWFBNK__Checked2_17__c().hashCode();
        }
        if (getAMWFBNK__Checked2_18__c() != null) {
            _hashCode += getAMWFBNK__Checked2_18__c().hashCode();
        }
        if (getAMWFBNK__Checked2_19__c() != null) {
            _hashCode += getAMWFBNK__Checked2_19__c().hashCode();
        }
        if (getAMWFBNK__Checked2_1__c() != null) {
            _hashCode += getAMWFBNK__Checked2_1__c().hashCode();
        }
        if (getAMWFBNK__Checked2_20__c() != null) {
            _hashCode += getAMWFBNK__Checked2_20__c().hashCode();
        }
        if (getAMWFBNK__Checked2_2__c() != null) {
            _hashCode += getAMWFBNK__Checked2_2__c().hashCode();
        }
        if (getAMWFBNK__Checked2_3__c() != null) {
            _hashCode += getAMWFBNK__Checked2_3__c().hashCode();
        }
        if (getAMWFBNK__Checked2_4__c() != null) {
            _hashCode += getAMWFBNK__Checked2_4__c().hashCode();
        }
        if (getAMWFBNK__Checked2_5__c() != null) {
            _hashCode += getAMWFBNK__Checked2_5__c().hashCode();
        }
        if (getAMWFBNK__Checked2_6__c() != null) {
            _hashCode += getAMWFBNK__Checked2_6__c().hashCode();
        }
        if (getAMWFBNK__Checked2_7__c() != null) {
            _hashCode += getAMWFBNK__Checked2_7__c().hashCode();
        }
        if (getAMWFBNK__Checked2_8__c() != null) {
            _hashCode += getAMWFBNK__Checked2_8__c().hashCode();
        }
        if (getAMWFBNK__Checked2_9__c() != null) {
            _hashCode += getAMWFBNK__Checked2_9__c().hashCode();
        }
        if (getAMWFBNK__FlowCode__c() != null) {
            _hashCode += getAMWFBNK__FlowCode__c().hashCode();
        }
        if (getAMWFBNK__FlowType__c() != null) {
            _hashCode += getAMWFBNK__FlowType__c().hashCode();
        }
        if (getAMWFBNK__FreeCheck1__c() != null) {
            _hashCode += getAMWFBNK__FreeCheck1__c().hashCode();
        }
        if (getAMWFBNK__FreeCheck2__c() != null) {
            _hashCode += getAMWFBNK__FreeCheck2__c().hashCode();
        }
        if (getAMWFBNK__FreeCheck3__c() != null) {
            _hashCode += getAMWFBNK__FreeCheck3__c().hashCode();
        }
        if (getAMWFBNK__FreeCheck4__c() != null) {
            _hashCode += getAMWFBNK__FreeCheck4__c().hashCode();
        }
        if (getAMWFBNK__FreeCheck5__c() != null) {
            _hashCode += getAMWFBNK__FreeCheck5__c().hashCode();
        }
        if (getAMWFBNK__FreeText1__c() != null) {
            _hashCode += getAMWFBNK__FreeText1__c().hashCode();
        }
        if (getAMWFBNK__FreeText2__c() != null) {
            _hashCode += getAMWFBNK__FreeText2__c().hashCode();
        }
        if (getAMWFBNK__FreeText3__c() != null) {
            _hashCode += getAMWFBNK__FreeText3__c().hashCode();
        }
        if (getAMWFBNK__FreeText4__c() != null) {
            _hashCode += getAMWFBNK__FreeText4__c().hashCode();
        }
        if (getAMWFBNK__FreeText5__c() != null) {
            _hashCode += getAMWFBNK__FreeText5__c().hashCode();
        }
        if (getAMWFBNK__GroupId1__c() != null) {
            _hashCode += getAMWFBNK__GroupId1__c().hashCode();
        }
        if (getAMWFBNK__GroupId2__c() != null) {
            _hashCode += getAMWFBNK__GroupId2__c().hashCode();
        }
        if (getAMWFBNK__GroupName1__c() != null) {
            _hashCode += getAMWFBNK__GroupName1__c().hashCode();
        }
        if (getAMWFBNK__GroupName2__c() != null) {
            _hashCode += getAMWFBNK__GroupName2__c().hashCode();
        }
        if (getAMWFBNK__ObjectName__c() != null) {
            _hashCode += getAMWFBNK__ObjectName__c().hashCode();
        }
        if (getAMWFBNK__RecordId__c() != null) {
            _hashCode += getAMWFBNK__RecordId__c().hashCode();
        }
        if (getAMWFBNK__Status__c() != null) {
            _hashCode += getAMWFBNK__Status__c().hashCode();
        }
        if (getAMWFBNK__SttnUnit__r() != null) {
            _hashCode += getAMWFBNK__SttnUnit__r().hashCode();
        }
        if (getAMWFBNK__URL__c() != null) {
            _hashCode += getAMWFBNK__URL__c().hashCode();
        }
        if (getAMWFBNK__UpsertedByAPI__c() != null) {
            _hashCode += getAMWFBNK__UpsertedByAPI__c().hashCode();
        }
        if (getAMWFBNK__User__c() != null) {
            _hashCode += getAMWFBNK__User__c().hashCode();
        }
        if (getAMWFBNK__User__r() != null) {
            _hashCode += getAMWFBNK__User__r().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getCIRCULATEDLASTDATE__c() != null) {
            _hashCode += getCIRCULATEDLASTDATE__c().hashCode();
        }
        if (getCIRCULATEDNAME__c() != null) {
            _hashCode += getCIRCULATEDNAME__c().hashCode();
        }
        if (getCIRCULATEDPOST__c() != null) {
            _hashCode += getCIRCULATEDPOST__c().hashCode();
        }
        if (getCIRCULATEDSETID__c() != null) {
            _hashCode += getCIRCULATEDSETID__c().hashCode();
        }
        if (getCIRCULATEDTOUSER__c() != null) {
            _hashCode += getCIRCULATEDTOUSER__c().hashCode();
        }
        if (getCIRCULATEDTOUSER__r() != null) {
            _hashCode += getCIRCULATEDTOUSER__r().hashCode();
        }
        if (getCIRCULATEDUNIT__c() != null) {
            _hashCode += getCIRCULATEDUNIT__c().hashCode();
        }
        if (getCONCURRENTFLAG1__c() != null) {
            _hashCode += getCONCURRENTFLAG1__c().hashCode();
        }
        if (getCONCURRENTFLAG2__c() != null) {
            _hashCode += getCONCURRENTFLAG2__c().hashCode();
        }
        if (getCONCURRENTFLAG__c() != null) {
            _hashCode += getCONCURRENTFLAG__c().hashCode();
        }
        if (getCONDITIONSTEXT__c() != null) {
            _hashCode += getCONDITIONSTEXT__c().hashCode();
        }
        if (getCONDITIONS__c() != null) {
            _hashCode += getCONDITIONS__c().hashCode();
        }
        if (getCONINDICATREPORT_TEXT__c() != null) {
            _hashCode += getCONINDICATREPORT_TEXT__c().hashCode();
        }
        if (getCONINDICATREPORT__c() != null) {
            _hashCode += getCONINDICATREPORT__c().hashCode();
        }
        if (getCONLASTMODIFIEDBY__c() != null) {
            _hashCode += getCONLASTMODIFIEDBY__c().hashCode();
        }
        if (getCONLASTMODIFIEDBY__r() != null) {
            _hashCode += getCONLASTMODIFIEDBY__r().hashCode();
        }
        if (getCONLASTMODIFIEDDATE__c() != null) {
            _hashCode += getCONLASTMODIFIEDDATE__c().hashCode();
        }
        if (getCONLASTMODIFIEDINFO__c() != null) {
            _hashCode += getCONLASTMODIFIEDINFO__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDAIKO_FLG__c() != null) {
            _hashCode += getDAIKO_FLG__c().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getIMPORTANT_TEXT__c() != null) {
            _hashCode += getIMPORTANT_TEXT__c().hashCode();
        }
        if (getIMPORTANT__c() != null) {
            _hashCode += getIMPORTANT__c().hashCode();
        }
        if (getINDICATIONTEXT__c() != null) {
            _hashCode += getINDICATIONTEXT__c().hashCode();
        }
        if (getINDICATION__c() != null) {
            _hashCode += getINDICATION__c().hashCode();
        }
        if (getINLASTMODIFIEDBY__c() != null) {
            _hashCode += getINLASTMODIFIEDBY__c().hashCode();
        }
        if (getINLASTMODIFIEDBY__r() != null) {
            _hashCode += getINLASTMODIFIEDBY__r().hashCode();
        }
        if (getINLASTMODIFIEDDATE__c() != null) {
            _hashCode += getINLASTMODIFIEDDATE__c().hashCode();
        }
        if (getINLASTMODIFIEDINFO__c() != null) {
            _hashCode += getINLASTMODIFIEDINFO__c().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getKAIFUSAKI_BUSHO__c() != null) {
            _hashCode += getKAIFUSAKI_BUSHO__c().hashCode();
        }
        if (getKAIFUSAKI_SHIMEI__c() != null) {
            _hashCode += getKAIFUSAKI_SHIMEI__c().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getNON_DISPLAYFLAG__c() != null) {
            _hashCode += getNON_DISPLAYFLAG__c().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getRATIFICATIONCHECK__c() != null) {
            _hashCode += getRATIFICATIONCHECK__c().hashCode();
        }
        if (getRATIFICATIONLIST__c() != null) {
            _hashCode += getRATIFICATIONLIST__c().hashCode();
        }
        if (getREFERENCECONCHECK__c() != null) {
            _hashCode += getREFERENCECONCHECK__c().hashCode();
        }
        if (getREFERENCECONLIST__c() != null) {
            _hashCode += getREFERENCECONLIST__c().hashCode();
        }
        if (getREPORTABLE__c() != null) {
            _hashCode += getREPORTABLE__c().hashCode();
        }
        if (getSEARCH_TEXT__c() != null) {
            _hashCode += getSEARCH_TEXT__c().hashCode();
        }
        if (getSORT_ORDER_STATUSCONFIRM__c() != null) {
            _hashCode += getSORT_ORDER_STATUSCONFIRM__c().hashCode();
        }
        if (getSORT_ORDER_WIDCIRCULATED__c() != null) {
            _hashCode += getSORT_ORDER_WIDCIRCULATED__c().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTANTOSHA_BUSHO__c() != null) {
            _hashCode += getTANTOSHA_BUSHO__c().hashCode();
        }
        if (getTANTOSHA_SHIMEI__c() != null) {
            _hashCode += getTANTOSHA_SHIMEI__c().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AMWFBNK__Unit__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Unit__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__AppliCode__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__AppliCode__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__AppliName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__AppliName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_11__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_11__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_12__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_12__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_13__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_13__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_14__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_14__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_15__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_15__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_16__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_16__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_17__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_17__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_18__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_18__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_19__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_19__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_20__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_20__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_6__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_6__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_7__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_7__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_8__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_8__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint1_9__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint1_9__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_11__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_11__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_12__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_12__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_13__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_13__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_14__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_14__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_15__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_15__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_16__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_16__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_17__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_17__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_18__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_18__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_19__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_19__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_20__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_20__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_6__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_6__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_7__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_7__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_8__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_8__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__CheckPoint2_9__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__CheckPoint2_9__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_11__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_11__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_12__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_12__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_13__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_13__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_14__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_14__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_15__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_15__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_16__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_16__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_17__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_17__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_18__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_18__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_19__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_19__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_20__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_20__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_6__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_6__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_7__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_7__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_8__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_8__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked1_9__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked1_9__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_11__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_11__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_12__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_12__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_13__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_13__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_14__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_14__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_15__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_15__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_16__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_16__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_17__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_17__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_18__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_18__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_19__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_19__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_20__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_20__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_6__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_6__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_7__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_7__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_8__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_8__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Checked2_9__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Checked2_9__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FlowCode__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FlowCode__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FlowType__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FlowType__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeCheck1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeCheck1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeCheck2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeCheck2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeCheck3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeCheck3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeCheck4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeCheck4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeCheck5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeCheck5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeText1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeText1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeText2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeText2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeText3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeText3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeText4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeText4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__FreeText5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__FreeText5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__GroupId1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__GroupId1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__GroupId2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__GroupId2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__GroupName1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__GroupName1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__GroupName2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__GroupName2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__ObjectName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__ObjectName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__RecordId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__RecordId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__Status__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__Status__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__SttnUnit__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__SttnUnit__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__URL__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__URL__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__UpsertedByAPI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__UpsertedByAPI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__User__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__User__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AMWFBNK__User__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AMWFBNK__User__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIRCULATEDLASTDATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIRCULATEDLASTDATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIRCULATEDNAME__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIRCULATEDNAME__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIRCULATEDPOST__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIRCULATEDPOST__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIRCULATEDSETID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIRCULATEDSETID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIRCULATEDTOUSER__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIRCULATEDTOUSER__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIRCULATEDTOUSER__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIRCULATEDTOUSER__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIRCULATEDUNIT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIRCULATEDUNIT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONCURRENTFLAG1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONCURRENTFLAG1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONCURRENTFLAG2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONCURRENTFLAG2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONCURRENTFLAG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONCURRENTFLAG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONDITIONSTEXT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONDITIONSTEXT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONDITIONS__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONDITIONS__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONINDICATREPORT_TEXT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONINDICATREPORT_TEXT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONINDICATREPORT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONINDICATREPORT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONLASTMODIFIEDBY__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONLASTMODIFIEDBY__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONLASTMODIFIEDBY__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONLASTMODIFIEDBY__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONLASTMODIFIEDDATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONLASTMODIFIEDDATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CONLASTMODIFIEDINFO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CONLASTMODIFIEDINFO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DAIKO_FLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DAIKO_FLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IMPORTANT_TEXT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IMPORTANT_TEXT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IMPORTANT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IMPORTANT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INDICATIONTEXT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "INDICATIONTEXT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INDICATION__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "INDICATION__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INLASTMODIFIEDBY__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "INLASTMODIFIEDBY__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INLASTMODIFIEDBY__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "INLASTMODIFIEDBY__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INLASTMODIFIEDDATE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "INLASTMODIFIEDDATE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("INLASTMODIFIEDINFO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "INLASTMODIFIEDINFO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAIFUSAKI_BUSHO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAIFUSAKI_BUSHO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAIFUSAKI_SHIMEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAIFUSAKI_SHIMEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NON_DISPLAYFLAG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NON_DISPLAYFLAG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RATIFICATIONCHECK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RATIFICATIONCHECK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RATIFICATIONLIST__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RATIFICATIONLIST__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REFERENCECONCHECK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "REFERENCECONCHECK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REFERENCECONLIST__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "REFERENCECONLIST__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTABLE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "REPORTABLE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SEARCH_TEXT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SEARCH_TEXT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SORT_ORDER_STATUSCONFIRM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SORT_ORDER_STATUSCONFIRM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SORT_ORDER_WIDCIRCULATED__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SORT_ORDER_WIDCIRCULATED__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TANTOSHA_BUSHO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TANTOSHA_BUSHO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TANTOSHA_SHIMEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TANTOSHA_SHIMEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
