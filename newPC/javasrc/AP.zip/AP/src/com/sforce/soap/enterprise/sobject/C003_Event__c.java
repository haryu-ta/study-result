/**
 * C003_Event__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C003_Event__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String c003_AccountRef__c;

    private com.sforce.soap.enterprise.sobject.Account c003_AccountRef__r;

    private java.lang.String c003_Area_01__c;

    private java.lang.String c003_Area_02__c;

    private java.lang.String c003_Area_03__c;

    private java.lang.String c003_Area_04__c;

    private java.lang.String c003_Area_05__c;

    private java.lang.String c003_Area_06__c;

    private java.lang.String c003_Area_07__c;

    private java.lang.String c003_Area_08__c;

    private java.lang.String c003_Area_09__c;

    private java.lang.String c003_Area_10__c;

    private java.util.Date c003_BaseDateFrom__c;

    private java.util.Date c003_BaseDateTo__c;

    private java.lang.String c003_Comment__c;

    private java.lang.String c003_ContractRef__c;

    private com.sforce.soap.enterprise.sobject.C003_Contract__c c003_ContractRef__r;

    private java.util.Date c003_EndDate__c;

    private java.lang.String c003_EventConfigRef__c;

    private com.sforce.soap.enterprise.sobject.C003_EventConfig__c c003_EventConfigRef__r;

    private java.lang.Boolean c003_Invalid30Days__c;

    private java.lang.String c003_NoticeAddress_User__c;

    private com.sforce.soap.enterprise.sobject.User c003_NoticeAddress_User__r;

    private java.lang.Double c003_ScoreTemp__c;

    private java.lang.String c003_Score__c;

    private java.util.Date c003_StartDate__c;

    private java.lang.String c003_Text_01__c;

    private java.lang.String c003_Text_02__c;

    private java.lang.String c003_Text_03__c;

    private java.lang.String c003_Text_04__c;

    private java.lang.String c003_Text_05__c;

    private java.lang.String c003_Text_06__c;

    private java.lang.String c003_Text_07__c;

    private java.lang.String c003_Text_08__c;

    private java.lang.String c003_Text_09__c;

    private java.lang.String c003_Text_10__c;

    private java.lang.String c003_Text_11__c;

    private java.lang.String c003_Text_12__c;

    private java.lang.String c003_Text_13__c;

    private java.lang.String c003_Text_14__c;

    private java.lang.String c003_Text_15__c;

    private java.lang.String c003_Text_16__c;

    private java.lang.String c003_Text_17__c;

    private java.lang.String c003_Text_18__c;

    private java.lang.String c003_Text_19__c;

    private java.lang.String c003_Text_20__c;

    private java.lang.String c003_Text_21__c;

    private java.lang.String c003_Text_22__c;

    private java.lang.String c003_Text_23__c;

    private java.lang.String c003_Text_24__c;

    private java.lang.String c003_Text_25__c;

    private java.lang.String c003_Text_26__c;

    private java.lang.String c003_Text_27__c;

    private java.lang.String c003_Text_28__c;

    private java.lang.String c003_Text_29__c;

    private java.lang.String c003_Text_30__c;

    private java.lang.String c003_Text_31__c;

    private java.lang.String c003_Text_32__c;

    private java.lang.String c003_Text_33__c;

    private java.lang.String c003_Text_34__c;

    private java.lang.String c003_Text_35__c;

    private java.lang.String c003_Text_36__c;

    private java.lang.String c003_Text_37__c;

    private java.lang.String c003_Text_38__c;

    private java.lang.String c003_Text_39__c;

    private java.lang.String c003_Text_40__c;

    private java.lang.String c003_Text_41__c;

    private java.lang.String c003_Text_42__c;

    private java.lang.String c003_Text_43__c;

    private java.lang.String c003_Text_44__c;

    private java.lang.String c003_Text_45__c;

    private java.lang.String c003_Text_46__c;

    private java.lang.String c003_Text_47__c;

    private java.lang.String c003_Text_48__c;

    private java.lang.String c003_Text_49__c;

    private java.lang.String c003_Text_50__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.util.Calendar lastReferencedDate;

    private java.util.Calendar lastViewedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    public C003_Event__c() {
    }

    public C003_Event__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String c003_AccountRef__c,
           com.sforce.soap.enterprise.sobject.Account c003_AccountRef__r,
           java.lang.String c003_Area_01__c,
           java.lang.String c003_Area_02__c,
           java.lang.String c003_Area_03__c,
           java.lang.String c003_Area_04__c,
           java.lang.String c003_Area_05__c,
           java.lang.String c003_Area_06__c,
           java.lang.String c003_Area_07__c,
           java.lang.String c003_Area_08__c,
           java.lang.String c003_Area_09__c,
           java.lang.String c003_Area_10__c,
           java.util.Date c003_BaseDateFrom__c,
           java.util.Date c003_BaseDateTo__c,
           java.lang.String c003_Comment__c,
           java.lang.String c003_ContractRef__c,
           com.sforce.soap.enterprise.sobject.C003_Contract__c c003_ContractRef__r,
           java.util.Date c003_EndDate__c,
           java.lang.String c003_EventConfigRef__c,
           com.sforce.soap.enterprise.sobject.C003_EventConfig__c c003_EventConfigRef__r,
           java.lang.Boolean c003_Invalid30Days__c,
           java.lang.String c003_NoticeAddress_User__c,
           com.sforce.soap.enterprise.sobject.User c003_NoticeAddress_User__r,
           java.lang.Double c003_ScoreTemp__c,
           java.lang.String c003_Score__c,
           java.util.Date c003_StartDate__c,
           java.lang.String c003_Text_01__c,
           java.lang.String c003_Text_02__c,
           java.lang.String c003_Text_03__c,
           java.lang.String c003_Text_04__c,
           java.lang.String c003_Text_05__c,
           java.lang.String c003_Text_06__c,
           java.lang.String c003_Text_07__c,
           java.lang.String c003_Text_08__c,
           java.lang.String c003_Text_09__c,
           java.lang.String c003_Text_10__c,
           java.lang.String c003_Text_11__c,
           java.lang.String c003_Text_12__c,
           java.lang.String c003_Text_13__c,
           java.lang.String c003_Text_14__c,
           java.lang.String c003_Text_15__c,
           java.lang.String c003_Text_16__c,
           java.lang.String c003_Text_17__c,
           java.lang.String c003_Text_18__c,
           java.lang.String c003_Text_19__c,
           java.lang.String c003_Text_20__c,
           java.lang.String c003_Text_21__c,
           java.lang.String c003_Text_22__c,
           java.lang.String c003_Text_23__c,
           java.lang.String c003_Text_24__c,
           java.lang.String c003_Text_25__c,
           java.lang.String c003_Text_26__c,
           java.lang.String c003_Text_27__c,
           java.lang.String c003_Text_28__c,
           java.lang.String c003_Text_29__c,
           java.lang.String c003_Text_30__c,
           java.lang.String c003_Text_31__c,
           java.lang.String c003_Text_32__c,
           java.lang.String c003_Text_33__c,
           java.lang.String c003_Text_34__c,
           java.lang.String c003_Text_35__c,
           java.lang.String c003_Text_36__c,
           java.lang.String c003_Text_37__c,
           java.lang.String c003_Text_38__c,
           java.lang.String c003_Text_39__c,
           java.lang.String c003_Text_40__c,
           java.lang.String c003_Text_41__c,
           java.lang.String c003_Text_42__c,
           java.lang.String c003_Text_43__c,
           java.lang.String c003_Text_44__c,
           java.lang.String c003_Text_45__c,
           java.lang.String c003_Text_46__c,
           java.lang.String c003_Text_47__c,
           java.lang.String c003_Text_48__c,
           java.lang.String c003_Text_49__c,
           java.lang.String c003_Text_50__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.util.Calendar lastReferencedDate,
           java.util.Calendar lastViewedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        super(
            fieldsToNull,
            id);
        this.attachments = attachments;
        this.c003_AccountRef__c = c003_AccountRef__c;
        this.c003_AccountRef__r = c003_AccountRef__r;
        this.c003_Area_01__c = c003_Area_01__c;
        this.c003_Area_02__c = c003_Area_02__c;
        this.c003_Area_03__c = c003_Area_03__c;
        this.c003_Area_04__c = c003_Area_04__c;
        this.c003_Area_05__c = c003_Area_05__c;
        this.c003_Area_06__c = c003_Area_06__c;
        this.c003_Area_07__c = c003_Area_07__c;
        this.c003_Area_08__c = c003_Area_08__c;
        this.c003_Area_09__c = c003_Area_09__c;
        this.c003_Area_10__c = c003_Area_10__c;
        this.c003_BaseDateFrom__c = c003_BaseDateFrom__c;
        this.c003_BaseDateTo__c = c003_BaseDateTo__c;
        this.c003_Comment__c = c003_Comment__c;
        this.c003_ContractRef__c = c003_ContractRef__c;
        this.c003_ContractRef__r = c003_ContractRef__r;
        this.c003_EndDate__c = c003_EndDate__c;
        this.c003_EventConfigRef__c = c003_EventConfigRef__c;
        this.c003_EventConfigRef__r = c003_EventConfigRef__r;
        this.c003_Invalid30Days__c = c003_Invalid30Days__c;
        this.c003_NoticeAddress_User__c = c003_NoticeAddress_User__c;
        this.c003_NoticeAddress_User__r = c003_NoticeAddress_User__r;
        this.c003_ScoreTemp__c = c003_ScoreTemp__c;
        this.c003_Score__c = c003_Score__c;
        this.c003_StartDate__c = c003_StartDate__c;
        this.c003_Text_01__c = c003_Text_01__c;
        this.c003_Text_02__c = c003_Text_02__c;
        this.c003_Text_03__c = c003_Text_03__c;
        this.c003_Text_04__c = c003_Text_04__c;
        this.c003_Text_05__c = c003_Text_05__c;
        this.c003_Text_06__c = c003_Text_06__c;
        this.c003_Text_07__c = c003_Text_07__c;
        this.c003_Text_08__c = c003_Text_08__c;
        this.c003_Text_09__c = c003_Text_09__c;
        this.c003_Text_10__c = c003_Text_10__c;
        this.c003_Text_11__c = c003_Text_11__c;
        this.c003_Text_12__c = c003_Text_12__c;
        this.c003_Text_13__c = c003_Text_13__c;
        this.c003_Text_14__c = c003_Text_14__c;
        this.c003_Text_15__c = c003_Text_15__c;
        this.c003_Text_16__c = c003_Text_16__c;
        this.c003_Text_17__c = c003_Text_17__c;
        this.c003_Text_18__c = c003_Text_18__c;
        this.c003_Text_19__c = c003_Text_19__c;
        this.c003_Text_20__c = c003_Text_20__c;
        this.c003_Text_21__c = c003_Text_21__c;
        this.c003_Text_22__c = c003_Text_22__c;
        this.c003_Text_23__c = c003_Text_23__c;
        this.c003_Text_24__c = c003_Text_24__c;
        this.c003_Text_25__c = c003_Text_25__c;
        this.c003_Text_26__c = c003_Text_26__c;
        this.c003_Text_27__c = c003_Text_27__c;
        this.c003_Text_28__c = c003_Text_28__c;
        this.c003_Text_29__c = c003_Text_29__c;
        this.c003_Text_30__c = c003_Text_30__c;
        this.c003_Text_31__c = c003_Text_31__c;
        this.c003_Text_32__c = c003_Text_32__c;
        this.c003_Text_33__c = c003_Text_33__c;
        this.c003_Text_34__c = c003_Text_34__c;
        this.c003_Text_35__c = c003_Text_35__c;
        this.c003_Text_36__c = c003_Text_36__c;
        this.c003_Text_37__c = c003_Text_37__c;
        this.c003_Text_38__c = c003_Text_38__c;
        this.c003_Text_39__c = c003_Text_39__c;
        this.c003_Text_40__c = c003_Text_40__c;
        this.c003_Text_41__c = c003_Text_41__c;
        this.c003_Text_42__c = c003_Text_42__c;
        this.c003_Text_43__c = c003_Text_43__c;
        this.c003_Text_44__c = c003_Text_44__c;
        this.c003_Text_45__c = c003_Text_45__c;
        this.c003_Text_46__c = c003_Text_46__c;
        this.c003_Text_47__c = c003_Text_47__c;
        this.c003_Text_48__c = c003_Text_48__c;
        this.c003_Text_49__c = c003_Text_49__c;
        this.c003_Text_50__c = c003_Text_50__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.duplicateRecordItems = duplicateRecordItems;
        this.isDeleted = isDeleted;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lastReferencedDate = lastReferencedDate;
        this.lastViewedDate = lastViewedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.systemModstamp = systemModstamp;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the attachments value for this C003_Event__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C003_Event__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the c003_AccountRef__c value for this C003_Event__c.
     * 
     * @return c003_AccountRef__c
     */
    public java.lang.String getC003_AccountRef__c() {
        return c003_AccountRef__c;
    }


    /**
     * Sets the c003_AccountRef__c value for this C003_Event__c.
     * 
     * @param c003_AccountRef__c
     */
    public void setC003_AccountRef__c(java.lang.String c003_AccountRef__c) {
        this.c003_AccountRef__c = c003_AccountRef__c;
    }


    /**
     * Gets the c003_AccountRef__r value for this C003_Event__c.
     * 
     * @return c003_AccountRef__r
     */
    public com.sforce.soap.enterprise.sobject.Account getC003_AccountRef__r() {
        return c003_AccountRef__r;
    }


    /**
     * Sets the c003_AccountRef__r value for this C003_Event__c.
     * 
     * @param c003_AccountRef__r
     */
    public void setC003_AccountRef__r(com.sforce.soap.enterprise.sobject.Account c003_AccountRef__r) {
        this.c003_AccountRef__r = c003_AccountRef__r;
    }


    /**
     * Gets the c003_Area_01__c value for this C003_Event__c.
     * 
     * @return c003_Area_01__c
     */
    public java.lang.String getC003_Area_01__c() {
        return c003_Area_01__c;
    }


    /**
     * Sets the c003_Area_01__c value for this C003_Event__c.
     * 
     * @param c003_Area_01__c
     */
    public void setC003_Area_01__c(java.lang.String c003_Area_01__c) {
        this.c003_Area_01__c = c003_Area_01__c;
    }


    /**
     * Gets the c003_Area_02__c value for this C003_Event__c.
     * 
     * @return c003_Area_02__c
     */
    public java.lang.String getC003_Area_02__c() {
        return c003_Area_02__c;
    }


    /**
     * Sets the c003_Area_02__c value for this C003_Event__c.
     * 
     * @param c003_Area_02__c
     */
    public void setC003_Area_02__c(java.lang.String c003_Area_02__c) {
        this.c003_Area_02__c = c003_Area_02__c;
    }


    /**
     * Gets the c003_Area_03__c value for this C003_Event__c.
     * 
     * @return c003_Area_03__c
     */
    public java.lang.String getC003_Area_03__c() {
        return c003_Area_03__c;
    }


    /**
     * Sets the c003_Area_03__c value for this C003_Event__c.
     * 
     * @param c003_Area_03__c
     */
    public void setC003_Area_03__c(java.lang.String c003_Area_03__c) {
        this.c003_Area_03__c = c003_Area_03__c;
    }


    /**
     * Gets the c003_Area_04__c value for this C003_Event__c.
     * 
     * @return c003_Area_04__c
     */
    public java.lang.String getC003_Area_04__c() {
        return c003_Area_04__c;
    }


    /**
     * Sets the c003_Area_04__c value for this C003_Event__c.
     * 
     * @param c003_Area_04__c
     */
    public void setC003_Area_04__c(java.lang.String c003_Area_04__c) {
        this.c003_Area_04__c = c003_Area_04__c;
    }


    /**
     * Gets the c003_Area_05__c value for this C003_Event__c.
     * 
     * @return c003_Area_05__c
     */
    public java.lang.String getC003_Area_05__c() {
        return c003_Area_05__c;
    }


    /**
     * Sets the c003_Area_05__c value for this C003_Event__c.
     * 
     * @param c003_Area_05__c
     */
    public void setC003_Area_05__c(java.lang.String c003_Area_05__c) {
        this.c003_Area_05__c = c003_Area_05__c;
    }


    /**
     * Gets the c003_Area_06__c value for this C003_Event__c.
     * 
     * @return c003_Area_06__c
     */
    public java.lang.String getC003_Area_06__c() {
        return c003_Area_06__c;
    }


    /**
     * Sets the c003_Area_06__c value for this C003_Event__c.
     * 
     * @param c003_Area_06__c
     */
    public void setC003_Area_06__c(java.lang.String c003_Area_06__c) {
        this.c003_Area_06__c = c003_Area_06__c;
    }


    /**
     * Gets the c003_Area_07__c value for this C003_Event__c.
     * 
     * @return c003_Area_07__c
     */
    public java.lang.String getC003_Area_07__c() {
        return c003_Area_07__c;
    }


    /**
     * Sets the c003_Area_07__c value for this C003_Event__c.
     * 
     * @param c003_Area_07__c
     */
    public void setC003_Area_07__c(java.lang.String c003_Area_07__c) {
        this.c003_Area_07__c = c003_Area_07__c;
    }


    /**
     * Gets the c003_Area_08__c value for this C003_Event__c.
     * 
     * @return c003_Area_08__c
     */
    public java.lang.String getC003_Area_08__c() {
        return c003_Area_08__c;
    }


    /**
     * Sets the c003_Area_08__c value for this C003_Event__c.
     * 
     * @param c003_Area_08__c
     */
    public void setC003_Area_08__c(java.lang.String c003_Area_08__c) {
        this.c003_Area_08__c = c003_Area_08__c;
    }


    /**
     * Gets the c003_Area_09__c value for this C003_Event__c.
     * 
     * @return c003_Area_09__c
     */
    public java.lang.String getC003_Area_09__c() {
        return c003_Area_09__c;
    }


    /**
     * Sets the c003_Area_09__c value for this C003_Event__c.
     * 
     * @param c003_Area_09__c
     */
    public void setC003_Area_09__c(java.lang.String c003_Area_09__c) {
        this.c003_Area_09__c = c003_Area_09__c;
    }


    /**
     * Gets the c003_Area_10__c value for this C003_Event__c.
     * 
     * @return c003_Area_10__c
     */
    public java.lang.String getC003_Area_10__c() {
        return c003_Area_10__c;
    }


    /**
     * Sets the c003_Area_10__c value for this C003_Event__c.
     * 
     * @param c003_Area_10__c
     */
    public void setC003_Area_10__c(java.lang.String c003_Area_10__c) {
        this.c003_Area_10__c = c003_Area_10__c;
    }


    /**
     * Gets the c003_BaseDateFrom__c value for this C003_Event__c.
     * 
     * @return c003_BaseDateFrom__c
     */
    public java.util.Date getC003_BaseDateFrom__c() {
        return c003_BaseDateFrom__c;
    }


    /**
     * Sets the c003_BaseDateFrom__c value for this C003_Event__c.
     * 
     * @param c003_BaseDateFrom__c
     */
    public void setC003_BaseDateFrom__c(java.util.Date c003_BaseDateFrom__c) {
        this.c003_BaseDateFrom__c = c003_BaseDateFrom__c;
    }


    /**
     * Gets the c003_BaseDateTo__c value for this C003_Event__c.
     * 
     * @return c003_BaseDateTo__c
     */
    public java.util.Date getC003_BaseDateTo__c() {
        return c003_BaseDateTo__c;
    }


    /**
     * Sets the c003_BaseDateTo__c value for this C003_Event__c.
     * 
     * @param c003_BaseDateTo__c
     */
    public void setC003_BaseDateTo__c(java.util.Date c003_BaseDateTo__c) {
        this.c003_BaseDateTo__c = c003_BaseDateTo__c;
    }


    /**
     * Gets the c003_Comment__c value for this C003_Event__c.
     * 
     * @return c003_Comment__c
     */
    public java.lang.String getC003_Comment__c() {
        return c003_Comment__c;
    }


    /**
     * Sets the c003_Comment__c value for this C003_Event__c.
     * 
     * @param c003_Comment__c
     */
    public void setC003_Comment__c(java.lang.String c003_Comment__c) {
        this.c003_Comment__c = c003_Comment__c;
    }


    /**
     * Gets the c003_ContractRef__c value for this C003_Event__c.
     * 
     * @return c003_ContractRef__c
     */
    public java.lang.String getC003_ContractRef__c() {
        return c003_ContractRef__c;
    }


    /**
     * Sets the c003_ContractRef__c value for this C003_Event__c.
     * 
     * @param c003_ContractRef__c
     */
    public void setC003_ContractRef__c(java.lang.String c003_ContractRef__c) {
        this.c003_ContractRef__c = c003_ContractRef__c;
    }


    /**
     * Gets the c003_ContractRef__r value for this C003_Event__c.
     * 
     * @return c003_ContractRef__r
     */
    public com.sforce.soap.enterprise.sobject.C003_Contract__c getC003_ContractRef__r() {
        return c003_ContractRef__r;
    }


    /**
     * Sets the c003_ContractRef__r value for this C003_Event__c.
     * 
     * @param c003_ContractRef__r
     */
    public void setC003_ContractRef__r(com.sforce.soap.enterprise.sobject.C003_Contract__c c003_ContractRef__r) {
        this.c003_ContractRef__r = c003_ContractRef__r;
    }


    /**
     * Gets the c003_EndDate__c value for this C003_Event__c.
     * 
     * @return c003_EndDate__c
     */
    public java.util.Date getC003_EndDate__c() {
        return c003_EndDate__c;
    }


    /**
     * Sets the c003_EndDate__c value for this C003_Event__c.
     * 
     * @param c003_EndDate__c
     */
    public void setC003_EndDate__c(java.util.Date c003_EndDate__c) {
        this.c003_EndDate__c = c003_EndDate__c;
    }


    /**
     * Gets the c003_EventConfigRef__c value for this C003_Event__c.
     * 
     * @return c003_EventConfigRef__c
     */
    public java.lang.String getC003_EventConfigRef__c() {
        return c003_EventConfigRef__c;
    }


    /**
     * Sets the c003_EventConfigRef__c value for this C003_Event__c.
     * 
     * @param c003_EventConfigRef__c
     */
    public void setC003_EventConfigRef__c(java.lang.String c003_EventConfigRef__c) {
        this.c003_EventConfigRef__c = c003_EventConfigRef__c;
    }


    /**
     * Gets the c003_EventConfigRef__r value for this C003_Event__c.
     * 
     * @return c003_EventConfigRef__r
     */
    public com.sforce.soap.enterprise.sobject.C003_EventConfig__c getC003_EventConfigRef__r() {
        return c003_EventConfigRef__r;
    }


    /**
     * Sets the c003_EventConfigRef__r value for this C003_Event__c.
     * 
     * @param c003_EventConfigRef__r
     */
    public void setC003_EventConfigRef__r(com.sforce.soap.enterprise.sobject.C003_EventConfig__c c003_EventConfigRef__r) {
        this.c003_EventConfigRef__r = c003_EventConfigRef__r;
    }


    /**
     * Gets the c003_Invalid30Days__c value for this C003_Event__c.
     * 
     * @return c003_Invalid30Days__c
     */
    public java.lang.Boolean getC003_Invalid30Days__c() {
        return c003_Invalid30Days__c;
    }


    /**
     * Sets the c003_Invalid30Days__c value for this C003_Event__c.
     * 
     * @param c003_Invalid30Days__c
     */
    public void setC003_Invalid30Days__c(java.lang.Boolean c003_Invalid30Days__c) {
        this.c003_Invalid30Days__c = c003_Invalid30Days__c;
    }


    /**
     * Gets the c003_NoticeAddress_User__c value for this C003_Event__c.
     * 
     * @return c003_NoticeAddress_User__c
     */
    public java.lang.String getC003_NoticeAddress_User__c() {
        return c003_NoticeAddress_User__c;
    }


    /**
     * Sets the c003_NoticeAddress_User__c value for this C003_Event__c.
     * 
     * @param c003_NoticeAddress_User__c
     */
    public void setC003_NoticeAddress_User__c(java.lang.String c003_NoticeAddress_User__c) {
        this.c003_NoticeAddress_User__c = c003_NoticeAddress_User__c;
    }


    /**
     * Gets the c003_NoticeAddress_User__r value for this C003_Event__c.
     * 
     * @return c003_NoticeAddress_User__r
     */
    public com.sforce.soap.enterprise.sobject.User getC003_NoticeAddress_User__r() {
        return c003_NoticeAddress_User__r;
    }


    /**
     * Sets the c003_NoticeAddress_User__r value for this C003_Event__c.
     * 
     * @param c003_NoticeAddress_User__r
     */
    public void setC003_NoticeAddress_User__r(com.sforce.soap.enterprise.sobject.User c003_NoticeAddress_User__r) {
        this.c003_NoticeAddress_User__r = c003_NoticeAddress_User__r;
    }


    /**
     * Gets the c003_ScoreTemp__c value for this C003_Event__c.
     * 
     * @return c003_ScoreTemp__c
     */
    public java.lang.Double getC003_ScoreTemp__c() {
        return c003_ScoreTemp__c;
    }


    /**
     * Sets the c003_ScoreTemp__c value for this C003_Event__c.
     * 
     * @param c003_ScoreTemp__c
     */
    public void setC003_ScoreTemp__c(java.lang.Double c003_ScoreTemp__c) {
        this.c003_ScoreTemp__c = c003_ScoreTemp__c;
    }


    /**
     * Gets the c003_Score__c value for this C003_Event__c.
     * 
     * @return c003_Score__c
     */
    public java.lang.String getC003_Score__c() {
        return c003_Score__c;
    }


    /**
     * Sets the c003_Score__c value for this C003_Event__c.
     * 
     * @param c003_Score__c
     */
    public void setC003_Score__c(java.lang.String c003_Score__c) {
        this.c003_Score__c = c003_Score__c;
    }


    /**
     * Gets the c003_StartDate__c value for this C003_Event__c.
     * 
     * @return c003_StartDate__c
     */
    public java.util.Date getC003_StartDate__c() {
        return c003_StartDate__c;
    }


    /**
     * Sets the c003_StartDate__c value for this C003_Event__c.
     * 
     * @param c003_StartDate__c
     */
    public void setC003_StartDate__c(java.util.Date c003_StartDate__c) {
        this.c003_StartDate__c = c003_StartDate__c;
    }


    /**
     * Gets the c003_Text_01__c value for this C003_Event__c.
     * 
     * @return c003_Text_01__c
     */
    public java.lang.String getC003_Text_01__c() {
        return c003_Text_01__c;
    }


    /**
     * Sets the c003_Text_01__c value for this C003_Event__c.
     * 
     * @param c003_Text_01__c
     */
    public void setC003_Text_01__c(java.lang.String c003_Text_01__c) {
        this.c003_Text_01__c = c003_Text_01__c;
    }


    /**
     * Gets the c003_Text_02__c value for this C003_Event__c.
     * 
     * @return c003_Text_02__c
     */
    public java.lang.String getC003_Text_02__c() {
        return c003_Text_02__c;
    }


    /**
     * Sets the c003_Text_02__c value for this C003_Event__c.
     * 
     * @param c003_Text_02__c
     */
    public void setC003_Text_02__c(java.lang.String c003_Text_02__c) {
        this.c003_Text_02__c = c003_Text_02__c;
    }


    /**
     * Gets the c003_Text_03__c value for this C003_Event__c.
     * 
     * @return c003_Text_03__c
     */
    public java.lang.String getC003_Text_03__c() {
        return c003_Text_03__c;
    }


    /**
     * Sets the c003_Text_03__c value for this C003_Event__c.
     * 
     * @param c003_Text_03__c
     */
    public void setC003_Text_03__c(java.lang.String c003_Text_03__c) {
        this.c003_Text_03__c = c003_Text_03__c;
    }


    /**
     * Gets the c003_Text_04__c value for this C003_Event__c.
     * 
     * @return c003_Text_04__c
     */
    public java.lang.String getC003_Text_04__c() {
        return c003_Text_04__c;
    }


    /**
     * Sets the c003_Text_04__c value for this C003_Event__c.
     * 
     * @param c003_Text_04__c
     */
    public void setC003_Text_04__c(java.lang.String c003_Text_04__c) {
        this.c003_Text_04__c = c003_Text_04__c;
    }


    /**
     * Gets the c003_Text_05__c value for this C003_Event__c.
     * 
     * @return c003_Text_05__c
     */
    public java.lang.String getC003_Text_05__c() {
        return c003_Text_05__c;
    }


    /**
     * Sets the c003_Text_05__c value for this C003_Event__c.
     * 
     * @param c003_Text_05__c
     */
    public void setC003_Text_05__c(java.lang.String c003_Text_05__c) {
        this.c003_Text_05__c = c003_Text_05__c;
    }


    /**
     * Gets the c003_Text_06__c value for this C003_Event__c.
     * 
     * @return c003_Text_06__c
     */
    public java.lang.String getC003_Text_06__c() {
        return c003_Text_06__c;
    }


    /**
     * Sets the c003_Text_06__c value for this C003_Event__c.
     * 
     * @param c003_Text_06__c
     */
    public void setC003_Text_06__c(java.lang.String c003_Text_06__c) {
        this.c003_Text_06__c = c003_Text_06__c;
    }


    /**
     * Gets the c003_Text_07__c value for this C003_Event__c.
     * 
     * @return c003_Text_07__c
     */
    public java.lang.String getC003_Text_07__c() {
        return c003_Text_07__c;
    }


    /**
     * Sets the c003_Text_07__c value for this C003_Event__c.
     * 
     * @param c003_Text_07__c
     */
    public void setC003_Text_07__c(java.lang.String c003_Text_07__c) {
        this.c003_Text_07__c = c003_Text_07__c;
    }


    /**
     * Gets the c003_Text_08__c value for this C003_Event__c.
     * 
     * @return c003_Text_08__c
     */
    public java.lang.String getC003_Text_08__c() {
        return c003_Text_08__c;
    }


    /**
     * Sets the c003_Text_08__c value for this C003_Event__c.
     * 
     * @param c003_Text_08__c
     */
    public void setC003_Text_08__c(java.lang.String c003_Text_08__c) {
        this.c003_Text_08__c = c003_Text_08__c;
    }


    /**
     * Gets the c003_Text_09__c value for this C003_Event__c.
     * 
     * @return c003_Text_09__c
     */
    public java.lang.String getC003_Text_09__c() {
        return c003_Text_09__c;
    }


    /**
     * Sets the c003_Text_09__c value for this C003_Event__c.
     * 
     * @param c003_Text_09__c
     */
    public void setC003_Text_09__c(java.lang.String c003_Text_09__c) {
        this.c003_Text_09__c = c003_Text_09__c;
    }


    /**
     * Gets the c003_Text_10__c value for this C003_Event__c.
     * 
     * @return c003_Text_10__c
     */
    public java.lang.String getC003_Text_10__c() {
        return c003_Text_10__c;
    }


    /**
     * Sets the c003_Text_10__c value for this C003_Event__c.
     * 
     * @param c003_Text_10__c
     */
    public void setC003_Text_10__c(java.lang.String c003_Text_10__c) {
        this.c003_Text_10__c = c003_Text_10__c;
    }


    /**
     * Gets the c003_Text_11__c value for this C003_Event__c.
     * 
     * @return c003_Text_11__c
     */
    public java.lang.String getC003_Text_11__c() {
        return c003_Text_11__c;
    }


    /**
     * Sets the c003_Text_11__c value for this C003_Event__c.
     * 
     * @param c003_Text_11__c
     */
    public void setC003_Text_11__c(java.lang.String c003_Text_11__c) {
        this.c003_Text_11__c = c003_Text_11__c;
    }


    /**
     * Gets the c003_Text_12__c value for this C003_Event__c.
     * 
     * @return c003_Text_12__c
     */
    public java.lang.String getC003_Text_12__c() {
        return c003_Text_12__c;
    }


    /**
     * Sets the c003_Text_12__c value for this C003_Event__c.
     * 
     * @param c003_Text_12__c
     */
    public void setC003_Text_12__c(java.lang.String c003_Text_12__c) {
        this.c003_Text_12__c = c003_Text_12__c;
    }


    /**
     * Gets the c003_Text_13__c value for this C003_Event__c.
     * 
     * @return c003_Text_13__c
     */
    public java.lang.String getC003_Text_13__c() {
        return c003_Text_13__c;
    }


    /**
     * Sets the c003_Text_13__c value for this C003_Event__c.
     * 
     * @param c003_Text_13__c
     */
    public void setC003_Text_13__c(java.lang.String c003_Text_13__c) {
        this.c003_Text_13__c = c003_Text_13__c;
    }


    /**
     * Gets the c003_Text_14__c value for this C003_Event__c.
     * 
     * @return c003_Text_14__c
     */
    public java.lang.String getC003_Text_14__c() {
        return c003_Text_14__c;
    }


    /**
     * Sets the c003_Text_14__c value for this C003_Event__c.
     * 
     * @param c003_Text_14__c
     */
    public void setC003_Text_14__c(java.lang.String c003_Text_14__c) {
        this.c003_Text_14__c = c003_Text_14__c;
    }


    /**
     * Gets the c003_Text_15__c value for this C003_Event__c.
     * 
     * @return c003_Text_15__c
     */
    public java.lang.String getC003_Text_15__c() {
        return c003_Text_15__c;
    }


    /**
     * Sets the c003_Text_15__c value for this C003_Event__c.
     * 
     * @param c003_Text_15__c
     */
    public void setC003_Text_15__c(java.lang.String c003_Text_15__c) {
        this.c003_Text_15__c = c003_Text_15__c;
    }


    /**
     * Gets the c003_Text_16__c value for this C003_Event__c.
     * 
     * @return c003_Text_16__c
     */
    public java.lang.String getC003_Text_16__c() {
        return c003_Text_16__c;
    }


    /**
     * Sets the c003_Text_16__c value for this C003_Event__c.
     * 
     * @param c003_Text_16__c
     */
    public void setC003_Text_16__c(java.lang.String c003_Text_16__c) {
        this.c003_Text_16__c = c003_Text_16__c;
    }


    /**
     * Gets the c003_Text_17__c value for this C003_Event__c.
     * 
     * @return c003_Text_17__c
     */
    public java.lang.String getC003_Text_17__c() {
        return c003_Text_17__c;
    }


    /**
     * Sets the c003_Text_17__c value for this C003_Event__c.
     * 
     * @param c003_Text_17__c
     */
    public void setC003_Text_17__c(java.lang.String c003_Text_17__c) {
        this.c003_Text_17__c = c003_Text_17__c;
    }


    /**
     * Gets the c003_Text_18__c value for this C003_Event__c.
     * 
     * @return c003_Text_18__c
     */
    public java.lang.String getC003_Text_18__c() {
        return c003_Text_18__c;
    }


    /**
     * Sets the c003_Text_18__c value for this C003_Event__c.
     * 
     * @param c003_Text_18__c
     */
    public void setC003_Text_18__c(java.lang.String c003_Text_18__c) {
        this.c003_Text_18__c = c003_Text_18__c;
    }


    /**
     * Gets the c003_Text_19__c value for this C003_Event__c.
     * 
     * @return c003_Text_19__c
     */
    public java.lang.String getC003_Text_19__c() {
        return c003_Text_19__c;
    }


    /**
     * Sets the c003_Text_19__c value for this C003_Event__c.
     * 
     * @param c003_Text_19__c
     */
    public void setC003_Text_19__c(java.lang.String c003_Text_19__c) {
        this.c003_Text_19__c = c003_Text_19__c;
    }


    /**
     * Gets the c003_Text_20__c value for this C003_Event__c.
     * 
     * @return c003_Text_20__c
     */
    public java.lang.String getC003_Text_20__c() {
        return c003_Text_20__c;
    }


    /**
     * Sets the c003_Text_20__c value for this C003_Event__c.
     * 
     * @param c003_Text_20__c
     */
    public void setC003_Text_20__c(java.lang.String c003_Text_20__c) {
        this.c003_Text_20__c = c003_Text_20__c;
    }


    /**
     * Gets the c003_Text_21__c value for this C003_Event__c.
     * 
     * @return c003_Text_21__c
     */
    public java.lang.String getC003_Text_21__c() {
        return c003_Text_21__c;
    }


    /**
     * Sets the c003_Text_21__c value for this C003_Event__c.
     * 
     * @param c003_Text_21__c
     */
    public void setC003_Text_21__c(java.lang.String c003_Text_21__c) {
        this.c003_Text_21__c = c003_Text_21__c;
    }


    /**
     * Gets the c003_Text_22__c value for this C003_Event__c.
     * 
     * @return c003_Text_22__c
     */
    public java.lang.String getC003_Text_22__c() {
        return c003_Text_22__c;
    }


    /**
     * Sets the c003_Text_22__c value for this C003_Event__c.
     * 
     * @param c003_Text_22__c
     */
    public void setC003_Text_22__c(java.lang.String c003_Text_22__c) {
        this.c003_Text_22__c = c003_Text_22__c;
    }


    /**
     * Gets the c003_Text_23__c value for this C003_Event__c.
     * 
     * @return c003_Text_23__c
     */
    public java.lang.String getC003_Text_23__c() {
        return c003_Text_23__c;
    }


    /**
     * Sets the c003_Text_23__c value for this C003_Event__c.
     * 
     * @param c003_Text_23__c
     */
    public void setC003_Text_23__c(java.lang.String c003_Text_23__c) {
        this.c003_Text_23__c = c003_Text_23__c;
    }


    /**
     * Gets the c003_Text_24__c value for this C003_Event__c.
     * 
     * @return c003_Text_24__c
     */
    public java.lang.String getC003_Text_24__c() {
        return c003_Text_24__c;
    }


    /**
     * Sets the c003_Text_24__c value for this C003_Event__c.
     * 
     * @param c003_Text_24__c
     */
    public void setC003_Text_24__c(java.lang.String c003_Text_24__c) {
        this.c003_Text_24__c = c003_Text_24__c;
    }


    /**
     * Gets the c003_Text_25__c value for this C003_Event__c.
     * 
     * @return c003_Text_25__c
     */
    public java.lang.String getC003_Text_25__c() {
        return c003_Text_25__c;
    }


    /**
     * Sets the c003_Text_25__c value for this C003_Event__c.
     * 
     * @param c003_Text_25__c
     */
    public void setC003_Text_25__c(java.lang.String c003_Text_25__c) {
        this.c003_Text_25__c = c003_Text_25__c;
    }


    /**
     * Gets the c003_Text_26__c value for this C003_Event__c.
     * 
     * @return c003_Text_26__c
     */
    public java.lang.String getC003_Text_26__c() {
        return c003_Text_26__c;
    }


    /**
     * Sets the c003_Text_26__c value for this C003_Event__c.
     * 
     * @param c003_Text_26__c
     */
    public void setC003_Text_26__c(java.lang.String c003_Text_26__c) {
        this.c003_Text_26__c = c003_Text_26__c;
    }


    /**
     * Gets the c003_Text_27__c value for this C003_Event__c.
     * 
     * @return c003_Text_27__c
     */
    public java.lang.String getC003_Text_27__c() {
        return c003_Text_27__c;
    }


    /**
     * Sets the c003_Text_27__c value for this C003_Event__c.
     * 
     * @param c003_Text_27__c
     */
    public void setC003_Text_27__c(java.lang.String c003_Text_27__c) {
        this.c003_Text_27__c = c003_Text_27__c;
    }


    /**
     * Gets the c003_Text_28__c value for this C003_Event__c.
     * 
     * @return c003_Text_28__c
     */
    public java.lang.String getC003_Text_28__c() {
        return c003_Text_28__c;
    }


    /**
     * Sets the c003_Text_28__c value for this C003_Event__c.
     * 
     * @param c003_Text_28__c
     */
    public void setC003_Text_28__c(java.lang.String c003_Text_28__c) {
        this.c003_Text_28__c = c003_Text_28__c;
    }


    /**
     * Gets the c003_Text_29__c value for this C003_Event__c.
     * 
     * @return c003_Text_29__c
     */
    public java.lang.String getC003_Text_29__c() {
        return c003_Text_29__c;
    }


    /**
     * Sets the c003_Text_29__c value for this C003_Event__c.
     * 
     * @param c003_Text_29__c
     */
    public void setC003_Text_29__c(java.lang.String c003_Text_29__c) {
        this.c003_Text_29__c = c003_Text_29__c;
    }


    /**
     * Gets the c003_Text_30__c value for this C003_Event__c.
     * 
     * @return c003_Text_30__c
     */
    public java.lang.String getC003_Text_30__c() {
        return c003_Text_30__c;
    }


    /**
     * Sets the c003_Text_30__c value for this C003_Event__c.
     * 
     * @param c003_Text_30__c
     */
    public void setC003_Text_30__c(java.lang.String c003_Text_30__c) {
        this.c003_Text_30__c = c003_Text_30__c;
    }


    /**
     * Gets the c003_Text_31__c value for this C003_Event__c.
     * 
     * @return c003_Text_31__c
     */
    public java.lang.String getC003_Text_31__c() {
        return c003_Text_31__c;
    }


    /**
     * Sets the c003_Text_31__c value for this C003_Event__c.
     * 
     * @param c003_Text_31__c
     */
    public void setC003_Text_31__c(java.lang.String c003_Text_31__c) {
        this.c003_Text_31__c = c003_Text_31__c;
    }


    /**
     * Gets the c003_Text_32__c value for this C003_Event__c.
     * 
     * @return c003_Text_32__c
     */
    public java.lang.String getC003_Text_32__c() {
        return c003_Text_32__c;
    }


    /**
     * Sets the c003_Text_32__c value for this C003_Event__c.
     * 
     * @param c003_Text_32__c
     */
    public void setC003_Text_32__c(java.lang.String c003_Text_32__c) {
        this.c003_Text_32__c = c003_Text_32__c;
    }


    /**
     * Gets the c003_Text_33__c value for this C003_Event__c.
     * 
     * @return c003_Text_33__c
     */
    public java.lang.String getC003_Text_33__c() {
        return c003_Text_33__c;
    }


    /**
     * Sets the c003_Text_33__c value for this C003_Event__c.
     * 
     * @param c003_Text_33__c
     */
    public void setC003_Text_33__c(java.lang.String c003_Text_33__c) {
        this.c003_Text_33__c = c003_Text_33__c;
    }


    /**
     * Gets the c003_Text_34__c value for this C003_Event__c.
     * 
     * @return c003_Text_34__c
     */
    public java.lang.String getC003_Text_34__c() {
        return c003_Text_34__c;
    }


    /**
     * Sets the c003_Text_34__c value for this C003_Event__c.
     * 
     * @param c003_Text_34__c
     */
    public void setC003_Text_34__c(java.lang.String c003_Text_34__c) {
        this.c003_Text_34__c = c003_Text_34__c;
    }


    /**
     * Gets the c003_Text_35__c value for this C003_Event__c.
     * 
     * @return c003_Text_35__c
     */
    public java.lang.String getC003_Text_35__c() {
        return c003_Text_35__c;
    }


    /**
     * Sets the c003_Text_35__c value for this C003_Event__c.
     * 
     * @param c003_Text_35__c
     */
    public void setC003_Text_35__c(java.lang.String c003_Text_35__c) {
        this.c003_Text_35__c = c003_Text_35__c;
    }


    /**
     * Gets the c003_Text_36__c value for this C003_Event__c.
     * 
     * @return c003_Text_36__c
     */
    public java.lang.String getC003_Text_36__c() {
        return c003_Text_36__c;
    }


    /**
     * Sets the c003_Text_36__c value for this C003_Event__c.
     * 
     * @param c003_Text_36__c
     */
    public void setC003_Text_36__c(java.lang.String c003_Text_36__c) {
        this.c003_Text_36__c = c003_Text_36__c;
    }


    /**
     * Gets the c003_Text_37__c value for this C003_Event__c.
     * 
     * @return c003_Text_37__c
     */
    public java.lang.String getC003_Text_37__c() {
        return c003_Text_37__c;
    }


    /**
     * Sets the c003_Text_37__c value for this C003_Event__c.
     * 
     * @param c003_Text_37__c
     */
    public void setC003_Text_37__c(java.lang.String c003_Text_37__c) {
        this.c003_Text_37__c = c003_Text_37__c;
    }


    /**
     * Gets the c003_Text_38__c value for this C003_Event__c.
     * 
     * @return c003_Text_38__c
     */
    public java.lang.String getC003_Text_38__c() {
        return c003_Text_38__c;
    }


    /**
     * Sets the c003_Text_38__c value for this C003_Event__c.
     * 
     * @param c003_Text_38__c
     */
    public void setC003_Text_38__c(java.lang.String c003_Text_38__c) {
        this.c003_Text_38__c = c003_Text_38__c;
    }


    /**
     * Gets the c003_Text_39__c value for this C003_Event__c.
     * 
     * @return c003_Text_39__c
     */
    public java.lang.String getC003_Text_39__c() {
        return c003_Text_39__c;
    }


    /**
     * Sets the c003_Text_39__c value for this C003_Event__c.
     * 
     * @param c003_Text_39__c
     */
    public void setC003_Text_39__c(java.lang.String c003_Text_39__c) {
        this.c003_Text_39__c = c003_Text_39__c;
    }


    /**
     * Gets the c003_Text_40__c value for this C003_Event__c.
     * 
     * @return c003_Text_40__c
     */
    public java.lang.String getC003_Text_40__c() {
        return c003_Text_40__c;
    }


    /**
     * Sets the c003_Text_40__c value for this C003_Event__c.
     * 
     * @param c003_Text_40__c
     */
    public void setC003_Text_40__c(java.lang.String c003_Text_40__c) {
        this.c003_Text_40__c = c003_Text_40__c;
    }


    /**
     * Gets the c003_Text_41__c value for this C003_Event__c.
     * 
     * @return c003_Text_41__c
     */
    public java.lang.String getC003_Text_41__c() {
        return c003_Text_41__c;
    }


    /**
     * Sets the c003_Text_41__c value for this C003_Event__c.
     * 
     * @param c003_Text_41__c
     */
    public void setC003_Text_41__c(java.lang.String c003_Text_41__c) {
        this.c003_Text_41__c = c003_Text_41__c;
    }


    /**
     * Gets the c003_Text_42__c value for this C003_Event__c.
     * 
     * @return c003_Text_42__c
     */
    public java.lang.String getC003_Text_42__c() {
        return c003_Text_42__c;
    }


    /**
     * Sets the c003_Text_42__c value for this C003_Event__c.
     * 
     * @param c003_Text_42__c
     */
    public void setC003_Text_42__c(java.lang.String c003_Text_42__c) {
        this.c003_Text_42__c = c003_Text_42__c;
    }


    /**
     * Gets the c003_Text_43__c value for this C003_Event__c.
     * 
     * @return c003_Text_43__c
     */
    public java.lang.String getC003_Text_43__c() {
        return c003_Text_43__c;
    }


    /**
     * Sets the c003_Text_43__c value for this C003_Event__c.
     * 
     * @param c003_Text_43__c
     */
    public void setC003_Text_43__c(java.lang.String c003_Text_43__c) {
        this.c003_Text_43__c = c003_Text_43__c;
    }


    /**
     * Gets the c003_Text_44__c value for this C003_Event__c.
     * 
     * @return c003_Text_44__c
     */
    public java.lang.String getC003_Text_44__c() {
        return c003_Text_44__c;
    }


    /**
     * Sets the c003_Text_44__c value for this C003_Event__c.
     * 
     * @param c003_Text_44__c
     */
    public void setC003_Text_44__c(java.lang.String c003_Text_44__c) {
        this.c003_Text_44__c = c003_Text_44__c;
    }


    /**
     * Gets the c003_Text_45__c value for this C003_Event__c.
     * 
     * @return c003_Text_45__c
     */
    public java.lang.String getC003_Text_45__c() {
        return c003_Text_45__c;
    }


    /**
     * Sets the c003_Text_45__c value for this C003_Event__c.
     * 
     * @param c003_Text_45__c
     */
    public void setC003_Text_45__c(java.lang.String c003_Text_45__c) {
        this.c003_Text_45__c = c003_Text_45__c;
    }


    /**
     * Gets the c003_Text_46__c value for this C003_Event__c.
     * 
     * @return c003_Text_46__c
     */
    public java.lang.String getC003_Text_46__c() {
        return c003_Text_46__c;
    }


    /**
     * Sets the c003_Text_46__c value for this C003_Event__c.
     * 
     * @param c003_Text_46__c
     */
    public void setC003_Text_46__c(java.lang.String c003_Text_46__c) {
        this.c003_Text_46__c = c003_Text_46__c;
    }


    /**
     * Gets the c003_Text_47__c value for this C003_Event__c.
     * 
     * @return c003_Text_47__c
     */
    public java.lang.String getC003_Text_47__c() {
        return c003_Text_47__c;
    }


    /**
     * Sets the c003_Text_47__c value for this C003_Event__c.
     * 
     * @param c003_Text_47__c
     */
    public void setC003_Text_47__c(java.lang.String c003_Text_47__c) {
        this.c003_Text_47__c = c003_Text_47__c;
    }


    /**
     * Gets the c003_Text_48__c value for this C003_Event__c.
     * 
     * @return c003_Text_48__c
     */
    public java.lang.String getC003_Text_48__c() {
        return c003_Text_48__c;
    }


    /**
     * Sets the c003_Text_48__c value for this C003_Event__c.
     * 
     * @param c003_Text_48__c
     */
    public void setC003_Text_48__c(java.lang.String c003_Text_48__c) {
        this.c003_Text_48__c = c003_Text_48__c;
    }


    /**
     * Gets the c003_Text_49__c value for this C003_Event__c.
     * 
     * @return c003_Text_49__c
     */
    public java.lang.String getC003_Text_49__c() {
        return c003_Text_49__c;
    }


    /**
     * Sets the c003_Text_49__c value for this C003_Event__c.
     * 
     * @param c003_Text_49__c
     */
    public void setC003_Text_49__c(java.lang.String c003_Text_49__c) {
        this.c003_Text_49__c = c003_Text_49__c;
    }


    /**
     * Gets the c003_Text_50__c value for this C003_Event__c.
     * 
     * @return c003_Text_50__c
     */
    public java.lang.String getC003_Text_50__c() {
        return c003_Text_50__c;
    }


    /**
     * Sets the c003_Text_50__c value for this C003_Event__c.
     * 
     * @param c003_Text_50__c
     */
    public void setC003_Text_50__c(java.lang.String c003_Text_50__c) {
        this.c003_Text_50__c = c003_Text_50__c;
    }


    /**
     * Gets the combinedAttachments value for this C003_Event__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C003_Event__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C003_Event__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C003_Event__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C003_Event__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C003_Event__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C003_Event__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C003_Event__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the duplicateRecordItems value for this C003_Event__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C003_Event__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the isDeleted value for this C003_Event__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C003_Event__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the lastModifiedBy value for this C003_Event__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C003_Event__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C003_Event__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C003_Event__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C003_Event__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C003_Event__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lastReferencedDate value for this C003_Event__c.
     * 
     * @return lastReferencedDate
     */
    public java.util.Calendar getLastReferencedDate() {
        return lastReferencedDate;
    }


    /**
     * Sets the lastReferencedDate value for this C003_Event__c.
     * 
     * @param lastReferencedDate
     */
    public void setLastReferencedDate(java.util.Calendar lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }


    /**
     * Gets the lastViewedDate value for this C003_Event__c.
     * 
     * @return lastViewedDate
     */
    public java.util.Calendar getLastViewedDate() {
        return lastViewedDate;
    }


    /**
     * Sets the lastViewedDate value for this C003_Event__c.
     * 
     * @param lastViewedDate
     */
    public void setLastViewedDate(java.util.Calendar lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C003_Event__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C003_Event__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this C003_Event__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C003_Event__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C003_Event__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C003_Event__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C003_Event__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C003_Event__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the processInstances value for this C003_Event__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C003_Event__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C003_Event__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C003_Event__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the systemModstamp value for this C003_Event__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C003_Event__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the topicAssignments value for this C003_Event__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C003_Event__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this C003_Event__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C003_Event__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C003_Event__c)) return false;
        C003_Event__c other = (C003_Event__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.c003_AccountRef__c==null && other.getC003_AccountRef__c()==null) || 
             (this.c003_AccountRef__c!=null &&
              this.c003_AccountRef__c.equals(other.getC003_AccountRef__c()))) &&
            ((this.c003_AccountRef__r==null && other.getC003_AccountRef__r()==null) || 
             (this.c003_AccountRef__r!=null &&
              this.c003_AccountRef__r.equals(other.getC003_AccountRef__r()))) &&
            ((this.c003_Area_01__c==null && other.getC003_Area_01__c()==null) || 
             (this.c003_Area_01__c!=null &&
              this.c003_Area_01__c.equals(other.getC003_Area_01__c()))) &&
            ((this.c003_Area_02__c==null && other.getC003_Area_02__c()==null) || 
             (this.c003_Area_02__c!=null &&
              this.c003_Area_02__c.equals(other.getC003_Area_02__c()))) &&
            ((this.c003_Area_03__c==null && other.getC003_Area_03__c()==null) || 
             (this.c003_Area_03__c!=null &&
              this.c003_Area_03__c.equals(other.getC003_Area_03__c()))) &&
            ((this.c003_Area_04__c==null && other.getC003_Area_04__c()==null) || 
             (this.c003_Area_04__c!=null &&
              this.c003_Area_04__c.equals(other.getC003_Area_04__c()))) &&
            ((this.c003_Area_05__c==null && other.getC003_Area_05__c()==null) || 
             (this.c003_Area_05__c!=null &&
              this.c003_Area_05__c.equals(other.getC003_Area_05__c()))) &&
            ((this.c003_Area_06__c==null && other.getC003_Area_06__c()==null) || 
             (this.c003_Area_06__c!=null &&
              this.c003_Area_06__c.equals(other.getC003_Area_06__c()))) &&
            ((this.c003_Area_07__c==null && other.getC003_Area_07__c()==null) || 
             (this.c003_Area_07__c!=null &&
              this.c003_Area_07__c.equals(other.getC003_Area_07__c()))) &&
            ((this.c003_Area_08__c==null && other.getC003_Area_08__c()==null) || 
             (this.c003_Area_08__c!=null &&
              this.c003_Area_08__c.equals(other.getC003_Area_08__c()))) &&
            ((this.c003_Area_09__c==null && other.getC003_Area_09__c()==null) || 
             (this.c003_Area_09__c!=null &&
              this.c003_Area_09__c.equals(other.getC003_Area_09__c()))) &&
            ((this.c003_Area_10__c==null && other.getC003_Area_10__c()==null) || 
             (this.c003_Area_10__c!=null &&
              this.c003_Area_10__c.equals(other.getC003_Area_10__c()))) &&
            ((this.c003_BaseDateFrom__c==null && other.getC003_BaseDateFrom__c()==null) || 
             (this.c003_BaseDateFrom__c!=null &&
              this.c003_BaseDateFrom__c.equals(other.getC003_BaseDateFrom__c()))) &&
            ((this.c003_BaseDateTo__c==null && other.getC003_BaseDateTo__c()==null) || 
             (this.c003_BaseDateTo__c!=null &&
              this.c003_BaseDateTo__c.equals(other.getC003_BaseDateTo__c()))) &&
            ((this.c003_Comment__c==null && other.getC003_Comment__c()==null) || 
             (this.c003_Comment__c!=null &&
              this.c003_Comment__c.equals(other.getC003_Comment__c()))) &&
            ((this.c003_ContractRef__c==null && other.getC003_ContractRef__c()==null) || 
             (this.c003_ContractRef__c!=null &&
              this.c003_ContractRef__c.equals(other.getC003_ContractRef__c()))) &&
            ((this.c003_ContractRef__r==null && other.getC003_ContractRef__r()==null) || 
             (this.c003_ContractRef__r!=null &&
              this.c003_ContractRef__r.equals(other.getC003_ContractRef__r()))) &&
            ((this.c003_EndDate__c==null && other.getC003_EndDate__c()==null) || 
             (this.c003_EndDate__c!=null &&
              this.c003_EndDate__c.equals(other.getC003_EndDate__c()))) &&
            ((this.c003_EventConfigRef__c==null && other.getC003_EventConfigRef__c()==null) || 
             (this.c003_EventConfigRef__c!=null &&
              this.c003_EventConfigRef__c.equals(other.getC003_EventConfigRef__c()))) &&
            ((this.c003_EventConfigRef__r==null && other.getC003_EventConfigRef__r()==null) || 
             (this.c003_EventConfigRef__r!=null &&
              this.c003_EventConfigRef__r.equals(other.getC003_EventConfigRef__r()))) &&
            ((this.c003_Invalid30Days__c==null && other.getC003_Invalid30Days__c()==null) || 
             (this.c003_Invalid30Days__c!=null &&
              this.c003_Invalid30Days__c.equals(other.getC003_Invalid30Days__c()))) &&
            ((this.c003_NoticeAddress_User__c==null && other.getC003_NoticeAddress_User__c()==null) || 
             (this.c003_NoticeAddress_User__c!=null &&
              this.c003_NoticeAddress_User__c.equals(other.getC003_NoticeAddress_User__c()))) &&
            ((this.c003_NoticeAddress_User__r==null && other.getC003_NoticeAddress_User__r()==null) || 
             (this.c003_NoticeAddress_User__r!=null &&
              this.c003_NoticeAddress_User__r.equals(other.getC003_NoticeAddress_User__r()))) &&
            ((this.c003_ScoreTemp__c==null && other.getC003_ScoreTemp__c()==null) || 
             (this.c003_ScoreTemp__c!=null &&
              this.c003_ScoreTemp__c.equals(other.getC003_ScoreTemp__c()))) &&
            ((this.c003_Score__c==null && other.getC003_Score__c()==null) || 
             (this.c003_Score__c!=null &&
              this.c003_Score__c.equals(other.getC003_Score__c()))) &&
            ((this.c003_StartDate__c==null && other.getC003_StartDate__c()==null) || 
             (this.c003_StartDate__c!=null &&
              this.c003_StartDate__c.equals(other.getC003_StartDate__c()))) &&
            ((this.c003_Text_01__c==null && other.getC003_Text_01__c()==null) || 
             (this.c003_Text_01__c!=null &&
              this.c003_Text_01__c.equals(other.getC003_Text_01__c()))) &&
            ((this.c003_Text_02__c==null && other.getC003_Text_02__c()==null) || 
             (this.c003_Text_02__c!=null &&
              this.c003_Text_02__c.equals(other.getC003_Text_02__c()))) &&
            ((this.c003_Text_03__c==null && other.getC003_Text_03__c()==null) || 
             (this.c003_Text_03__c!=null &&
              this.c003_Text_03__c.equals(other.getC003_Text_03__c()))) &&
            ((this.c003_Text_04__c==null && other.getC003_Text_04__c()==null) || 
             (this.c003_Text_04__c!=null &&
              this.c003_Text_04__c.equals(other.getC003_Text_04__c()))) &&
            ((this.c003_Text_05__c==null && other.getC003_Text_05__c()==null) || 
             (this.c003_Text_05__c!=null &&
              this.c003_Text_05__c.equals(other.getC003_Text_05__c()))) &&
            ((this.c003_Text_06__c==null && other.getC003_Text_06__c()==null) || 
             (this.c003_Text_06__c!=null &&
              this.c003_Text_06__c.equals(other.getC003_Text_06__c()))) &&
            ((this.c003_Text_07__c==null && other.getC003_Text_07__c()==null) || 
             (this.c003_Text_07__c!=null &&
              this.c003_Text_07__c.equals(other.getC003_Text_07__c()))) &&
            ((this.c003_Text_08__c==null && other.getC003_Text_08__c()==null) || 
             (this.c003_Text_08__c!=null &&
              this.c003_Text_08__c.equals(other.getC003_Text_08__c()))) &&
            ((this.c003_Text_09__c==null && other.getC003_Text_09__c()==null) || 
             (this.c003_Text_09__c!=null &&
              this.c003_Text_09__c.equals(other.getC003_Text_09__c()))) &&
            ((this.c003_Text_10__c==null && other.getC003_Text_10__c()==null) || 
             (this.c003_Text_10__c!=null &&
              this.c003_Text_10__c.equals(other.getC003_Text_10__c()))) &&
            ((this.c003_Text_11__c==null && other.getC003_Text_11__c()==null) || 
             (this.c003_Text_11__c!=null &&
              this.c003_Text_11__c.equals(other.getC003_Text_11__c()))) &&
            ((this.c003_Text_12__c==null && other.getC003_Text_12__c()==null) || 
             (this.c003_Text_12__c!=null &&
              this.c003_Text_12__c.equals(other.getC003_Text_12__c()))) &&
            ((this.c003_Text_13__c==null && other.getC003_Text_13__c()==null) || 
             (this.c003_Text_13__c!=null &&
              this.c003_Text_13__c.equals(other.getC003_Text_13__c()))) &&
            ((this.c003_Text_14__c==null && other.getC003_Text_14__c()==null) || 
             (this.c003_Text_14__c!=null &&
              this.c003_Text_14__c.equals(other.getC003_Text_14__c()))) &&
            ((this.c003_Text_15__c==null && other.getC003_Text_15__c()==null) || 
             (this.c003_Text_15__c!=null &&
              this.c003_Text_15__c.equals(other.getC003_Text_15__c()))) &&
            ((this.c003_Text_16__c==null && other.getC003_Text_16__c()==null) || 
             (this.c003_Text_16__c!=null &&
              this.c003_Text_16__c.equals(other.getC003_Text_16__c()))) &&
            ((this.c003_Text_17__c==null && other.getC003_Text_17__c()==null) || 
             (this.c003_Text_17__c!=null &&
              this.c003_Text_17__c.equals(other.getC003_Text_17__c()))) &&
            ((this.c003_Text_18__c==null && other.getC003_Text_18__c()==null) || 
             (this.c003_Text_18__c!=null &&
              this.c003_Text_18__c.equals(other.getC003_Text_18__c()))) &&
            ((this.c003_Text_19__c==null && other.getC003_Text_19__c()==null) || 
             (this.c003_Text_19__c!=null &&
              this.c003_Text_19__c.equals(other.getC003_Text_19__c()))) &&
            ((this.c003_Text_20__c==null && other.getC003_Text_20__c()==null) || 
             (this.c003_Text_20__c!=null &&
              this.c003_Text_20__c.equals(other.getC003_Text_20__c()))) &&
            ((this.c003_Text_21__c==null && other.getC003_Text_21__c()==null) || 
             (this.c003_Text_21__c!=null &&
              this.c003_Text_21__c.equals(other.getC003_Text_21__c()))) &&
            ((this.c003_Text_22__c==null && other.getC003_Text_22__c()==null) || 
             (this.c003_Text_22__c!=null &&
              this.c003_Text_22__c.equals(other.getC003_Text_22__c()))) &&
            ((this.c003_Text_23__c==null && other.getC003_Text_23__c()==null) || 
             (this.c003_Text_23__c!=null &&
              this.c003_Text_23__c.equals(other.getC003_Text_23__c()))) &&
            ((this.c003_Text_24__c==null && other.getC003_Text_24__c()==null) || 
             (this.c003_Text_24__c!=null &&
              this.c003_Text_24__c.equals(other.getC003_Text_24__c()))) &&
            ((this.c003_Text_25__c==null && other.getC003_Text_25__c()==null) || 
             (this.c003_Text_25__c!=null &&
              this.c003_Text_25__c.equals(other.getC003_Text_25__c()))) &&
            ((this.c003_Text_26__c==null && other.getC003_Text_26__c()==null) || 
             (this.c003_Text_26__c!=null &&
              this.c003_Text_26__c.equals(other.getC003_Text_26__c()))) &&
            ((this.c003_Text_27__c==null && other.getC003_Text_27__c()==null) || 
             (this.c003_Text_27__c!=null &&
              this.c003_Text_27__c.equals(other.getC003_Text_27__c()))) &&
            ((this.c003_Text_28__c==null && other.getC003_Text_28__c()==null) || 
             (this.c003_Text_28__c!=null &&
              this.c003_Text_28__c.equals(other.getC003_Text_28__c()))) &&
            ((this.c003_Text_29__c==null && other.getC003_Text_29__c()==null) || 
             (this.c003_Text_29__c!=null &&
              this.c003_Text_29__c.equals(other.getC003_Text_29__c()))) &&
            ((this.c003_Text_30__c==null && other.getC003_Text_30__c()==null) || 
             (this.c003_Text_30__c!=null &&
              this.c003_Text_30__c.equals(other.getC003_Text_30__c()))) &&
            ((this.c003_Text_31__c==null && other.getC003_Text_31__c()==null) || 
             (this.c003_Text_31__c!=null &&
              this.c003_Text_31__c.equals(other.getC003_Text_31__c()))) &&
            ((this.c003_Text_32__c==null && other.getC003_Text_32__c()==null) || 
             (this.c003_Text_32__c!=null &&
              this.c003_Text_32__c.equals(other.getC003_Text_32__c()))) &&
            ((this.c003_Text_33__c==null && other.getC003_Text_33__c()==null) || 
             (this.c003_Text_33__c!=null &&
              this.c003_Text_33__c.equals(other.getC003_Text_33__c()))) &&
            ((this.c003_Text_34__c==null && other.getC003_Text_34__c()==null) || 
             (this.c003_Text_34__c!=null &&
              this.c003_Text_34__c.equals(other.getC003_Text_34__c()))) &&
            ((this.c003_Text_35__c==null && other.getC003_Text_35__c()==null) || 
             (this.c003_Text_35__c!=null &&
              this.c003_Text_35__c.equals(other.getC003_Text_35__c()))) &&
            ((this.c003_Text_36__c==null && other.getC003_Text_36__c()==null) || 
             (this.c003_Text_36__c!=null &&
              this.c003_Text_36__c.equals(other.getC003_Text_36__c()))) &&
            ((this.c003_Text_37__c==null && other.getC003_Text_37__c()==null) || 
             (this.c003_Text_37__c!=null &&
              this.c003_Text_37__c.equals(other.getC003_Text_37__c()))) &&
            ((this.c003_Text_38__c==null && other.getC003_Text_38__c()==null) || 
             (this.c003_Text_38__c!=null &&
              this.c003_Text_38__c.equals(other.getC003_Text_38__c()))) &&
            ((this.c003_Text_39__c==null && other.getC003_Text_39__c()==null) || 
             (this.c003_Text_39__c!=null &&
              this.c003_Text_39__c.equals(other.getC003_Text_39__c()))) &&
            ((this.c003_Text_40__c==null && other.getC003_Text_40__c()==null) || 
             (this.c003_Text_40__c!=null &&
              this.c003_Text_40__c.equals(other.getC003_Text_40__c()))) &&
            ((this.c003_Text_41__c==null && other.getC003_Text_41__c()==null) || 
             (this.c003_Text_41__c!=null &&
              this.c003_Text_41__c.equals(other.getC003_Text_41__c()))) &&
            ((this.c003_Text_42__c==null && other.getC003_Text_42__c()==null) || 
             (this.c003_Text_42__c!=null &&
              this.c003_Text_42__c.equals(other.getC003_Text_42__c()))) &&
            ((this.c003_Text_43__c==null && other.getC003_Text_43__c()==null) || 
             (this.c003_Text_43__c!=null &&
              this.c003_Text_43__c.equals(other.getC003_Text_43__c()))) &&
            ((this.c003_Text_44__c==null && other.getC003_Text_44__c()==null) || 
             (this.c003_Text_44__c!=null &&
              this.c003_Text_44__c.equals(other.getC003_Text_44__c()))) &&
            ((this.c003_Text_45__c==null && other.getC003_Text_45__c()==null) || 
             (this.c003_Text_45__c!=null &&
              this.c003_Text_45__c.equals(other.getC003_Text_45__c()))) &&
            ((this.c003_Text_46__c==null && other.getC003_Text_46__c()==null) || 
             (this.c003_Text_46__c!=null &&
              this.c003_Text_46__c.equals(other.getC003_Text_46__c()))) &&
            ((this.c003_Text_47__c==null && other.getC003_Text_47__c()==null) || 
             (this.c003_Text_47__c!=null &&
              this.c003_Text_47__c.equals(other.getC003_Text_47__c()))) &&
            ((this.c003_Text_48__c==null && other.getC003_Text_48__c()==null) || 
             (this.c003_Text_48__c!=null &&
              this.c003_Text_48__c.equals(other.getC003_Text_48__c()))) &&
            ((this.c003_Text_49__c==null && other.getC003_Text_49__c()==null) || 
             (this.c003_Text_49__c!=null &&
              this.c003_Text_49__c.equals(other.getC003_Text_49__c()))) &&
            ((this.c003_Text_50__c==null && other.getC003_Text_50__c()==null) || 
             (this.c003_Text_50__c!=null &&
              this.c003_Text_50__c.equals(other.getC003_Text_50__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lastReferencedDate==null && other.getLastReferencedDate()==null) || 
             (this.lastReferencedDate!=null &&
              this.lastReferencedDate.equals(other.getLastReferencedDate()))) &&
            ((this.lastViewedDate==null && other.getLastViewedDate()==null) || 
             (this.lastViewedDate!=null &&
              this.lastViewedDate.equals(other.getLastViewedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getC003_AccountRef__c() != null) {
            _hashCode += getC003_AccountRef__c().hashCode();
        }
        if (getC003_AccountRef__r() != null) {
            _hashCode += getC003_AccountRef__r().hashCode();
        }
        if (getC003_Area_01__c() != null) {
            _hashCode += getC003_Area_01__c().hashCode();
        }
        if (getC003_Area_02__c() != null) {
            _hashCode += getC003_Area_02__c().hashCode();
        }
        if (getC003_Area_03__c() != null) {
            _hashCode += getC003_Area_03__c().hashCode();
        }
        if (getC003_Area_04__c() != null) {
            _hashCode += getC003_Area_04__c().hashCode();
        }
        if (getC003_Area_05__c() != null) {
            _hashCode += getC003_Area_05__c().hashCode();
        }
        if (getC003_Area_06__c() != null) {
            _hashCode += getC003_Area_06__c().hashCode();
        }
        if (getC003_Area_07__c() != null) {
            _hashCode += getC003_Area_07__c().hashCode();
        }
        if (getC003_Area_08__c() != null) {
            _hashCode += getC003_Area_08__c().hashCode();
        }
        if (getC003_Area_09__c() != null) {
            _hashCode += getC003_Area_09__c().hashCode();
        }
        if (getC003_Area_10__c() != null) {
            _hashCode += getC003_Area_10__c().hashCode();
        }
        if (getC003_BaseDateFrom__c() != null) {
            _hashCode += getC003_BaseDateFrom__c().hashCode();
        }
        if (getC003_BaseDateTo__c() != null) {
            _hashCode += getC003_BaseDateTo__c().hashCode();
        }
        if (getC003_Comment__c() != null) {
            _hashCode += getC003_Comment__c().hashCode();
        }
        if (getC003_ContractRef__c() != null) {
            _hashCode += getC003_ContractRef__c().hashCode();
        }
        if (getC003_ContractRef__r() != null) {
            _hashCode += getC003_ContractRef__r().hashCode();
        }
        if (getC003_EndDate__c() != null) {
            _hashCode += getC003_EndDate__c().hashCode();
        }
        if (getC003_EventConfigRef__c() != null) {
            _hashCode += getC003_EventConfigRef__c().hashCode();
        }
        if (getC003_EventConfigRef__r() != null) {
            _hashCode += getC003_EventConfigRef__r().hashCode();
        }
        if (getC003_Invalid30Days__c() != null) {
            _hashCode += getC003_Invalid30Days__c().hashCode();
        }
        if (getC003_NoticeAddress_User__c() != null) {
            _hashCode += getC003_NoticeAddress_User__c().hashCode();
        }
        if (getC003_NoticeAddress_User__r() != null) {
            _hashCode += getC003_NoticeAddress_User__r().hashCode();
        }
        if (getC003_ScoreTemp__c() != null) {
            _hashCode += getC003_ScoreTemp__c().hashCode();
        }
        if (getC003_Score__c() != null) {
            _hashCode += getC003_Score__c().hashCode();
        }
        if (getC003_StartDate__c() != null) {
            _hashCode += getC003_StartDate__c().hashCode();
        }
        if (getC003_Text_01__c() != null) {
            _hashCode += getC003_Text_01__c().hashCode();
        }
        if (getC003_Text_02__c() != null) {
            _hashCode += getC003_Text_02__c().hashCode();
        }
        if (getC003_Text_03__c() != null) {
            _hashCode += getC003_Text_03__c().hashCode();
        }
        if (getC003_Text_04__c() != null) {
            _hashCode += getC003_Text_04__c().hashCode();
        }
        if (getC003_Text_05__c() != null) {
            _hashCode += getC003_Text_05__c().hashCode();
        }
        if (getC003_Text_06__c() != null) {
            _hashCode += getC003_Text_06__c().hashCode();
        }
        if (getC003_Text_07__c() != null) {
            _hashCode += getC003_Text_07__c().hashCode();
        }
        if (getC003_Text_08__c() != null) {
            _hashCode += getC003_Text_08__c().hashCode();
        }
        if (getC003_Text_09__c() != null) {
            _hashCode += getC003_Text_09__c().hashCode();
        }
        if (getC003_Text_10__c() != null) {
            _hashCode += getC003_Text_10__c().hashCode();
        }
        if (getC003_Text_11__c() != null) {
            _hashCode += getC003_Text_11__c().hashCode();
        }
        if (getC003_Text_12__c() != null) {
            _hashCode += getC003_Text_12__c().hashCode();
        }
        if (getC003_Text_13__c() != null) {
            _hashCode += getC003_Text_13__c().hashCode();
        }
        if (getC003_Text_14__c() != null) {
            _hashCode += getC003_Text_14__c().hashCode();
        }
        if (getC003_Text_15__c() != null) {
            _hashCode += getC003_Text_15__c().hashCode();
        }
        if (getC003_Text_16__c() != null) {
            _hashCode += getC003_Text_16__c().hashCode();
        }
        if (getC003_Text_17__c() != null) {
            _hashCode += getC003_Text_17__c().hashCode();
        }
        if (getC003_Text_18__c() != null) {
            _hashCode += getC003_Text_18__c().hashCode();
        }
        if (getC003_Text_19__c() != null) {
            _hashCode += getC003_Text_19__c().hashCode();
        }
        if (getC003_Text_20__c() != null) {
            _hashCode += getC003_Text_20__c().hashCode();
        }
        if (getC003_Text_21__c() != null) {
            _hashCode += getC003_Text_21__c().hashCode();
        }
        if (getC003_Text_22__c() != null) {
            _hashCode += getC003_Text_22__c().hashCode();
        }
        if (getC003_Text_23__c() != null) {
            _hashCode += getC003_Text_23__c().hashCode();
        }
        if (getC003_Text_24__c() != null) {
            _hashCode += getC003_Text_24__c().hashCode();
        }
        if (getC003_Text_25__c() != null) {
            _hashCode += getC003_Text_25__c().hashCode();
        }
        if (getC003_Text_26__c() != null) {
            _hashCode += getC003_Text_26__c().hashCode();
        }
        if (getC003_Text_27__c() != null) {
            _hashCode += getC003_Text_27__c().hashCode();
        }
        if (getC003_Text_28__c() != null) {
            _hashCode += getC003_Text_28__c().hashCode();
        }
        if (getC003_Text_29__c() != null) {
            _hashCode += getC003_Text_29__c().hashCode();
        }
        if (getC003_Text_30__c() != null) {
            _hashCode += getC003_Text_30__c().hashCode();
        }
        if (getC003_Text_31__c() != null) {
            _hashCode += getC003_Text_31__c().hashCode();
        }
        if (getC003_Text_32__c() != null) {
            _hashCode += getC003_Text_32__c().hashCode();
        }
        if (getC003_Text_33__c() != null) {
            _hashCode += getC003_Text_33__c().hashCode();
        }
        if (getC003_Text_34__c() != null) {
            _hashCode += getC003_Text_34__c().hashCode();
        }
        if (getC003_Text_35__c() != null) {
            _hashCode += getC003_Text_35__c().hashCode();
        }
        if (getC003_Text_36__c() != null) {
            _hashCode += getC003_Text_36__c().hashCode();
        }
        if (getC003_Text_37__c() != null) {
            _hashCode += getC003_Text_37__c().hashCode();
        }
        if (getC003_Text_38__c() != null) {
            _hashCode += getC003_Text_38__c().hashCode();
        }
        if (getC003_Text_39__c() != null) {
            _hashCode += getC003_Text_39__c().hashCode();
        }
        if (getC003_Text_40__c() != null) {
            _hashCode += getC003_Text_40__c().hashCode();
        }
        if (getC003_Text_41__c() != null) {
            _hashCode += getC003_Text_41__c().hashCode();
        }
        if (getC003_Text_42__c() != null) {
            _hashCode += getC003_Text_42__c().hashCode();
        }
        if (getC003_Text_43__c() != null) {
            _hashCode += getC003_Text_43__c().hashCode();
        }
        if (getC003_Text_44__c() != null) {
            _hashCode += getC003_Text_44__c().hashCode();
        }
        if (getC003_Text_45__c() != null) {
            _hashCode += getC003_Text_45__c().hashCode();
        }
        if (getC003_Text_46__c() != null) {
            _hashCode += getC003_Text_46__c().hashCode();
        }
        if (getC003_Text_47__c() != null) {
            _hashCode += getC003_Text_47__c().hashCode();
        }
        if (getC003_Text_48__c() != null) {
            _hashCode += getC003_Text_48__c().hashCode();
        }
        if (getC003_Text_49__c() != null) {
            _hashCode += getC003_Text_49__c().hashCode();
        }
        if (getC003_Text_50__c() != null) {
            _hashCode += getC003_Text_50__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLastReferencedDate() != null) {
            _hashCode += getLastReferencedDate().hashCode();
        }
        if (getLastViewedDate() != null) {
            _hashCode += getLastViewedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C003_Event__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Event__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_AccountRef__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_AccountRef__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_AccountRef__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_AccountRef__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Account"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_02__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_02__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_03__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_03__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_04__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_04__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_05__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_05__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_06__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_06__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_07__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_07__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_08__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_08__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_09__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_09__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Area_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Area_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_BaseDateFrom__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_BaseDateFrom__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_BaseDateTo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_BaseDateTo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Comment__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Comment__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_ContractRef__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_ContractRef__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_ContractRef__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_ContractRef__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Contract__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_EndDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_EndDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_EventConfigRef__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_EventConfigRef__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_EventConfigRef__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_EventConfigRef__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_EventConfig__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Invalid30Days__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Invalid30Days__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_NoticeAddress_User__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_NoticeAddress_User__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_NoticeAddress_User__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_NoticeAddress_User__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_ScoreTemp__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_ScoreTemp__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Score__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Score__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_StartDate__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_StartDate__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_01__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_01__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_02__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_02__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_03__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_03__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_04__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_04__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_05__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_05__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_06__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_06__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_07__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_07__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_08__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_08__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_09__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_09__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_11__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_11__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_12__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_12__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_13__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_13__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_14__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_14__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_15__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_15__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_16__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_16__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_17__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_17__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_18__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_18__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_19__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_19__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_20__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_20__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_21__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_21__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_22__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_22__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_23__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_23__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_24__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_24__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_25__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_25__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_26__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_26__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_27__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_27__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_28__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_28__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_29__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_29__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_30__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_30__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_31__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_31__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_32__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_32__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_33__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_33__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_34__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_34__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_35__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_35__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_36__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_36__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_37__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_37__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_38__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_38__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_39__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_39__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_40__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_40__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_41__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_41__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_42__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_42__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_43__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_43__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_44__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_44__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_45__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_45__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_46__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_46__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_47__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_47__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_48__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_48__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_49__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_49__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_Text_50__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_Text_50__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastReferencedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastReferencedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastViewedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastViewedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
