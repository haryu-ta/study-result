/**
 * A006_TRN_BankMaster__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class A006_TRN_BankMaster__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult allocationLimitToBankMaster__r;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private com.sforce.soap.enterprise.QueryResult BMasterToGinkoBu__r;

    private com.sforce.soap.enterprise.QueryResult BScopeToGinkoBu__r;

    private com.sforce.soap.enterprise.QueryResult bankCreditAmountToBankMaster__r;

    private com.sforce.soap.enterprise.QueryResult bankMatchinToBankMaster__r;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.QueryResult creJitsuToBank__r;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult creditLimitToBankMaster__r;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult GLimitToGinkoBu__r;

    private com.sforce.soap.enterprise.QueryResult gaiginGinkoBuToBankMaster__r;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.QueryResult jitsuzanToBankMaster__r;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.util.Calendar lastReferencedDate;

    private java.util.Calendar lastViewedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult nostroToGinkoBu__r;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult PLossToGinkoBu__r;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    private com.sforce.soap.enterprise.QueryResult vostroToGinkoBu__r;

    public A006_TRN_BankMaster__c() {
    }

    public A006_TRN_BankMaster__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult allocationLimitToBankMaster__r,
           com.sforce.soap.enterprise.QueryResult attachments,
           com.sforce.soap.enterprise.QueryResult BMasterToGinkoBu__r,
           com.sforce.soap.enterprise.QueryResult BScopeToGinkoBu__r,
           com.sforce.soap.enterprise.QueryResult bankCreditAmountToBankMaster__r,
           com.sforce.soap.enterprise.QueryResult bankMatchinToBankMaster__r,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.QueryResult creJitsuToBank__r,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult creditLimitToBankMaster__r,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult GLimitToGinkoBu__r,
           com.sforce.soap.enterprise.QueryResult gaiginGinkoBuToBankMaster__r,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.QueryResult jitsuzanToBankMaster__r,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.util.Calendar lastReferencedDate,
           java.util.Calendar lastViewedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult nostroToGinkoBu__r,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult PLossToGinkoBu__r,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess,
           com.sforce.soap.enterprise.QueryResult vostroToGinkoBu__r) {
        super(
            fieldsToNull,
            id);
        this.allocationLimitToBankMaster__r = allocationLimitToBankMaster__r;
        this.attachments = attachments;
        this.BMasterToGinkoBu__r = BMasterToGinkoBu__r;
        this.BScopeToGinkoBu__r = BScopeToGinkoBu__r;
        this.bankCreditAmountToBankMaster__r = bankCreditAmountToBankMaster__r;
        this.bankMatchinToBankMaster__r = bankMatchinToBankMaster__r;
        this.combinedAttachments = combinedAttachments;
        this.creJitsuToBank__r = creJitsuToBank__r;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.creditLimitToBankMaster__r = creditLimitToBankMaster__r;
        this.duplicateRecordItems = duplicateRecordItems;
        this.GLimitToGinkoBu__r = GLimitToGinkoBu__r;
        this.gaiginGinkoBuToBankMaster__r = gaiginGinkoBuToBankMaster__r;
        this.isDeleted = isDeleted;
        this.jitsuzanToBankMaster__r = jitsuzanToBankMaster__r;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lastReferencedDate = lastReferencedDate;
        this.lastViewedDate = lastViewedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.nostroToGinkoBu__r = nostroToGinkoBu__r;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.owner = owner;
        this.ownerId = ownerId;
        this.PLossToGinkoBu__r = PLossToGinkoBu__r;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.systemModstamp = systemModstamp;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
        this.vostroToGinkoBu__r = vostroToGinkoBu__r;
    }


    /**
     * Gets the allocationLimitToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @return allocationLimitToBankMaster__r
     */
    public com.sforce.soap.enterprise.QueryResult getAllocationLimitToBankMaster__r() {
        return allocationLimitToBankMaster__r;
    }


    /**
     * Sets the allocationLimitToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @param allocationLimitToBankMaster__r
     */
    public void setAllocationLimitToBankMaster__r(com.sforce.soap.enterprise.QueryResult allocationLimitToBankMaster__r) {
        this.allocationLimitToBankMaster__r = allocationLimitToBankMaster__r;
    }


    /**
     * Gets the attachments value for this A006_TRN_BankMaster__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this A006_TRN_BankMaster__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the BMasterToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @return BMasterToGinkoBu__r
     */
    public com.sforce.soap.enterprise.QueryResult getBMasterToGinkoBu__r() {
        return BMasterToGinkoBu__r;
    }


    /**
     * Sets the BMasterToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @param BMasterToGinkoBu__r
     */
    public void setBMasterToGinkoBu__r(com.sforce.soap.enterprise.QueryResult BMasterToGinkoBu__r) {
        this.BMasterToGinkoBu__r = BMasterToGinkoBu__r;
    }


    /**
     * Gets the BScopeToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @return BScopeToGinkoBu__r
     */
    public com.sforce.soap.enterprise.QueryResult getBScopeToGinkoBu__r() {
        return BScopeToGinkoBu__r;
    }


    /**
     * Sets the BScopeToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @param BScopeToGinkoBu__r
     */
    public void setBScopeToGinkoBu__r(com.sforce.soap.enterprise.QueryResult BScopeToGinkoBu__r) {
        this.BScopeToGinkoBu__r = BScopeToGinkoBu__r;
    }


    /**
     * Gets the bankCreditAmountToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @return bankCreditAmountToBankMaster__r
     */
    public com.sforce.soap.enterprise.QueryResult getBankCreditAmountToBankMaster__r() {
        return bankCreditAmountToBankMaster__r;
    }


    /**
     * Sets the bankCreditAmountToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @param bankCreditAmountToBankMaster__r
     */
    public void setBankCreditAmountToBankMaster__r(com.sforce.soap.enterprise.QueryResult bankCreditAmountToBankMaster__r) {
        this.bankCreditAmountToBankMaster__r = bankCreditAmountToBankMaster__r;
    }


    /**
     * Gets the bankMatchinToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @return bankMatchinToBankMaster__r
     */
    public com.sforce.soap.enterprise.QueryResult getBankMatchinToBankMaster__r() {
        return bankMatchinToBankMaster__r;
    }


    /**
     * Sets the bankMatchinToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @param bankMatchinToBankMaster__r
     */
    public void setBankMatchinToBankMaster__r(com.sforce.soap.enterprise.QueryResult bankMatchinToBankMaster__r) {
        this.bankMatchinToBankMaster__r = bankMatchinToBankMaster__r;
    }


    /**
     * Gets the combinedAttachments value for this A006_TRN_BankMaster__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this A006_TRN_BankMaster__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the creJitsuToBank__r value for this A006_TRN_BankMaster__c.
     * 
     * @return creJitsuToBank__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreJitsuToBank__r() {
        return creJitsuToBank__r;
    }


    /**
     * Sets the creJitsuToBank__r value for this A006_TRN_BankMaster__c.
     * 
     * @param creJitsuToBank__r
     */
    public void setCreJitsuToBank__r(com.sforce.soap.enterprise.QueryResult creJitsuToBank__r) {
        this.creJitsuToBank__r = creJitsuToBank__r;
    }


    /**
     * Gets the createdBy value for this A006_TRN_BankMaster__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this A006_TRN_BankMaster__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this A006_TRN_BankMaster__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this A006_TRN_BankMaster__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this A006_TRN_BankMaster__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this A006_TRN_BankMaster__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the creditLimitToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @return creditLimitToBankMaster__r
     */
    public com.sforce.soap.enterprise.QueryResult getCreditLimitToBankMaster__r() {
        return creditLimitToBankMaster__r;
    }


    /**
     * Sets the creditLimitToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @param creditLimitToBankMaster__r
     */
    public void setCreditLimitToBankMaster__r(com.sforce.soap.enterprise.QueryResult creditLimitToBankMaster__r) {
        this.creditLimitToBankMaster__r = creditLimitToBankMaster__r;
    }


    /**
     * Gets the duplicateRecordItems value for this A006_TRN_BankMaster__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this A006_TRN_BankMaster__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the GLimitToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @return GLimitToGinkoBu__r
     */
    public com.sforce.soap.enterprise.QueryResult getGLimitToGinkoBu__r() {
        return GLimitToGinkoBu__r;
    }


    /**
     * Sets the GLimitToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @param GLimitToGinkoBu__r
     */
    public void setGLimitToGinkoBu__r(com.sforce.soap.enterprise.QueryResult GLimitToGinkoBu__r) {
        this.GLimitToGinkoBu__r = GLimitToGinkoBu__r;
    }


    /**
     * Gets the gaiginGinkoBuToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @return gaiginGinkoBuToBankMaster__r
     */
    public com.sforce.soap.enterprise.QueryResult getGaiginGinkoBuToBankMaster__r() {
        return gaiginGinkoBuToBankMaster__r;
    }


    /**
     * Sets the gaiginGinkoBuToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @param gaiginGinkoBuToBankMaster__r
     */
    public void setGaiginGinkoBuToBankMaster__r(com.sforce.soap.enterprise.QueryResult gaiginGinkoBuToBankMaster__r) {
        this.gaiginGinkoBuToBankMaster__r = gaiginGinkoBuToBankMaster__r;
    }


    /**
     * Gets the isDeleted value for this A006_TRN_BankMaster__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this A006_TRN_BankMaster__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the jitsuzanToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @return jitsuzanToBankMaster__r
     */
    public com.sforce.soap.enterprise.QueryResult getJitsuzanToBankMaster__r() {
        return jitsuzanToBankMaster__r;
    }


    /**
     * Sets the jitsuzanToBankMaster__r value for this A006_TRN_BankMaster__c.
     * 
     * @param jitsuzanToBankMaster__r
     */
    public void setJitsuzanToBankMaster__r(com.sforce.soap.enterprise.QueryResult jitsuzanToBankMaster__r) {
        this.jitsuzanToBankMaster__r = jitsuzanToBankMaster__r;
    }


    /**
     * Gets the lastModifiedBy value for this A006_TRN_BankMaster__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this A006_TRN_BankMaster__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this A006_TRN_BankMaster__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this A006_TRN_BankMaster__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this A006_TRN_BankMaster__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this A006_TRN_BankMaster__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lastReferencedDate value for this A006_TRN_BankMaster__c.
     * 
     * @return lastReferencedDate
     */
    public java.util.Calendar getLastReferencedDate() {
        return lastReferencedDate;
    }


    /**
     * Sets the lastReferencedDate value for this A006_TRN_BankMaster__c.
     * 
     * @param lastReferencedDate
     */
    public void setLastReferencedDate(java.util.Calendar lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }


    /**
     * Gets the lastViewedDate value for this A006_TRN_BankMaster__c.
     * 
     * @return lastViewedDate
     */
    public java.util.Calendar getLastViewedDate() {
        return lastViewedDate;
    }


    /**
     * Sets the lastViewedDate value for this A006_TRN_BankMaster__c.
     * 
     * @param lastViewedDate
     */
    public void setLastViewedDate(java.util.Calendar lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this A006_TRN_BankMaster__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this A006_TRN_BankMaster__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this A006_TRN_BankMaster__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this A006_TRN_BankMaster__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the nostroToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @return nostroToGinkoBu__r
     */
    public com.sforce.soap.enterprise.QueryResult getNostroToGinkoBu__r() {
        return nostroToGinkoBu__r;
    }


    /**
     * Sets the nostroToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @param nostroToGinkoBu__r
     */
    public void setNostroToGinkoBu__r(com.sforce.soap.enterprise.QueryResult nostroToGinkoBu__r) {
        this.nostroToGinkoBu__r = nostroToGinkoBu__r;
    }


    /**
     * Gets the notes value for this A006_TRN_BankMaster__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this A006_TRN_BankMaster__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this A006_TRN_BankMaster__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this A006_TRN_BankMaster__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the owner value for this A006_TRN_BankMaster__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this A006_TRN_BankMaster__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this A006_TRN_BankMaster__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this A006_TRN_BankMaster__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the PLossToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @return PLossToGinkoBu__r
     */
    public com.sforce.soap.enterprise.QueryResult getPLossToGinkoBu__r() {
        return PLossToGinkoBu__r;
    }


    /**
     * Sets the PLossToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @param PLossToGinkoBu__r
     */
    public void setPLossToGinkoBu__r(com.sforce.soap.enterprise.QueryResult PLossToGinkoBu__r) {
        this.PLossToGinkoBu__r = PLossToGinkoBu__r;
    }


    /**
     * Gets the processInstances value for this A006_TRN_BankMaster__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this A006_TRN_BankMaster__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this A006_TRN_BankMaster__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this A006_TRN_BankMaster__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the systemModstamp value for this A006_TRN_BankMaster__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this A006_TRN_BankMaster__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the topicAssignments value for this A006_TRN_BankMaster__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this A006_TRN_BankMaster__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this A006_TRN_BankMaster__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this A006_TRN_BankMaster__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the vostroToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @return vostroToGinkoBu__r
     */
    public com.sforce.soap.enterprise.QueryResult getVostroToGinkoBu__r() {
        return vostroToGinkoBu__r;
    }


    /**
     * Sets the vostroToGinkoBu__r value for this A006_TRN_BankMaster__c.
     * 
     * @param vostroToGinkoBu__r
     */
    public void setVostroToGinkoBu__r(com.sforce.soap.enterprise.QueryResult vostroToGinkoBu__r) {
        this.vostroToGinkoBu__r = vostroToGinkoBu__r;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof A006_TRN_BankMaster__c)) return false;
        A006_TRN_BankMaster__c other = (A006_TRN_BankMaster__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.allocationLimitToBankMaster__r==null && other.getAllocationLimitToBankMaster__r()==null) || 
             (this.allocationLimitToBankMaster__r!=null &&
              this.allocationLimitToBankMaster__r.equals(other.getAllocationLimitToBankMaster__r()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.BMasterToGinkoBu__r==null && other.getBMasterToGinkoBu__r()==null) || 
             (this.BMasterToGinkoBu__r!=null &&
              this.BMasterToGinkoBu__r.equals(other.getBMasterToGinkoBu__r()))) &&
            ((this.BScopeToGinkoBu__r==null && other.getBScopeToGinkoBu__r()==null) || 
             (this.BScopeToGinkoBu__r!=null &&
              this.BScopeToGinkoBu__r.equals(other.getBScopeToGinkoBu__r()))) &&
            ((this.bankCreditAmountToBankMaster__r==null && other.getBankCreditAmountToBankMaster__r()==null) || 
             (this.bankCreditAmountToBankMaster__r!=null &&
              this.bankCreditAmountToBankMaster__r.equals(other.getBankCreditAmountToBankMaster__r()))) &&
            ((this.bankMatchinToBankMaster__r==null && other.getBankMatchinToBankMaster__r()==null) || 
             (this.bankMatchinToBankMaster__r!=null &&
              this.bankMatchinToBankMaster__r.equals(other.getBankMatchinToBankMaster__r()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.creJitsuToBank__r==null && other.getCreJitsuToBank__r()==null) || 
             (this.creJitsuToBank__r!=null &&
              this.creJitsuToBank__r.equals(other.getCreJitsuToBank__r()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.creditLimitToBankMaster__r==null && other.getCreditLimitToBankMaster__r()==null) || 
             (this.creditLimitToBankMaster__r!=null &&
              this.creditLimitToBankMaster__r.equals(other.getCreditLimitToBankMaster__r()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.GLimitToGinkoBu__r==null && other.getGLimitToGinkoBu__r()==null) || 
             (this.GLimitToGinkoBu__r!=null &&
              this.GLimitToGinkoBu__r.equals(other.getGLimitToGinkoBu__r()))) &&
            ((this.gaiginGinkoBuToBankMaster__r==null && other.getGaiginGinkoBuToBankMaster__r()==null) || 
             (this.gaiginGinkoBuToBankMaster__r!=null &&
              this.gaiginGinkoBuToBankMaster__r.equals(other.getGaiginGinkoBuToBankMaster__r()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.jitsuzanToBankMaster__r==null && other.getJitsuzanToBankMaster__r()==null) || 
             (this.jitsuzanToBankMaster__r!=null &&
              this.jitsuzanToBankMaster__r.equals(other.getJitsuzanToBankMaster__r()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lastReferencedDate==null && other.getLastReferencedDate()==null) || 
             (this.lastReferencedDate!=null &&
              this.lastReferencedDate.equals(other.getLastReferencedDate()))) &&
            ((this.lastViewedDate==null && other.getLastViewedDate()==null) || 
             (this.lastViewedDate!=null &&
              this.lastViewedDate.equals(other.getLastViewedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.nostroToGinkoBu__r==null && other.getNostroToGinkoBu__r()==null) || 
             (this.nostroToGinkoBu__r!=null &&
              this.nostroToGinkoBu__r.equals(other.getNostroToGinkoBu__r()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.PLossToGinkoBu__r==null && other.getPLossToGinkoBu__r()==null) || 
             (this.PLossToGinkoBu__r!=null &&
              this.PLossToGinkoBu__r.equals(other.getPLossToGinkoBu__r()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess()))) &&
            ((this.vostroToGinkoBu__r==null && other.getVostroToGinkoBu__r()==null) || 
             (this.vostroToGinkoBu__r!=null &&
              this.vostroToGinkoBu__r.equals(other.getVostroToGinkoBu__r())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getAllocationLimitToBankMaster__r() != null) {
            _hashCode += getAllocationLimitToBankMaster__r().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBMasterToGinkoBu__r() != null) {
            _hashCode += getBMasterToGinkoBu__r().hashCode();
        }
        if (getBScopeToGinkoBu__r() != null) {
            _hashCode += getBScopeToGinkoBu__r().hashCode();
        }
        if (getBankCreditAmountToBankMaster__r() != null) {
            _hashCode += getBankCreditAmountToBankMaster__r().hashCode();
        }
        if (getBankMatchinToBankMaster__r() != null) {
            _hashCode += getBankMatchinToBankMaster__r().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreJitsuToBank__r() != null) {
            _hashCode += getCreJitsuToBank__r().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getCreditLimitToBankMaster__r() != null) {
            _hashCode += getCreditLimitToBankMaster__r().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getGLimitToGinkoBu__r() != null) {
            _hashCode += getGLimitToGinkoBu__r().hashCode();
        }
        if (getGaiginGinkoBuToBankMaster__r() != null) {
            _hashCode += getGaiginGinkoBuToBankMaster__r().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getJitsuzanToBankMaster__r() != null) {
            _hashCode += getJitsuzanToBankMaster__r().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLastReferencedDate() != null) {
            _hashCode += getLastReferencedDate().hashCode();
        }
        if (getLastViewedDate() != null) {
            _hashCode += getLastViewedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNostroToGinkoBu__r() != null) {
            _hashCode += getNostroToGinkoBu__r().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getPLossToGinkoBu__r() != null) {
            _hashCode += getPLossToGinkoBu__r().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        if (getVostroToGinkoBu__r() != null) {
            _hashCode += getVostroToGinkoBu__r().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(A006_TRN_BankMaster__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A006_TRN_BankMaster__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allocationLimitToBankMaster__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AllocationLimitToBankMaster__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BMasterToGinkoBu__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BMasterToGinkoBu__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BScopeToGinkoBu__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BScopeToGinkoBu__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankCreditAmountToBankMaster__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BankCreditAmountToBankMaster__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bankMatchinToBankMaster__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BankMatchinToBankMaster__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creJitsuToBank__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreJitsuToBank__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("creditLimitToBankMaster__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreditLimitToBankMaster__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GLimitToGinkoBu__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GLimitToGinkoBu__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("gaiginGinkoBuToBankMaster__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GaiginGinkoBuToBankMaster__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("jitsuzanToBankMaster__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JitsuzanToBankMaster__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastReferencedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastReferencedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastViewedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastViewedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nostroToGinkoBu__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NostroToGinkoBu__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PLossToGinkoBu__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "PLossToGinkoBu__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vostroToGinkoBu__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "VostroToGinkoBu__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
