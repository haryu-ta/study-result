/**
 * C000_BUSHOINFO__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C000_BUSHOINFO__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String ADTEN__c;

    private java.lang.String AREAINFOCD__c;

    private java.lang.String AREANM__c;

    private java.lang.String AREARYAKU__c;

    private com.sforce.soap.enterprise.QueryResult acceptOffice__r;

    private com.sforce.soap.enterprise.QueryResult activityHistories;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String BANKTORIHIKICDKANRIBUFLG__c;

    private java.lang.String BATCHHENKOUKBN__c;

    private java.lang.String BLOKBN__c;

    private java.lang.String BOTENCD__c;

    private java.lang.String BUMONBETSUFLG__c;

    private java.lang.String BUMONCD_HENKOU__c;

    private java.lang.String BUMONCD__c;

    private java.lang.String BUMONHONBUCD__c;

    private java.lang.String BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;

    private java.lang.String BUTENBANGOU__c;

    private java.lang.String BUTENCHOUYAKUSHOKUCD__c;

    private java.lang.String BUTENNM1__c;

    private java.lang.String BUTENNM2__c;

    private java.lang.String BUTENNM3__c;

    private java.lang.String BUTENNMKANA__c;

    private java.lang.String BUTENNMRENKETSU__c;

    private java.lang.String BUTENNMRYAKU__c;

    private com.sforce.soap.enterprise.QueryResult c000_026_OBJECT_APPLICATION_INFO_03__r;

    private com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_02__r;

    private com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_04__r;

    private com.sforce.soap.enterprise.QueryResult c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_BUSHOINFO_BushitsuTembanMei_O_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_BUSHOINFO_BushitsuTemban_S_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_02__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_04__r;

    private com.sforce.soap.enterprise.QueryResult c001_Offices_01__r;

    private com.sforce.soap.enterprise.QueryResult c001_TantouKyotenNameMitoris_01__r;

    private com.sforce.soap.enterprise.QueryResult c003_BUSHOINFOs_01__r;

    private com.sforce.soap.enterprise.QueryResult c003_BUSHOINFOs_03__r;

    private java.lang.String CHIKUCD__c;

    private java.lang.String CHINESE_WALLKBN__c;

    private com.sforce.soap.enterprise.QueryResult chokusetsuBranchName__r;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private java.lang.Boolean DELFLG__c;

    private java.lang.String DOUBLECNTKYOYOUFLG__c;

    private com.sforce.soap.enterprise.QueryResult dairiBranchName1__r;

    private com.sforce.soap.enterprise.QueryResult dairiBranchName2__r;

    private com.sforce.soap.enterprise.QueryResult dairiBranchName3__r;

    private com.sforce.soap.enterprise.QueryResult dairiBranchName4__r;

    private com.sforce.soap.enterprise.QueryResult dairiBranchName5__r;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private java.lang.String EIGYOKBN__c;

    private java.lang.String EIGYOKEITAIKBN__c;

    private com.sforce.soap.enterprise.QueryResult events;

    private java.util.Date HAITENBI__c;

    private java.lang.String HONBU_EIGYOKYOTENFLG__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private java.lang.String JIMUSOSHIKIKBN__c;

    private java.lang.String JOUIAREAINFOCD__c;

    private java.lang.String JOUIBUTENBANGOU_HENKOU__c;

    private java.lang.String JOUIBUTENBANGOU__c;

    private java.lang.String JOUIKACD__c;

    private java.lang.String JOUKENKENSAKUYOUFLG__c;

    private java.lang.String KACD__c;

    private java.lang.String KAIGAIFLG__c;

    private java.util.Date KAITENBI__c;

    private java.lang.String KANJOTENKBN__c;

    private java.lang.String KA_GRNMKANA__c;

    private java.lang.String KA_GRNMRYAKU__c;

    private java.lang.String KA_GRNM__c;

    private java.lang.String KOKYAKUKANRIHONBUKBN__c;

    private java.lang.String KYOTENFLG__c;

    private java.util.Date lastActivityDate;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.QueryResult openActivities;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.String RENKETSUFLG__c;

    private java.lang.String RMFKYOYOUFLG__c;

    private com.sforce.soap.enterprise.QueryResult requestBranchName__r;

    private java.lang.String SAISHUUTEAMCD__c;

    private java.lang.String SHIJOUNAYOSEKANRIBUFLG__c;

    private java.lang.String SHOUNINJOUKYOUFLG__c;

    private java.lang.String SOSHIKICATEGORYKBN__c;

    private java.lang.String SOSHIKIJUNCD__c;

    private java.lang.String SOSHIKIKEITAI__c;

    private java.lang.String SOUGOURISKKANRIBUFLG__c;

    private com.sforce.soap.enterprise.QueryResult shares;

    private java.util.Calendar systemModstamp;

    private java.lang.String TATEMONOKBN__c;

    private java.lang.String TEAMCD__c;

    private java.lang.String TEAMNM__c;

    private java.lang.String TENSHITSU__c;

    private java.lang.String TOKUTEISOSHIKIKBN__c;

    private java.lang.String TOUMEIHANCD__c;

    private com.sforce.soap.enterprise.QueryResult tasks;

    private com.sforce.soap.enterprise.QueryResult tesuryoBranchName__r;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    private java.lang.String YOSHINSHOKANBUFLG__c;

    private java.util.Date YUUKOUKIKANKAISHIBI__c;

    private java.lang.String ZENSENKAHONBUFLG__c;

    public C000_BUSHOINFO__c() {
    }

    public C000_BUSHOINFO__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String ADTEN__c,
           java.lang.String AREAINFOCD__c,
           java.lang.String AREANM__c,
           java.lang.String AREARYAKU__c,
           com.sforce.soap.enterprise.QueryResult acceptOffice__r,
           com.sforce.soap.enterprise.QueryResult activityHistories,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String BANKTORIHIKICDKANRIBUFLG__c,
           java.lang.String BATCHHENKOUKBN__c,
           java.lang.String BLOKBN__c,
           java.lang.String BOTENCD__c,
           java.lang.String BUMONBETSUFLG__c,
           java.lang.String BUMONCD_HENKOU__c,
           java.lang.String BUMONCD__c,
           java.lang.String BUMONHONBUCD__c,
           java.lang.String BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c,
           java.lang.String BUTENBANGOU__c,
           java.lang.String BUTENCHOUYAKUSHOKUCD__c,
           java.lang.String BUTENNM1__c,
           java.lang.String BUTENNM2__c,
           java.lang.String BUTENNM3__c,
           java.lang.String BUTENNMKANA__c,
           java.lang.String BUTENNMRENKETSU__c,
           java.lang.String BUTENNMRYAKU__c,
           com.sforce.soap.enterprise.QueryResult c000_026_OBJECT_APPLICATION_INFO_03__r,
           com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_02__r,
           com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_04__r,
           com.sforce.soap.enterprise.QueryResult c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r,
           com.sforce.soap.enterprise.QueryResult c000_BUSHOINFO_BushitsuTembanMei_O_01__r,
           com.sforce.soap.enterprise.QueryResult c000_BUSHOINFO_BushitsuTemban_S_01__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_02__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_04__r,
           com.sforce.soap.enterprise.QueryResult c001_Offices_01__r,
           com.sforce.soap.enterprise.QueryResult c001_TantouKyotenNameMitoris_01__r,
           com.sforce.soap.enterprise.QueryResult c003_BUSHOINFOs_01__r,
           com.sforce.soap.enterprise.QueryResult c003_BUSHOINFOs_03__r,
           java.lang.String CHIKUCD__c,
           java.lang.String CHINESE_WALLKBN__c,
           com.sforce.soap.enterprise.QueryResult chokusetsuBranchName__r,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           java.lang.Boolean DELFLG__c,
           java.lang.String DOUBLECNTKYOYOUFLG__c,
           com.sforce.soap.enterprise.QueryResult dairiBranchName1__r,
           com.sforce.soap.enterprise.QueryResult dairiBranchName2__r,
           com.sforce.soap.enterprise.QueryResult dairiBranchName3__r,
           com.sforce.soap.enterprise.QueryResult dairiBranchName4__r,
           com.sforce.soap.enterprise.QueryResult dairiBranchName5__r,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           java.lang.String EIGYOKBN__c,
           java.lang.String EIGYOKEITAIKBN__c,
           com.sforce.soap.enterprise.QueryResult events,
           java.util.Date HAITENBI__c,
           java.lang.String HONBU_EIGYOKYOTENFLG__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           java.lang.String JIMUSOSHIKIKBN__c,
           java.lang.String JOUIAREAINFOCD__c,
           java.lang.String JOUIBUTENBANGOU_HENKOU__c,
           java.lang.String JOUIBUTENBANGOU__c,
           java.lang.String JOUIKACD__c,
           java.lang.String JOUKENKENSAKUYOUFLG__c,
           java.lang.String KACD__c,
           java.lang.String KAIGAIFLG__c,
           java.util.Date KAITENBI__c,
           java.lang.String KANJOTENKBN__c,
           java.lang.String KA_GRNMKANA__c,
           java.lang.String KA_GRNMRYAKU__c,
           java.lang.String KA_GRNM__c,
           java.lang.String KOKYAKUKANRIHONBUKBN__c,
           java.lang.String KYOTENFLG__c,
           java.util.Date lastActivityDate,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.QueryResult openActivities,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.String RENKETSUFLG__c,
           java.lang.String RMFKYOYOUFLG__c,
           com.sforce.soap.enterprise.QueryResult requestBranchName__r,
           java.lang.String SAISHUUTEAMCD__c,
           java.lang.String SHIJOUNAYOSEKANRIBUFLG__c,
           java.lang.String SHOUNINJOUKYOUFLG__c,
           java.lang.String SOSHIKICATEGORYKBN__c,
           java.lang.String SOSHIKIJUNCD__c,
           java.lang.String SOSHIKIKEITAI__c,
           java.lang.String SOUGOURISKKANRIBUFLG__c,
           com.sforce.soap.enterprise.QueryResult shares,
           java.util.Calendar systemModstamp,
           java.lang.String TATEMONOKBN__c,
           java.lang.String TEAMCD__c,
           java.lang.String TEAMNM__c,
           java.lang.String TENSHITSU__c,
           java.lang.String TOKUTEISOSHIKIKBN__c,
           java.lang.String TOUMEIHANCD__c,
           com.sforce.soap.enterprise.QueryResult tasks,
           com.sforce.soap.enterprise.QueryResult tesuryoBranchName__r,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess,
           java.lang.String YOSHINSHOKANBUFLG__c,
           java.util.Date YUUKOUKIKANKAISHIBI__c,
           java.lang.String ZENSENKAHONBUFLG__c) {
        super(
            fieldsToNull,
            id);
        this.ADTEN__c = ADTEN__c;
        this.AREAINFOCD__c = AREAINFOCD__c;
        this.AREANM__c = AREANM__c;
        this.AREARYAKU__c = AREARYAKU__c;
        this.acceptOffice__r = acceptOffice__r;
        this.activityHistories = activityHistories;
        this.attachments = attachments;
        this.BANKTORIHIKICDKANRIBUFLG__c = BANKTORIHIKICDKANRIBUFLG__c;
        this.BATCHHENKOUKBN__c = BATCHHENKOUKBN__c;
        this.BLOKBN__c = BLOKBN__c;
        this.BOTENCD__c = BOTENCD__c;
        this.BUMONBETSUFLG__c = BUMONBETSUFLG__c;
        this.BUMONCD_HENKOU__c = BUMONCD_HENKOU__c;
        this.BUMONCD__c = BUMONCD__c;
        this.BUMONHONBUCD__c = BUMONHONBUCD__c;
        this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c = BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;
        this.BUTENBANGOU__c = BUTENBANGOU__c;
        this.BUTENCHOUYAKUSHOKUCD__c = BUTENCHOUYAKUSHOKUCD__c;
        this.BUTENNM1__c = BUTENNM1__c;
        this.BUTENNM2__c = BUTENNM2__c;
        this.BUTENNM3__c = BUTENNM3__c;
        this.BUTENNMKANA__c = BUTENNMKANA__c;
        this.BUTENNMRENKETSU__c = BUTENNMRENKETSU__c;
        this.BUTENNMRYAKU__c = BUTENNMRYAKU__c;
        this.c000_026_OBJECT_APPLICATION_INFO_03__r = c000_026_OBJECT_APPLICATION_INFO_03__r;
        this.c000_042_CIF_PROPERTY_CHANGE_INFO_02__r = c000_042_CIF_PROPERTY_CHANGE_INFO_02__r;
        this.c000_042_CIF_PROPERTY_CHANGE_INFO_04__r = c000_042_CIF_PROPERTY_CHANGE_INFO_04__r;
        this.c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r = c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r;
        this.c000_BUSHOINFO_BushitsuTembanMei_O_01__r = c000_BUSHOINFO_BushitsuTembanMei_O_01__r;
        this.c000_BUSHOINFO_BushitsuTemban_S_01__r = c000_BUSHOINFO_BushitsuTemban_S_01__r;
        this.c000_CIFZOKUSEIINFO_02__r = c000_CIFZOKUSEIINFO_02__r;
        this.c000_CIFZOKUSEIINFO_04__r = c000_CIFZOKUSEIINFO_04__r;
        this.c001_Offices_01__r = c001_Offices_01__r;
        this.c001_TantouKyotenNameMitoris_01__r = c001_TantouKyotenNameMitoris_01__r;
        this.c003_BUSHOINFOs_01__r = c003_BUSHOINFOs_01__r;
        this.c003_BUSHOINFOs_03__r = c003_BUSHOINFOs_03__r;
        this.CHIKUCD__c = CHIKUCD__c;
        this.CHINESE_WALLKBN__c = CHINESE_WALLKBN__c;
        this.chokusetsuBranchName__r = chokusetsuBranchName__r;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.DELFLG__c = DELFLG__c;
        this.DOUBLECNTKYOYOUFLG__c = DOUBLECNTKYOYOUFLG__c;
        this.dairiBranchName1__r = dairiBranchName1__r;
        this.dairiBranchName2__r = dairiBranchName2__r;
        this.dairiBranchName3__r = dairiBranchName3__r;
        this.dairiBranchName4__r = dairiBranchName4__r;
        this.dairiBranchName5__r = dairiBranchName5__r;
        this.duplicateRecordItems = duplicateRecordItems;
        this.EIGYOKBN__c = EIGYOKBN__c;
        this.EIGYOKEITAIKBN__c = EIGYOKEITAIKBN__c;
        this.events = events;
        this.HAITENBI__c = HAITENBI__c;
        this.HONBU_EIGYOKYOTENFLG__c = HONBU_EIGYOKYOTENFLG__c;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.JIMUSOSHIKIKBN__c = JIMUSOSHIKIKBN__c;
        this.JOUIAREAINFOCD__c = JOUIAREAINFOCD__c;
        this.JOUIBUTENBANGOU_HENKOU__c = JOUIBUTENBANGOU_HENKOU__c;
        this.JOUIBUTENBANGOU__c = JOUIBUTENBANGOU__c;
        this.JOUIKACD__c = JOUIKACD__c;
        this.JOUKENKENSAKUYOUFLG__c = JOUKENKENSAKUYOUFLG__c;
        this.KACD__c = KACD__c;
        this.KAIGAIFLG__c = KAIGAIFLG__c;
        this.KAITENBI__c = KAITENBI__c;
        this.KANJOTENKBN__c = KANJOTENKBN__c;
        this.KA_GRNMKANA__c = KA_GRNMKANA__c;
        this.KA_GRNMRYAKU__c = KA_GRNMRYAKU__c;
        this.KA_GRNM__c = KA_GRNM__c;
        this.KOKYAKUKANRIHONBUKBN__c = KOKYAKUKANRIHONBUKBN__c;
        this.KYOTENFLG__c = KYOTENFLG__c;
        this.lastActivityDate = lastActivityDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.openActivities = openActivities;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.RENKETSUFLG__c = RENKETSUFLG__c;
        this.RMFKYOYOUFLG__c = RMFKYOYOUFLG__c;
        this.requestBranchName__r = requestBranchName__r;
        this.SAISHUUTEAMCD__c = SAISHUUTEAMCD__c;
        this.SHIJOUNAYOSEKANRIBUFLG__c = SHIJOUNAYOSEKANRIBUFLG__c;
        this.SHOUNINJOUKYOUFLG__c = SHOUNINJOUKYOUFLG__c;
        this.SOSHIKICATEGORYKBN__c = SOSHIKICATEGORYKBN__c;
        this.SOSHIKIJUNCD__c = SOSHIKIJUNCD__c;
        this.SOSHIKIKEITAI__c = SOSHIKIKEITAI__c;
        this.SOUGOURISKKANRIBUFLG__c = SOUGOURISKKANRIBUFLG__c;
        this.shares = shares;
        this.systemModstamp = systemModstamp;
        this.TATEMONOKBN__c = TATEMONOKBN__c;
        this.TEAMCD__c = TEAMCD__c;
        this.TEAMNM__c = TEAMNM__c;
        this.TENSHITSU__c = TENSHITSU__c;
        this.TOKUTEISOSHIKIKBN__c = TOKUTEISOSHIKIKBN__c;
        this.TOUMEIHANCD__c = TOUMEIHANCD__c;
        this.tasks = tasks;
        this.tesuryoBranchName__r = tesuryoBranchName__r;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
        this.YOSHINSHOKANBUFLG__c = YOSHINSHOKANBUFLG__c;
        this.YUUKOUKIKANKAISHIBI__c = YUUKOUKIKANKAISHIBI__c;
        this.ZENSENKAHONBUFLG__c = ZENSENKAHONBUFLG__c;
    }


    /**
     * Gets the ADTEN__c value for this C000_BUSHOINFO__c.
     * 
     * @return ADTEN__c
     */
    public java.lang.String getADTEN__c() {
        return ADTEN__c;
    }


    /**
     * Sets the ADTEN__c value for this C000_BUSHOINFO__c.
     * 
     * @param ADTEN__c
     */
    public void setADTEN__c(java.lang.String ADTEN__c) {
        this.ADTEN__c = ADTEN__c;
    }


    /**
     * Gets the AREAINFOCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return AREAINFOCD__c
     */
    public java.lang.String getAREAINFOCD__c() {
        return AREAINFOCD__c;
    }


    /**
     * Sets the AREAINFOCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param AREAINFOCD__c
     */
    public void setAREAINFOCD__c(java.lang.String AREAINFOCD__c) {
        this.AREAINFOCD__c = AREAINFOCD__c;
    }


    /**
     * Gets the AREANM__c value for this C000_BUSHOINFO__c.
     * 
     * @return AREANM__c
     */
    public java.lang.String getAREANM__c() {
        return AREANM__c;
    }


    /**
     * Sets the AREANM__c value for this C000_BUSHOINFO__c.
     * 
     * @param AREANM__c
     */
    public void setAREANM__c(java.lang.String AREANM__c) {
        this.AREANM__c = AREANM__c;
    }


    /**
     * Gets the AREARYAKU__c value for this C000_BUSHOINFO__c.
     * 
     * @return AREARYAKU__c
     */
    public java.lang.String getAREARYAKU__c() {
        return AREARYAKU__c;
    }


    /**
     * Sets the AREARYAKU__c value for this C000_BUSHOINFO__c.
     * 
     * @param AREARYAKU__c
     */
    public void setAREARYAKU__c(java.lang.String AREARYAKU__c) {
        this.AREARYAKU__c = AREARYAKU__c;
    }


    /**
     * Gets the acceptOffice__r value for this C000_BUSHOINFO__c.
     * 
     * @return acceptOffice__r
     */
    public com.sforce.soap.enterprise.QueryResult getAcceptOffice__r() {
        return acceptOffice__r;
    }


    /**
     * Sets the acceptOffice__r value for this C000_BUSHOINFO__c.
     * 
     * @param acceptOffice__r
     */
    public void setAcceptOffice__r(com.sforce.soap.enterprise.QueryResult acceptOffice__r) {
        this.acceptOffice__r = acceptOffice__r;
    }


    /**
     * Gets the activityHistories value for this C000_BUSHOINFO__c.
     * 
     * @return activityHistories
     */
    public com.sforce.soap.enterprise.QueryResult getActivityHistories() {
        return activityHistories;
    }


    /**
     * Sets the activityHistories value for this C000_BUSHOINFO__c.
     * 
     * @param activityHistories
     */
    public void setActivityHistories(com.sforce.soap.enterprise.QueryResult activityHistories) {
        this.activityHistories = activityHistories;
    }


    /**
     * Gets the attachments value for this C000_BUSHOINFO__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C000_BUSHOINFO__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the BANKTORIHIKICDKANRIBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return BANKTORIHIKICDKANRIBUFLG__c
     */
    public java.lang.String getBANKTORIHIKICDKANRIBUFLG__c() {
        return BANKTORIHIKICDKANRIBUFLG__c;
    }


    /**
     * Sets the BANKTORIHIKICDKANRIBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param BANKTORIHIKICDKANRIBUFLG__c
     */
    public void setBANKTORIHIKICDKANRIBUFLG__c(java.lang.String BANKTORIHIKICDKANRIBUFLG__c) {
        this.BANKTORIHIKICDKANRIBUFLG__c = BANKTORIHIKICDKANRIBUFLG__c;
    }


    /**
     * Gets the BATCHHENKOUKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return BATCHHENKOUKBN__c
     */
    public java.lang.String getBATCHHENKOUKBN__c() {
        return BATCHHENKOUKBN__c;
    }


    /**
     * Sets the BATCHHENKOUKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param BATCHHENKOUKBN__c
     */
    public void setBATCHHENKOUKBN__c(java.lang.String BATCHHENKOUKBN__c) {
        this.BATCHHENKOUKBN__c = BATCHHENKOUKBN__c;
    }


    /**
     * Gets the BLOKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return BLOKBN__c
     */
    public java.lang.String getBLOKBN__c() {
        return BLOKBN__c;
    }


    /**
     * Sets the BLOKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param BLOKBN__c
     */
    public void setBLOKBN__c(java.lang.String BLOKBN__c) {
        this.BLOKBN__c = BLOKBN__c;
    }


    /**
     * Gets the BOTENCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return BOTENCD__c
     */
    public java.lang.String getBOTENCD__c() {
        return BOTENCD__c;
    }


    /**
     * Sets the BOTENCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param BOTENCD__c
     */
    public void setBOTENCD__c(java.lang.String BOTENCD__c) {
        this.BOTENCD__c = BOTENCD__c;
    }


    /**
     * Gets the BUMONBETSUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUMONBETSUFLG__c
     */
    public java.lang.String getBUMONBETSUFLG__c() {
        return BUMONBETSUFLG__c;
    }


    /**
     * Sets the BUMONBETSUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUMONBETSUFLG__c
     */
    public void setBUMONBETSUFLG__c(java.lang.String BUMONBETSUFLG__c) {
        this.BUMONBETSUFLG__c = BUMONBETSUFLG__c;
    }


    /**
     * Gets the BUMONCD_HENKOU__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUMONCD_HENKOU__c
     */
    public java.lang.String getBUMONCD_HENKOU__c() {
        return BUMONCD_HENKOU__c;
    }


    /**
     * Sets the BUMONCD_HENKOU__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUMONCD_HENKOU__c
     */
    public void setBUMONCD_HENKOU__c(java.lang.String BUMONCD_HENKOU__c) {
        this.BUMONCD_HENKOU__c = BUMONCD_HENKOU__c;
    }


    /**
     * Gets the BUMONCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUMONCD__c
     */
    public java.lang.String getBUMONCD__c() {
        return BUMONCD__c;
    }


    /**
     * Sets the BUMONCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUMONCD__c
     */
    public void setBUMONCD__c(java.lang.String BUMONCD__c) {
        this.BUMONCD__c = BUMONCD__c;
    }


    /**
     * Gets the BUMONHONBUCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUMONHONBUCD__c
     */
    public java.lang.String getBUMONHONBUCD__c() {
        return BUMONHONBUCD__c;
    }


    /**
     * Sets the BUMONHONBUCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUMONHONBUCD__c
     */
    public void setBUMONHONBUCD__c(java.lang.String BUMONHONBUCD__c) {
        this.BUMONHONBUCD__c = BUMONHONBUCD__c;
    }


    /**
     * Gets the BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c
     */
    public java.lang.String getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c() {
        return BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;
    }


    /**
     * Sets the BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c
     */
    public void setBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c(java.lang.String BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c) {
        this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c = BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;
    }


    /**
     * Gets the BUTENBANGOU__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUTENBANGOU__c
     */
    public java.lang.String getBUTENBANGOU__c() {
        return BUTENBANGOU__c;
    }


    /**
     * Sets the BUTENBANGOU__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUTENBANGOU__c
     */
    public void setBUTENBANGOU__c(java.lang.String BUTENBANGOU__c) {
        this.BUTENBANGOU__c = BUTENBANGOU__c;
    }


    /**
     * Gets the BUTENCHOUYAKUSHOKUCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUTENCHOUYAKUSHOKUCD__c
     */
    public java.lang.String getBUTENCHOUYAKUSHOKUCD__c() {
        return BUTENCHOUYAKUSHOKUCD__c;
    }


    /**
     * Sets the BUTENCHOUYAKUSHOKUCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUTENCHOUYAKUSHOKUCD__c
     */
    public void setBUTENCHOUYAKUSHOKUCD__c(java.lang.String BUTENCHOUYAKUSHOKUCD__c) {
        this.BUTENCHOUYAKUSHOKUCD__c = BUTENCHOUYAKUSHOKUCD__c;
    }


    /**
     * Gets the BUTENNM1__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUTENNM1__c
     */
    public java.lang.String getBUTENNM1__c() {
        return BUTENNM1__c;
    }


    /**
     * Sets the BUTENNM1__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUTENNM1__c
     */
    public void setBUTENNM1__c(java.lang.String BUTENNM1__c) {
        this.BUTENNM1__c = BUTENNM1__c;
    }


    /**
     * Gets the BUTENNM2__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUTENNM2__c
     */
    public java.lang.String getBUTENNM2__c() {
        return BUTENNM2__c;
    }


    /**
     * Sets the BUTENNM2__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUTENNM2__c
     */
    public void setBUTENNM2__c(java.lang.String BUTENNM2__c) {
        this.BUTENNM2__c = BUTENNM2__c;
    }


    /**
     * Gets the BUTENNM3__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUTENNM3__c
     */
    public java.lang.String getBUTENNM3__c() {
        return BUTENNM3__c;
    }


    /**
     * Sets the BUTENNM3__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUTENNM3__c
     */
    public void setBUTENNM3__c(java.lang.String BUTENNM3__c) {
        this.BUTENNM3__c = BUTENNM3__c;
    }


    /**
     * Gets the BUTENNMKANA__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUTENNMKANA__c
     */
    public java.lang.String getBUTENNMKANA__c() {
        return BUTENNMKANA__c;
    }


    /**
     * Sets the BUTENNMKANA__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUTENNMKANA__c
     */
    public void setBUTENNMKANA__c(java.lang.String BUTENNMKANA__c) {
        this.BUTENNMKANA__c = BUTENNMKANA__c;
    }


    /**
     * Gets the BUTENNMRENKETSU__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUTENNMRENKETSU__c
     */
    public java.lang.String getBUTENNMRENKETSU__c() {
        return BUTENNMRENKETSU__c;
    }


    /**
     * Sets the BUTENNMRENKETSU__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUTENNMRENKETSU__c
     */
    public void setBUTENNMRENKETSU__c(java.lang.String BUTENNMRENKETSU__c) {
        this.BUTENNMRENKETSU__c = BUTENNMRENKETSU__c;
    }


    /**
     * Gets the BUTENNMRYAKU__c value for this C000_BUSHOINFO__c.
     * 
     * @return BUTENNMRYAKU__c
     */
    public java.lang.String getBUTENNMRYAKU__c() {
        return BUTENNMRYAKU__c;
    }


    /**
     * Sets the BUTENNMRYAKU__c value for this C000_BUSHOINFO__c.
     * 
     * @param BUTENNMRYAKU__c
     */
    public void setBUTENNMRYAKU__c(java.lang.String BUTENNMRYAKU__c) {
        this.BUTENNMRYAKU__c = BUTENNMRYAKU__c;
    }


    /**
     * Gets the c000_026_OBJECT_APPLICATION_INFO_03__r value for this C000_BUSHOINFO__c.
     * 
     * @return c000_026_OBJECT_APPLICATION_INFO_03__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_026_OBJECT_APPLICATION_INFO_03__r() {
        return c000_026_OBJECT_APPLICATION_INFO_03__r;
    }


    /**
     * Sets the c000_026_OBJECT_APPLICATION_INFO_03__r value for this C000_BUSHOINFO__c.
     * 
     * @param c000_026_OBJECT_APPLICATION_INFO_03__r
     */
    public void setC000_026_OBJECT_APPLICATION_INFO_03__r(com.sforce.soap.enterprise.QueryResult c000_026_OBJECT_APPLICATION_INFO_03__r) {
        this.c000_026_OBJECT_APPLICATION_INFO_03__r = c000_026_OBJECT_APPLICATION_INFO_03__r;
    }


    /**
     * Gets the c000_042_CIF_PROPERTY_CHANGE_INFO_02__r value for this C000_BUSHOINFO__c.
     * 
     * @return c000_042_CIF_PROPERTY_CHANGE_INFO_02__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_042_CIF_PROPERTY_CHANGE_INFO_02__r() {
        return c000_042_CIF_PROPERTY_CHANGE_INFO_02__r;
    }


    /**
     * Sets the c000_042_CIF_PROPERTY_CHANGE_INFO_02__r value for this C000_BUSHOINFO__c.
     * 
     * @param c000_042_CIF_PROPERTY_CHANGE_INFO_02__r
     */
    public void setC000_042_CIF_PROPERTY_CHANGE_INFO_02__r(com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_02__r) {
        this.c000_042_CIF_PROPERTY_CHANGE_INFO_02__r = c000_042_CIF_PROPERTY_CHANGE_INFO_02__r;
    }


    /**
     * Gets the c000_042_CIF_PROPERTY_CHANGE_INFO_04__r value for this C000_BUSHOINFO__c.
     * 
     * @return c000_042_CIF_PROPERTY_CHANGE_INFO_04__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_042_CIF_PROPERTY_CHANGE_INFO_04__r() {
        return c000_042_CIF_PROPERTY_CHANGE_INFO_04__r;
    }


    /**
     * Sets the c000_042_CIF_PROPERTY_CHANGE_INFO_04__r value for this C000_BUSHOINFO__c.
     * 
     * @param c000_042_CIF_PROPERTY_CHANGE_INFO_04__r
     */
    public void setC000_042_CIF_PROPERTY_CHANGE_INFO_04__r(com.sforce.soap.enterprise.QueryResult c000_042_CIF_PROPERTY_CHANGE_INFO_04__r) {
        this.c000_042_CIF_PROPERTY_CHANGE_INFO_04__r = c000_042_CIF_PROPERTY_CHANGE_INFO_04__r;
    }


    /**
     * Gets the c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r value for this C000_BUSHOINFO__c.
     * 
     * @return c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_BUSHOINFO_BushitsuTemMei_Kicho_01__r() {
        return c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r;
    }


    /**
     * Sets the c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r value for this C000_BUSHOINFO__c.
     * 
     * @param c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r
     */
    public void setC000_BUSHOINFO_BushitsuTemMei_Kicho_01__r(com.sforce.soap.enterprise.QueryResult c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r) {
        this.c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r = c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r;
    }


    /**
     * Gets the c000_BUSHOINFO_BushitsuTembanMei_O_01__r value for this C000_BUSHOINFO__c.
     * 
     * @return c000_BUSHOINFO_BushitsuTembanMei_O_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_BUSHOINFO_BushitsuTembanMei_O_01__r() {
        return c000_BUSHOINFO_BushitsuTembanMei_O_01__r;
    }


    /**
     * Sets the c000_BUSHOINFO_BushitsuTembanMei_O_01__r value for this C000_BUSHOINFO__c.
     * 
     * @param c000_BUSHOINFO_BushitsuTembanMei_O_01__r
     */
    public void setC000_BUSHOINFO_BushitsuTembanMei_O_01__r(com.sforce.soap.enterprise.QueryResult c000_BUSHOINFO_BushitsuTembanMei_O_01__r) {
        this.c000_BUSHOINFO_BushitsuTembanMei_O_01__r = c000_BUSHOINFO_BushitsuTembanMei_O_01__r;
    }


    /**
     * Gets the c000_BUSHOINFO_BushitsuTemban_S_01__r value for this C000_BUSHOINFO__c.
     * 
     * @return c000_BUSHOINFO_BushitsuTemban_S_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_BUSHOINFO_BushitsuTemban_S_01__r() {
        return c000_BUSHOINFO_BushitsuTemban_S_01__r;
    }


    /**
     * Sets the c000_BUSHOINFO_BushitsuTemban_S_01__r value for this C000_BUSHOINFO__c.
     * 
     * @param c000_BUSHOINFO_BushitsuTemban_S_01__r
     */
    public void setC000_BUSHOINFO_BushitsuTemban_S_01__r(com.sforce.soap.enterprise.QueryResult c000_BUSHOINFO_BushitsuTemban_S_01__r) {
        this.c000_BUSHOINFO_BushitsuTemban_S_01__r = c000_BUSHOINFO_BushitsuTemban_S_01__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_02__r value for this C000_BUSHOINFO__c.
     * 
     * @return c000_CIFZOKUSEIINFO_02__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_02__r() {
        return c000_CIFZOKUSEIINFO_02__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_02__r value for this C000_BUSHOINFO__c.
     * 
     * @param c000_CIFZOKUSEIINFO_02__r
     */
    public void setC000_CIFZOKUSEIINFO_02__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_02__r) {
        this.c000_CIFZOKUSEIINFO_02__r = c000_CIFZOKUSEIINFO_02__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_04__r value for this C000_BUSHOINFO__c.
     * 
     * @return c000_CIFZOKUSEIINFO_04__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_04__r() {
        return c000_CIFZOKUSEIINFO_04__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_04__r value for this C000_BUSHOINFO__c.
     * 
     * @param c000_CIFZOKUSEIINFO_04__r
     */
    public void setC000_CIFZOKUSEIINFO_04__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_04__r) {
        this.c000_CIFZOKUSEIINFO_04__r = c000_CIFZOKUSEIINFO_04__r;
    }


    /**
     * Gets the c001_Offices_01__r value for this C000_BUSHOINFO__c.
     * 
     * @return c001_Offices_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC001_Offices_01__r() {
        return c001_Offices_01__r;
    }


    /**
     * Sets the c001_Offices_01__r value for this C000_BUSHOINFO__c.
     * 
     * @param c001_Offices_01__r
     */
    public void setC001_Offices_01__r(com.sforce.soap.enterprise.QueryResult c001_Offices_01__r) {
        this.c001_Offices_01__r = c001_Offices_01__r;
    }


    /**
     * Gets the c001_TantouKyotenNameMitoris_01__r value for this C000_BUSHOINFO__c.
     * 
     * @return c001_TantouKyotenNameMitoris_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC001_TantouKyotenNameMitoris_01__r() {
        return c001_TantouKyotenNameMitoris_01__r;
    }


    /**
     * Sets the c001_TantouKyotenNameMitoris_01__r value for this C000_BUSHOINFO__c.
     * 
     * @param c001_TantouKyotenNameMitoris_01__r
     */
    public void setC001_TantouKyotenNameMitoris_01__r(com.sforce.soap.enterprise.QueryResult c001_TantouKyotenNameMitoris_01__r) {
        this.c001_TantouKyotenNameMitoris_01__r = c001_TantouKyotenNameMitoris_01__r;
    }


    /**
     * Gets the c003_BUSHOINFOs_01__r value for this C000_BUSHOINFO__c.
     * 
     * @return c003_BUSHOINFOs_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC003_BUSHOINFOs_01__r() {
        return c003_BUSHOINFOs_01__r;
    }


    /**
     * Sets the c003_BUSHOINFOs_01__r value for this C000_BUSHOINFO__c.
     * 
     * @param c003_BUSHOINFOs_01__r
     */
    public void setC003_BUSHOINFOs_01__r(com.sforce.soap.enterprise.QueryResult c003_BUSHOINFOs_01__r) {
        this.c003_BUSHOINFOs_01__r = c003_BUSHOINFOs_01__r;
    }


    /**
     * Gets the c003_BUSHOINFOs_03__r value for this C000_BUSHOINFO__c.
     * 
     * @return c003_BUSHOINFOs_03__r
     */
    public com.sforce.soap.enterprise.QueryResult getC003_BUSHOINFOs_03__r() {
        return c003_BUSHOINFOs_03__r;
    }


    /**
     * Sets the c003_BUSHOINFOs_03__r value for this C000_BUSHOINFO__c.
     * 
     * @param c003_BUSHOINFOs_03__r
     */
    public void setC003_BUSHOINFOs_03__r(com.sforce.soap.enterprise.QueryResult c003_BUSHOINFOs_03__r) {
        this.c003_BUSHOINFOs_03__r = c003_BUSHOINFOs_03__r;
    }


    /**
     * Gets the CHIKUCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return CHIKUCD__c
     */
    public java.lang.String getCHIKUCD__c() {
        return CHIKUCD__c;
    }


    /**
     * Sets the CHIKUCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param CHIKUCD__c
     */
    public void setCHIKUCD__c(java.lang.String CHIKUCD__c) {
        this.CHIKUCD__c = CHIKUCD__c;
    }


    /**
     * Gets the CHINESE_WALLKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return CHINESE_WALLKBN__c
     */
    public java.lang.String getCHINESE_WALLKBN__c() {
        return CHINESE_WALLKBN__c;
    }


    /**
     * Sets the CHINESE_WALLKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param CHINESE_WALLKBN__c
     */
    public void setCHINESE_WALLKBN__c(java.lang.String CHINESE_WALLKBN__c) {
        this.CHINESE_WALLKBN__c = CHINESE_WALLKBN__c;
    }


    /**
     * Gets the chokusetsuBranchName__r value for this C000_BUSHOINFO__c.
     * 
     * @return chokusetsuBranchName__r
     */
    public com.sforce.soap.enterprise.QueryResult getChokusetsuBranchName__r() {
        return chokusetsuBranchName__r;
    }


    /**
     * Sets the chokusetsuBranchName__r value for this C000_BUSHOINFO__c.
     * 
     * @param chokusetsuBranchName__r
     */
    public void setChokusetsuBranchName__r(com.sforce.soap.enterprise.QueryResult chokusetsuBranchName__r) {
        this.chokusetsuBranchName__r = chokusetsuBranchName__r;
    }


    /**
     * Gets the combinedAttachments value for this C000_BUSHOINFO__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C000_BUSHOINFO__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C000_BUSHOINFO__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C000_BUSHOINFO__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C000_BUSHOINFO__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C000_BUSHOINFO__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C000_BUSHOINFO__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C000_BUSHOINFO__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the DELFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return DELFLG__c
     */
    public java.lang.Boolean getDELFLG__c() {
        return DELFLG__c;
    }


    /**
     * Sets the DELFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param DELFLG__c
     */
    public void setDELFLG__c(java.lang.Boolean DELFLG__c) {
        this.DELFLG__c = DELFLG__c;
    }


    /**
     * Gets the DOUBLECNTKYOYOUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return DOUBLECNTKYOYOUFLG__c
     */
    public java.lang.String getDOUBLECNTKYOYOUFLG__c() {
        return DOUBLECNTKYOYOUFLG__c;
    }


    /**
     * Sets the DOUBLECNTKYOYOUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param DOUBLECNTKYOYOUFLG__c
     */
    public void setDOUBLECNTKYOYOUFLG__c(java.lang.String DOUBLECNTKYOYOUFLG__c) {
        this.DOUBLECNTKYOYOUFLG__c = DOUBLECNTKYOYOUFLG__c;
    }


    /**
     * Gets the dairiBranchName1__r value for this C000_BUSHOINFO__c.
     * 
     * @return dairiBranchName1__r
     */
    public com.sforce.soap.enterprise.QueryResult getDairiBranchName1__r() {
        return dairiBranchName1__r;
    }


    /**
     * Sets the dairiBranchName1__r value for this C000_BUSHOINFO__c.
     * 
     * @param dairiBranchName1__r
     */
    public void setDairiBranchName1__r(com.sforce.soap.enterprise.QueryResult dairiBranchName1__r) {
        this.dairiBranchName1__r = dairiBranchName1__r;
    }


    /**
     * Gets the dairiBranchName2__r value for this C000_BUSHOINFO__c.
     * 
     * @return dairiBranchName2__r
     */
    public com.sforce.soap.enterprise.QueryResult getDairiBranchName2__r() {
        return dairiBranchName2__r;
    }


    /**
     * Sets the dairiBranchName2__r value for this C000_BUSHOINFO__c.
     * 
     * @param dairiBranchName2__r
     */
    public void setDairiBranchName2__r(com.sforce.soap.enterprise.QueryResult dairiBranchName2__r) {
        this.dairiBranchName2__r = dairiBranchName2__r;
    }


    /**
     * Gets the dairiBranchName3__r value for this C000_BUSHOINFO__c.
     * 
     * @return dairiBranchName3__r
     */
    public com.sforce.soap.enterprise.QueryResult getDairiBranchName3__r() {
        return dairiBranchName3__r;
    }


    /**
     * Sets the dairiBranchName3__r value for this C000_BUSHOINFO__c.
     * 
     * @param dairiBranchName3__r
     */
    public void setDairiBranchName3__r(com.sforce.soap.enterprise.QueryResult dairiBranchName3__r) {
        this.dairiBranchName3__r = dairiBranchName3__r;
    }


    /**
     * Gets the dairiBranchName4__r value for this C000_BUSHOINFO__c.
     * 
     * @return dairiBranchName4__r
     */
    public com.sforce.soap.enterprise.QueryResult getDairiBranchName4__r() {
        return dairiBranchName4__r;
    }


    /**
     * Sets the dairiBranchName4__r value for this C000_BUSHOINFO__c.
     * 
     * @param dairiBranchName4__r
     */
    public void setDairiBranchName4__r(com.sforce.soap.enterprise.QueryResult dairiBranchName4__r) {
        this.dairiBranchName4__r = dairiBranchName4__r;
    }


    /**
     * Gets the dairiBranchName5__r value for this C000_BUSHOINFO__c.
     * 
     * @return dairiBranchName5__r
     */
    public com.sforce.soap.enterprise.QueryResult getDairiBranchName5__r() {
        return dairiBranchName5__r;
    }


    /**
     * Sets the dairiBranchName5__r value for this C000_BUSHOINFO__c.
     * 
     * @param dairiBranchName5__r
     */
    public void setDairiBranchName5__r(com.sforce.soap.enterprise.QueryResult dairiBranchName5__r) {
        this.dairiBranchName5__r = dairiBranchName5__r;
    }


    /**
     * Gets the duplicateRecordItems value for this C000_BUSHOINFO__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C000_BUSHOINFO__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the EIGYOKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return EIGYOKBN__c
     */
    public java.lang.String getEIGYOKBN__c() {
        return EIGYOKBN__c;
    }


    /**
     * Sets the EIGYOKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param EIGYOKBN__c
     */
    public void setEIGYOKBN__c(java.lang.String EIGYOKBN__c) {
        this.EIGYOKBN__c = EIGYOKBN__c;
    }


    /**
     * Gets the EIGYOKEITAIKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return EIGYOKEITAIKBN__c
     */
    public java.lang.String getEIGYOKEITAIKBN__c() {
        return EIGYOKEITAIKBN__c;
    }


    /**
     * Sets the EIGYOKEITAIKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param EIGYOKEITAIKBN__c
     */
    public void setEIGYOKEITAIKBN__c(java.lang.String EIGYOKEITAIKBN__c) {
        this.EIGYOKEITAIKBN__c = EIGYOKEITAIKBN__c;
    }


    /**
     * Gets the events value for this C000_BUSHOINFO__c.
     * 
     * @return events
     */
    public com.sforce.soap.enterprise.QueryResult getEvents() {
        return events;
    }


    /**
     * Sets the events value for this C000_BUSHOINFO__c.
     * 
     * @param events
     */
    public void setEvents(com.sforce.soap.enterprise.QueryResult events) {
        this.events = events;
    }


    /**
     * Gets the HAITENBI__c value for this C000_BUSHOINFO__c.
     * 
     * @return HAITENBI__c
     */
    public java.util.Date getHAITENBI__c() {
        return HAITENBI__c;
    }


    /**
     * Sets the HAITENBI__c value for this C000_BUSHOINFO__c.
     * 
     * @param HAITENBI__c
     */
    public void setHAITENBI__c(java.util.Date HAITENBI__c) {
        this.HAITENBI__c = HAITENBI__c;
    }


    /**
     * Gets the HONBU_EIGYOKYOTENFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return HONBU_EIGYOKYOTENFLG__c
     */
    public java.lang.String getHONBU_EIGYOKYOTENFLG__c() {
        return HONBU_EIGYOKYOTENFLG__c;
    }


    /**
     * Sets the HONBU_EIGYOKYOTENFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param HONBU_EIGYOKYOTENFLG__c
     */
    public void setHONBU_EIGYOKYOTENFLG__c(java.lang.String HONBU_EIGYOKYOTENFLG__c) {
        this.HONBU_EIGYOKYOTENFLG__c = HONBU_EIGYOKYOTENFLG__c;
    }


    /**
     * Gets the histories value for this C000_BUSHOINFO__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this C000_BUSHOINFO__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this C000_BUSHOINFO__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C000_BUSHOINFO__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the JIMUSOSHIKIKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return JIMUSOSHIKIKBN__c
     */
    public java.lang.String getJIMUSOSHIKIKBN__c() {
        return JIMUSOSHIKIKBN__c;
    }


    /**
     * Sets the JIMUSOSHIKIKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param JIMUSOSHIKIKBN__c
     */
    public void setJIMUSOSHIKIKBN__c(java.lang.String JIMUSOSHIKIKBN__c) {
        this.JIMUSOSHIKIKBN__c = JIMUSOSHIKIKBN__c;
    }


    /**
     * Gets the JOUIAREAINFOCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return JOUIAREAINFOCD__c
     */
    public java.lang.String getJOUIAREAINFOCD__c() {
        return JOUIAREAINFOCD__c;
    }


    /**
     * Sets the JOUIAREAINFOCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param JOUIAREAINFOCD__c
     */
    public void setJOUIAREAINFOCD__c(java.lang.String JOUIAREAINFOCD__c) {
        this.JOUIAREAINFOCD__c = JOUIAREAINFOCD__c;
    }


    /**
     * Gets the JOUIBUTENBANGOU_HENKOU__c value for this C000_BUSHOINFO__c.
     * 
     * @return JOUIBUTENBANGOU_HENKOU__c
     */
    public java.lang.String getJOUIBUTENBANGOU_HENKOU__c() {
        return JOUIBUTENBANGOU_HENKOU__c;
    }


    /**
     * Sets the JOUIBUTENBANGOU_HENKOU__c value for this C000_BUSHOINFO__c.
     * 
     * @param JOUIBUTENBANGOU_HENKOU__c
     */
    public void setJOUIBUTENBANGOU_HENKOU__c(java.lang.String JOUIBUTENBANGOU_HENKOU__c) {
        this.JOUIBUTENBANGOU_HENKOU__c = JOUIBUTENBANGOU_HENKOU__c;
    }


    /**
     * Gets the JOUIBUTENBANGOU__c value for this C000_BUSHOINFO__c.
     * 
     * @return JOUIBUTENBANGOU__c
     */
    public java.lang.String getJOUIBUTENBANGOU__c() {
        return JOUIBUTENBANGOU__c;
    }


    /**
     * Sets the JOUIBUTENBANGOU__c value for this C000_BUSHOINFO__c.
     * 
     * @param JOUIBUTENBANGOU__c
     */
    public void setJOUIBUTENBANGOU__c(java.lang.String JOUIBUTENBANGOU__c) {
        this.JOUIBUTENBANGOU__c = JOUIBUTENBANGOU__c;
    }


    /**
     * Gets the JOUIKACD__c value for this C000_BUSHOINFO__c.
     * 
     * @return JOUIKACD__c
     */
    public java.lang.String getJOUIKACD__c() {
        return JOUIKACD__c;
    }


    /**
     * Sets the JOUIKACD__c value for this C000_BUSHOINFO__c.
     * 
     * @param JOUIKACD__c
     */
    public void setJOUIKACD__c(java.lang.String JOUIKACD__c) {
        this.JOUIKACD__c = JOUIKACD__c;
    }


    /**
     * Gets the JOUKENKENSAKUYOUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return JOUKENKENSAKUYOUFLG__c
     */
    public java.lang.String getJOUKENKENSAKUYOUFLG__c() {
        return JOUKENKENSAKUYOUFLG__c;
    }


    /**
     * Sets the JOUKENKENSAKUYOUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param JOUKENKENSAKUYOUFLG__c
     */
    public void setJOUKENKENSAKUYOUFLG__c(java.lang.String JOUKENKENSAKUYOUFLG__c) {
        this.JOUKENKENSAKUYOUFLG__c = JOUKENKENSAKUYOUFLG__c;
    }


    /**
     * Gets the KACD__c value for this C000_BUSHOINFO__c.
     * 
     * @return KACD__c
     */
    public java.lang.String getKACD__c() {
        return KACD__c;
    }


    /**
     * Sets the KACD__c value for this C000_BUSHOINFO__c.
     * 
     * @param KACD__c
     */
    public void setKACD__c(java.lang.String KACD__c) {
        this.KACD__c = KACD__c;
    }


    /**
     * Gets the KAIGAIFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return KAIGAIFLG__c
     */
    public java.lang.String getKAIGAIFLG__c() {
        return KAIGAIFLG__c;
    }


    /**
     * Sets the KAIGAIFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param KAIGAIFLG__c
     */
    public void setKAIGAIFLG__c(java.lang.String KAIGAIFLG__c) {
        this.KAIGAIFLG__c = KAIGAIFLG__c;
    }


    /**
     * Gets the KAITENBI__c value for this C000_BUSHOINFO__c.
     * 
     * @return KAITENBI__c
     */
    public java.util.Date getKAITENBI__c() {
        return KAITENBI__c;
    }


    /**
     * Sets the KAITENBI__c value for this C000_BUSHOINFO__c.
     * 
     * @param KAITENBI__c
     */
    public void setKAITENBI__c(java.util.Date KAITENBI__c) {
        this.KAITENBI__c = KAITENBI__c;
    }


    /**
     * Gets the KANJOTENKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return KANJOTENKBN__c
     */
    public java.lang.String getKANJOTENKBN__c() {
        return KANJOTENKBN__c;
    }


    /**
     * Sets the KANJOTENKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param KANJOTENKBN__c
     */
    public void setKANJOTENKBN__c(java.lang.String KANJOTENKBN__c) {
        this.KANJOTENKBN__c = KANJOTENKBN__c;
    }


    /**
     * Gets the KA_GRNMKANA__c value for this C000_BUSHOINFO__c.
     * 
     * @return KA_GRNMKANA__c
     */
    public java.lang.String getKA_GRNMKANA__c() {
        return KA_GRNMKANA__c;
    }


    /**
     * Sets the KA_GRNMKANA__c value for this C000_BUSHOINFO__c.
     * 
     * @param KA_GRNMKANA__c
     */
    public void setKA_GRNMKANA__c(java.lang.String KA_GRNMKANA__c) {
        this.KA_GRNMKANA__c = KA_GRNMKANA__c;
    }


    /**
     * Gets the KA_GRNMRYAKU__c value for this C000_BUSHOINFO__c.
     * 
     * @return KA_GRNMRYAKU__c
     */
    public java.lang.String getKA_GRNMRYAKU__c() {
        return KA_GRNMRYAKU__c;
    }


    /**
     * Sets the KA_GRNMRYAKU__c value for this C000_BUSHOINFO__c.
     * 
     * @param KA_GRNMRYAKU__c
     */
    public void setKA_GRNMRYAKU__c(java.lang.String KA_GRNMRYAKU__c) {
        this.KA_GRNMRYAKU__c = KA_GRNMRYAKU__c;
    }


    /**
     * Gets the KA_GRNM__c value for this C000_BUSHOINFO__c.
     * 
     * @return KA_GRNM__c
     */
    public java.lang.String getKA_GRNM__c() {
        return KA_GRNM__c;
    }


    /**
     * Sets the KA_GRNM__c value for this C000_BUSHOINFO__c.
     * 
     * @param KA_GRNM__c
     */
    public void setKA_GRNM__c(java.lang.String KA_GRNM__c) {
        this.KA_GRNM__c = KA_GRNM__c;
    }


    /**
     * Gets the KOKYAKUKANRIHONBUKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return KOKYAKUKANRIHONBUKBN__c
     */
    public java.lang.String getKOKYAKUKANRIHONBUKBN__c() {
        return KOKYAKUKANRIHONBUKBN__c;
    }


    /**
     * Sets the KOKYAKUKANRIHONBUKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param KOKYAKUKANRIHONBUKBN__c
     */
    public void setKOKYAKUKANRIHONBUKBN__c(java.lang.String KOKYAKUKANRIHONBUKBN__c) {
        this.KOKYAKUKANRIHONBUKBN__c = KOKYAKUKANRIHONBUKBN__c;
    }


    /**
     * Gets the KYOTENFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return KYOTENFLG__c
     */
    public java.lang.String getKYOTENFLG__c() {
        return KYOTENFLG__c;
    }


    /**
     * Sets the KYOTENFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param KYOTENFLG__c
     */
    public void setKYOTENFLG__c(java.lang.String KYOTENFLG__c) {
        this.KYOTENFLG__c = KYOTENFLG__c;
    }


    /**
     * Gets the lastActivityDate value for this C000_BUSHOINFO__c.
     * 
     * @return lastActivityDate
     */
    public java.util.Date getLastActivityDate() {
        return lastActivityDate;
    }


    /**
     * Sets the lastActivityDate value for this C000_BUSHOINFO__c.
     * 
     * @param lastActivityDate
     */
    public void setLastActivityDate(java.util.Date lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }


    /**
     * Gets the lastModifiedBy value for this C000_BUSHOINFO__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C000_BUSHOINFO__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C000_BUSHOINFO__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C000_BUSHOINFO__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C000_BUSHOINFO__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C000_BUSHOINFO__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C000_BUSHOINFO__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C000_BUSHOINFO__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this C000_BUSHOINFO__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C000_BUSHOINFO__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C000_BUSHOINFO__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C000_BUSHOINFO__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C000_BUSHOINFO__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C000_BUSHOINFO__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the openActivities value for this C000_BUSHOINFO__c.
     * 
     * @return openActivities
     */
    public com.sforce.soap.enterprise.QueryResult getOpenActivities() {
        return openActivities;
    }


    /**
     * Sets the openActivities value for this C000_BUSHOINFO__c.
     * 
     * @param openActivities
     */
    public void setOpenActivities(com.sforce.soap.enterprise.QueryResult openActivities) {
        this.openActivities = openActivities;
    }


    /**
     * Gets the owner value for this C000_BUSHOINFO__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this C000_BUSHOINFO__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this C000_BUSHOINFO__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this C000_BUSHOINFO__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this C000_BUSHOINFO__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C000_BUSHOINFO__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C000_BUSHOINFO__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C000_BUSHOINFO__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the RENKETSUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return RENKETSUFLG__c
     */
    public java.lang.String getRENKETSUFLG__c() {
        return RENKETSUFLG__c;
    }


    /**
     * Sets the RENKETSUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param RENKETSUFLG__c
     */
    public void setRENKETSUFLG__c(java.lang.String RENKETSUFLG__c) {
        this.RENKETSUFLG__c = RENKETSUFLG__c;
    }


    /**
     * Gets the RMFKYOYOUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return RMFKYOYOUFLG__c
     */
    public java.lang.String getRMFKYOYOUFLG__c() {
        return RMFKYOYOUFLG__c;
    }


    /**
     * Sets the RMFKYOYOUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param RMFKYOYOUFLG__c
     */
    public void setRMFKYOYOUFLG__c(java.lang.String RMFKYOYOUFLG__c) {
        this.RMFKYOYOUFLG__c = RMFKYOYOUFLG__c;
    }


    /**
     * Gets the requestBranchName__r value for this C000_BUSHOINFO__c.
     * 
     * @return requestBranchName__r
     */
    public com.sforce.soap.enterprise.QueryResult getRequestBranchName__r() {
        return requestBranchName__r;
    }


    /**
     * Sets the requestBranchName__r value for this C000_BUSHOINFO__c.
     * 
     * @param requestBranchName__r
     */
    public void setRequestBranchName__r(com.sforce.soap.enterprise.QueryResult requestBranchName__r) {
        this.requestBranchName__r = requestBranchName__r;
    }


    /**
     * Gets the SAISHUUTEAMCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return SAISHUUTEAMCD__c
     */
    public java.lang.String getSAISHUUTEAMCD__c() {
        return SAISHUUTEAMCD__c;
    }


    /**
     * Sets the SAISHUUTEAMCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param SAISHUUTEAMCD__c
     */
    public void setSAISHUUTEAMCD__c(java.lang.String SAISHUUTEAMCD__c) {
        this.SAISHUUTEAMCD__c = SAISHUUTEAMCD__c;
    }


    /**
     * Gets the SHIJOUNAYOSEKANRIBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return SHIJOUNAYOSEKANRIBUFLG__c
     */
    public java.lang.String getSHIJOUNAYOSEKANRIBUFLG__c() {
        return SHIJOUNAYOSEKANRIBUFLG__c;
    }


    /**
     * Sets the SHIJOUNAYOSEKANRIBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param SHIJOUNAYOSEKANRIBUFLG__c
     */
    public void setSHIJOUNAYOSEKANRIBUFLG__c(java.lang.String SHIJOUNAYOSEKANRIBUFLG__c) {
        this.SHIJOUNAYOSEKANRIBUFLG__c = SHIJOUNAYOSEKANRIBUFLG__c;
    }


    /**
     * Gets the SHOUNINJOUKYOUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return SHOUNINJOUKYOUFLG__c
     */
    public java.lang.String getSHOUNINJOUKYOUFLG__c() {
        return SHOUNINJOUKYOUFLG__c;
    }


    /**
     * Sets the SHOUNINJOUKYOUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param SHOUNINJOUKYOUFLG__c
     */
    public void setSHOUNINJOUKYOUFLG__c(java.lang.String SHOUNINJOUKYOUFLG__c) {
        this.SHOUNINJOUKYOUFLG__c = SHOUNINJOUKYOUFLG__c;
    }


    /**
     * Gets the SOSHIKICATEGORYKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return SOSHIKICATEGORYKBN__c
     */
    public java.lang.String getSOSHIKICATEGORYKBN__c() {
        return SOSHIKICATEGORYKBN__c;
    }


    /**
     * Sets the SOSHIKICATEGORYKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param SOSHIKICATEGORYKBN__c
     */
    public void setSOSHIKICATEGORYKBN__c(java.lang.String SOSHIKICATEGORYKBN__c) {
        this.SOSHIKICATEGORYKBN__c = SOSHIKICATEGORYKBN__c;
    }


    /**
     * Gets the SOSHIKIJUNCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return SOSHIKIJUNCD__c
     */
    public java.lang.String getSOSHIKIJUNCD__c() {
        return SOSHIKIJUNCD__c;
    }


    /**
     * Sets the SOSHIKIJUNCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param SOSHIKIJUNCD__c
     */
    public void setSOSHIKIJUNCD__c(java.lang.String SOSHIKIJUNCD__c) {
        this.SOSHIKIJUNCD__c = SOSHIKIJUNCD__c;
    }


    /**
     * Gets the SOSHIKIKEITAI__c value for this C000_BUSHOINFO__c.
     * 
     * @return SOSHIKIKEITAI__c
     */
    public java.lang.String getSOSHIKIKEITAI__c() {
        return SOSHIKIKEITAI__c;
    }


    /**
     * Sets the SOSHIKIKEITAI__c value for this C000_BUSHOINFO__c.
     * 
     * @param SOSHIKIKEITAI__c
     */
    public void setSOSHIKIKEITAI__c(java.lang.String SOSHIKIKEITAI__c) {
        this.SOSHIKIKEITAI__c = SOSHIKIKEITAI__c;
    }


    /**
     * Gets the SOUGOURISKKANRIBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return SOUGOURISKKANRIBUFLG__c
     */
    public java.lang.String getSOUGOURISKKANRIBUFLG__c() {
        return SOUGOURISKKANRIBUFLG__c;
    }


    /**
     * Sets the SOUGOURISKKANRIBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param SOUGOURISKKANRIBUFLG__c
     */
    public void setSOUGOURISKKANRIBUFLG__c(java.lang.String SOUGOURISKKANRIBUFLG__c) {
        this.SOUGOURISKKANRIBUFLG__c = SOUGOURISKKANRIBUFLG__c;
    }


    /**
     * Gets the shares value for this C000_BUSHOINFO__c.
     * 
     * @return shares
     */
    public com.sforce.soap.enterprise.QueryResult getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this C000_BUSHOINFO__c.
     * 
     * @param shares
     */
    public void setShares(com.sforce.soap.enterprise.QueryResult shares) {
        this.shares = shares;
    }


    /**
     * Gets the systemModstamp value for this C000_BUSHOINFO__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C000_BUSHOINFO__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the TATEMONOKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return TATEMONOKBN__c
     */
    public java.lang.String getTATEMONOKBN__c() {
        return TATEMONOKBN__c;
    }


    /**
     * Sets the TATEMONOKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param TATEMONOKBN__c
     */
    public void setTATEMONOKBN__c(java.lang.String TATEMONOKBN__c) {
        this.TATEMONOKBN__c = TATEMONOKBN__c;
    }


    /**
     * Gets the TEAMCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return TEAMCD__c
     */
    public java.lang.String getTEAMCD__c() {
        return TEAMCD__c;
    }


    /**
     * Sets the TEAMCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param TEAMCD__c
     */
    public void setTEAMCD__c(java.lang.String TEAMCD__c) {
        this.TEAMCD__c = TEAMCD__c;
    }


    /**
     * Gets the TEAMNM__c value for this C000_BUSHOINFO__c.
     * 
     * @return TEAMNM__c
     */
    public java.lang.String getTEAMNM__c() {
        return TEAMNM__c;
    }


    /**
     * Sets the TEAMNM__c value for this C000_BUSHOINFO__c.
     * 
     * @param TEAMNM__c
     */
    public void setTEAMNM__c(java.lang.String TEAMNM__c) {
        this.TEAMNM__c = TEAMNM__c;
    }


    /**
     * Gets the TENSHITSU__c value for this C000_BUSHOINFO__c.
     * 
     * @return TENSHITSU__c
     */
    public java.lang.String getTENSHITSU__c() {
        return TENSHITSU__c;
    }


    /**
     * Sets the TENSHITSU__c value for this C000_BUSHOINFO__c.
     * 
     * @param TENSHITSU__c
     */
    public void setTENSHITSU__c(java.lang.String TENSHITSU__c) {
        this.TENSHITSU__c = TENSHITSU__c;
    }


    /**
     * Gets the TOKUTEISOSHIKIKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @return TOKUTEISOSHIKIKBN__c
     */
    public java.lang.String getTOKUTEISOSHIKIKBN__c() {
        return TOKUTEISOSHIKIKBN__c;
    }


    /**
     * Sets the TOKUTEISOSHIKIKBN__c value for this C000_BUSHOINFO__c.
     * 
     * @param TOKUTEISOSHIKIKBN__c
     */
    public void setTOKUTEISOSHIKIKBN__c(java.lang.String TOKUTEISOSHIKIKBN__c) {
        this.TOKUTEISOSHIKIKBN__c = TOKUTEISOSHIKIKBN__c;
    }


    /**
     * Gets the TOUMEIHANCD__c value for this C000_BUSHOINFO__c.
     * 
     * @return TOUMEIHANCD__c
     */
    public java.lang.String getTOUMEIHANCD__c() {
        return TOUMEIHANCD__c;
    }


    /**
     * Sets the TOUMEIHANCD__c value for this C000_BUSHOINFO__c.
     * 
     * @param TOUMEIHANCD__c
     */
    public void setTOUMEIHANCD__c(java.lang.String TOUMEIHANCD__c) {
        this.TOUMEIHANCD__c = TOUMEIHANCD__c;
    }


    /**
     * Gets the tasks value for this C000_BUSHOINFO__c.
     * 
     * @return tasks
     */
    public com.sforce.soap.enterprise.QueryResult getTasks() {
        return tasks;
    }


    /**
     * Sets the tasks value for this C000_BUSHOINFO__c.
     * 
     * @param tasks
     */
    public void setTasks(com.sforce.soap.enterprise.QueryResult tasks) {
        this.tasks = tasks;
    }


    /**
     * Gets the tesuryoBranchName__r value for this C000_BUSHOINFO__c.
     * 
     * @return tesuryoBranchName__r
     */
    public com.sforce.soap.enterprise.QueryResult getTesuryoBranchName__r() {
        return tesuryoBranchName__r;
    }


    /**
     * Sets the tesuryoBranchName__r value for this C000_BUSHOINFO__c.
     * 
     * @param tesuryoBranchName__r
     */
    public void setTesuryoBranchName__r(com.sforce.soap.enterprise.QueryResult tesuryoBranchName__r) {
        this.tesuryoBranchName__r = tesuryoBranchName__r;
    }


    /**
     * Gets the topicAssignments value for this C000_BUSHOINFO__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C000_BUSHOINFO__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this C000_BUSHOINFO__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C000_BUSHOINFO__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the YOSHINSHOKANBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return YOSHINSHOKANBUFLG__c
     */
    public java.lang.String getYOSHINSHOKANBUFLG__c() {
        return YOSHINSHOKANBUFLG__c;
    }


    /**
     * Sets the YOSHINSHOKANBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param YOSHINSHOKANBUFLG__c
     */
    public void setYOSHINSHOKANBUFLG__c(java.lang.String YOSHINSHOKANBUFLG__c) {
        this.YOSHINSHOKANBUFLG__c = YOSHINSHOKANBUFLG__c;
    }


    /**
     * Gets the YUUKOUKIKANKAISHIBI__c value for this C000_BUSHOINFO__c.
     * 
     * @return YUUKOUKIKANKAISHIBI__c
     */
    public java.util.Date getYUUKOUKIKANKAISHIBI__c() {
        return YUUKOUKIKANKAISHIBI__c;
    }


    /**
     * Sets the YUUKOUKIKANKAISHIBI__c value for this C000_BUSHOINFO__c.
     * 
     * @param YUUKOUKIKANKAISHIBI__c
     */
    public void setYUUKOUKIKANKAISHIBI__c(java.util.Date YUUKOUKIKANKAISHIBI__c) {
        this.YUUKOUKIKANKAISHIBI__c = YUUKOUKIKANKAISHIBI__c;
    }


    /**
     * Gets the ZENSENKAHONBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @return ZENSENKAHONBUFLG__c
     */
    public java.lang.String getZENSENKAHONBUFLG__c() {
        return ZENSENKAHONBUFLG__c;
    }


    /**
     * Sets the ZENSENKAHONBUFLG__c value for this C000_BUSHOINFO__c.
     * 
     * @param ZENSENKAHONBUFLG__c
     */
    public void setZENSENKAHONBUFLG__c(java.lang.String ZENSENKAHONBUFLG__c) {
        this.ZENSENKAHONBUFLG__c = ZENSENKAHONBUFLG__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C000_BUSHOINFO__c)) return false;
        C000_BUSHOINFO__c other = (C000_BUSHOINFO__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.ADTEN__c==null && other.getADTEN__c()==null) || 
             (this.ADTEN__c!=null &&
              this.ADTEN__c.equals(other.getADTEN__c()))) &&
            ((this.AREAINFOCD__c==null && other.getAREAINFOCD__c()==null) || 
             (this.AREAINFOCD__c!=null &&
              this.AREAINFOCD__c.equals(other.getAREAINFOCD__c()))) &&
            ((this.AREANM__c==null && other.getAREANM__c()==null) || 
             (this.AREANM__c!=null &&
              this.AREANM__c.equals(other.getAREANM__c()))) &&
            ((this.AREARYAKU__c==null && other.getAREARYAKU__c()==null) || 
             (this.AREARYAKU__c!=null &&
              this.AREARYAKU__c.equals(other.getAREARYAKU__c()))) &&
            ((this.acceptOffice__r==null && other.getAcceptOffice__r()==null) || 
             (this.acceptOffice__r!=null &&
              this.acceptOffice__r.equals(other.getAcceptOffice__r()))) &&
            ((this.activityHistories==null && other.getActivityHistories()==null) || 
             (this.activityHistories!=null &&
              this.activityHistories.equals(other.getActivityHistories()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.BANKTORIHIKICDKANRIBUFLG__c==null && other.getBANKTORIHIKICDKANRIBUFLG__c()==null) || 
             (this.BANKTORIHIKICDKANRIBUFLG__c!=null &&
              this.BANKTORIHIKICDKANRIBUFLG__c.equals(other.getBANKTORIHIKICDKANRIBUFLG__c()))) &&
            ((this.BATCHHENKOUKBN__c==null && other.getBATCHHENKOUKBN__c()==null) || 
             (this.BATCHHENKOUKBN__c!=null &&
              this.BATCHHENKOUKBN__c.equals(other.getBATCHHENKOUKBN__c()))) &&
            ((this.BLOKBN__c==null && other.getBLOKBN__c()==null) || 
             (this.BLOKBN__c!=null &&
              this.BLOKBN__c.equals(other.getBLOKBN__c()))) &&
            ((this.BOTENCD__c==null && other.getBOTENCD__c()==null) || 
             (this.BOTENCD__c!=null &&
              this.BOTENCD__c.equals(other.getBOTENCD__c()))) &&
            ((this.BUMONBETSUFLG__c==null && other.getBUMONBETSUFLG__c()==null) || 
             (this.BUMONBETSUFLG__c!=null &&
              this.BUMONBETSUFLG__c.equals(other.getBUMONBETSUFLG__c()))) &&
            ((this.BUMONCD_HENKOU__c==null && other.getBUMONCD_HENKOU__c()==null) || 
             (this.BUMONCD_HENKOU__c!=null &&
              this.BUMONCD_HENKOU__c.equals(other.getBUMONCD_HENKOU__c()))) &&
            ((this.BUMONCD__c==null && other.getBUMONCD__c()==null) || 
             (this.BUMONCD__c!=null &&
              this.BUMONCD__c.equals(other.getBUMONCD__c()))) &&
            ((this.BUMONHONBUCD__c==null && other.getBUMONHONBUCD__c()==null) || 
             (this.BUMONHONBUCD__c!=null &&
              this.BUMONHONBUCD__c.equals(other.getBUMONHONBUCD__c()))) &&
            ((this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c==null && other.getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c()==null) || 
             (this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c!=null &&
              this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c.equals(other.getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c()))) &&
            ((this.BUTENBANGOU__c==null && other.getBUTENBANGOU__c()==null) || 
             (this.BUTENBANGOU__c!=null &&
              this.BUTENBANGOU__c.equals(other.getBUTENBANGOU__c()))) &&
            ((this.BUTENCHOUYAKUSHOKUCD__c==null && other.getBUTENCHOUYAKUSHOKUCD__c()==null) || 
             (this.BUTENCHOUYAKUSHOKUCD__c!=null &&
              this.BUTENCHOUYAKUSHOKUCD__c.equals(other.getBUTENCHOUYAKUSHOKUCD__c()))) &&
            ((this.BUTENNM1__c==null && other.getBUTENNM1__c()==null) || 
             (this.BUTENNM1__c!=null &&
              this.BUTENNM1__c.equals(other.getBUTENNM1__c()))) &&
            ((this.BUTENNM2__c==null && other.getBUTENNM2__c()==null) || 
             (this.BUTENNM2__c!=null &&
              this.BUTENNM2__c.equals(other.getBUTENNM2__c()))) &&
            ((this.BUTENNM3__c==null && other.getBUTENNM3__c()==null) || 
             (this.BUTENNM3__c!=null &&
              this.BUTENNM3__c.equals(other.getBUTENNM3__c()))) &&
            ((this.BUTENNMKANA__c==null && other.getBUTENNMKANA__c()==null) || 
             (this.BUTENNMKANA__c!=null &&
              this.BUTENNMKANA__c.equals(other.getBUTENNMKANA__c()))) &&
            ((this.BUTENNMRENKETSU__c==null && other.getBUTENNMRENKETSU__c()==null) || 
             (this.BUTENNMRENKETSU__c!=null &&
              this.BUTENNMRENKETSU__c.equals(other.getBUTENNMRENKETSU__c()))) &&
            ((this.BUTENNMRYAKU__c==null && other.getBUTENNMRYAKU__c()==null) || 
             (this.BUTENNMRYAKU__c!=null &&
              this.BUTENNMRYAKU__c.equals(other.getBUTENNMRYAKU__c()))) &&
            ((this.c000_026_OBJECT_APPLICATION_INFO_03__r==null && other.getC000_026_OBJECT_APPLICATION_INFO_03__r()==null) || 
             (this.c000_026_OBJECT_APPLICATION_INFO_03__r!=null &&
              this.c000_026_OBJECT_APPLICATION_INFO_03__r.equals(other.getC000_026_OBJECT_APPLICATION_INFO_03__r()))) &&
            ((this.c000_042_CIF_PROPERTY_CHANGE_INFO_02__r==null && other.getC000_042_CIF_PROPERTY_CHANGE_INFO_02__r()==null) || 
             (this.c000_042_CIF_PROPERTY_CHANGE_INFO_02__r!=null &&
              this.c000_042_CIF_PROPERTY_CHANGE_INFO_02__r.equals(other.getC000_042_CIF_PROPERTY_CHANGE_INFO_02__r()))) &&
            ((this.c000_042_CIF_PROPERTY_CHANGE_INFO_04__r==null && other.getC000_042_CIF_PROPERTY_CHANGE_INFO_04__r()==null) || 
             (this.c000_042_CIF_PROPERTY_CHANGE_INFO_04__r!=null &&
              this.c000_042_CIF_PROPERTY_CHANGE_INFO_04__r.equals(other.getC000_042_CIF_PROPERTY_CHANGE_INFO_04__r()))) &&
            ((this.c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r==null && other.getC000_BUSHOINFO_BushitsuTemMei_Kicho_01__r()==null) || 
             (this.c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r!=null &&
              this.c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r.equals(other.getC000_BUSHOINFO_BushitsuTemMei_Kicho_01__r()))) &&
            ((this.c000_BUSHOINFO_BushitsuTembanMei_O_01__r==null && other.getC000_BUSHOINFO_BushitsuTembanMei_O_01__r()==null) || 
             (this.c000_BUSHOINFO_BushitsuTembanMei_O_01__r!=null &&
              this.c000_BUSHOINFO_BushitsuTembanMei_O_01__r.equals(other.getC000_BUSHOINFO_BushitsuTembanMei_O_01__r()))) &&
            ((this.c000_BUSHOINFO_BushitsuTemban_S_01__r==null && other.getC000_BUSHOINFO_BushitsuTemban_S_01__r()==null) || 
             (this.c000_BUSHOINFO_BushitsuTemban_S_01__r!=null &&
              this.c000_BUSHOINFO_BushitsuTemban_S_01__r.equals(other.getC000_BUSHOINFO_BushitsuTemban_S_01__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_02__r==null && other.getC000_CIFZOKUSEIINFO_02__r()==null) || 
             (this.c000_CIFZOKUSEIINFO_02__r!=null &&
              this.c000_CIFZOKUSEIINFO_02__r.equals(other.getC000_CIFZOKUSEIINFO_02__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_04__r==null && other.getC000_CIFZOKUSEIINFO_04__r()==null) || 
             (this.c000_CIFZOKUSEIINFO_04__r!=null &&
              this.c000_CIFZOKUSEIINFO_04__r.equals(other.getC000_CIFZOKUSEIINFO_04__r()))) &&
            ((this.c001_Offices_01__r==null && other.getC001_Offices_01__r()==null) || 
             (this.c001_Offices_01__r!=null &&
              this.c001_Offices_01__r.equals(other.getC001_Offices_01__r()))) &&
            ((this.c001_TantouKyotenNameMitoris_01__r==null && other.getC001_TantouKyotenNameMitoris_01__r()==null) || 
             (this.c001_TantouKyotenNameMitoris_01__r!=null &&
              this.c001_TantouKyotenNameMitoris_01__r.equals(other.getC001_TantouKyotenNameMitoris_01__r()))) &&
            ((this.c003_BUSHOINFOs_01__r==null && other.getC003_BUSHOINFOs_01__r()==null) || 
             (this.c003_BUSHOINFOs_01__r!=null &&
              this.c003_BUSHOINFOs_01__r.equals(other.getC003_BUSHOINFOs_01__r()))) &&
            ((this.c003_BUSHOINFOs_03__r==null && other.getC003_BUSHOINFOs_03__r()==null) || 
             (this.c003_BUSHOINFOs_03__r!=null &&
              this.c003_BUSHOINFOs_03__r.equals(other.getC003_BUSHOINFOs_03__r()))) &&
            ((this.CHIKUCD__c==null && other.getCHIKUCD__c()==null) || 
             (this.CHIKUCD__c!=null &&
              this.CHIKUCD__c.equals(other.getCHIKUCD__c()))) &&
            ((this.CHINESE_WALLKBN__c==null && other.getCHINESE_WALLKBN__c()==null) || 
             (this.CHINESE_WALLKBN__c!=null &&
              this.CHINESE_WALLKBN__c.equals(other.getCHINESE_WALLKBN__c()))) &&
            ((this.chokusetsuBranchName__r==null && other.getChokusetsuBranchName__r()==null) || 
             (this.chokusetsuBranchName__r!=null &&
              this.chokusetsuBranchName__r.equals(other.getChokusetsuBranchName__r()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.DELFLG__c==null && other.getDELFLG__c()==null) || 
             (this.DELFLG__c!=null &&
              this.DELFLG__c.equals(other.getDELFLG__c()))) &&
            ((this.DOUBLECNTKYOYOUFLG__c==null && other.getDOUBLECNTKYOYOUFLG__c()==null) || 
             (this.DOUBLECNTKYOYOUFLG__c!=null &&
              this.DOUBLECNTKYOYOUFLG__c.equals(other.getDOUBLECNTKYOYOUFLG__c()))) &&
            ((this.dairiBranchName1__r==null && other.getDairiBranchName1__r()==null) || 
             (this.dairiBranchName1__r!=null &&
              this.dairiBranchName1__r.equals(other.getDairiBranchName1__r()))) &&
            ((this.dairiBranchName2__r==null && other.getDairiBranchName2__r()==null) || 
             (this.dairiBranchName2__r!=null &&
              this.dairiBranchName2__r.equals(other.getDairiBranchName2__r()))) &&
            ((this.dairiBranchName3__r==null && other.getDairiBranchName3__r()==null) || 
             (this.dairiBranchName3__r!=null &&
              this.dairiBranchName3__r.equals(other.getDairiBranchName3__r()))) &&
            ((this.dairiBranchName4__r==null && other.getDairiBranchName4__r()==null) || 
             (this.dairiBranchName4__r!=null &&
              this.dairiBranchName4__r.equals(other.getDairiBranchName4__r()))) &&
            ((this.dairiBranchName5__r==null && other.getDairiBranchName5__r()==null) || 
             (this.dairiBranchName5__r!=null &&
              this.dairiBranchName5__r.equals(other.getDairiBranchName5__r()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.EIGYOKBN__c==null && other.getEIGYOKBN__c()==null) || 
             (this.EIGYOKBN__c!=null &&
              this.EIGYOKBN__c.equals(other.getEIGYOKBN__c()))) &&
            ((this.EIGYOKEITAIKBN__c==null && other.getEIGYOKEITAIKBN__c()==null) || 
             (this.EIGYOKEITAIKBN__c!=null &&
              this.EIGYOKEITAIKBN__c.equals(other.getEIGYOKEITAIKBN__c()))) &&
            ((this.events==null && other.getEvents()==null) || 
             (this.events!=null &&
              this.events.equals(other.getEvents()))) &&
            ((this.HAITENBI__c==null && other.getHAITENBI__c()==null) || 
             (this.HAITENBI__c!=null &&
              this.HAITENBI__c.equals(other.getHAITENBI__c()))) &&
            ((this.HONBU_EIGYOKYOTENFLG__c==null && other.getHONBU_EIGYOKYOTENFLG__c()==null) || 
             (this.HONBU_EIGYOKYOTENFLG__c!=null &&
              this.HONBU_EIGYOKYOTENFLG__c.equals(other.getHONBU_EIGYOKYOTENFLG__c()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.JIMUSOSHIKIKBN__c==null && other.getJIMUSOSHIKIKBN__c()==null) || 
             (this.JIMUSOSHIKIKBN__c!=null &&
              this.JIMUSOSHIKIKBN__c.equals(other.getJIMUSOSHIKIKBN__c()))) &&
            ((this.JOUIAREAINFOCD__c==null && other.getJOUIAREAINFOCD__c()==null) || 
             (this.JOUIAREAINFOCD__c!=null &&
              this.JOUIAREAINFOCD__c.equals(other.getJOUIAREAINFOCD__c()))) &&
            ((this.JOUIBUTENBANGOU_HENKOU__c==null && other.getJOUIBUTENBANGOU_HENKOU__c()==null) || 
             (this.JOUIBUTENBANGOU_HENKOU__c!=null &&
              this.JOUIBUTENBANGOU_HENKOU__c.equals(other.getJOUIBUTENBANGOU_HENKOU__c()))) &&
            ((this.JOUIBUTENBANGOU__c==null && other.getJOUIBUTENBANGOU__c()==null) || 
             (this.JOUIBUTENBANGOU__c!=null &&
              this.JOUIBUTENBANGOU__c.equals(other.getJOUIBUTENBANGOU__c()))) &&
            ((this.JOUIKACD__c==null && other.getJOUIKACD__c()==null) || 
             (this.JOUIKACD__c!=null &&
              this.JOUIKACD__c.equals(other.getJOUIKACD__c()))) &&
            ((this.JOUKENKENSAKUYOUFLG__c==null && other.getJOUKENKENSAKUYOUFLG__c()==null) || 
             (this.JOUKENKENSAKUYOUFLG__c!=null &&
              this.JOUKENKENSAKUYOUFLG__c.equals(other.getJOUKENKENSAKUYOUFLG__c()))) &&
            ((this.KACD__c==null && other.getKACD__c()==null) || 
             (this.KACD__c!=null &&
              this.KACD__c.equals(other.getKACD__c()))) &&
            ((this.KAIGAIFLG__c==null && other.getKAIGAIFLG__c()==null) || 
             (this.KAIGAIFLG__c!=null &&
              this.KAIGAIFLG__c.equals(other.getKAIGAIFLG__c()))) &&
            ((this.KAITENBI__c==null && other.getKAITENBI__c()==null) || 
             (this.KAITENBI__c!=null &&
              this.KAITENBI__c.equals(other.getKAITENBI__c()))) &&
            ((this.KANJOTENKBN__c==null && other.getKANJOTENKBN__c()==null) || 
             (this.KANJOTENKBN__c!=null &&
              this.KANJOTENKBN__c.equals(other.getKANJOTENKBN__c()))) &&
            ((this.KA_GRNMKANA__c==null && other.getKA_GRNMKANA__c()==null) || 
             (this.KA_GRNMKANA__c!=null &&
              this.KA_GRNMKANA__c.equals(other.getKA_GRNMKANA__c()))) &&
            ((this.KA_GRNMRYAKU__c==null && other.getKA_GRNMRYAKU__c()==null) || 
             (this.KA_GRNMRYAKU__c!=null &&
              this.KA_GRNMRYAKU__c.equals(other.getKA_GRNMRYAKU__c()))) &&
            ((this.KA_GRNM__c==null && other.getKA_GRNM__c()==null) || 
             (this.KA_GRNM__c!=null &&
              this.KA_GRNM__c.equals(other.getKA_GRNM__c()))) &&
            ((this.KOKYAKUKANRIHONBUKBN__c==null && other.getKOKYAKUKANRIHONBUKBN__c()==null) || 
             (this.KOKYAKUKANRIHONBUKBN__c!=null &&
              this.KOKYAKUKANRIHONBUKBN__c.equals(other.getKOKYAKUKANRIHONBUKBN__c()))) &&
            ((this.KYOTENFLG__c==null && other.getKYOTENFLG__c()==null) || 
             (this.KYOTENFLG__c!=null &&
              this.KYOTENFLG__c.equals(other.getKYOTENFLG__c()))) &&
            ((this.lastActivityDate==null && other.getLastActivityDate()==null) || 
             (this.lastActivityDate!=null &&
              this.lastActivityDate.equals(other.getLastActivityDate()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.openActivities==null && other.getOpenActivities()==null) || 
             (this.openActivities!=null &&
              this.openActivities.equals(other.getOpenActivities()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.RENKETSUFLG__c==null && other.getRENKETSUFLG__c()==null) || 
             (this.RENKETSUFLG__c!=null &&
              this.RENKETSUFLG__c.equals(other.getRENKETSUFLG__c()))) &&
            ((this.RMFKYOYOUFLG__c==null && other.getRMFKYOYOUFLG__c()==null) || 
             (this.RMFKYOYOUFLG__c!=null &&
              this.RMFKYOYOUFLG__c.equals(other.getRMFKYOYOUFLG__c()))) &&
            ((this.requestBranchName__r==null && other.getRequestBranchName__r()==null) || 
             (this.requestBranchName__r!=null &&
              this.requestBranchName__r.equals(other.getRequestBranchName__r()))) &&
            ((this.SAISHUUTEAMCD__c==null && other.getSAISHUUTEAMCD__c()==null) || 
             (this.SAISHUUTEAMCD__c!=null &&
              this.SAISHUUTEAMCD__c.equals(other.getSAISHUUTEAMCD__c()))) &&
            ((this.SHIJOUNAYOSEKANRIBUFLG__c==null && other.getSHIJOUNAYOSEKANRIBUFLG__c()==null) || 
             (this.SHIJOUNAYOSEKANRIBUFLG__c!=null &&
              this.SHIJOUNAYOSEKANRIBUFLG__c.equals(other.getSHIJOUNAYOSEKANRIBUFLG__c()))) &&
            ((this.SHOUNINJOUKYOUFLG__c==null && other.getSHOUNINJOUKYOUFLG__c()==null) || 
             (this.SHOUNINJOUKYOUFLG__c!=null &&
              this.SHOUNINJOUKYOUFLG__c.equals(other.getSHOUNINJOUKYOUFLG__c()))) &&
            ((this.SOSHIKICATEGORYKBN__c==null && other.getSOSHIKICATEGORYKBN__c()==null) || 
             (this.SOSHIKICATEGORYKBN__c!=null &&
              this.SOSHIKICATEGORYKBN__c.equals(other.getSOSHIKICATEGORYKBN__c()))) &&
            ((this.SOSHIKIJUNCD__c==null && other.getSOSHIKIJUNCD__c()==null) || 
             (this.SOSHIKIJUNCD__c!=null &&
              this.SOSHIKIJUNCD__c.equals(other.getSOSHIKIJUNCD__c()))) &&
            ((this.SOSHIKIKEITAI__c==null && other.getSOSHIKIKEITAI__c()==null) || 
             (this.SOSHIKIKEITAI__c!=null &&
              this.SOSHIKIKEITAI__c.equals(other.getSOSHIKIKEITAI__c()))) &&
            ((this.SOUGOURISKKANRIBUFLG__c==null && other.getSOUGOURISKKANRIBUFLG__c()==null) || 
             (this.SOUGOURISKKANRIBUFLG__c!=null &&
              this.SOUGOURISKKANRIBUFLG__c.equals(other.getSOUGOURISKKANRIBUFLG__c()))) &&
            ((this.shares==null && other.getShares()==null) || 
             (this.shares!=null &&
              this.shares.equals(other.getShares()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.TATEMONOKBN__c==null && other.getTATEMONOKBN__c()==null) || 
             (this.TATEMONOKBN__c!=null &&
              this.TATEMONOKBN__c.equals(other.getTATEMONOKBN__c()))) &&
            ((this.TEAMCD__c==null && other.getTEAMCD__c()==null) || 
             (this.TEAMCD__c!=null &&
              this.TEAMCD__c.equals(other.getTEAMCD__c()))) &&
            ((this.TEAMNM__c==null && other.getTEAMNM__c()==null) || 
             (this.TEAMNM__c!=null &&
              this.TEAMNM__c.equals(other.getTEAMNM__c()))) &&
            ((this.TENSHITSU__c==null && other.getTENSHITSU__c()==null) || 
             (this.TENSHITSU__c!=null &&
              this.TENSHITSU__c.equals(other.getTENSHITSU__c()))) &&
            ((this.TOKUTEISOSHIKIKBN__c==null && other.getTOKUTEISOSHIKIKBN__c()==null) || 
             (this.TOKUTEISOSHIKIKBN__c!=null &&
              this.TOKUTEISOSHIKIKBN__c.equals(other.getTOKUTEISOSHIKIKBN__c()))) &&
            ((this.TOUMEIHANCD__c==null && other.getTOUMEIHANCD__c()==null) || 
             (this.TOUMEIHANCD__c!=null &&
              this.TOUMEIHANCD__c.equals(other.getTOUMEIHANCD__c()))) &&
            ((this.tasks==null && other.getTasks()==null) || 
             (this.tasks!=null &&
              this.tasks.equals(other.getTasks()))) &&
            ((this.tesuryoBranchName__r==null && other.getTesuryoBranchName__r()==null) || 
             (this.tesuryoBranchName__r!=null &&
              this.tesuryoBranchName__r.equals(other.getTesuryoBranchName__r()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess()))) &&
            ((this.YOSHINSHOKANBUFLG__c==null && other.getYOSHINSHOKANBUFLG__c()==null) || 
             (this.YOSHINSHOKANBUFLG__c!=null &&
              this.YOSHINSHOKANBUFLG__c.equals(other.getYOSHINSHOKANBUFLG__c()))) &&
            ((this.YUUKOUKIKANKAISHIBI__c==null && other.getYUUKOUKIKANKAISHIBI__c()==null) || 
             (this.YUUKOUKIKANKAISHIBI__c!=null &&
              this.YUUKOUKIKANKAISHIBI__c.equals(other.getYUUKOUKIKANKAISHIBI__c()))) &&
            ((this.ZENSENKAHONBUFLG__c==null && other.getZENSENKAHONBUFLG__c()==null) || 
             (this.ZENSENKAHONBUFLG__c!=null &&
              this.ZENSENKAHONBUFLG__c.equals(other.getZENSENKAHONBUFLG__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getADTEN__c() != null) {
            _hashCode += getADTEN__c().hashCode();
        }
        if (getAREAINFOCD__c() != null) {
            _hashCode += getAREAINFOCD__c().hashCode();
        }
        if (getAREANM__c() != null) {
            _hashCode += getAREANM__c().hashCode();
        }
        if (getAREARYAKU__c() != null) {
            _hashCode += getAREARYAKU__c().hashCode();
        }
        if (getAcceptOffice__r() != null) {
            _hashCode += getAcceptOffice__r().hashCode();
        }
        if (getActivityHistories() != null) {
            _hashCode += getActivityHistories().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBANKTORIHIKICDKANRIBUFLG__c() != null) {
            _hashCode += getBANKTORIHIKICDKANRIBUFLG__c().hashCode();
        }
        if (getBATCHHENKOUKBN__c() != null) {
            _hashCode += getBATCHHENKOUKBN__c().hashCode();
        }
        if (getBLOKBN__c() != null) {
            _hashCode += getBLOKBN__c().hashCode();
        }
        if (getBOTENCD__c() != null) {
            _hashCode += getBOTENCD__c().hashCode();
        }
        if (getBUMONBETSUFLG__c() != null) {
            _hashCode += getBUMONBETSUFLG__c().hashCode();
        }
        if (getBUMONCD_HENKOU__c() != null) {
            _hashCode += getBUMONCD_HENKOU__c().hashCode();
        }
        if (getBUMONCD__c() != null) {
            _hashCode += getBUMONCD__c().hashCode();
        }
        if (getBUMONHONBUCD__c() != null) {
            _hashCode += getBUMONHONBUCD__c().hashCode();
        }
        if (getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c() != null) {
            _hashCode += getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c().hashCode();
        }
        if (getBUTENBANGOU__c() != null) {
            _hashCode += getBUTENBANGOU__c().hashCode();
        }
        if (getBUTENCHOUYAKUSHOKUCD__c() != null) {
            _hashCode += getBUTENCHOUYAKUSHOKUCD__c().hashCode();
        }
        if (getBUTENNM1__c() != null) {
            _hashCode += getBUTENNM1__c().hashCode();
        }
        if (getBUTENNM2__c() != null) {
            _hashCode += getBUTENNM2__c().hashCode();
        }
        if (getBUTENNM3__c() != null) {
            _hashCode += getBUTENNM3__c().hashCode();
        }
        if (getBUTENNMKANA__c() != null) {
            _hashCode += getBUTENNMKANA__c().hashCode();
        }
        if (getBUTENNMRENKETSU__c() != null) {
            _hashCode += getBUTENNMRENKETSU__c().hashCode();
        }
        if (getBUTENNMRYAKU__c() != null) {
            _hashCode += getBUTENNMRYAKU__c().hashCode();
        }
        if (getC000_026_OBJECT_APPLICATION_INFO_03__r() != null) {
            _hashCode += getC000_026_OBJECT_APPLICATION_INFO_03__r().hashCode();
        }
        if (getC000_042_CIF_PROPERTY_CHANGE_INFO_02__r() != null) {
            _hashCode += getC000_042_CIF_PROPERTY_CHANGE_INFO_02__r().hashCode();
        }
        if (getC000_042_CIF_PROPERTY_CHANGE_INFO_04__r() != null) {
            _hashCode += getC000_042_CIF_PROPERTY_CHANGE_INFO_04__r().hashCode();
        }
        if (getC000_BUSHOINFO_BushitsuTemMei_Kicho_01__r() != null) {
            _hashCode += getC000_BUSHOINFO_BushitsuTemMei_Kicho_01__r().hashCode();
        }
        if (getC000_BUSHOINFO_BushitsuTembanMei_O_01__r() != null) {
            _hashCode += getC000_BUSHOINFO_BushitsuTembanMei_O_01__r().hashCode();
        }
        if (getC000_BUSHOINFO_BushitsuTemban_S_01__r() != null) {
            _hashCode += getC000_BUSHOINFO_BushitsuTemban_S_01__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_02__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_02__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_04__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_04__r().hashCode();
        }
        if (getC001_Offices_01__r() != null) {
            _hashCode += getC001_Offices_01__r().hashCode();
        }
        if (getC001_TantouKyotenNameMitoris_01__r() != null) {
            _hashCode += getC001_TantouKyotenNameMitoris_01__r().hashCode();
        }
        if (getC003_BUSHOINFOs_01__r() != null) {
            _hashCode += getC003_BUSHOINFOs_01__r().hashCode();
        }
        if (getC003_BUSHOINFOs_03__r() != null) {
            _hashCode += getC003_BUSHOINFOs_03__r().hashCode();
        }
        if (getCHIKUCD__c() != null) {
            _hashCode += getCHIKUCD__c().hashCode();
        }
        if (getCHINESE_WALLKBN__c() != null) {
            _hashCode += getCHINESE_WALLKBN__c().hashCode();
        }
        if (getChokusetsuBranchName__r() != null) {
            _hashCode += getChokusetsuBranchName__r().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDELFLG__c() != null) {
            _hashCode += getDELFLG__c().hashCode();
        }
        if (getDOUBLECNTKYOYOUFLG__c() != null) {
            _hashCode += getDOUBLECNTKYOYOUFLG__c().hashCode();
        }
        if (getDairiBranchName1__r() != null) {
            _hashCode += getDairiBranchName1__r().hashCode();
        }
        if (getDairiBranchName2__r() != null) {
            _hashCode += getDairiBranchName2__r().hashCode();
        }
        if (getDairiBranchName3__r() != null) {
            _hashCode += getDairiBranchName3__r().hashCode();
        }
        if (getDairiBranchName4__r() != null) {
            _hashCode += getDairiBranchName4__r().hashCode();
        }
        if (getDairiBranchName5__r() != null) {
            _hashCode += getDairiBranchName5__r().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getEIGYOKBN__c() != null) {
            _hashCode += getEIGYOKBN__c().hashCode();
        }
        if (getEIGYOKEITAIKBN__c() != null) {
            _hashCode += getEIGYOKEITAIKBN__c().hashCode();
        }
        if (getEvents() != null) {
            _hashCode += getEvents().hashCode();
        }
        if (getHAITENBI__c() != null) {
            _hashCode += getHAITENBI__c().hashCode();
        }
        if (getHONBU_EIGYOKYOTENFLG__c() != null) {
            _hashCode += getHONBU_EIGYOKYOTENFLG__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getJIMUSOSHIKIKBN__c() != null) {
            _hashCode += getJIMUSOSHIKIKBN__c().hashCode();
        }
        if (getJOUIAREAINFOCD__c() != null) {
            _hashCode += getJOUIAREAINFOCD__c().hashCode();
        }
        if (getJOUIBUTENBANGOU_HENKOU__c() != null) {
            _hashCode += getJOUIBUTENBANGOU_HENKOU__c().hashCode();
        }
        if (getJOUIBUTENBANGOU__c() != null) {
            _hashCode += getJOUIBUTENBANGOU__c().hashCode();
        }
        if (getJOUIKACD__c() != null) {
            _hashCode += getJOUIKACD__c().hashCode();
        }
        if (getJOUKENKENSAKUYOUFLG__c() != null) {
            _hashCode += getJOUKENKENSAKUYOUFLG__c().hashCode();
        }
        if (getKACD__c() != null) {
            _hashCode += getKACD__c().hashCode();
        }
        if (getKAIGAIFLG__c() != null) {
            _hashCode += getKAIGAIFLG__c().hashCode();
        }
        if (getKAITENBI__c() != null) {
            _hashCode += getKAITENBI__c().hashCode();
        }
        if (getKANJOTENKBN__c() != null) {
            _hashCode += getKANJOTENKBN__c().hashCode();
        }
        if (getKA_GRNMKANA__c() != null) {
            _hashCode += getKA_GRNMKANA__c().hashCode();
        }
        if (getKA_GRNMRYAKU__c() != null) {
            _hashCode += getKA_GRNMRYAKU__c().hashCode();
        }
        if (getKA_GRNM__c() != null) {
            _hashCode += getKA_GRNM__c().hashCode();
        }
        if (getKOKYAKUKANRIHONBUKBN__c() != null) {
            _hashCode += getKOKYAKUKANRIHONBUKBN__c().hashCode();
        }
        if (getKYOTENFLG__c() != null) {
            _hashCode += getKYOTENFLG__c().hashCode();
        }
        if (getLastActivityDate() != null) {
            _hashCode += getLastActivityDate().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOpenActivities() != null) {
            _hashCode += getOpenActivities().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getRENKETSUFLG__c() != null) {
            _hashCode += getRENKETSUFLG__c().hashCode();
        }
        if (getRMFKYOYOUFLG__c() != null) {
            _hashCode += getRMFKYOYOUFLG__c().hashCode();
        }
        if (getRequestBranchName__r() != null) {
            _hashCode += getRequestBranchName__r().hashCode();
        }
        if (getSAISHUUTEAMCD__c() != null) {
            _hashCode += getSAISHUUTEAMCD__c().hashCode();
        }
        if (getSHIJOUNAYOSEKANRIBUFLG__c() != null) {
            _hashCode += getSHIJOUNAYOSEKANRIBUFLG__c().hashCode();
        }
        if (getSHOUNINJOUKYOUFLG__c() != null) {
            _hashCode += getSHOUNINJOUKYOUFLG__c().hashCode();
        }
        if (getSOSHIKICATEGORYKBN__c() != null) {
            _hashCode += getSOSHIKICATEGORYKBN__c().hashCode();
        }
        if (getSOSHIKIJUNCD__c() != null) {
            _hashCode += getSOSHIKIJUNCD__c().hashCode();
        }
        if (getSOSHIKIKEITAI__c() != null) {
            _hashCode += getSOSHIKIKEITAI__c().hashCode();
        }
        if (getSOUGOURISKKANRIBUFLG__c() != null) {
            _hashCode += getSOUGOURISKKANRIBUFLG__c().hashCode();
        }
        if (getShares() != null) {
            _hashCode += getShares().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTATEMONOKBN__c() != null) {
            _hashCode += getTATEMONOKBN__c().hashCode();
        }
        if (getTEAMCD__c() != null) {
            _hashCode += getTEAMCD__c().hashCode();
        }
        if (getTEAMNM__c() != null) {
            _hashCode += getTEAMNM__c().hashCode();
        }
        if (getTENSHITSU__c() != null) {
            _hashCode += getTENSHITSU__c().hashCode();
        }
        if (getTOKUTEISOSHIKIKBN__c() != null) {
            _hashCode += getTOKUTEISOSHIKIKBN__c().hashCode();
        }
        if (getTOUMEIHANCD__c() != null) {
            _hashCode += getTOUMEIHANCD__c().hashCode();
        }
        if (getTasks() != null) {
            _hashCode += getTasks().hashCode();
        }
        if (getTesuryoBranchName__r() != null) {
            _hashCode += getTesuryoBranchName__r().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        if (getYOSHINSHOKANBUFLG__c() != null) {
            _hashCode += getYOSHINSHOKANBUFLG__c().hashCode();
        }
        if (getYUUKOUKIKANKAISHIBI__c() != null) {
            _hashCode += getYUUKOUKIKANKAISHIBI__c().hashCode();
        }
        if (getZENSENKAHONBUFLG__c() != null) {
            _hashCode += getZENSENKAHONBUFLG__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C000_BUSHOINFO__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_BUSHOINFO__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ADTEN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ADTEN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AREAINFOCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AREAINFOCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AREANM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AREANM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AREARYAKU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AREARYAKU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("acceptOffice__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AcceptOffice__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activityHistories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivityHistories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BANKTORIHIKICDKANRIBUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BANKTORIHIKICDKANRIBUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BATCHHENKOUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BATCHHENKOUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BLOKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BLOKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BOTENCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BOTENCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUMONBETSUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUMONBETSUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUMONCD_HENKOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUMONCD_HENKOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUMONCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUMONCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUMONHONBUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUMONHONBUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENCHOUYAKUSHOKUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENCHOUYAKUSHOKUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNM1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNM1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNM2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNM2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNM3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNM3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNMKANA__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNMKANA__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNMRENKETSU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNMRENKETSU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNMRYAKU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNMRYAKU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_026_OBJECT_APPLICATION_INFO_03__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_026_OBJECT_APPLICATION_INFO_03__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_042_CIF_PROPERTY_CHANGE_INFO_02__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_042_CIF_PROPERTY_CHANGE_INFO_02__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_042_CIF_PROPERTY_CHANGE_INFO_04__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_042_CIF_PROPERTY_CHANGE_INFO_04__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_BUSHOINFO_BushitsuTemMei_Kicho_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_BUSHOINFO_BushitsuTemMei_Kicho_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_BUSHOINFO_BushitsuTembanMei_O_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_BUSHOINFO_BushitsuTembanMei_O_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_BUSHOINFO_BushitsuTemban_S_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_BUSHOINFO_BushitsuTemban_S_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_02__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_02__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_04__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_04__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c001_Offices_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C001_Offices_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c001_TantouKyotenNameMitoris_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C001_TantouKyotenNameMitoris_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_BUSHOINFOs_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_BUSHOINFOs_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_BUSHOINFOs_03__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_BUSHOINFOs_03__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHIKUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CHIKUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHINESE_WALLKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CHINESE_WALLKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("chokusetsuBranchName__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ChokusetsuBranchName__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DELFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DELFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOUBLECNTKYOYOUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DOUBLECNTKYOYOUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dairiBranchName1__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DairiBranchName1__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dairiBranchName2__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DairiBranchName2__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dairiBranchName3__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DairiBranchName3__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dairiBranchName4__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DairiBranchName4__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dairiBranchName5__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DairiBranchName5__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EIGYOKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EIGYOKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EIGYOKEITAIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "EIGYOKEITAIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("events");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Events"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HAITENBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HAITENBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HONBU_EIGYOKYOTENFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HONBU_EIGYOKYOTENFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JIMUSOSHIKIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JIMUSOSHIKIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUIAREAINFOCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUIAREAINFOCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUIBUTENBANGOU_HENKOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUIBUTENBANGOU_HENKOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUIBUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUIBUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUIKACD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUIKACD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUKENKENSAKUYOUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUKENKENSAKUYOUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KACD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KACD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAIGAIFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAIGAIFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAITENBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAITENBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KANJOTENKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KANJOTENKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KA_GRNMKANA__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KA_GRNMKANA__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KA_GRNMRYAKU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KA_GRNMRYAKU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KA_GRNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KA_GRNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKYAKUKANRIHONBUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKYAKUKANRIHONBUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOTENFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOTENFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastActivityDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastActivityDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpenActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RENKETSUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RENKETSUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RMFKYOYOUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RMFKYOYOUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("requestBranchName__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RequestBranchName__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAISHUUTEAMCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAISHUUTEAMCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHIJOUNAYOSEKANRIBUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHIJOUNAYOSEKANRIBUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOUNINJOUKYOUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOUNINJOUKYOUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SOSHIKICATEGORYKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SOSHIKICATEGORYKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SOSHIKIJUNCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SOSHIKIJUNCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SOSHIKIKEITAI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SOSHIKIKEITAI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SOUGOURISKKANRIBUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SOUGOURISKKANRIBUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TATEMONOKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TATEMONOKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TEAMCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TEAMCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TEAMNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TEAMNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENSHITSU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENSHITSU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TOKUTEISOSHIKIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TOKUTEISOSHIKIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TOUMEIHANCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TOUMEIHANCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tasks");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Tasks"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tesuryoBranchName__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TesuryoBranchName__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOSHINSHOKANBUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOSHINSHOKANBUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YUUKOUKIKANKAISHIBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YUUKOUKIKANKAISHIBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ZENSENKAHONBUFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ZENSENKAHONBUFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
