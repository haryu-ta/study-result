/**
 * C002_Task__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C002_Task__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private java.lang.String a013_Line__c;

    private java.lang.String a014_CustomerContact__c;

    private java.lang.String a014_Detail__c;

    private java.lang.String a014_Place__c;

    private java.lang.String a014_Taido__c;

    private java.lang.String a014_TantouTeam__c;

    private java.lang.String a014_Tantousha__c;

    private java.lang.Boolean a014_TeianKirikuchi1__c;

    private java.lang.Boolean a014_TeianKirikuchi2__c;

    private java.lang.Boolean a014_TeianKirikuchi3__c;

    private java.lang.Boolean a014_TeianKirikuchi4__c;

    private java.lang.Boolean a014_TeianKirikuchi5__c;

    private java.lang.String a014_TeianKirikuchiOtherDetail__c;

    private java.lang.Boolean a014_TeianKirikuchiOther__c;

    private java.lang.Boolean a014_TeianshoUmu__c;

    private java.lang.Boolean a015_HouzinCRMKiroku__c;

    private java.lang.String a015_Seika__c;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String c002_Action__c;

    private java.lang.Boolean c002_AllowedChangeCustomer__c;

    private java.lang.String c002_AppName__c;

    private java.lang.String c002_CRM_KatsudoId__c;

    private java.lang.Boolean c002_Confirm1__c;

    private java.lang.Boolean c002_Confirm2__c;

    private java.lang.Boolean c002_Confirm3__c;

    private java.lang.String c002_CsvKatsudo__c;

    private java.lang.String c002_CsvRecordTantou__c;

    private java.lang.String c002_CsvTaido__c;

    private java.lang.String c002_CustomerContact__c;

    private java.lang.String c002_CustomerId__c;

    private java.lang.String c002_CustomerName__c;

    private java.lang.String c002_CustomerRef__c;

    private com.sforce.soap.enterprise.sobject.C001_Customer__c c002_CustomerRef__r;

    private java.util.Date c002_Date__c;

    private java.lang.String c002_Detail__c;

    private java.lang.String c002_Katsudo__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Katsudo__r;

    private java.lang.String c002_KyotenName__c;

    private java.lang.String c002_Outline__c;

    private java.lang.String c002_Place__c;

    private java.lang.String c002_RMTanto__c;

    private java.lang.String c002_RecordTypeName2__c;

    private java.lang.String c002_RelatedCaseID__c;

    private java.lang.String c002_Remarks__c;

    private java.lang.String c002_TaidoNyuryokuyo__c;

    private java.lang.String c002_Taido__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Taido__r;

    private java.lang.String c002_TantoButenName__c;

    private java.lang.String c002_Tanto__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tanto__r;

    private java.lang.String c002_TantobuTemban__c;

    private java.lang.String c002_TaskName__c;

    private com.sforce.soap.enterprise.QueryResult c002_Tasks_01__r;

    private java.lang.String c002_TembanCif__c;

    private java.lang.String c002_TokoKakuzuke__c;

    private java.lang.String c002_Type__c;

    private java.lang.String c002_YomikomiNo__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private java.util.Calendar lastReferencedDate;

    private java.util.Calendar lastViewedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private com.sforce.soap.enterprise.sobject.RecordType recordType;

    private java.lang.String recordTypeId;

    private com.sforce.soap.enterprise.QueryResult shares;

    private java.util.Calendar systemModstamp;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    public C002_Task__c() {
    }

    public C002_Task__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           java.lang.String a013_Line__c,
           java.lang.String a014_CustomerContact__c,
           java.lang.String a014_Detail__c,
           java.lang.String a014_Place__c,
           java.lang.String a014_Taido__c,
           java.lang.String a014_TantouTeam__c,
           java.lang.String a014_Tantousha__c,
           java.lang.Boolean a014_TeianKirikuchi1__c,
           java.lang.Boolean a014_TeianKirikuchi2__c,
           java.lang.Boolean a014_TeianKirikuchi3__c,
           java.lang.Boolean a014_TeianKirikuchi4__c,
           java.lang.Boolean a014_TeianKirikuchi5__c,
           java.lang.String a014_TeianKirikuchiOtherDetail__c,
           java.lang.Boolean a014_TeianKirikuchiOther__c,
           java.lang.Boolean a014_TeianshoUmu__c,
           java.lang.Boolean a015_HouzinCRMKiroku__c,
           java.lang.String a015_Seika__c,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String c002_Action__c,
           java.lang.Boolean c002_AllowedChangeCustomer__c,
           java.lang.String c002_AppName__c,
           java.lang.String c002_CRM_KatsudoId__c,
           java.lang.Boolean c002_Confirm1__c,
           java.lang.Boolean c002_Confirm2__c,
           java.lang.Boolean c002_Confirm3__c,
           java.lang.String c002_CsvKatsudo__c,
           java.lang.String c002_CsvRecordTantou__c,
           java.lang.String c002_CsvTaido__c,
           java.lang.String c002_CustomerContact__c,
           java.lang.String c002_CustomerId__c,
           java.lang.String c002_CustomerName__c,
           java.lang.String c002_CustomerRef__c,
           com.sforce.soap.enterprise.sobject.C001_Customer__c c002_CustomerRef__r,
           java.util.Date c002_Date__c,
           java.lang.String c002_Detail__c,
           java.lang.String c002_Katsudo__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Katsudo__r,
           java.lang.String c002_KyotenName__c,
           java.lang.String c002_Outline__c,
           java.lang.String c002_Place__c,
           java.lang.String c002_RMTanto__c,
           java.lang.String c002_RecordTypeName2__c,
           java.lang.String c002_RelatedCaseID__c,
           java.lang.String c002_Remarks__c,
           java.lang.String c002_TaidoNyuryokuyo__c,
           java.lang.String c002_Taido__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Taido__r,
           java.lang.String c002_TantoButenName__c,
           java.lang.String c002_Tanto__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tanto__r,
           java.lang.String c002_TantobuTemban__c,
           java.lang.String c002_TaskName__c,
           com.sforce.soap.enterprise.QueryResult c002_Tasks_01__r,
           java.lang.String c002_TembanCif__c,
           java.lang.String c002_TokoKakuzuke__c,
           java.lang.String c002_Type__c,
           java.lang.String c002_YomikomiNo__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           java.util.Calendar lastReferencedDate,
           java.util.Calendar lastViewedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           com.sforce.soap.enterprise.sobject.RecordType recordType,
           java.lang.String recordTypeId,
           com.sforce.soap.enterprise.QueryResult shares,
           java.util.Calendar systemModstamp,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        super(
            fieldsToNull,
            id);
        this.a013_Line__c = a013_Line__c;
        this.a014_CustomerContact__c = a014_CustomerContact__c;
        this.a014_Detail__c = a014_Detail__c;
        this.a014_Place__c = a014_Place__c;
        this.a014_Taido__c = a014_Taido__c;
        this.a014_TantouTeam__c = a014_TantouTeam__c;
        this.a014_Tantousha__c = a014_Tantousha__c;
        this.a014_TeianKirikuchi1__c = a014_TeianKirikuchi1__c;
        this.a014_TeianKirikuchi2__c = a014_TeianKirikuchi2__c;
        this.a014_TeianKirikuchi3__c = a014_TeianKirikuchi3__c;
        this.a014_TeianKirikuchi4__c = a014_TeianKirikuchi4__c;
        this.a014_TeianKirikuchi5__c = a014_TeianKirikuchi5__c;
        this.a014_TeianKirikuchiOtherDetail__c = a014_TeianKirikuchiOtherDetail__c;
        this.a014_TeianKirikuchiOther__c = a014_TeianKirikuchiOther__c;
        this.a014_TeianshoUmu__c = a014_TeianshoUmu__c;
        this.a015_HouzinCRMKiroku__c = a015_HouzinCRMKiroku__c;
        this.a015_Seika__c = a015_Seika__c;
        this.attachments = attachments;
        this.c002_Action__c = c002_Action__c;
        this.c002_AllowedChangeCustomer__c = c002_AllowedChangeCustomer__c;
        this.c002_AppName__c = c002_AppName__c;
        this.c002_CRM_KatsudoId__c = c002_CRM_KatsudoId__c;
        this.c002_Confirm1__c = c002_Confirm1__c;
        this.c002_Confirm2__c = c002_Confirm2__c;
        this.c002_Confirm3__c = c002_Confirm3__c;
        this.c002_CsvKatsudo__c = c002_CsvKatsudo__c;
        this.c002_CsvRecordTantou__c = c002_CsvRecordTantou__c;
        this.c002_CsvTaido__c = c002_CsvTaido__c;
        this.c002_CustomerContact__c = c002_CustomerContact__c;
        this.c002_CustomerId__c = c002_CustomerId__c;
        this.c002_CustomerName__c = c002_CustomerName__c;
        this.c002_CustomerRef__c = c002_CustomerRef__c;
        this.c002_CustomerRef__r = c002_CustomerRef__r;
        this.c002_Date__c = c002_Date__c;
        this.c002_Detail__c = c002_Detail__c;
        this.c002_Katsudo__c = c002_Katsudo__c;
        this.c002_Katsudo__r = c002_Katsudo__r;
        this.c002_KyotenName__c = c002_KyotenName__c;
        this.c002_Outline__c = c002_Outline__c;
        this.c002_Place__c = c002_Place__c;
        this.c002_RMTanto__c = c002_RMTanto__c;
        this.c002_RecordTypeName2__c = c002_RecordTypeName2__c;
        this.c002_RelatedCaseID__c = c002_RelatedCaseID__c;
        this.c002_Remarks__c = c002_Remarks__c;
        this.c002_TaidoNyuryokuyo__c = c002_TaidoNyuryokuyo__c;
        this.c002_Taido__c = c002_Taido__c;
        this.c002_Taido__r = c002_Taido__r;
        this.c002_TantoButenName__c = c002_TantoButenName__c;
        this.c002_Tanto__c = c002_Tanto__c;
        this.c002_Tanto__r = c002_Tanto__r;
        this.c002_TantobuTemban__c = c002_TantobuTemban__c;
        this.c002_TaskName__c = c002_TaskName__c;
        this.c002_Tasks_01__r = c002_Tasks_01__r;
        this.c002_TembanCif__c = c002_TembanCif__c;
        this.c002_TokoKakuzuke__c = c002_TokoKakuzuke__c;
        this.c002_Type__c = c002_Type__c;
        this.c002_YomikomiNo__c = c002_YomikomiNo__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.duplicateRecordItems = duplicateRecordItems;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lastReferencedDate = lastReferencedDate;
        this.lastViewedDate = lastViewedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.recordType = recordType;
        this.recordTypeId = recordTypeId;
        this.shares = shares;
        this.systemModstamp = systemModstamp;
        this.topicAssignments = topicAssignments;
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the a013_Line__c value for this C002_Task__c.
     * 
     * @return a013_Line__c
     */
    public java.lang.String getA013_Line__c() {
        return a013_Line__c;
    }


    /**
     * Sets the a013_Line__c value for this C002_Task__c.
     * 
     * @param a013_Line__c
     */
    public void setA013_Line__c(java.lang.String a013_Line__c) {
        this.a013_Line__c = a013_Line__c;
    }


    /**
     * Gets the a014_CustomerContact__c value for this C002_Task__c.
     * 
     * @return a014_CustomerContact__c
     */
    public java.lang.String getA014_CustomerContact__c() {
        return a014_CustomerContact__c;
    }


    /**
     * Sets the a014_CustomerContact__c value for this C002_Task__c.
     * 
     * @param a014_CustomerContact__c
     */
    public void setA014_CustomerContact__c(java.lang.String a014_CustomerContact__c) {
        this.a014_CustomerContact__c = a014_CustomerContact__c;
    }


    /**
     * Gets the a014_Detail__c value for this C002_Task__c.
     * 
     * @return a014_Detail__c
     */
    public java.lang.String getA014_Detail__c() {
        return a014_Detail__c;
    }


    /**
     * Sets the a014_Detail__c value for this C002_Task__c.
     * 
     * @param a014_Detail__c
     */
    public void setA014_Detail__c(java.lang.String a014_Detail__c) {
        this.a014_Detail__c = a014_Detail__c;
    }


    /**
     * Gets the a014_Place__c value for this C002_Task__c.
     * 
     * @return a014_Place__c
     */
    public java.lang.String getA014_Place__c() {
        return a014_Place__c;
    }


    /**
     * Sets the a014_Place__c value for this C002_Task__c.
     * 
     * @param a014_Place__c
     */
    public void setA014_Place__c(java.lang.String a014_Place__c) {
        this.a014_Place__c = a014_Place__c;
    }


    /**
     * Gets the a014_Taido__c value for this C002_Task__c.
     * 
     * @return a014_Taido__c
     */
    public java.lang.String getA014_Taido__c() {
        return a014_Taido__c;
    }


    /**
     * Sets the a014_Taido__c value for this C002_Task__c.
     * 
     * @param a014_Taido__c
     */
    public void setA014_Taido__c(java.lang.String a014_Taido__c) {
        this.a014_Taido__c = a014_Taido__c;
    }


    /**
     * Gets the a014_TantouTeam__c value for this C002_Task__c.
     * 
     * @return a014_TantouTeam__c
     */
    public java.lang.String getA014_TantouTeam__c() {
        return a014_TantouTeam__c;
    }


    /**
     * Sets the a014_TantouTeam__c value for this C002_Task__c.
     * 
     * @param a014_TantouTeam__c
     */
    public void setA014_TantouTeam__c(java.lang.String a014_TantouTeam__c) {
        this.a014_TantouTeam__c = a014_TantouTeam__c;
    }


    /**
     * Gets the a014_Tantousha__c value for this C002_Task__c.
     * 
     * @return a014_Tantousha__c
     */
    public java.lang.String getA014_Tantousha__c() {
        return a014_Tantousha__c;
    }


    /**
     * Sets the a014_Tantousha__c value for this C002_Task__c.
     * 
     * @param a014_Tantousha__c
     */
    public void setA014_Tantousha__c(java.lang.String a014_Tantousha__c) {
        this.a014_Tantousha__c = a014_Tantousha__c;
    }


    /**
     * Gets the a014_TeianKirikuchi1__c value for this C002_Task__c.
     * 
     * @return a014_TeianKirikuchi1__c
     */
    public java.lang.Boolean getA014_TeianKirikuchi1__c() {
        return a014_TeianKirikuchi1__c;
    }


    /**
     * Sets the a014_TeianKirikuchi1__c value for this C002_Task__c.
     * 
     * @param a014_TeianKirikuchi1__c
     */
    public void setA014_TeianKirikuchi1__c(java.lang.Boolean a014_TeianKirikuchi1__c) {
        this.a014_TeianKirikuchi1__c = a014_TeianKirikuchi1__c;
    }


    /**
     * Gets the a014_TeianKirikuchi2__c value for this C002_Task__c.
     * 
     * @return a014_TeianKirikuchi2__c
     */
    public java.lang.Boolean getA014_TeianKirikuchi2__c() {
        return a014_TeianKirikuchi2__c;
    }


    /**
     * Sets the a014_TeianKirikuchi2__c value for this C002_Task__c.
     * 
     * @param a014_TeianKirikuchi2__c
     */
    public void setA014_TeianKirikuchi2__c(java.lang.Boolean a014_TeianKirikuchi2__c) {
        this.a014_TeianKirikuchi2__c = a014_TeianKirikuchi2__c;
    }


    /**
     * Gets the a014_TeianKirikuchi3__c value for this C002_Task__c.
     * 
     * @return a014_TeianKirikuchi3__c
     */
    public java.lang.Boolean getA014_TeianKirikuchi3__c() {
        return a014_TeianKirikuchi3__c;
    }


    /**
     * Sets the a014_TeianKirikuchi3__c value for this C002_Task__c.
     * 
     * @param a014_TeianKirikuchi3__c
     */
    public void setA014_TeianKirikuchi3__c(java.lang.Boolean a014_TeianKirikuchi3__c) {
        this.a014_TeianKirikuchi3__c = a014_TeianKirikuchi3__c;
    }


    /**
     * Gets the a014_TeianKirikuchi4__c value for this C002_Task__c.
     * 
     * @return a014_TeianKirikuchi4__c
     */
    public java.lang.Boolean getA014_TeianKirikuchi4__c() {
        return a014_TeianKirikuchi4__c;
    }


    /**
     * Sets the a014_TeianKirikuchi4__c value for this C002_Task__c.
     * 
     * @param a014_TeianKirikuchi4__c
     */
    public void setA014_TeianKirikuchi4__c(java.lang.Boolean a014_TeianKirikuchi4__c) {
        this.a014_TeianKirikuchi4__c = a014_TeianKirikuchi4__c;
    }


    /**
     * Gets the a014_TeianKirikuchi5__c value for this C002_Task__c.
     * 
     * @return a014_TeianKirikuchi5__c
     */
    public java.lang.Boolean getA014_TeianKirikuchi5__c() {
        return a014_TeianKirikuchi5__c;
    }


    /**
     * Sets the a014_TeianKirikuchi5__c value for this C002_Task__c.
     * 
     * @param a014_TeianKirikuchi5__c
     */
    public void setA014_TeianKirikuchi5__c(java.lang.Boolean a014_TeianKirikuchi5__c) {
        this.a014_TeianKirikuchi5__c = a014_TeianKirikuchi5__c;
    }


    /**
     * Gets the a014_TeianKirikuchiOtherDetail__c value for this C002_Task__c.
     * 
     * @return a014_TeianKirikuchiOtherDetail__c
     */
    public java.lang.String getA014_TeianKirikuchiOtherDetail__c() {
        return a014_TeianKirikuchiOtherDetail__c;
    }


    /**
     * Sets the a014_TeianKirikuchiOtherDetail__c value for this C002_Task__c.
     * 
     * @param a014_TeianKirikuchiOtherDetail__c
     */
    public void setA014_TeianKirikuchiOtherDetail__c(java.lang.String a014_TeianKirikuchiOtherDetail__c) {
        this.a014_TeianKirikuchiOtherDetail__c = a014_TeianKirikuchiOtherDetail__c;
    }


    /**
     * Gets the a014_TeianKirikuchiOther__c value for this C002_Task__c.
     * 
     * @return a014_TeianKirikuchiOther__c
     */
    public java.lang.Boolean getA014_TeianKirikuchiOther__c() {
        return a014_TeianKirikuchiOther__c;
    }


    /**
     * Sets the a014_TeianKirikuchiOther__c value for this C002_Task__c.
     * 
     * @param a014_TeianKirikuchiOther__c
     */
    public void setA014_TeianKirikuchiOther__c(java.lang.Boolean a014_TeianKirikuchiOther__c) {
        this.a014_TeianKirikuchiOther__c = a014_TeianKirikuchiOther__c;
    }


    /**
     * Gets the a014_TeianshoUmu__c value for this C002_Task__c.
     * 
     * @return a014_TeianshoUmu__c
     */
    public java.lang.Boolean getA014_TeianshoUmu__c() {
        return a014_TeianshoUmu__c;
    }


    /**
     * Sets the a014_TeianshoUmu__c value for this C002_Task__c.
     * 
     * @param a014_TeianshoUmu__c
     */
    public void setA014_TeianshoUmu__c(java.lang.Boolean a014_TeianshoUmu__c) {
        this.a014_TeianshoUmu__c = a014_TeianshoUmu__c;
    }


    /**
     * Gets the a015_HouzinCRMKiroku__c value for this C002_Task__c.
     * 
     * @return a015_HouzinCRMKiroku__c
     */
    public java.lang.Boolean getA015_HouzinCRMKiroku__c() {
        return a015_HouzinCRMKiroku__c;
    }


    /**
     * Sets the a015_HouzinCRMKiroku__c value for this C002_Task__c.
     * 
     * @param a015_HouzinCRMKiroku__c
     */
    public void setA015_HouzinCRMKiroku__c(java.lang.Boolean a015_HouzinCRMKiroku__c) {
        this.a015_HouzinCRMKiroku__c = a015_HouzinCRMKiroku__c;
    }


    /**
     * Gets the a015_Seika__c value for this C002_Task__c.
     * 
     * @return a015_Seika__c
     */
    public java.lang.String getA015_Seika__c() {
        return a015_Seika__c;
    }


    /**
     * Sets the a015_Seika__c value for this C002_Task__c.
     * 
     * @param a015_Seika__c
     */
    public void setA015_Seika__c(java.lang.String a015_Seika__c) {
        this.a015_Seika__c = a015_Seika__c;
    }


    /**
     * Gets the attachments value for this C002_Task__c.
     * 
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C002_Task__c.
     * 
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the c002_Action__c value for this C002_Task__c.
     * 
     * @return c002_Action__c
     */
    public java.lang.String getC002_Action__c() {
        return c002_Action__c;
    }


    /**
     * Sets the c002_Action__c value for this C002_Task__c.
     * 
     * @param c002_Action__c
     */
    public void setC002_Action__c(java.lang.String c002_Action__c) {
        this.c002_Action__c = c002_Action__c;
    }


    /**
     * Gets the c002_AllowedChangeCustomer__c value for this C002_Task__c.
     * 
     * @return c002_AllowedChangeCustomer__c
     */
    public java.lang.Boolean getC002_AllowedChangeCustomer__c() {
        return c002_AllowedChangeCustomer__c;
    }


    /**
     * Sets the c002_AllowedChangeCustomer__c value for this C002_Task__c.
     * 
     * @param c002_AllowedChangeCustomer__c
     */
    public void setC002_AllowedChangeCustomer__c(java.lang.Boolean c002_AllowedChangeCustomer__c) {
        this.c002_AllowedChangeCustomer__c = c002_AllowedChangeCustomer__c;
    }


    /**
     * Gets the c002_AppName__c value for this C002_Task__c.
     * 
     * @return c002_AppName__c
     */
    public java.lang.String getC002_AppName__c() {
        return c002_AppName__c;
    }


    /**
     * Sets the c002_AppName__c value for this C002_Task__c.
     * 
     * @param c002_AppName__c
     */
    public void setC002_AppName__c(java.lang.String c002_AppName__c) {
        this.c002_AppName__c = c002_AppName__c;
    }


    /**
     * Gets the c002_CRM_KatsudoId__c value for this C002_Task__c.
     * 
     * @return c002_CRM_KatsudoId__c
     */
    public java.lang.String getC002_CRM_KatsudoId__c() {
        return c002_CRM_KatsudoId__c;
    }


    /**
     * Sets the c002_CRM_KatsudoId__c value for this C002_Task__c.
     * 
     * @param c002_CRM_KatsudoId__c
     */
    public void setC002_CRM_KatsudoId__c(java.lang.String c002_CRM_KatsudoId__c) {
        this.c002_CRM_KatsudoId__c = c002_CRM_KatsudoId__c;
    }


    /**
     * Gets the c002_Confirm1__c value for this C002_Task__c.
     * 
     * @return c002_Confirm1__c
     */
    public java.lang.Boolean getC002_Confirm1__c() {
        return c002_Confirm1__c;
    }


    /**
     * Sets the c002_Confirm1__c value for this C002_Task__c.
     * 
     * @param c002_Confirm1__c
     */
    public void setC002_Confirm1__c(java.lang.Boolean c002_Confirm1__c) {
        this.c002_Confirm1__c = c002_Confirm1__c;
    }


    /**
     * Gets the c002_Confirm2__c value for this C002_Task__c.
     * 
     * @return c002_Confirm2__c
     */
    public java.lang.Boolean getC002_Confirm2__c() {
        return c002_Confirm2__c;
    }


    /**
     * Sets the c002_Confirm2__c value for this C002_Task__c.
     * 
     * @param c002_Confirm2__c
     */
    public void setC002_Confirm2__c(java.lang.Boolean c002_Confirm2__c) {
        this.c002_Confirm2__c = c002_Confirm2__c;
    }


    /**
     * Gets the c002_Confirm3__c value for this C002_Task__c.
     * 
     * @return c002_Confirm3__c
     */
    public java.lang.Boolean getC002_Confirm3__c() {
        return c002_Confirm3__c;
    }


    /**
     * Sets the c002_Confirm3__c value for this C002_Task__c.
     * 
     * @param c002_Confirm3__c
     */
    public void setC002_Confirm3__c(java.lang.Boolean c002_Confirm3__c) {
        this.c002_Confirm3__c = c002_Confirm3__c;
    }


    /**
     * Gets the c002_CsvKatsudo__c value for this C002_Task__c.
     * 
     * @return c002_CsvKatsudo__c
     */
    public java.lang.String getC002_CsvKatsudo__c() {
        return c002_CsvKatsudo__c;
    }


    /**
     * Sets the c002_CsvKatsudo__c value for this C002_Task__c.
     * 
     * @param c002_CsvKatsudo__c
     */
    public void setC002_CsvKatsudo__c(java.lang.String c002_CsvKatsudo__c) {
        this.c002_CsvKatsudo__c = c002_CsvKatsudo__c;
    }


    /**
     * Gets the c002_CsvRecordTantou__c value for this C002_Task__c.
     * 
     * @return c002_CsvRecordTantou__c
     */
    public java.lang.String getC002_CsvRecordTantou__c() {
        return c002_CsvRecordTantou__c;
    }


    /**
     * Sets the c002_CsvRecordTantou__c value for this C002_Task__c.
     * 
     * @param c002_CsvRecordTantou__c
     */
    public void setC002_CsvRecordTantou__c(java.lang.String c002_CsvRecordTantou__c) {
        this.c002_CsvRecordTantou__c = c002_CsvRecordTantou__c;
    }


    /**
     * Gets the c002_CsvTaido__c value for this C002_Task__c.
     * 
     * @return c002_CsvTaido__c
     */
    public java.lang.String getC002_CsvTaido__c() {
        return c002_CsvTaido__c;
    }


    /**
     * Sets the c002_CsvTaido__c value for this C002_Task__c.
     * 
     * @param c002_CsvTaido__c
     */
    public void setC002_CsvTaido__c(java.lang.String c002_CsvTaido__c) {
        this.c002_CsvTaido__c = c002_CsvTaido__c;
    }


    /**
     * Gets the c002_CustomerContact__c value for this C002_Task__c.
     * 
     * @return c002_CustomerContact__c
     */
    public java.lang.String getC002_CustomerContact__c() {
        return c002_CustomerContact__c;
    }


    /**
     * Sets the c002_CustomerContact__c value for this C002_Task__c.
     * 
     * @param c002_CustomerContact__c
     */
    public void setC002_CustomerContact__c(java.lang.String c002_CustomerContact__c) {
        this.c002_CustomerContact__c = c002_CustomerContact__c;
    }


    /**
     * Gets the c002_CustomerId__c value for this C002_Task__c.
     * 
     * @return c002_CustomerId__c
     */
    public java.lang.String getC002_CustomerId__c() {
        return c002_CustomerId__c;
    }


    /**
     * Sets the c002_CustomerId__c value for this C002_Task__c.
     * 
     * @param c002_CustomerId__c
     */
    public void setC002_CustomerId__c(java.lang.String c002_CustomerId__c) {
        this.c002_CustomerId__c = c002_CustomerId__c;
    }


    /**
     * Gets the c002_CustomerName__c value for this C002_Task__c.
     * 
     * @return c002_CustomerName__c
     */
    public java.lang.String getC002_CustomerName__c() {
        return c002_CustomerName__c;
    }


    /**
     * Sets the c002_CustomerName__c value for this C002_Task__c.
     * 
     * @param c002_CustomerName__c
     */
    public void setC002_CustomerName__c(java.lang.String c002_CustomerName__c) {
        this.c002_CustomerName__c = c002_CustomerName__c;
    }


    /**
     * Gets the c002_CustomerRef__c value for this C002_Task__c.
     * 
     * @return c002_CustomerRef__c
     */
    public java.lang.String getC002_CustomerRef__c() {
        return c002_CustomerRef__c;
    }


    /**
     * Sets the c002_CustomerRef__c value for this C002_Task__c.
     * 
     * @param c002_CustomerRef__c
     */
    public void setC002_CustomerRef__c(java.lang.String c002_CustomerRef__c) {
        this.c002_CustomerRef__c = c002_CustomerRef__c;
    }


    /**
     * Gets the c002_CustomerRef__r value for this C002_Task__c.
     * 
     * @return c002_CustomerRef__r
     */
    public com.sforce.soap.enterprise.sobject.C001_Customer__c getC002_CustomerRef__r() {
        return c002_CustomerRef__r;
    }


    /**
     * Sets the c002_CustomerRef__r value for this C002_Task__c.
     * 
     * @param c002_CustomerRef__r
     */
    public void setC002_CustomerRef__r(com.sforce.soap.enterprise.sobject.C001_Customer__c c002_CustomerRef__r) {
        this.c002_CustomerRef__r = c002_CustomerRef__r;
    }


    /**
     * Gets the c002_Date__c value for this C002_Task__c.
     * 
     * @return c002_Date__c
     */
    public java.util.Date getC002_Date__c() {
        return c002_Date__c;
    }


    /**
     * Sets the c002_Date__c value for this C002_Task__c.
     * 
     * @param c002_Date__c
     */
    public void setC002_Date__c(java.util.Date c002_Date__c) {
        this.c002_Date__c = c002_Date__c;
    }


    /**
     * Gets the c002_Detail__c value for this C002_Task__c.
     * 
     * @return c002_Detail__c
     */
    public java.lang.String getC002_Detail__c() {
        return c002_Detail__c;
    }


    /**
     * Sets the c002_Detail__c value for this C002_Task__c.
     * 
     * @param c002_Detail__c
     */
    public void setC002_Detail__c(java.lang.String c002_Detail__c) {
        this.c002_Detail__c = c002_Detail__c;
    }


    /**
     * Gets the c002_Katsudo__c value for this C002_Task__c.
     * 
     * @return c002_Katsudo__c
     */
    public java.lang.String getC002_Katsudo__c() {
        return c002_Katsudo__c;
    }


    /**
     * Sets the c002_Katsudo__c value for this C002_Task__c.
     * 
     * @param c002_Katsudo__c
     */
    public void setC002_Katsudo__c(java.lang.String c002_Katsudo__c) {
        this.c002_Katsudo__c = c002_Katsudo__c;
    }


    /**
     * Gets the c002_Katsudo__r value for this C002_Task__c.
     * 
     * @return c002_Katsudo__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getC002_Katsudo__r() {
        return c002_Katsudo__r;
    }


    /**
     * Sets the c002_Katsudo__r value for this C002_Task__c.
     * 
     * @param c002_Katsudo__r
     */
    public void setC002_Katsudo__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Katsudo__r) {
        this.c002_Katsudo__r = c002_Katsudo__r;
    }


    /**
     * Gets the c002_KyotenName__c value for this C002_Task__c.
     * 
     * @return c002_KyotenName__c
     */
    public java.lang.String getC002_KyotenName__c() {
        return c002_KyotenName__c;
    }


    /**
     * Sets the c002_KyotenName__c value for this C002_Task__c.
     * 
     * @param c002_KyotenName__c
     */
    public void setC002_KyotenName__c(java.lang.String c002_KyotenName__c) {
        this.c002_KyotenName__c = c002_KyotenName__c;
    }


    /**
     * Gets the c002_Outline__c value for this C002_Task__c.
     * 
     * @return c002_Outline__c
     */
    public java.lang.String getC002_Outline__c() {
        return c002_Outline__c;
    }


    /**
     * Sets the c002_Outline__c value for this C002_Task__c.
     * 
     * @param c002_Outline__c
     */
    public void setC002_Outline__c(java.lang.String c002_Outline__c) {
        this.c002_Outline__c = c002_Outline__c;
    }


    /**
     * Gets the c002_Place__c value for this C002_Task__c.
     * 
     * @return c002_Place__c
     */
    public java.lang.String getC002_Place__c() {
        return c002_Place__c;
    }


    /**
     * Sets the c002_Place__c value for this C002_Task__c.
     * 
     * @param c002_Place__c
     */
    public void setC002_Place__c(java.lang.String c002_Place__c) {
        this.c002_Place__c = c002_Place__c;
    }


    /**
     * Gets the c002_RMTanto__c value for this C002_Task__c.
     * 
     * @return c002_RMTanto__c
     */
    public java.lang.String getC002_RMTanto__c() {
        return c002_RMTanto__c;
    }


    /**
     * Sets the c002_RMTanto__c value for this C002_Task__c.
     * 
     * @param c002_RMTanto__c
     */
    public void setC002_RMTanto__c(java.lang.String c002_RMTanto__c) {
        this.c002_RMTanto__c = c002_RMTanto__c;
    }


    /**
     * Gets the c002_RecordTypeName2__c value for this C002_Task__c.
     * 
     * @return c002_RecordTypeName2__c
     */
    public java.lang.String getC002_RecordTypeName2__c() {
        return c002_RecordTypeName2__c;
    }


    /**
     * Sets the c002_RecordTypeName2__c value for this C002_Task__c.
     * 
     * @param c002_RecordTypeName2__c
     */
    public void setC002_RecordTypeName2__c(java.lang.String c002_RecordTypeName2__c) {
        this.c002_RecordTypeName2__c = c002_RecordTypeName2__c;
    }


    /**
     * Gets the c002_RelatedCaseID__c value for this C002_Task__c.
     * 
     * @return c002_RelatedCaseID__c
     */
    public java.lang.String getC002_RelatedCaseID__c() {
        return c002_RelatedCaseID__c;
    }


    /**
     * Sets the c002_RelatedCaseID__c value for this C002_Task__c.
     * 
     * @param c002_RelatedCaseID__c
     */
    public void setC002_RelatedCaseID__c(java.lang.String c002_RelatedCaseID__c) {
        this.c002_RelatedCaseID__c = c002_RelatedCaseID__c;
    }


    /**
     * Gets the c002_Remarks__c value for this C002_Task__c.
     * 
     * @return c002_Remarks__c
     */
    public java.lang.String getC002_Remarks__c() {
        return c002_Remarks__c;
    }


    /**
     * Sets the c002_Remarks__c value for this C002_Task__c.
     * 
     * @param c002_Remarks__c
     */
    public void setC002_Remarks__c(java.lang.String c002_Remarks__c) {
        this.c002_Remarks__c = c002_Remarks__c;
    }


    /**
     * Gets the c002_TaidoNyuryokuyo__c value for this C002_Task__c.
     * 
     * @return c002_TaidoNyuryokuyo__c
     */
    public java.lang.String getC002_TaidoNyuryokuyo__c() {
        return c002_TaidoNyuryokuyo__c;
    }


    /**
     * Sets the c002_TaidoNyuryokuyo__c value for this C002_Task__c.
     * 
     * @param c002_TaidoNyuryokuyo__c
     */
    public void setC002_TaidoNyuryokuyo__c(java.lang.String c002_TaidoNyuryokuyo__c) {
        this.c002_TaidoNyuryokuyo__c = c002_TaidoNyuryokuyo__c;
    }


    /**
     * Gets the c002_Taido__c value for this C002_Task__c.
     * 
     * @return c002_Taido__c
     */
    public java.lang.String getC002_Taido__c() {
        return c002_Taido__c;
    }


    /**
     * Sets the c002_Taido__c value for this C002_Task__c.
     * 
     * @param c002_Taido__c
     */
    public void setC002_Taido__c(java.lang.String c002_Taido__c) {
        this.c002_Taido__c = c002_Taido__c;
    }


    /**
     * Gets the c002_Taido__r value for this C002_Task__c.
     * 
     * @return c002_Taido__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getC002_Taido__r() {
        return c002_Taido__r;
    }


    /**
     * Sets the c002_Taido__r value for this C002_Task__c.
     * 
     * @param c002_Taido__r
     */
    public void setC002_Taido__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Taido__r) {
        this.c002_Taido__r = c002_Taido__r;
    }


    /**
     * Gets the c002_TantoButenName__c value for this C002_Task__c.
     * 
     * @return c002_TantoButenName__c
     */
    public java.lang.String getC002_TantoButenName__c() {
        return c002_TantoButenName__c;
    }


    /**
     * Sets the c002_TantoButenName__c value for this C002_Task__c.
     * 
     * @param c002_TantoButenName__c
     */
    public void setC002_TantoButenName__c(java.lang.String c002_TantoButenName__c) {
        this.c002_TantoButenName__c = c002_TantoButenName__c;
    }


    /**
     * Gets the c002_Tanto__c value for this C002_Task__c.
     * 
     * @return c002_Tanto__c
     */
    public java.lang.String getC002_Tanto__c() {
        return c002_Tanto__c;
    }


    /**
     * Sets the c002_Tanto__c value for this C002_Task__c.
     * 
     * @param c002_Tanto__c
     */
    public void setC002_Tanto__c(java.lang.String c002_Tanto__c) {
        this.c002_Tanto__c = c002_Tanto__c;
    }


    /**
     * Gets the c002_Tanto__r value for this C002_Task__c.
     * 
     * @return c002_Tanto__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getC002_Tanto__r() {
        return c002_Tanto__r;
    }


    /**
     * Sets the c002_Tanto__r value for this C002_Task__c.
     * 
     * @param c002_Tanto__r
     */
    public void setC002_Tanto__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c c002_Tanto__r) {
        this.c002_Tanto__r = c002_Tanto__r;
    }


    /**
     * Gets the c002_TantobuTemban__c value for this C002_Task__c.
     * 
     * @return c002_TantobuTemban__c
     */
    public java.lang.String getC002_TantobuTemban__c() {
        return c002_TantobuTemban__c;
    }


    /**
     * Sets the c002_TantobuTemban__c value for this C002_Task__c.
     * 
     * @param c002_TantobuTemban__c
     */
    public void setC002_TantobuTemban__c(java.lang.String c002_TantobuTemban__c) {
        this.c002_TantobuTemban__c = c002_TantobuTemban__c;
    }


    /**
     * Gets the c002_TaskName__c value for this C002_Task__c.
     * 
     * @return c002_TaskName__c
     */
    public java.lang.String getC002_TaskName__c() {
        return c002_TaskName__c;
    }


    /**
     * Sets the c002_TaskName__c value for this C002_Task__c.
     * 
     * @param c002_TaskName__c
     */
    public void setC002_TaskName__c(java.lang.String c002_TaskName__c) {
        this.c002_TaskName__c = c002_TaskName__c;
    }


    /**
     * Gets the c002_Tasks_01__r value for this C002_Task__c.
     * 
     * @return c002_Tasks_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC002_Tasks_01__r() {
        return c002_Tasks_01__r;
    }


    /**
     * Sets the c002_Tasks_01__r value for this C002_Task__c.
     * 
     * @param c002_Tasks_01__r
     */
    public void setC002_Tasks_01__r(com.sforce.soap.enterprise.QueryResult c002_Tasks_01__r) {
        this.c002_Tasks_01__r = c002_Tasks_01__r;
    }


    /**
     * Gets the c002_TembanCif__c value for this C002_Task__c.
     * 
     * @return c002_TembanCif__c
     */
    public java.lang.String getC002_TembanCif__c() {
        return c002_TembanCif__c;
    }


    /**
     * Sets the c002_TembanCif__c value for this C002_Task__c.
     * 
     * @param c002_TembanCif__c
     */
    public void setC002_TembanCif__c(java.lang.String c002_TembanCif__c) {
        this.c002_TembanCif__c = c002_TembanCif__c;
    }


    /**
     * Gets the c002_TokoKakuzuke__c value for this C002_Task__c.
     * 
     * @return c002_TokoKakuzuke__c
     */
    public java.lang.String getC002_TokoKakuzuke__c() {
        return c002_TokoKakuzuke__c;
    }


    /**
     * Sets the c002_TokoKakuzuke__c value for this C002_Task__c.
     * 
     * @param c002_TokoKakuzuke__c
     */
    public void setC002_TokoKakuzuke__c(java.lang.String c002_TokoKakuzuke__c) {
        this.c002_TokoKakuzuke__c = c002_TokoKakuzuke__c;
    }


    /**
     * Gets the c002_Type__c value for this C002_Task__c.
     * 
     * @return c002_Type__c
     */
    public java.lang.String getC002_Type__c() {
        return c002_Type__c;
    }


    /**
     * Sets the c002_Type__c value for this C002_Task__c.
     * 
     * @param c002_Type__c
     */
    public void setC002_Type__c(java.lang.String c002_Type__c) {
        this.c002_Type__c = c002_Type__c;
    }


    /**
     * Gets the c002_YomikomiNo__c value for this C002_Task__c.
     * 
     * @return c002_YomikomiNo__c
     */
    public java.lang.String getC002_YomikomiNo__c() {
        return c002_YomikomiNo__c;
    }


    /**
     * Sets the c002_YomikomiNo__c value for this C002_Task__c.
     * 
     * @param c002_YomikomiNo__c
     */
    public void setC002_YomikomiNo__c(java.lang.String c002_YomikomiNo__c) {
        this.c002_YomikomiNo__c = c002_YomikomiNo__c;
    }


    /**
     * Gets the combinedAttachments value for this C002_Task__c.
     * 
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C002_Task__c.
     * 
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C002_Task__c.
     * 
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C002_Task__c.
     * 
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C002_Task__c.
     * 
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C002_Task__c.
     * 
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C002_Task__c.
     * 
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C002_Task__c.
     * 
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the duplicateRecordItems value for this C002_Task__c.
     * 
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C002_Task__c.
     * 
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the histories value for this C002_Task__c.
     * 
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this C002_Task__c.
     * 
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this C002_Task__c.
     * 
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C002_Task__c.
     * 
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the lastModifiedBy value for this C002_Task__c.
     * 
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C002_Task__c.
     * 
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C002_Task__c.
     * 
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C002_Task__c.
     * 
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C002_Task__c.
     * 
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C002_Task__c.
     * 
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lastReferencedDate value for this C002_Task__c.
     * 
     * @return lastReferencedDate
     */
    public java.util.Calendar getLastReferencedDate() {
        return lastReferencedDate;
    }


    /**
     * Sets the lastReferencedDate value for this C002_Task__c.
     * 
     * @param lastReferencedDate
     */
    public void setLastReferencedDate(java.util.Calendar lastReferencedDate) {
        this.lastReferencedDate = lastReferencedDate;
    }


    /**
     * Gets the lastViewedDate value for this C002_Task__c.
     * 
     * @return lastViewedDate
     */
    public java.util.Calendar getLastViewedDate() {
        return lastViewedDate;
    }


    /**
     * Sets the lastViewedDate value for this C002_Task__c.
     * 
     * @param lastViewedDate
     */
    public void setLastViewedDate(java.util.Calendar lastViewedDate) {
        this.lastViewedDate = lastViewedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C002_Task__c.
     * 
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C002_Task__c.
     * 
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the name value for this C002_Task__c.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C002_Task__c.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C002_Task__c.
     * 
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C002_Task__c.
     * 
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C002_Task__c.
     * 
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C002_Task__c.
     * 
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the owner value for this C002_Task__c.
     * 
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this C002_Task__c.
     * 
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this C002_Task__c.
     * 
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this C002_Task__c.
     * 
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this C002_Task__c.
     * 
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C002_Task__c.
     * 
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C002_Task__c.
     * 
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C002_Task__c.
     * 
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the recordType value for this C002_Task__c.
     * 
     * @return recordType
     */
    public com.sforce.soap.enterprise.sobject.RecordType getRecordType() {
        return recordType;
    }


    /**
     * Sets the recordType value for this C002_Task__c.
     * 
     * @param recordType
     */
    public void setRecordType(com.sforce.soap.enterprise.sobject.RecordType recordType) {
        this.recordType = recordType;
    }


    /**
     * Gets the recordTypeId value for this C002_Task__c.
     * 
     * @return recordTypeId
     */
    public java.lang.String getRecordTypeId() {
        return recordTypeId;
    }


    /**
     * Sets the recordTypeId value for this C002_Task__c.
     * 
     * @param recordTypeId
     */
    public void setRecordTypeId(java.lang.String recordTypeId) {
        this.recordTypeId = recordTypeId;
    }


    /**
     * Gets the shares value for this C002_Task__c.
     * 
     * @return shares
     */
    public com.sforce.soap.enterprise.QueryResult getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this C002_Task__c.
     * 
     * @param shares
     */
    public void setShares(com.sforce.soap.enterprise.QueryResult shares) {
        this.shares = shares;
    }


    /**
     * Gets the systemModstamp value for this C002_Task__c.
     * 
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C002_Task__c.
     * 
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the topicAssignments value for this C002_Task__c.
     * 
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C002_Task__c.
     * 
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the userRecordAccess value for this C002_Task__c.
     * 
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C002_Task__c.
     * 
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C002_Task__c)) return false;
        C002_Task__c other = (C002_Task__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.a013_Line__c==null && other.getA013_Line__c()==null) || 
             (this.a013_Line__c!=null &&
              this.a013_Line__c.equals(other.getA013_Line__c()))) &&
            ((this.a014_CustomerContact__c==null && other.getA014_CustomerContact__c()==null) || 
             (this.a014_CustomerContact__c!=null &&
              this.a014_CustomerContact__c.equals(other.getA014_CustomerContact__c()))) &&
            ((this.a014_Detail__c==null && other.getA014_Detail__c()==null) || 
             (this.a014_Detail__c!=null &&
              this.a014_Detail__c.equals(other.getA014_Detail__c()))) &&
            ((this.a014_Place__c==null && other.getA014_Place__c()==null) || 
             (this.a014_Place__c!=null &&
              this.a014_Place__c.equals(other.getA014_Place__c()))) &&
            ((this.a014_Taido__c==null && other.getA014_Taido__c()==null) || 
             (this.a014_Taido__c!=null &&
              this.a014_Taido__c.equals(other.getA014_Taido__c()))) &&
            ((this.a014_TantouTeam__c==null && other.getA014_TantouTeam__c()==null) || 
             (this.a014_TantouTeam__c!=null &&
              this.a014_TantouTeam__c.equals(other.getA014_TantouTeam__c()))) &&
            ((this.a014_Tantousha__c==null && other.getA014_Tantousha__c()==null) || 
             (this.a014_Tantousha__c!=null &&
              this.a014_Tantousha__c.equals(other.getA014_Tantousha__c()))) &&
            ((this.a014_TeianKirikuchi1__c==null && other.getA014_TeianKirikuchi1__c()==null) || 
             (this.a014_TeianKirikuchi1__c!=null &&
              this.a014_TeianKirikuchi1__c.equals(other.getA014_TeianKirikuchi1__c()))) &&
            ((this.a014_TeianKirikuchi2__c==null && other.getA014_TeianKirikuchi2__c()==null) || 
             (this.a014_TeianKirikuchi2__c!=null &&
              this.a014_TeianKirikuchi2__c.equals(other.getA014_TeianKirikuchi2__c()))) &&
            ((this.a014_TeianKirikuchi3__c==null && other.getA014_TeianKirikuchi3__c()==null) || 
             (this.a014_TeianKirikuchi3__c!=null &&
              this.a014_TeianKirikuchi3__c.equals(other.getA014_TeianKirikuchi3__c()))) &&
            ((this.a014_TeianKirikuchi4__c==null && other.getA014_TeianKirikuchi4__c()==null) || 
             (this.a014_TeianKirikuchi4__c!=null &&
              this.a014_TeianKirikuchi4__c.equals(other.getA014_TeianKirikuchi4__c()))) &&
            ((this.a014_TeianKirikuchi5__c==null && other.getA014_TeianKirikuchi5__c()==null) || 
             (this.a014_TeianKirikuchi5__c!=null &&
              this.a014_TeianKirikuchi5__c.equals(other.getA014_TeianKirikuchi5__c()))) &&
            ((this.a014_TeianKirikuchiOtherDetail__c==null && other.getA014_TeianKirikuchiOtherDetail__c()==null) || 
             (this.a014_TeianKirikuchiOtherDetail__c!=null &&
              this.a014_TeianKirikuchiOtherDetail__c.equals(other.getA014_TeianKirikuchiOtherDetail__c()))) &&
            ((this.a014_TeianKirikuchiOther__c==null && other.getA014_TeianKirikuchiOther__c()==null) || 
             (this.a014_TeianKirikuchiOther__c!=null &&
              this.a014_TeianKirikuchiOther__c.equals(other.getA014_TeianKirikuchiOther__c()))) &&
            ((this.a014_TeianshoUmu__c==null && other.getA014_TeianshoUmu__c()==null) || 
             (this.a014_TeianshoUmu__c!=null &&
              this.a014_TeianshoUmu__c.equals(other.getA014_TeianshoUmu__c()))) &&
            ((this.a015_HouzinCRMKiroku__c==null && other.getA015_HouzinCRMKiroku__c()==null) || 
             (this.a015_HouzinCRMKiroku__c!=null &&
              this.a015_HouzinCRMKiroku__c.equals(other.getA015_HouzinCRMKiroku__c()))) &&
            ((this.a015_Seika__c==null && other.getA015_Seika__c()==null) || 
             (this.a015_Seika__c!=null &&
              this.a015_Seika__c.equals(other.getA015_Seika__c()))) &&
            ((this.attachments==null && other.getAttachments()==null) || 
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.c002_Action__c==null && other.getC002_Action__c()==null) || 
             (this.c002_Action__c!=null &&
              this.c002_Action__c.equals(other.getC002_Action__c()))) &&
            ((this.c002_AllowedChangeCustomer__c==null && other.getC002_AllowedChangeCustomer__c()==null) || 
             (this.c002_AllowedChangeCustomer__c!=null &&
              this.c002_AllowedChangeCustomer__c.equals(other.getC002_AllowedChangeCustomer__c()))) &&
            ((this.c002_AppName__c==null && other.getC002_AppName__c()==null) || 
             (this.c002_AppName__c!=null &&
              this.c002_AppName__c.equals(other.getC002_AppName__c()))) &&
            ((this.c002_CRM_KatsudoId__c==null && other.getC002_CRM_KatsudoId__c()==null) || 
             (this.c002_CRM_KatsudoId__c!=null &&
              this.c002_CRM_KatsudoId__c.equals(other.getC002_CRM_KatsudoId__c()))) &&
            ((this.c002_Confirm1__c==null && other.getC002_Confirm1__c()==null) || 
             (this.c002_Confirm1__c!=null &&
              this.c002_Confirm1__c.equals(other.getC002_Confirm1__c()))) &&
            ((this.c002_Confirm2__c==null && other.getC002_Confirm2__c()==null) || 
             (this.c002_Confirm2__c!=null &&
              this.c002_Confirm2__c.equals(other.getC002_Confirm2__c()))) &&
            ((this.c002_Confirm3__c==null && other.getC002_Confirm3__c()==null) || 
             (this.c002_Confirm3__c!=null &&
              this.c002_Confirm3__c.equals(other.getC002_Confirm3__c()))) &&
            ((this.c002_CsvKatsudo__c==null && other.getC002_CsvKatsudo__c()==null) || 
             (this.c002_CsvKatsudo__c!=null &&
              this.c002_CsvKatsudo__c.equals(other.getC002_CsvKatsudo__c()))) &&
            ((this.c002_CsvRecordTantou__c==null && other.getC002_CsvRecordTantou__c()==null) || 
             (this.c002_CsvRecordTantou__c!=null &&
              this.c002_CsvRecordTantou__c.equals(other.getC002_CsvRecordTantou__c()))) &&
            ((this.c002_CsvTaido__c==null && other.getC002_CsvTaido__c()==null) || 
             (this.c002_CsvTaido__c!=null &&
              this.c002_CsvTaido__c.equals(other.getC002_CsvTaido__c()))) &&
            ((this.c002_CustomerContact__c==null && other.getC002_CustomerContact__c()==null) || 
             (this.c002_CustomerContact__c!=null &&
              this.c002_CustomerContact__c.equals(other.getC002_CustomerContact__c()))) &&
            ((this.c002_CustomerId__c==null && other.getC002_CustomerId__c()==null) || 
             (this.c002_CustomerId__c!=null &&
              this.c002_CustomerId__c.equals(other.getC002_CustomerId__c()))) &&
            ((this.c002_CustomerName__c==null && other.getC002_CustomerName__c()==null) || 
             (this.c002_CustomerName__c!=null &&
              this.c002_CustomerName__c.equals(other.getC002_CustomerName__c()))) &&
            ((this.c002_CustomerRef__c==null && other.getC002_CustomerRef__c()==null) || 
             (this.c002_CustomerRef__c!=null &&
              this.c002_CustomerRef__c.equals(other.getC002_CustomerRef__c()))) &&
            ((this.c002_CustomerRef__r==null && other.getC002_CustomerRef__r()==null) || 
             (this.c002_CustomerRef__r!=null &&
              this.c002_CustomerRef__r.equals(other.getC002_CustomerRef__r()))) &&
            ((this.c002_Date__c==null && other.getC002_Date__c()==null) || 
             (this.c002_Date__c!=null &&
              this.c002_Date__c.equals(other.getC002_Date__c()))) &&
            ((this.c002_Detail__c==null && other.getC002_Detail__c()==null) || 
             (this.c002_Detail__c!=null &&
              this.c002_Detail__c.equals(other.getC002_Detail__c()))) &&
            ((this.c002_Katsudo__c==null && other.getC002_Katsudo__c()==null) || 
             (this.c002_Katsudo__c!=null &&
              this.c002_Katsudo__c.equals(other.getC002_Katsudo__c()))) &&
            ((this.c002_Katsudo__r==null && other.getC002_Katsudo__r()==null) || 
             (this.c002_Katsudo__r!=null &&
              this.c002_Katsudo__r.equals(other.getC002_Katsudo__r()))) &&
            ((this.c002_KyotenName__c==null && other.getC002_KyotenName__c()==null) || 
             (this.c002_KyotenName__c!=null &&
              this.c002_KyotenName__c.equals(other.getC002_KyotenName__c()))) &&
            ((this.c002_Outline__c==null && other.getC002_Outline__c()==null) || 
             (this.c002_Outline__c!=null &&
              this.c002_Outline__c.equals(other.getC002_Outline__c()))) &&
            ((this.c002_Place__c==null && other.getC002_Place__c()==null) || 
             (this.c002_Place__c!=null &&
              this.c002_Place__c.equals(other.getC002_Place__c()))) &&
            ((this.c002_RMTanto__c==null && other.getC002_RMTanto__c()==null) || 
             (this.c002_RMTanto__c!=null &&
              this.c002_RMTanto__c.equals(other.getC002_RMTanto__c()))) &&
            ((this.c002_RecordTypeName2__c==null && other.getC002_RecordTypeName2__c()==null) || 
             (this.c002_RecordTypeName2__c!=null &&
              this.c002_RecordTypeName2__c.equals(other.getC002_RecordTypeName2__c()))) &&
            ((this.c002_RelatedCaseID__c==null && other.getC002_RelatedCaseID__c()==null) || 
             (this.c002_RelatedCaseID__c!=null &&
              this.c002_RelatedCaseID__c.equals(other.getC002_RelatedCaseID__c()))) &&
            ((this.c002_Remarks__c==null && other.getC002_Remarks__c()==null) || 
             (this.c002_Remarks__c!=null &&
              this.c002_Remarks__c.equals(other.getC002_Remarks__c()))) &&
            ((this.c002_TaidoNyuryokuyo__c==null && other.getC002_TaidoNyuryokuyo__c()==null) || 
             (this.c002_TaidoNyuryokuyo__c!=null &&
              this.c002_TaidoNyuryokuyo__c.equals(other.getC002_TaidoNyuryokuyo__c()))) &&
            ((this.c002_Taido__c==null && other.getC002_Taido__c()==null) || 
             (this.c002_Taido__c!=null &&
              this.c002_Taido__c.equals(other.getC002_Taido__c()))) &&
            ((this.c002_Taido__r==null && other.getC002_Taido__r()==null) || 
             (this.c002_Taido__r!=null &&
              this.c002_Taido__r.equals(other.getC002_Taido__r()))) &&
            ((this.c002_TantoButenName__c==null && other.getC002_TantoButenName__c()==null) || 
             (this.c002_TantoButenName__c!=null &&
              this.c002_TantoButenName__c.equals(other.getC002_TantoButenName__c()))) &&
            ((this.c002_Tanto__c==null && other.getC002_Tanto__c()==null) || 
             (this.c002_Tanto__c!=null &&
              this.c002_Tanto__c.equals(other.getC002_Tanto__c()))) &&
            ((this.c002_Tanto__r==null && other.getC002_Tanto__r()==null) || 
             (this.c002_Tanto__r!=null &&
              this.c002_Tanto__r.equals(other.getC002_Tanto__r()))) &&
            ((this.c002_TantobuTemban__c==null && other.getC002_TantobuTemban__c()==null) || 
             (this.c002_TantobuTemban__c!=null &&
              this.c002_TantobuTemban__c.equals(other.getC002_TantobuTemban__c()))) &&
            ((this.c002_TaskName__c==null && other.getC002_TaskName__c()==null) || 
             (this.c002_TaskName__c!=null &&
              this.c002_TaskName__c.equals(other.getC002_TaskName__c()))) &&
            ((this.c002_Tasks_01__r==null && other.getC002_Tasks_01__r()==null) || 
             (this.c002_Tasks_01__r!=null &&
              this.c002_Tasks_01__r.equals(other.getC002_Tasks_01__r()))) &&
            ((this.c002_TembanCif__c==null && other.getC002_TembanCif__c()==null) || 
             (this.c002_TembanCif__c!=null &&
              this.c002_TembanCif__c.equals(other.getC002_TembanCif__c()))) &&
            ((this.c002_TokoKakuzuke__c==null && other.getC002_TokoKakuzuke__c()==null) || 
             (this.c002_TokoKakuzuke__c!=null &&
              this.c002_TokoKakuzuke__c.equals(other.getC002_TokoKakuzuke__c()))) &&
            ((this.c002_Type__c==null && other.getC002_Type__c()==null) || 
             (this.c002_Type__c!=null &&
              this.c002_Type__c.equals(other.getC002_Type__c()))) &&
            ((this.c002_YomikomiNo__c==null && other.getC002_YomikomiNo__c()==null) || 
             (this.c002_YomikomiNo__c!=null &&
              this.c002_YomikomiNo__c.equals(other.getC002_YomikomiNo__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) || 
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) || 
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) || 
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) || 
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.histories==null && other.getHistories()==null) || 
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) || 
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) || 
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) || 
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) || 
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lastReferencedDate==null && other.getLastReferencedDate()==null) || 
             (this.lastReferencedDate!=null &&
              this.lastReferencedDate.equals(other.getLastReferencedDate()))) &&
            ((this.lastViewedDate==null && other.getLastViewedDate()==null) || 
             (this.lastViewedDate!=null &&
              this.lastViewedDate.equals(other.getLastViewedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) || 
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) || 
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) || 
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) || 
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) || 
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) || 
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.recordType==null && other.getRecordType()==null) || 
             (this.recordType!=null &&
              this.recordType.equals(other.getRecordType()))) &&
            ((this.recordTypeId==null && other.getRecordTypeId()==null) || 
             (this.recordTypeId!=null &&
              this.recordTypeId.equals(other.getRecordTypeId()))) &&
            ((this.shares==null && other.getShares()==null) || 
             (this.shares!=null &&
              this.shares.equals(other.getShares()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) || 
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) || 
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) || 
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getA013_Line__c() != null) {
            _hashCode += getA013_Line__c().hashCode();
        }
        if (getA014_CustomerContact__c() != null) {
            _hashCode += getA014_CustomerContact__c().hashCode();
        }
        if (getA014_Detail__c() != null) {
            _hashCode += getA014_Detail__c().hashCode();
        }
        if (getA014_Place__c() != null) {
            _hashCode += getA014_Place__c().hashCode();
        }
        if (getA014_Taido__c() != null) {
            _hashCode += getA014_Taido__c().hashCode();
        }
        if (getA014_TantouTeam__c() != null) {
            _hashCode += getA014_TantouTeam__c().hashCode();
        }
        if (getA014_Tantousha__c() != null) {
            _hashCode += getA014_Tantousha__c().hashCode();
        }
        if (getA014_TeianKirikuchi1__c() != null) {
            _hashCode += getA014_TeianKirikuchi1__c().hashCode();
        }
        if (getA014_TeianKirikuchi2__c() != null) {
            _hashCode += getA014_TeianKirikuchi2__c().hashCode();
        }
        if (getA014_TeianKirikuchi3__c() != null) {
            _hashCode += getA014_TeianKirikuchi3__c().hashCode();
        }
        if (getA014_TeianKirikuchi4__c() != null) {
            _hashCode += getA014_TeianKirikuchi4__c().hashCode();
        }
        if (getA014_TeianKirikuchi5__c() != null) {
            _hashCode += getA014_TeianKirikuchi5__c().hashCode();
        }
        if (getA014_TeianKirikuchiOtherDetail__c() != null) {
            _hashCode += getA014_TeianKirikuchiOtherDetail__c().hashCode();
        }
        if (getA014_TeianKirikuchiOther__c() != null) {
            _hashCode += getA014_TeianKirikuchiOther__c().hashCode();
        }
        if (getA014_TeianshoUmu__c() != null) {
            _hashCode += getA014_TeianshoUmu__c().hashCode();
        }
        if (getA015_HouzinCRMKiroku__c() != null) {
            _hashCode += getA015_HouzinCRMKiroku__c().hashCode();
        }
        if (getA015_Seika__c() != null) {
            _hashCode += getA015_Seika__c().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getC002_Action__c() != null) {
            _hashCode += getC002_Action__c().hashCode();
        }
        if (getC002_AllowedChangeCustomer__c() != null) {
            _hashCode += getC002_AllowedChangeCustomer__c().hashCode();
        }
        if (getC002_AppName__c() != null) {
            _hashCode += getC002_AppName__c().hashCode();
        }
        if (getC002_CRM_KatsudoId__c() != null) {
            _hashCode += getC002_CRM_KatsudoId__c().hashCode();
        }
        if (getC002_Confirm1__c() != null) {
            _hashCode += getC002_Confirm1__c().hashCode();
        }
        if (getC002_Confirm2__c() != null) {
            _hashCode += getC002_Confirm2__c().hashCode();
        }
        if (getC002_Confirm3__c() != null) {
            _hashCode += getC002_Confirm3__c().hashCode();
        }
        if (getC002_CsvKatsudo__c() != null) {
            _hashCode += getC002_CsvKatsudo__c().hashCode();
        }
        if (getC002_CsvRecordTantou__c() != null) {
            _hashCode += getC002_CsvRecordTantou__c().hashCode();
        }
        if (getC002_CsvTaido__c() != null) {
            _hashCode += getC002_CsvTaido__c().hashCode();
        }
        if (getC002_CustomerContact__c() != null) {
            _hashCode += getC002_CustomerContact__c().hashCode();
        }
        if (getC002_CustomerId__c() != null) {
            _hashCode += getC002_CustomerId__c().hashCode();
        }
        if (getC002_CustomerName__c() != null) {
            _hashCode += getC002_CustomerName__c().hashCode();
        }
        if (getC002_CustomerRef__c() != null) {
            _hashCode += getC002_CustomerRef__c().hashCode();
        }
        if (getC002_CustomerRef__r() != null) {
            _hashCode += getC002_CustomerRef__r().hashCode();
        }
        if (getC002_Date__c() != null) {
            _hashCode += getC002_Date__c().hashCode();
        }
        if (getC002_Detail__c() != null) {
            _hashCode += getC002_Detail__c().hashCode();
        }
        if (getC002_Katsudo__c() != null) {
            _hashCode += getC002_Katsudo__c().hashCode();
        }
        if (getC002_Katsudo__r() != null) {
            _hashCode += getC002_Katsudo__r().hashCode();
        }
        if (getC002_KyotenName__c() != null) {
            _hashCode += getC002_KyotenName__c().hashCode();
        }
        if (getC002_Outline__c() != null) {
            _hashCode += getC002_Outline__c().hashCode();
        }
        if (getC002_Place__c() != null) {
            _hashCode += getC002_Place__c().hashCode();
        }
        if (getC002_RMTanto__c() != null) {
            _hashCode += getC002_RMTanto__c().hashCode();
        }
        if (getC002_RecordTypeName2__c() != null) {
            _hashCode += getC002_RecordTypeName2__c().hashCode();
        }
        if (getC002_RelatedCaseID__c() != null) {
            _hashCode += getC002_RelatedCaseID__c().hashCode();
        }
        if (getC002_Remarks__c() != null) {
            _hashCode += getC002_Remarks__c().hashCode();
        }
        if (getC002_TaidoNyuryokuyo__c() != null) {
            _hashCode += getC002_TaidoNyuryokuyo__c().hashCode();
        }
        if (getC002_Taido__c() != null) {
            _hashCode += getC002_Taido__c().hashCode();
        }
        if (getC002_Taido__r() != null) {
            _hashCode += getC002_Taido__r().hashCode();
        }
        if (getC002_TantoButenName__c() != null) {
            _hashCode += getC002_TantoButenName__c().hashCode();
        }
        if (getC002_Tanto__c() != null) {
            _hashCode += getC002_Tanto__c().hashCode();
        }
        if (getC002_Tanto__r() != null) {
            _hashCode += getC002_Tanto__r().hashCode();
        }
        if (getC002_TantobuTemban__c() != null) {
            _hashCode += getC002_TantobuTemban__c().hashCode();
        }
        if (getC002_TaskName__c() != null) {
            _hashCode += getC002_TaskName__c().hashCode();
        }
        if (getC002_Tasks_01__r() != null) {
            _hashCode += getC002_Tasks_01__r().hashCode();
        }
        if (getC002_TembanCif__c() != null) {
            _hashCode += getC002_TembanCif__c().hashCode();
        }
        if (getC002_TokoKakuzuke__c() != null) {
            _hashCode += getC002_TokoKakuzuke__c().hashCode();
        }
        if (getC002_Type__c() != null) {
            _hashCode += getC002_Type__c().hashCode();
        }
        if (getC002_YomikomiNo__c() != null) {
            _hashCode += getC002_YomikomiNo__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLastReferencedDate() != null) {
            _hashCode += getLastReferencedDate().hashCode();
        }
        if (getLastViewedDate() != null) {
            _hashCode += getLastViewedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getRecordType() != null) {
            _hashCode += getRecordType().hashCode();
        }
        if (getRecordTypeId() != null) {
            _hashCode += getRecordTypeId().hashCode();
        }
        if (getShares() != null) {
            _hashCode += getShares().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C002_Task__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Task__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a013_Line__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A013_Line__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_CustomerContact__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_CustomerContact__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_Detail__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_Detail__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_Place__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_Place__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_Taido__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_Taido__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TantouTeam__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TantouTeam__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_Tantousha__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_Tantousha__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TeianKirikuchi1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TeianKirikuchi1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TeianKirikuchi2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TeianKirikuchi2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TeianKirikuchi3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TeianKirikuchi3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TeianKirikuchi4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TeianKirikuchi4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TeianKirikuchi5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TeianKirikuchi5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TeianKirikuchiOtherDetail__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TeianKirikuchiOtherDetail__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TeianKirikuchiOther__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TeianKirikuchiOther__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a014_TeianshoUmu__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A014_TeianshoUmu__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a015_HouzinCRMKiroku__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A015_HouzinCRMKiroku__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a015_Seika__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A015_Seika__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Action__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Action__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_AllowedChangeCustomer__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_AllowedChangeCustomer__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_AppName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_AppName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CRM_KatsudoId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CRM_KatsudoId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Confirm1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Confirm1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Confirm2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Confirm2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Confirm3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Confirm3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CsvKatsudo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CsvKatsudo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CsvRecordTantou__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CsvRecordTantou__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CsvTaido__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CsvTaido__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CustomerContact__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CustomerContact__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CustomerId__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CustomerId__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CustomerName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CustomerName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CustomerRef__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CustomerRef__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_CustomerRef__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_CustomerRef__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C001_Customer__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Date__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Date__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Detail__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Detail__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Katsudo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Katsudo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Katsudo__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Katsudo__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_KyotenName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_KyotenName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Outline__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Outline__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Place__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Place__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RMTanto__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RMTanto__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RecordTypeName2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RecordTypeName2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_RelatedCaseID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_RelatedCaseID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Remarks__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Remarks__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_TaidoNyuryokuyo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_TaidoNyuryokuyo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Taido__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Taido__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Taido__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Taido__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_TantoButenName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_TantoButenName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tanto__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tanto__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tanto__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tanto__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_TantobuTemban__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_TantobuTemban__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_TaskName__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_TaskName__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Tasks_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Tasks_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_TembanCif__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_TembanCif__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_TokoKakuzuke__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_TokoKakuzuke__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_Type__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_Type__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c002_YomikomiNo__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C002_YomikomiNo__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastReferencedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastReferencedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastViewedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastViewedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recordType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RecordType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RecordType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recordTypeId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RecordTypeId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
