/**
 * C000_CIFZOKUSEIINFO__c.java
 *
 * このファイルはWSDLから自動生成されました / [en]-(This file was auto-generated from WSDL)
 * Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java生成器によって / [en]-(by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.)
 */

package com.sforce.soap.enterprise.sobject;

public class C000_CIFZOKUSEIINFO__c  extends com.sforce.soap.enterprise.sobject.SObject  implements java.io.Serializable {
    private com.sforce.soap.enterprise.QueryResult a001_ANKEN_MiorikomiJoho_01__r;

    private com.sforce.soap.enterprise.QueryResult a001_ANKEN_TorikomiJoho_03__r;

    private com.sforce.soap.enterprise.QueryResult a002_ANKEN_Zairyou_001__r;

    private com.sforce.soap.enterprise.QueryResult a004_Kokyaku_01__r;

    private com.sforce.soap.enterprise.QueryResult a005_SERAs__r;

    private com.sforce.soap.enterprise.QueryResult a019_CIFs_01__r;

    private java.lang.String ADDRESSCD__c;

    private java.lang.String ADDRESS_KANJI__c;

    private java.lang.String AREAINFOCD__c;

    private com.sforce.soap.enterprise.QueryResult activityHistories;

    private com.sforce.soap.enterprise.QueryResult attachments;

    private java.lang.String BOUEKIKBN__c;

    private java.lang.String BUMONKBN__c;

    private java.lang.String BUMONSAIKUBUN1__c;

    private java.lang.String BUMONSAIKUBUN2__c;

    private java.lang.String BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;

    private com.sforce.soap.enterprise.sobject.C000_BUSHOINFO__c BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r;

    private java.lang.String BUTENBANGOU__c;

    private java.lang.String BUTENNMRENKETSU__c;

    private com.sforce.soap.enterprise.QueryResult c000_059_CIF_RATING_HISTORY_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_ChohyoSera_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r;

    private com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r;

    private com.sforce.soap.enterprise.QueryResult c001_CIFs_01__r;

    private com.sforce.soap.enterprise.QueryResult c003_CIFs_01__r;

    private com.sforce.soap.enterprise.QueryResult CIFZOKUSEIINFO__r;

    private com.sforce.soap.enterprise.QueryResult CIFZOKUSEIINFOs__r;

    private java.lang.String COUNTRYCD__c;

    private com.sforce.soap.enterprise.QueryResult combinedAttachments;

    private com.sforce.soap.enterprise.sobject.User createdBy;

    private java.lang.String createdById;

    private java.util.Calendar createdDate;

    private com.sforce.soap.enterprise.QueryResult d002_001__r;

    private com.sforce.soap.enterprise.QueryResult d002_002__r;

    private com.sforce.soap.enterprise.QueryResult d003_001__r;

    private com.sforce.soap.enterprise.QueryResult d003_002__r;

    private com.sforce.soap.enterprise.QueryResult d004_ToDoSnaps02__r;

    private com.sforce.soap.enterprise.QueryResult d004_ToDoSnaps__r;

    private com.sforce.soap.enterprise.QueryResult d004_ToDos02__r;

    private com.sforce.soap.enterprise.QueryResult d004_ToDos__r;

    private java.lang.Boolean DELFLG__c;

    private java.lang.String DENWABANGOU__c;

    private java.lang.String DMDOUIKBN__c;

    private com.sforce.soap.enterprise.QueryResult duplicateRecordItems;

    private com.sforce.soap.enterprise.QueryResult events;

    private java.lang.String GAISHIKEIKBN__c;

    private java.util.Date GAITAMETORIHIKIKAISHIBI__c;

    private java.util.Date GAITAMEYOSHINTORIHIKIKAISHIBI__c;

    private java.lang.String GCIFBANGOU__c;

    private java.lang.String GYOUSHUCD1__c;

    private java.lang.String GYOUSHUCD2__c;

    private java.lang.String GYOUSHUCD3__c;

    private java.lang.String HATANSAKISAIKUBUN__c;

    private java.lang.String HIKIATEHYOUKA__c;

    private java.lang.String HONBUTANTOUBUMONCD1__c;

    private java.lang.String HONBUTANTOUSHACD1__c;

    private java.lang.Double HYOUTEN__c;

    private com.sforce.soap.enterprise.QueryResult histories;

    private java.lang.Boolean isDeleted;

    private java.lang.String JCR_CSKHENKOUKBN__c;

    private java.lang.String JCR_CSKKEY1__c;

    private java.lang.String JCR_CSKKEY2__c;

    private java.util.Date JCR_CSKSTB__c;

    private java.lang.String JCR_CSK__c;

    private java.lang.String JCR_HAKKOUTAIID__c;

    private java.lang.String JCR_HAKKOUTAI_NM__c;

    private java.util.Date JCR_KIJUNBI__c;

    private java.lang.String JCR_MCKHENKOUKBN_CH__c;

    private java.lang.String JCR_MCKHENKOUKBN__c;

    private java.util.Date JCR_MCKSTB__c;

    private java.lang.String JCR_MCK_CH__c;

    private java.lang.String JCR_MCK__c;

    private java.lang.String JCR_MINASHIHANBETSUCD__c;

    private java.util.Date JCR_YUUKOUKIKANSHUURYOUBI__c;

    private java.lang.String JIGYOUSHA_HIJIGYOUSHAKBN__c;

    private java.lang.String JINKAKUKBN__c;

    private java.lang.String JOUJOUKBN1__c;

    private java.lang.String JOUJOUKBN2__c;

    private java.lang.String JOUJOUKBN3__c;

    private java.lang.String JOUJOUKBN__c;

    private java.lang.String JUNKYOHOUKBN__c;

    private java.lang.Double JUUGYOUIN_CNT__c;

    private java.lang.String KABUSHIKICD__c;

    private java.lang.String KACD__c;

    private java.util.Date KAKUDUKEHENKOUBI__c;

    private java.util.Date KAKUDUKEKOUSHINBI__c;

    private java.lang.String KAKUDUKESAIKUBUN__c;

    private java.lang.String KANJISHIMEI__c;

    private java.lang.String KANRISAKIKBN__c;

    private java.util.Date KANSAJISSHIBI__c;

    private java.lang.String KASHIGAITORIHIKIUMUKBN__c;

    private java.lang.String KA_GROUPNM__c;

    private java.lang.String KEIRETSU_KANJI__c;

    private java.lang.String KENSAKUYOUKANASHOUGOU__c;

    private java.lang.String KENSAKUYOUKANJISHOUGOU__c;

    private java.lang.String KESSANNENGETSU2__c;

    private java.lang.String KESSANNENGETSU3__c;

    private java.lang.String KESSANNENGETSU__c;

    private java.lang.String KESSANTSUKI_CHUU__c;

    private java.lang.String KESSANTSUKI_HON__c;

    private java.lang.String KIGYOUBANGOU__c;

    private java.lang.String KIGYOUKIBOCD__c;

    private java.lang.String KIGYOUSEG__c;

    private java.util.Date KOKUNAIYOSHINTORIHIKIKAISHIBI__c;

    private java.lang.String KOKYAKUBANGOU__c;

    private java.lang.String KOKYAKUKANRITENBAN__c;

    private java.lang.String KOUKINCD__c;

    private java.util.Date KOUSHINBI__c;

    private java.lang.String KOZATEMMEI__c;

    private java.lang.String KOZATENJOHO__c;

    private com.sforce.soap.enterprise.sobject.C000_BUSHOINFO__c KOZATENJOHO__r;

    private java.lang.String KYOJUUSEIKBN__c;

    private java.lang.String KYOTENHAIKAKAISOU1_BUTENBANGOU__c;

    private java.lang.String KYOTENHAIKAKAISOU2_BUTENBANGOU__c;

    private java.lang.String KYOTENHAIKAKAISOU3_BUTENBANGOU__c;

    private java.lang.String KYOTENSEG__c;

    private java.lang.String KYOTEN_BUTENBANGOU__c;

    private java.lang.String KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c;

    private java.lang.String KYOUTSUUNINSHOUKOUININFO_USERID__c;

    private com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c KYOUTSUUNINSHOUKOUININFO_USERID__r;

    private java.util.Date lastActivityDate;

    private com.sforce.soap.enterprise.sobject.User lastModifiedBy;

    private java.lang.String lastModifiedById;

    private java.util.Calendar lastModifiedDate;

    private com.sforce.soap.enterprise.QueryResult lookedUpFromActivities;

    private java.lang.String MAINKICHOUCIF_SYSTEMKBN__c;

    private java.lang.String MAINKICHOUCIF_ZOKUSEIBANGOU__c;

    private java.lang.String MAINKICHOUCIF__c;

    private java.lang.Boolean MAIN_CIF_FLG__c;

    private java.lang.String MO_HAKKOUTAIID__c;

    private java.lang.String MO_HAKKOUTAI_NM__c;

    private java.lang.String MO_JDCHKKEY__c;

    private java.lang.String MO_JDCHKRD__c;

    private java.util.Date MO_JDCHKSTB__c;

    private java.lang.String MO_JDCHKWR__c;

    private java.lang.String MO_JDCHK__c;

    private java.util.Date MO_KIJUNBI__c;

    private java.lang.String MO_MCKHENKOUKBN_CH__c;

    private java.lang.String MO_MCKRD__c;

    private java.util.Date MO_MCKSTB__c;

    private java.lang.String MO_MCKWR__c;

    private java.lang.String MO_MCK_CH__c;

    private java.lang.String MO_MCK__c;

    private java.lang.String MO_MINASHIHANBETSUCD__c;

    private java.util.Date MO_YUUKOUKIKANSHUURYOUBI__c;

    private java.lang.String m_CIF_FLG__c;

    private java.lang.String NIKKEI_HINIKKEIKBN__c;

    private java.lang.String name;

    private com.sforce.soap.enterprise.QueryResult notes;

    private com.sforce.soap.enterprise.QueryResult notesAndAttachments;

    private java.lang.String OUTLOOK__c;

    private com.sforce.soap.enterprise.QueryResult openActivities;

    private com.sforce.soap.enterprise.sobject.Name owner;

    private java.lang.String ownerId;

    private com.sforce.soap.enterprise.QueryResult processInstances;

    private com.sforce.soap.enterprise.QueryResult processSteps;

    private java.lang.Double RIEKI_KIN_SENUNIT2__c;

    private java.lang.Double RIEKI_KIN_SENUNIT3__c;

    private java.lang.Double RIEKI_KIN_SENUNIT__c;

    private java.lang.String RINGI_SAIRYOUKBN__c;

    private java.lang.String RI_CSKHENKOUKBN__c;

    private java.lang.String RI_CSKKEY1__c;

    private java.lang.String RI_CSKKEY2__c;

    private java.util.Date RI_CSKSTB__c;

    private java.lang.String RI_CSK__c;

    private java.lang.String RI_HAKKOUTAIID__c;

    private java.lang.String RI_HAKKOUTAI_NM__c;

    private java.util.Date RI_KIJUNBI__c;

    private java.lang.String RI_MCKHENKOUKBN_CH__c;

    private java.lang.String RI_MCKHK__c;

    private java.util.Date RI_MCKSTB__c;

    private java.lang.String RI_MCK_CH__c;

    private java.lang.String RI_MCK__c;

    private java.lang.String RI_MINASHIHANBETSUCD__c;

    private java.util.Date RI_YUUKOUKIKANSHUURYOUBI__c;

    private java.lang.String RMFFLG__c;

    private java.lang.String SAIMUCHOUKASAKIKBN__c;

    private java.util.Date SAIMUSHAKAKUDUKEYUUKOUKIGEN__c;

    private java.lang.String SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c;

    private java.lang.String SAIMUSHAKAKUDUKE__c;

    private java.lang.String SAIMUSHAKBN__c;

    private java.lang.String SAIMUSHA_HISAIMUSHAKBN__c;

    private java.lang.String SETAIKANRITANTOUSHA__c;

    private java.util.Date SETSURITSUNENGETSUBI__c;

    private java.lang.Double SHIHONKIN__c;

    private java.lang.Double SHINKOKUSHOTOKUKINGAKU2__c;

    private java.lang.Double SHINKOKUSHOTOKUKINGAKU3__c;

    private java.lang.Double SHINKOKUSHOTOKUKINGAKU__c;

    private java.lang.String SHINMITSUDO__c;

    private java.lang.String SHOUGOU_KANJI__c;

    private java.lang.String SHOUKYAKUKBN__c;

    private java.lang.String SHOZAICHI_KANJI__c;

    private java.lang.String SHURYOKUTAKOU1__c;

    private java.lang.String SHURYOKUTAKOU2__c;

    private java.lang.String SHURYOKUTAKOU3__c;

    private java.lang.String SP_HAKKOUTAIID__c;

    private java.lang.String SP_HAKKOUTAI_NM__c;

    private java.lang.String SP_JDCHKLOOK__c;

    private java.util.Date SP_JDCHKSTB__c;

    private java.lang.String SP_JDCHKW__c;

    private java.lang.String SP_JDCHK__c;

    private java.util.Date SP_KIJUNBI__c;

    private java.lang.String SP_MCKHENKOUKBN_CH__c;

    private java.lang.String SP_MCKLOOK__c;

    private java.util.Date SP_MCKSTB__c;

    private java.lang.String SP_MCKW__c;

    private java.lang.String SP_MCK_CH__c;

    private java.lang.String SP_MCK__c;

    private java.lang.String SP_MINASHIHANBETSUCD__c;

    private java.util.Date SP_YUUKOUKIKANSHUURYOUBI__c;

    private com.sforce.soap.enterprise.QueryResult saikenJotoTsuchi_CifzkuseiInfo__r;

    private com.sforce.soap.enterprise.QueryResult shares;

    private java.util.Calendar systemModstamp;

    private java.lang.String TANTOUSHACD1__c;

    private java.lang.String TANTOUSHACD2__c;

    private java.lang.String TDBSANGYOUBUNRUICD1__c;

    private java.lang.String TDBSANGYOUBUNRUICD2__c;

    private java.lang.String TDBSANGYOUBUNRUICD3__c;

    private java.lang.String TDBSANGYOUBUNRUICD4__c;

    private java.lang.String TDBSANGYOUBUNRUICD5__c;

    private java.lang.String TEAMCD__c;

    private java.lang.String TEKIKAKUKAISHACD__c;

    private java.lang.String TENBAN_3_KOKYAKUBANGOU__c;

    private java.lang.String TENBAN_3__c;

    private java.lang.String TENBAN_KOKYAKUBANGOU__c;

    private java.lang.String TENBAN__c;

    private java.lang.String TKCKAIIN__c;

    private java.lang.String TKCKANYOSAKI__c;

    private java.lang.String TORIHIKIBANKCD10__c;

    private java.lang.String TORIHIKIBANKCD1__c;

    private java.lang.String TORIHIKIBANKCD2__c;

    private java.lang.String TORIHIKIBANKCD3__c;

    private java.lang.String TORIHIKIBANKCD4__c;

    private java.lang.String TORIHIKIBANKCD5__c;

    private java.lang.String TORIHIKIBANKCD6__c;

    private java.lang.String TORIHIKIBANKCD7__c;

    private java.lang.String TORIHIKIBANKCD8__c;

    private java.lang.String TORIHIKIBANKCD9__c;

    private java.lang.String TORIHIKISAKI_NM_EIJI__c;

    private java.lang.String TORIHIKISAKI_NM_JOIN__c;

    private java.lang.String TORIHIKISAKI_NM_KANA__c;

    private java.lang.String TORIHIKISAKI_NM_KANJI__c;

    private java.lang.String TSUUSHINKBN__c;

    private com.sforce.soap.enterprise.QueryResult tasks;

    private com.sforce.soap.enterprise.QueryResult topicAssignments;

    private java.lang.Double URIAGEDAKA_HYAKUMANUNIT2__c;

    private java.lang.Double URIAGEDAKA_HYAKUMANUNIT3__c;

    private java.lang.Double URIAGEDAKA_HYAKUMANUNIT__c;

    private java.lang.String USERID_EDABAN__c;

    private java.lang.String USERID__c;

    private com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess;

    private java.util.Date YOKINTORIHIKIKAISHIBI__c;

    private java.lang.String YUUBINBANGOU__c;

    public C000_CIFZOKUSEIINFO__c() {
    }

    public C000_CIFZOKUSEIINFO__c(
           java.lang.String[] fieldsToNull,
           java.lang.String id,
           com.sforce.soap.enterprise.QueryResult a001_ANKEN_MiorikomiJoho_01__r,
           com.sforce.soap.enterprise.QueryResult a001_ANKEN_TorikomiJoho_03__r,
           com.sforce.soap.enterprise.QueryResult a002_ANKEN_Zairyou_001__r,
           com.sforce.soap.enterprise.QueryResult a004_Kokyaku_01__r,
           com.sforce.soap.enterprise.QueryResult a005_SERAs__r,
           com.sforce.soap.enterprise.QueryResult a019_CIFs_01__r,
           java.lang.String ADDRESSCD__c,
           java.lang.String ADDRESS_KANJI__c,
           java.lang.String AREAINFOCD__c,
           com.sforce.soap.enterprise.QueryResult activityHistories,
           com.sforce.soap.enterprise.QueryResult attachments,
           java.lang.String BOUEKIKBN__c,
           java.lang.String BUMONKBN__c,
           java.lang.String BUMONSAIKUBUN1__c,
           java.lang.String BUMONSAIKUBUN2__c,
           java.lang.String BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c,
           com.sforce.soap.enterprise.sobject.C000_BUSHOINFO__c BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r,
           java.lang.String BUTENBANGOU__c,
           java.lang.String BUTENNMRENKETSU__c,
           com.sforce.soap.enterprise.QueryResult c000_059_CIF_RATING_HISTORY_01__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_ChohyoSera_01__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r,
           com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r,
           com.sforce.soap.enterprise.QueryResult c001_CIFs_01__r,
           com.sforce.soap.enterprise.QueryResult c003_CIFs_01__r,
           com.sforce.soap.enterprise.QueryResult CIFZOKUSEIINFO__r,
           com.sforce.soap.enterprise.QueryResult CIFZOKUSEIINFOs__r,
           java.lang.String COUNTRYCD__c,
           com.sforce.soap.enterprise.QueryResult combinedAttachments,
           com.sforce.soap.enterprise.sobject.User createdBy,
           java.lang.String createdById,
           java.util.Calendar createdDate,
           com.sforce.soap.enterprise.QueryResult d002_001__r,
           com.sforce.soap.enterprise.QueryResult d002_002__r,
           com.sforce.soap.enterprise.QueryResult d003_001__r,
           com.sforce.soap.enterprise.QueryResult d003_002__r,
           com.sforce.soap.enterprise.QueryResult d004_ToDoSnaps02__r,
           com.sforce.soap.enterprise.QueryResult d004_ToDoSnaps__r,
           com.sforce.soap.enterprise.QueryResult d004_ToDos02__r,
           com.sforce.soap.enterprise.QueryResult d004_ToDos__r,
           java.lang.Boolean DELFLG__c,
           java.lang.String DENWABANGOU__c,
           java.lang.String DMDOUIKBN__c,
           com.sforce.soap.enterprise.QueryResult duplicateRecordItems,
           com.sforce.soap.enterprise.QueryResult events,
           java.lang.String GAISHIKEIKBN__c,
           java.util.Date GAITAMETORIHIKIKAISHIBI__c,
           java.util.Date GAITAMEYOSHINTORIHIKIKAISHIBI__c,
           java.lang.String GCIFBANGOU__c,
           java.lang.String GYOUSHUCD1__c,
           java.lang.String GYOUSHUCD2__c,
           java.lang.String GYOUSHUCD3__c,
           java.lang.String HATANSAKISAIKUBUN__c,
           java.lang.String HIKIATEHYOUKA__c,
           java.lang.String HONBUTANTOUBUMONCD1__c,
           java.lang.String HONBUTANTOUSHACD1__c,
           java.lang.Double HYOUTEN__c,
           com.sforce.soap.enterprise.QueryResult histories,
           java.lang.Boolean isDeleted,
           java.lang.String JCR_CSKHENKOUKBN__c,
           java.lang.String JCR_CSKKEY1__c,
           java.lang.String JCR_CSKKEY2__c,
           java.util.Date JCR_CSKSTB__c,
           java.lang.String JCR_CSK__c,
           java.lang.String JCR_HAKKOUTAIID__c,
           java.lang.String JCR_HAKKOUTAI_NM__c,
           java.util.Date JCR_KIJUNBI__c,
           java.lang.String JCR_MCKHENKOUKBN_CH__c,
           java.lang.String JCR_MCKHENKOUKBN__c,
           java.util.Date JCR_MCKSTB__c,
           java.lang.String JCR_MCK_CH__c,
           java.lang.String JCR_MCK__c,
           java.lang.String JCR_MINASHIHANBETSUCD__c,
           java.util.Date JCR_YUUKOUKIKANSHUURYOUBI__c,
           java.lang.String JIGYOUSHA_HIJIGYOUSHAKBN__c,
           java.lang.String JINKAKUKBN__c,
           java.lang.String JOUJOUKBN1__c,
           java.lang.String JOUJOUKBN2__c,
           java.lang.String JOUJOUKBN3__c,
           java.lang.String JOUJOUKBN__c,
           java.lang.String JUNKYOHOUKBN__c,
           java.lang.Double JUUGYOUIN_CNT__c,
           java.lang.String KABUSHIKICD__c,
           java.lang.String KACD__c,
           java.util.Date KAKUDUKEHENKOUBI__c,
           java.util.Date KAKUDUKEKOUSHINBI__c,
           java.lang.String KAKUDUKESAIKUBUN__c,
           java.lang.String KANJISHIMEI__c,
           java.lang.String KANRISAKIKBN__c,
           java.util.Date KANSAJISSHIBI__c,
           java.lang.String KASHIGAITORIHIKIUMUKBN__c,
           java.lang.String KA_GROUPNM__c,
           java.lang.String KEIRETSU_KANJI__c,
           java.lang.String KENSAKUYOUKANASHOUGOU__c,
           java.lang.String KENSAKUYOUKANJISHOUGOU__c,
           java.lang.String KESSANNENGETSU2__c,
           java.lang.String KESSANNENGETSU3__c,
           java.lang.String KESSANNENGETSU__c,
           java.lang.String KESSANTSUKI_CHUU__c,
           java.lang.String KESSANTSUKI_HON__c,
           java.lang.String KIGYOUBANGOU__c,
           java.lang.String KIGYOUKIBOCD__c,
           java.lang.String KIGYOUSEG__c,
           java.util.Date KOKUNAIYOSHINTORIHIKIKAISHIBI__c,
           java.lang.String KOKYAKUBANGOU__c,
           java.lang.String KOKYAKUKANRITENBAN__c,
           java.lang.String KOUKINCD__c,
           java.util.Date KOUSHINBI__c,
           java.lang.String KOZATEMMEI__c,
           java.lang.String KOZATENJOHO__c,
           com.sforce.soap.enterprise.sobject.C000_BUSHOINFO__c KOZATENJOHO__r,
           java.lang.String KYOJUUSEIKBN__c,
           java.lang.String KYOTENHAIKAKAISOU1_BUTENBANGOU__c,
           java.lang.String KYOTENHAIKAKAISOU2_BUTENBANGOU__c,
           java.lang.String KYOTENHAIKAKAISOU3_BUTENBANGOU__c,
           java.lang.String KYOTENSEG__c,
           java.lang.String KYOTEN_BUTENBANGOU__c,
           java.lang.String KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c,
           java.lang.String KYOUTSUUNINSHOUKOUININFO_USERID__c,
           com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c KYOUTSUUNINSHOUKOUININFO_USERID__r,
           java.util.Date lastActivityDate,
           com.sforce.soap.enterprise.sobject.User lastModifiedBy,
           java.lang.String lastModifiedById,
           java.util.Calendar lastModifiedDate,
           com.sforce.soap.enterprise.QueryResult lookedUpFromActivities,
           java.lang.String MAINKICHOUCIF_SYSTEMKBN__c,
           java.lang.String MAINKICHOUCIF_ZOKUSEIBANGOU__c,
           java.lang.String MAINKICHOUCIF__c,
           java.lang.Boolean MAIN_CIF_FLG__c,
           java.lang.String MO_HAKKOUTAIID__c,
           java.lang.String MO_HAKKOUTAI_NM__c,
           java.lang.String MO_JDCHKKEY__c,
           java.lang.String MO_JDCHKRD__c,
           java.util.Date MO_JDCHKSTB__c,
           java.lang.String MO_JDCHKWR__c,
           java.lang.String MO_JDCHK__c,
           java.util.Date MO_KIJUNBI__c,
           java.lang.String MO_MCKHENKOUKBN_CH__c,
           java.lang.String MO_MCKRD__c,
           java.util.Date MO_MCKSTB__c,
           java.lang.String MO_MCKWR__c,
           java.lang.String MO_MCK_CH__c,
           java.lang.String MO_MCK__c,
           java.lang.String MO_MINASHIHANBETSUCD__c,
           java.util.Date MO_YUUKOUKIKANSHUURYOUBI__c,
           java.lang.String m_CIF_FLG__c,
           java.lang.String NIKKEI_HINIKKEIKBN__c,
           java.lang.String name,
           com.sforce.soap.enterprise.QueryResult notes,
           com.sforce.soap.enterprise.QueryResult notesAndAttachments,
           java.lang.String OUTLOOK__c,
           com.sforce.soap.enterprise.QueryResult openActivities,
           com.sforce.soap.enterprise.sobject.Name owner,
           java.lang.String ownerId,
           com.sforce.soap.enterprise.QueryResult processInstances,
           com.sforce.soap.enterprise.QueryResult processSteps,
           java.lang.Double RIEKI_KIN_SENUNIT2__c,
           java.lang.Double RIEKI_KIN_SENUNIT3__c,
           java.lang.Double RIEKI_KIN_SENUNIT__c,
           java.lang.String RINGI_SAIRYOUKBN__c,
           java.lang.String RI_CSKHENKOUKBN__c,
           java.lang.String RI_CSKKEY1__c,
           java.lang.String RI_CSKKEY2__c,
           java.util.Date RI_CSKSTB__c,
           java.lang.String RI_CSK__c,
           java.lang.String RI_HAKKOUTAIID__c,
           java.lang.String RI_HAKKOUTAI_NM__c,
           java.util.Date RI_KIJUNBI__c,
           java.lang.String RI_MCKHENKOUKBN_CH__c,
           java.lang.String RI_MCKHK__c,
           java.util.Date RI_MCKSTB__c,
           java.lang.String RI_MCK_CH__c,
           java.lang.String RI_MCK__c,
           java.lang.String RI_MINASHIHANBETSUCD__c,
           java.util.Date RI_YUUKOUKIKANSHUURYOUBI__c,
           java.lang.String RMFFLG__c,
           java.lang.String SAIMUCHOUKASAKIKBN__c,
           java.util.Date SAIMUSHAKAKUDUKEYUUKOUKIGEN__c,
           java.lang.String SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c,
           java.lang.String SAIMUSHAKAKUDUKE__c,
           java.lang.String SAIMUSHAKBN__c,
           java.lang.String SAIMUSHA_HISAIMUSHAKBN__c,
           java.lang.String SETAIKANRITANTOUSHA__c,
           java.util.Date SETSURITSUNENGETSUBI__c,
           java.lang.Double SHIHONKIN__c,
           java.lang.Double SHINKOKUSHOTOKUKINGAKU2__c,
           java.lang.Double SHINKOKUSHOTOKUKINGAKU3__c,
           java.lang.Double SHINKOKUSHOTOKUKINGAKU__c,
           java.lang.String SHINMITSUDO__c,
           java.lang.String SHOUGOU_KANJI__c,
           java.lang.String SHOUKYAKUKBN__c,
           java.lang.String SHOZAICHI_KANJI__c,
           java.lang.String SHURYOKUTAKOU1__c,
           java.lang.String SHURYOKUTAKOU2__c,
           java.lang.String SHURYOKUTAKOU3__c,
           java.lang.String SP_HAKKOUTAIID__c,
           java.lang.String SP_HAKKOUTAI_NM__c,
           java.lang.String SP_JDCHKLOOK__c,
           java.util.Date SP_JDCHKSTB__c,
           java.lang.String SP_JDCHKW__c,
           java.lang.String SP_JDCHK__c,
           java.util.Date SP_KIJUNBI__c,
           java.lang.String SP_MCKHENKOUKBN_CH__c,
           java.lang.String SP_MCKLOOK__c,
           java.util.Date SP_MCKSTB__c,
           java.lang.String SP_MCKW__c,
           java.lang.String SP_MCK_CH__c,
           java.lang.String SP_MCK__c,
           java.lang.String SP_MINASHIHANBETSUCD__c,
           java.util.Date SP_YUUKOUKIKANSHUURYOUBI__c,
           com.sforce.soap.enterprise.QueryResult saikenJotoTsuchi_CifzkuseiInfo__r,
           com.sforce.soap.enterprise.QueryResult shares,
           java.util.Calendar systemModstamp,
           java.lang.String TANTOUSHACD1__c,
           java.lang.String TANTOUSHACD2__c,
//           java.lang.String TDBSANGYOUBUNRUICD1__c,
//           java.lang.String TDBSANGYOUBUNRUICD2__c,
//           java.lang.String TDBSANGYOUBUNRUICD3__c,
//           java.lang.String TDBSANGYOUBUNRUICD4__c,
//           java.lang.String TDBSANGYOUBUNRUICD5__c,
           java.lang.String TEAMCD__c,
           java.lang.String TEKIKAKUKAISHACD__c,
           java.lang.String TENBAN_3_KOKYAKUBANGOU__c,
           java.lang.String TENBAN_3__c,
           java.lang.String TENBAN_KOKYAKUBANGOU__c,
           java.lang.String TENBAN__c,
           java.lang.String TKCKAIIN__c,
           java.lang.String TKCKANYOSAKI__c,
           java.lang.String TORIHIKIBANKCD10__c,
           java.lang.String TORIHIKIBANKCD1__c,
           java.lang.String TORIHIKIBANKCD2__c,
           java.lang.String TORIHIKIBANKCD3__c,
           java.lang.String TORIHIKIBANKCD4__c,
           java.lang.String TORIHIKIBANKCD5__c,
           java.lang.String TORIHIKIBANKCD6__c,
           java.lang.String TORIHIKIBANKCD7__c,
           java.lang.String TORIHIKIBANKCD8__c,
           java.lang.String TORIHIKIBANKCD9__c,
           java.lang.String TORIHIKISAKI_NM_EIJI__c,
           java.lang.String TORIHIKISAKI_NM_JOIN__c,
           java.lang.String TORIHIKISAKI_NM_KANA__c,
           java.lang.String TORIHIKISAKI_NM_KANJI__c,
           java.lang.String TSUUSHINKBN__c,
           com.sforce.soap.enterprise.QueryResult tasks,
           com.sforce.soap.enterprise.QueryResult topicAssignments,
           java.lang.Double URIAGEDAKA_HYAKUMANUNIT2__c,
           java.lang.Double URIAGEDAKA_HYAKUMANUNIT3__c,
           java.lang.Double URIAGEDAKA_HYAKUMANUNIT__c,
           java.lang.String USERID_EDABAN__c,
           java.lang.String USERID__c,
           com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess,
//           java.util.Date YOKINTORIHIKIKAISHIBI__c,
           java.lang.String YUUBINBANGOU__c) {
        super(
            fieldsToNull,
            id);
        this.a001_ANKEN_MiorikomiJoho_01__r = a001_ANKEN_MiorikomiJoho_01__r;
        this.a001_ANKEN_TorikomiJoho_03__r = a001_ANKEN_TorikomiJoho_03__r;
        this.a002_ANKEN_Zairyou_001__r = a002_ANKEN_Zairyou_001__r;
        this.a004_Kokyaku_01__r = a004_Kokyaku_01__r;
        this.a005_SERAs__r = a005_SERAs__r;
        this.a019_CIFs_01__r = a019_CIFs_01__r;
        this.ADDRESSCD__c = ADDRESSCD__c;
        this.ADDRESS_KANJI__c = ADDRESS_KANJI__c;
        this.AREAINFOCD__c = AREAINFOCD__c;
        this.activityHistories = activityHistories;
        this.attachments = attachments;
        this.BOUEKIKBN__c = BOUEKIKBN__c;
        this.BUMONKBN__c = BUMONKBN__c;
        this.BUMONSAIKUBUN1__c = BUMONSAIKUBUN1__c;
        this.BUMONSAIKUBUN2__c = BUMONSAIKUBUN2__c;
        this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c = BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;
        this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r = BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r;
        this.BUTENBANGOU__c = BUTENBANGOU__c;
        this.BUTENNMRENKETSU__c = BUTENNMRENKETSU__c;
        this.c000_059_CIF_RATING_HISTORY_01__r = c000_059_CIF_RATING_HISTORY_01__r;
        this.c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r = c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r;
        this.c000_CIFZOKUSEIINFO_ChohyoSera_01__r = c000_CIFZOKUSEIINFO_ChohyoSera_01__r;
        this.c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r = c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r;
        this.c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r = c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r;
        this.c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r = c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r;
        this.c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r = c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r;
        this.c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r = c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r;
        this.c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r = c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r;
        this.c001_CIFs_01__r = c001_CIFs_01__r;
        this.c003_CIFs_01__r = c003_CIFs_01__r;
        this.CIFZOKUSEIINFO__r = CIFZOKUSEIINFO__r;
        this.CIFZOKUSEIINFOs__r = CIFZOKUSEIINFOs__r;
        this.COUNTRYCD__c = COUNTRYCD__c;
        this.combinedAttachments = combinedAttachments;
        this.createdBy = createdBy;
        this.createdById = createdById;
        this.createdDate = createdDate;
        this.d002_001__r = d002_001__r;
        this.d002_002__r = d002_002__r;
        this.d003_001__r = d003_001__r;
        this.d003_002__r = d003_002__r;
        this.d004_ToDoSnaps02__r = d004_ToDoSnaps02__r;
        this.d004_ToDoSnaps__r = d004_ToDoSnaps__r;
        this.d004_ToDos02__r = d004_ToDos02__r;
        this.d004_ToDos__r = d004_ToDos__r;
        this.DELFLG__c = DELFLG__c;
        this.DENWABANGOU__c = DENWABANGOU__c;
        this.DMDOUIKBN__c = DMDOUIKBN__c;
        this.duplicateRecordItems = duplicateRecordItems;
        this.events = events;
        this.GAISHIKEIKBN__c = GAISHIKEIKBN__c;
        this.GAITAMETORIHIKIKAISHIBI__c = GAITAMETORIHIKIKAISHIBI__c;
        this.GAITAMEYOSHINTORIHIKIKAISHIBI__c = GAITAMEYOSHINTORIHIKIKAISHIBI__c;
        this.GCIFBANGOU__c = GCIFBANGOU__c;
        this.GYOUSHUCD1__c = GYOUSHUCD1__c;
        this.GYOUSHUCD2__c = GYOUSHUCD2__c;
        this.GYOUSHUCD3__c = GYOUSHUCD3__c;
        this.HATANSAKISAIKUBUN__c = HATANSAKISAIKUBUN__c;
        this.HIKIATEHYOUKA__c = HIKIATEHYOUKA__c;
        this.HONBUTANTOUBUMONCD1__c = HONBUTANTOUBUMONCD1__c;
        this.HONBUTANTOUSHACD1__c = HONBUTANTOUSHACD1__c;
        this.HYOUTEN__c = HYOUTEN__c;
        this.histories = histories;
        this.isDeleted = isDeleted;
        this.JCR_CSKHENKOUKBN__c = JCR_CSKHENKOUKBN__c;
        this.JCR_CSKKEY1__c = JCR_CSKKEY1__c;
        this.JCR_CSKKEY2__c = JCR_CSKKEY2__c;
        this.JCR_CSKSTB__c = JCR_CSKSTB__c;
        this.JCR_CSK__c = JCR_CSK__c;
        this.JCR_HAKKOUTAIID__c = JCR_HAKKOUTAIID__c;
        this.JCR_HAKKOUTAI_NM__c = JCR_HAKKOUTAI_NM__c;
        this.JCR_KIJUNBI__c = JCR_KIJUNBI__c;
        this.JCR_MCKHENKOUKBN_CH__c = JCR_MCKHENKOUKBN_CH__c;
        this.JCR_MCKHENKOUKBN__c = JCR_MCKHENKOUKBN__c;
        this.JCR_MCKSTB__c = JCR_MCKSTB__c;
        this.JCR_MCK_CH__c = JCR_MCK_CH__c;
        this.JCR_MCK__c = JCR_MCK__c;
        this.JCR_MINASHIHANBETSUCD__c = JCR_MINASHIHANBETSUCD__c;
        this.JCR_YUUKOUKIKANSHUURYOUBI__c = JCR_YUUKOUKIKANSHUURYOUBI__c;
        this.JIGYOUSHA_HIJIGYOUSHAKBN__c = JIGYOUSHA_HIJIGYOUSHAKBN__c;
        this.JINKAKUKBN__c = JINKAKUKBN__c;
        this.JOUJOUKBN1__c = JOUJOUKBN1__c;
        this.JOUJOUKBN2__c = JOUJOUKBN2__c;
        this.JOUJOUKBN3__c = JOUJOUKBN3__c;
        this.JOUJOUKBN__c = JOUJOUKBN__c;
        this.JUNKYOHOUKBN__c = JUNKYOHOUKBN__c;
        this.JUUGYOUIN_CNT__c = JUUGYOUIN_CNT__c;
        this.KABUSHIKICD__c = KABUSHIKICD__c;
        this.KACD__c = KACD__c;
        this.KAKUDUKEHENKOUBI__c = KAKUDUKEHENKOUBI__c;
        this.KAKUDUKEKOUSHINBI__c = KAKUDUKEKOUSHINBI__c;
        this.KAKUDUKESAIKUBUN__c = KAKUDUKESAIKUBUN__c;
        this.KANJISHIMEI__c = KANJISHIMEI__c;
        this.KANRISAKIKBN__c = KANRISAKIKBN__c;
        this.KANSAJISSHIBI__c = KANSAJISSHIBI__c;
        this.KASHIGAITORIHIKIUMUKBN__c = KASHIGAITORIHIKIUMUKBN__c;
        this.KA_GROUPNM__c = KA_GROUPNM__c;
        this.KEIRETSU_KANJI__c = KEIRETSU_KANJI__c;
        this.KENSAKUYOUKANASHOUGOU__c = KENSAKUYOUKANASHOUGOU__c;
        this.KENSAKUYOUKANJISHOUGOU__c = KENSAKUYOUKANJISHOUGOU__c;
        this.KESSANNENGETSU2__c = KESSANNENGETSU2__c;
        this.KESSANNENGETSU3__c = KESSANNENGETSU3__c;
        this.KESSANNENGETSU__c = KESSANNENGETSU__c;
        this.KESSANTSUKI_CHUU__c = KESSANTSUKI_CHUU__c;
        this.KESSANTSUKI_HON__c = KESSANTSUKI_HON__c;
        this.KIGYOUBANGOU__c = KIGYOUBANGOU__c;
        this.KIGYOUKIBOCD__c = KIGYOUKIBOCD__c;
        this.KIGYOUSEG__c = KIGYOUSEG__c;
        this.KOKUNAIYOSHINTORIHIKIKAISHIBI__c = KOKUNAIYOSHINTORIHIKIKAISHIBI__c;
        this.KOKYAKUBANGOU__c = KOKYAKUBANGOU__c;
        this.KOKYAKUKANRITENBAN__c = KOKYAKUKANRITENBAN__c;
        this.KOUKINCD__c = KOUKINCD__c;
        this.KOUSHINBI__c = KOUSHINBI__c;
        this.KOZATEMMEI__c = KOZATEMMEI__c;
        this.KOZATENJOHO__c = KOZATENJOHO__c;
        this.KOZATENJOHO__r = KOZATENJOHO__r;
        this.KYOJUUSEIKBN__c = KYOJUUSEIKBN__c;
        this.KYOTENHAIKAKAISOU1_BUTENBANGOU__c = KYOTENHAIKAKAISOU1_BUTENBANGOU__c;
        this.KYOTENHAIKAKAISOU2_BUTENBANGOU__c = KYOTENHAIKAKAISOU2_BUTENBANGOU__c;
        this.KYOTENHAIKAKAISOU3_BUTENBANGOU__c = KYOTENHAIKAKAISOU3_BUTENBANGOU__c;
        this.KYOTENSEG__c = KYOTENSEG__c;
        this.KYOTEN_BUTENBANGOU__c = KYOTEN_BUTENBANGOU__c;
        this.KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c = KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c;
        this.KYOUTSUUNINSHOUKOUININFO_USERID__c = KYOUTSUUNINSHOUKOUININFO_USERID__c;
        this.KYOUTSUUNINSHOUKOUININFO_USERID__r = KYOUTSUUNINSHOUKOUININFO_USERID__r;
        this.lastActivityDate = lastActivityDate;
        this.lastModifiedBy = lastModifiedBy;
        this.lastModifiedById = lastModifiedById;
        this.lastModifiedDate = lastModifiedDate;
        this.lookedUpFromActivities = lookedUpFromActivities;
        this.MAINKICHOUCIF_SYSTEMKBN__c = MAINKICHOUCIF_SYSTEMKBN__c;
        this.MAINKICHOUCIF_ZOKUSEIBANGOU__c = MAINKICHOUCIF_ZOKUSEIBANGOU__c;
        this.MAINKICHOUCIF__c = MAINKICHOUCIF__c;
        this.MAIN_CIF_FLG__c = MAIN_CIF_FLG__c;
        this.MO_HAKKOUTAIID__c = MO_HAKKOUTAIID__c;
        this.MO_HAKKOUTAI_NM__c = MO_HAKKOUTAI_NM__c;
        this.MO_JDCHKKEY__c = MO_JDCHKKEY__c;
        this.MO_JDCHKRD__c = MO_JDCHKRD__c;
        this.MO_JDCHKSTB__c = MO_JDCHKSTB__c;
        this.MO_JDCHKWR__c = MO_JDCHKWR__c;
        this.MO_JDCHK__c = MO_JDCHK__c;
        this.MO_KIJUNBI__c = MO_KIJUNBI__c;
        this.MO_MCKHENKOUKBN_CH__c = MO_MCKHENKOUKBN_CH__c;
        this.MO_MCKRD__c = MO_MCKRD__c;
        this.MO_MCKSTB__c = MO_MCKSTB__c;
        this.MO_MCKWR__c = MO_MCKWR__c;
        this.MO_MCK_CH__c = MO_MCK_CH__c;
        this.MO_MCK__c = MO_MCK__c;
        this.MO_MINASHIHANBETSUCD__c = MO_MINASHIHANBETSUCD__c;
        this.MO_YUUKOUKIKANSHUURYOUBI__c = MO_YUUKOUKIKANSHUURYOUBI__c;
        this.m_CIF_FLG__c = m_CIF_FLG__c;
        this.NIKKEI_HINIKKEIKBN__c = NIKKEI_HINIKKEIKBN__c;
        this.name = name;
        this.notes = notes;
        this.notesAndAttachments = notesAndAttachments;
        this.OUTLOOK__c = OUTLOOK__c;
        this.openActivities = openActivities;
        this.owner = owner;
        this.ownerId = ownerId;
        this.processInstances = processInstances;
        this.processSteps = processSteps;
        this.RIEKI_KIN_SENUNIT2__c = RIEKI_KIN_SENUNIT2__c;
        this.RIEKI_KIN_SENUNIT3__c = RIEKI_KIN_SENUNIT3__c;
        this.RIEKI_KIN_SENUNIT__c = RIEKI_KIN_SENUNIT__c;
        this.RINGI_SAIRYOUKBN__c = RINGI_SAIRYOUKBN__c;
        this.RI_CSKHENKOUKBN__c = RI_CSKHENKOUKBN__c;
        this.RI_CSKKEY1__c = RI_CSKKEY1__c;
        this.RI_CSKKEY2__c = RI_CSKKEY2__c;
        this.RI_CSKSTB__c = RI_CSKSTB__c;
        this.RI_CSK__c = RI_CSK__c;
        this.RI_HAKKOUTAIID__c = RI_HAKKOUTAIID__c;
        this.RI_HAKKOUTAI_NM__c = RI_HAKKOUTAI_NM__c;
        this.RI_KIJUNBI__c = RI_KIJUNBI__c;
        this.RI_MCKHENKOUKBN_CH__c = RI_MCKHENKOUKBN_CH__c;
        this.RI_MCKHK__c = RI_MCKHK__c;
        this.RI_MCKSTB__c = RI_MCKSTB__c;
        this.RI_MCK_CH__c = RI_MCK_CH__c;
        this.RI_MCK__c = RI_MCK__c;
        this.RI_MINASHIHANBETSUCD__c = RI_MINASHIHANBETSUCD__c;
        this.RI_YUUKOUKIKANSHUURYOUBI__c = RI_YUUKOUKIKANSHUURYOUBI__c;
        this.RMFFLG__c = RMFFLG__c;
        this.SAIMUCHOUKASAKIKBN__c = SAIMUCHOUKASAKIKBN__c;
        this.SAIMUSHAKAKUDUKEYUUKOUKIGEN__c = SAIMUSHAKAKUDUKEYUUKOUKIGEN__c;
        this.SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c = SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c;
        this.SAIMUSHAKAKUDUKE__c = SAIMUSHAKAKUDUKE__c;
        this.SAIMUSHAKBN__c = SAIMUSHAKBN__c;
        this.SAIMUSHA_HISAIMUSHAKBN__c = SAIMUSHA_HISAIMUSHAKBN__c;
        this.SETAIKANRITANTOUSHA__c = SETAIKANRITANTOUSHA__c;
        this.SETSURITSUNENGETSUBI__c = SETSURITSUNENGETSUBI__c;
        this.SHIHONKIN__c = SHIHONKIN__c;
        this.SHINKOKUSHOTOKUKINGAKU2__c = SHINKOKUSHOTOKUKINGAKU2__c;
        this.SHINKOKUSHOTOKUKINGAKU3__c = SHINKOKUSHOTOKUKINGAKU3__c;
        this.SHINKOKUSHOTOKUKINGAKU__c = SHINKOKUSHOTOKUKINGAKU__c;
        this.SHINMITSUDO__c = SHINMITSUDO__c;
        this.SHOUGOU_KANJI__c = SHOUGOU_KANJI__c;
        this.SHOUKYAKUKBN__c = SHOUKYAKUKBN__c;
        this.SHOZAICHI_KANJI__c = SHOZAICHI_KANJI__c;
        this.SHURYOKUTAKOU1__c = SHURYOKUTAKOU1__c;
        this.SHURYOKUTAKOU2__c = SHURYOKUTAKOU2__c;
        this.SHURYOKUTAKOU3__c = SHURYOKUTAKOU3__c;
        this.SP_HAKKOUTAIID__c = SP_HAKKOUTAIID__c;
        this.SP_HAKKOUTAI_NM__c = SP_HAKKOUTAI_NM__c;
        this.SP_JDCHKLOOK__c = SP_JDCHKLOOK__c;
        this.SP_JDCHKSTB__c = SP_JDCHKSTB__c;
        this.SP_JDCHKW__c = SP_JDCHKW__c;
        this.SP_JDCHK__c = SP_JDCHK__c;
        this.SP_KIJUNBI__c = SP_KIJUNBI__c;
        this.SP_MCKHENKOUKBN_CH__c = SP_MCKHENKOUKBN_CH__c;
        this.SP_MCKLOOK__c = SP_MCKLOOK__c;
        this.SP_MCKSTB__c = SP_MCKSTB__c;
        this.SP_MCKW__c = SP_MCKW__c;
        this.SP_MCK_CH__c = SP_MCK_CH__c;
        this.SP_MCK__c = SP_MCK__c;
        this.SP_MINASHIHANBETSUCD__c = SP_MINASHIHANBETSUCD__c;
        this.SP_YUUKOUKIKANSHUURYOUBI__c = SP_YUUKOUKIKANSHUURYOUBI__c;
        this.saikenJotoTsuchi_CifzkuseiInfo__r = saikenJotoTsuchi_CifzkuseiInfo__r;
        this.shares = shares;
        this.systemModstamp = systemModstamp;
        this.TANTOUSHACD1__c = TANTOUSHACD1__c;
        this.TANTOUSHACD2__c = TANTOUSHACD2__c;
        this.TDBSANGYOUBUNRUICD1__c = TDBSANGYOUBUNRUICD1__c;
        this.TDBSANGYOUBUNRUICD2__c = TDBSANGYOUBUNRUICD2__c;
        this.TDBSANGYOUBUNRUICD3__c = TDBSANGYOUBUNRUICD3__c;
        this.TDBSANGYOUBUNRUICD4__c = TDBSANGYOUBUNRUICD4__c;
        this.TDBSANGYOUBUNRUICD5__c = TDBSANGYOUBUNRUICD5__c;
        this.TEAMCD__c = TEAMCD__c;
        this.TEKIKAKUKAISHACD__c = TEKIKAKUKAISHACD__c;
        this.TENBAN_3_KOKYAKUBANGOU__c = TENBAN_3_KOKYAKUBANGOU__c;
        this.TENBAN_3__c = TENBAN_3__c;
        this.TENBAN_KOKYAKUBANGOU__c = TENBAN_KOKYAKUBANGOU__c;
        this.TENBAN__c = TENBAN__c;
        this.TKCKAIIN__c = TKCKAIIN__c;
        this.TKCKANYOSAKI__c = TKCKANYOSAKI__c;
        this.TORIHIKIBANKCD10__c = TORIHIKIBANKCD10__c;
        this.TORIHIKIBANKCD1__c = TORIHIKIBANKCD1__c;
        this.TORIHIKIBANKCD2__c = TORIHIKIBANKCD2__c;
        this.TORIHIKIBANKCD3__c = TORIHIKIBANKCD3__c;
        this.TORIHIKIBANKCD4__c = TORIHIKIBANKCD4__c;
        this.TORIHIKIBANKCD5__c = TORIHIKIBANKCD5__c;
        this.TORIHIKIBANKCD6__c = TORIHIKIBANKCD6__c;
        this.TORIHIKIBANKCD7__c = TORIHIKIBANKCD7__c;
        this.TORIHIKIBANKCD8__c = TORIHIKIBANKCD8__c;
        this.TORIHIKIBANKCD9__c = TORIHIKIBANKCD9__c;
        this.TORIHIKISAKI_NM_EIJI__c = TORIHIKISAKI_NM_EIJI__c;
        this.TORIHIKISAKI_NM_JOIN__c = TORIHIKISAKI_NM_JOIN__c;
        this.TORIHIKISAKI_NM_KANA__c = TORIHIKISAKI_NM_KANA__c;
        this.TORIHIKISAKI_NM_KANJI__c = TORIHIKISAKI_NM_KANJI__c;
        this.TSUUSHINKBN__c = TSUUSHINKBN__c;
        this.tasks = tasks;
        this.topicAssignments = topicAssignments;
        this.URIAGEDAKA_HYAKUMANUNIT2__c = URIAGEDAKA_HYAKUMANUNIT2__c;
        this.URIAGEDAKA_HYAKUMANUNIT3__c = URIAGEDAKA_HYAKUMANUNIT3__c;
        this.URIAGEDAKA_HYAKUMANUNIT__c = URIAGEDAKA_HYAKUMANUNIT__c;
        this.USERID_EDABAN__c = USERID_EDABAN__c;
        this.USERID__c = USERID__c;
        this.userRecordAccess = userRecordAccess;
        this.YOKINTORIHIKIKAISHIBI__c = YOKINTORIHIKIKAISHIBI__c;
        this.YUUBINBANGOU__c = YUUBINBANGOU__c;
    }


    /**
     * Gets the a001_ANKEN_MiorikomiJoho_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return a001_ANKEN_MiorikomiJoho_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getA001_ANKEN_MiorikomiJoho_01__r() {
        return a001_ANKEN_MiorikomiJoho_01__r;
    }


    /**
     * Sets the a001_ANKEN_MiorikomiJoho_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param a001_ANKEN_MiorikomiJoho_01__r
     */
    public void setA001_ANKEN_MiorikomiJoho_01__r(com.sforce.soap.enterprise.QueryResult a001_ANKEN_MiorikomiJoho_01__r) {
        this.a001_ANKEN_MiorikomiJoho_01__r = a001_ANKEN_MiorikomiJoho_01__r;
    }


    /**
     * Gets the a001_ANKEN_TorikomiJoho_03__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return a001_ANKEN_TorikomiJoho_03__r
     */
    public com.sforce.soap.enterprise.QueryResult getA001_ANKEN_TorikomiJoho_03__r() {
        return a001_ANKEN_TorikomiJoho_03__r;
    }


    /**
     * Sets the a001_ANKEN_TorikomiJoho_03__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param a001_ANKEN_TorikomiJoho_03__r
     */
    public void setA001_ANKEN_TorikomiJoho_03__r(com.sforce.soap.enterprise.QueryResult a001_ANKEN_TorikomiJoho_03__r) {
        this.a001_ANKEN_TorikomiJoho_03__r = a001_ANKEN_TorikomiJoho_03__r;
    }


    /**
     * Gets the a002_ANKEN_Zairyou_001__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return a002_ANKEN_Zairyou_001__r
     */
    public com.sforce.soap.enterprise.QueryResult getA002_ANKEN_Zairyou_001__r() {
        return a002_ANKEN_Zairyou_001__r;
    }


    /**
     * Sets the a002_ANKEN_Zairyou_001__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param a002_ANKEN_Zairyou_001__r
     */
    public void setA002_ANKEN_Zairyou_001__r(com.sforce.soap.enterprise.QueryResult a002_ANKEN_Zairyou_001__r) {
        this.a002_ANKEN_Zairyou_001__r = a002_ANKEN_Zairyou_001__r;
    }


    /**
     * Gets the a004_Kokyaku_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return a004_Kokyaku_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getA004_Kokyaku_01__r() {
        return a004_Kokyaku_01__r;
    }


    /**
     * Sets the a004_Kokyaku_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param a004_Kokyaku_01__r
     */
    public void setA004_Kokyaku_01__r(com.sforce.soap.enterprise.QueryResult a004_Kokyaku_01__r) {
        this.a004_Kokyaku_01__r = a004_Kokyaku_01__r;
    }


    /**
     * Gets the a005_SERAs__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return a005_SERAs__r
     */
    public com.sforce.soap.enterprise.QueryResult getA005_SERAs__r() {
        return a005_SERAs__r;
    }


    /**
     * Sets the a005_SERAs__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param a005_SERAs__r
     */
    public void setA005_SERAs__r(com.sforce.soap.enterprise.QueryResult a005_SERAs__r) {
        this.a005_SERAs__r = a005_SERAs__r;
    }


    /**
     * Gets the a019_CIFs_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return a019_CIFs_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getA019_CIFs_01__r() {
        return a019_CIFs_01__r;
    }


    /**
     * Sets the a019_CIFs_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param a019_CIFs_01__r
     */
    public void setA019_CIFs_01__r(com.sforce.soap.enterprise.QueryResult a019_CIFs_01__r) {
        this.a019_CIFs_01__r = a019_CIFs_01__r;
    }


    /**
     * Gets the ADDRESSCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return ADDRESSCD__c
     */
    public java.lang.String getADDRESSCD__c() {
        return ADDRESSCD__c;
    }


    /**
     * Sets the ADDRESSCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param ADDRESSCD__c
     */
    public void setADDRESSCD__c(java.lang.String ADDRESSCD__c) {
        this.ADDRESSCD__c = ADDRESSCD__c;
    }


    /**
     * Gets the ADDRESS_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return ADDRESS_KANJI__c
     */
    public java.lang.String getADDRESS_KANJI__c() {
        return ADDRESS_KANJI__c;
    }


    /**
     * Sets the ADDRESS_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param ADDRESS_KANJI__c
     */
    public void setADDRESS_KANJI__c(java.lang.String ADDRESS_KANJI__c) {
        this.ADDRESS_KANJI__c = ADDRESS_KANJI__c;
    }


    /**
     * Gets the AREAINFOCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return AREAINFOCD__c
     */
    public java.lang.String getAREAINFOCD__c() {
        return AREAINFOCD__c;
    }


    /**
     * Sets the AREAINFOCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param AREAINFOCD__c
     */
    public void setAREAINFOCD__c(java.lang.String AREAINFOCD__c) {
        this.AREAINFOCD__c = AREAINFOCD__c;
    }


    /**
     * Gets the activityHistories value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return activityHistories
     */
    public com.sforce.soap.enterprise.QueryResult getActivityHistories() {
        return activityHistories;
    }


    /**
     * Sets the activityHistories value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param activityHistories
     */
    public void setActivityHistories(com.sforce.soap.enterprise.QueryResult activityHistories) {
        this.activityHistories = activityHistories;
    }


    /**
     * Gets the attachments value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return attachments
     */
    public com.sforce.soap.enterprise.QueryResult getAttachments() {
        return attachments;
    }


    /**
     * Sets the attachments value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param attachments
     */
    public void setAttachments(com.sforce.soap.enterprise.QueryResult attachments) {
        this.attachments = attachments;
    }


    /**
     * Gets the BOUEKIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return BOUEKIKBN__c
     */
    public java.lang.String getBOUEKIKBN__c() {
        return BOUEKIKBN__c;
    }


    /**
     * Sets the BOUEKIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param BOUEKIKBN__c
     */
    public void setBOUEKIKBN__c(java.lang.String BOUEKIKBN__c) {
        this.BOUEKIKBN__c = BOUEKIKBN__c;
    }


    /**
     * Gets the BUMONKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return BUMONKBN__c
     */
    public java.lang.String getBUMONKBN__c() {
        return BUMONKBN__c;
    }


    /**
     * Sets the BUMONKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param BUMONKBN__c
     */
    public void setBUMONKBN__c(java.lang.String BUMONKBN__c) {
        this.BUMONKBN__c = BUMONKBN__c;
    }


    /**
     * Gets the BUMONSAIKUBUN1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return BUMONSAIKUBUN1__c
     */
    public java.lang.String getBUMONSAIKUBUN1__c() {
        return BUMONSAIKUBUN1__c;
    }


    /**
     * Sets the BUMONSAIKUBUN1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param BUMONSAIKUBUN1__c
     */
    public void setBUMONSAIKUBUN1__c(java.lang.String BUMONSAIKUBUN1__c) {
        this.BUMONSAIKUBUN1__c = BUMONSAIKUBUN1__c;
    }


    /**
     * Gets the BUMONSAIKUBUN2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return BUMONSAIKUBUN2__c
     */
    public java.lang.String getBUMONSAIKUBUN2__c() {
        return BUMONSAIKUBUN2__c;
    }


    /**
     * Sets the BUMONSAIKUBUN2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param BUMONSAIKUBUN2__c
     */
    public void setBUMONSAIKUBUN2__c(java.lang.String BUMONSAIKUBUN2__c) {
        this.BUMONSAIKUBUN2__c = BUMONSAIKUBUN2__c;
    }


    /**
     * Gets the BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c
     */
    public java.lang.String getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c() {
        return BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;
    }


    /**
     * Sets the BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c
     */
    public void setBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c(java.lang.String BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c) {
        this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c = BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c;
    }


    /**
     * Gets the BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r
     */
    public com.sforce.soap.enterprise.sobject.C000_BUSHOINFO__c getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r() {
        return BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r;
    }


    /**
     * Sets the BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r
     */
    public void setBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r(com.sforce.soap.enterprise.sobject.C000_BUSHOINFO__c BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r) {
        this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r = BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r;
    }


    /**
     * Gets the BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return BUTENBANGOU__c
     */
    public java.lang.String getBUTENBANGOU__c() {
        return BUTENBANGOU__c;
    }


    /**
     * Sets the BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param BUTENBANGOU__c
     */
    public void setBUTENBANGOU__c(java.lang.String BUTENBANGOU__c) {
        this.BUTENBANGOU__c = BUTENBANGOU__c;
    }


    /**
     * Gets the BUTENNMRENKETSU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return BUTENNMRENKETSU__c
     */
    public java.lang.String getBUTENNMRENKETSU__c() {
        return BUTENNMRENKETSU__c;
    }


    /**
     * Sets the BUTENNMRENKETSU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param BUTENNMRENKETSU__c
     */
    public void setBUTENNMRENKETSU__c(java.lang.String BUTENNMRENKETSU__c) {
        this.BUTENNMRENKETSU__c = BUTENNMRENKETSU__c;
    }


    /**
     * Gets the c000_059_CIF_RATING_HISTORY_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c000_059_CIF_RATING_HISTORY_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_059_CIF_RATING_HISTORY_01__r() {
        return c000_059_CIF_RATING_HISTORY_01__r;
    }


    /**
     * Sets the c000_059_CIF_RATING_HISTORY_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c000_059_CIF_RATING_HISTORY_01__r
     */
    public void setC000_059_CIF_RATING_HISTORY_01__r(com.sforce.soap.enterprise.QueryResult c000_059_CIF_RATING_HISTORY_01__r) {
        this.c000_059_CIF_RATING_HISTORY_01__r = c000_059_CIF_RATING_HISTORY_01__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_ChohyoOburiga_01__r() {
        return c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r
     */
    public void setC000_CIFZOKUSEIINFO_ChohyoOburiga_01__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r) {
        this.c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r = c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_ChohyoSera_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c000_CIFZOKUSEIINFO_ChohyoSera_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_ChohyoSera_01__r() {
        return c000_CIFZOKUSEIINFO_ChohyoSera_01__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_ChohyoSera_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c000_CIFZOKUSEIINFO_ChohyoSera_01__r
     */
    public void setC000_CIFZOKUSEIINFO_ChohyoSera_01__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_ChohyoSera_01__r) {
        this.c000_CIFZOKUSEIINFO_ChohyoSera_01__r = c000_CIFZOKUSEIINFO_ChohyoSera_01__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r() {
        return c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r
     */
    public void setC000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r) {
        this.c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r = c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r() {
        return c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r
     */
    public void setC000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r) {
        this.c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r = c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r() {
        return c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r
     */
    public void setC000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r) {
        this.c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r = c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r() {
        return c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r
     */
    public void setC000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r) {
        this.c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r = c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r() {
        return c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r
     */
    public void setC000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r) {
        this.c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r = c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r;
    }


    /**
     * Gets the c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r() {
        return c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r;
    }


    /**
     * Sets the c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r
     */
    public void setC000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r(com.sforce.soap.enterprise.QueryResult c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r) {
        this.c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r = c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r;
    }


    /**
     * Gets the c001_CIFs_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c001_CIFs_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC001_CIFs_01__r() {
        return c001_CIFs_01__r;
    }


    /**
     * Sets the c001_CIFs_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c001_CIFs_01__r
     */
    public void setC001_CIFs_01__r(com.sforce.soap.enterprise.QueryResult c001_CIFs_01__r) {
        this.c001_CIFs_01__r = c001_CIFs_01__r;
    }


    /**
     * Gets the c003_CIFs_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return c003_CIFs_01__r
     */
    public com.sforce.soap.enterprise.QueryResult getC003_CIFs_01__r() {
        return c003_CIFs_01__r;
    }


    /**
     * Sets the c003_CIFs_01__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param c003_CIFs_01__r
     */
    public void setC003_CIFs_01__r(com.sforce.soap.enterprise.QueryResult c003_CIFs_01__r) {
        this.c003_CIFs_01__r = c003_CIFs_01__r;
    }


    /**
     * Gets the CIFZOKUSEIINFO__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return CIFZOKUSEIINFO__r
     */
    public com.sforce.soap.enterprise.QueryResult getCIFZOKUSEIINFO__r() {
        return CIFZOKUSEIINFO__r;
    }


    /**
     * Sets the CIFZOKUSEIINFO__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param CIFZOKUSEIINFO__r
     */
    public void setCIFZOKUSEIINFO__r(com.sforce.soap.enterprise.QueryResult CIFZOKUSEIINFO__r) {
        this.CIFZOKUSEIINFO__r = CIFZOKUSEIINFO__r;
    }


    /**
     * Gets the CIFZOKUSEIINFOs__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return CIFZOKUSEIINFOs__r
     */
    public com.sforce.soap.enterprise.QueryResult getCIFZOKUSEIINFOs__r() {
        return CIFZOKUSEIINFOs__r;
    }


    /**
     * Sets the CIFZOKUSEIINFOs__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param CIFZOKUSEIINFOs__r
     */
    public void setCIFZOKUSEIINFOs__r(com.sforce.soap.enterprise.QueryResult CIFZOKUSEIINFOs__r) {
        this.CIFZOKUSEIINFOs__r = CIFZOKUSEIINFOs__r;
    }


    /**
     * Gets the COUNTRYCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return COUNTRYCD__c
     */
    public java.lang.String getCOUNTRYCD__c() {
        return COUNTRYCD__c;
    }


    /**
     * Sets the COUNTRYCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param COUNTRYCD__c
     */
    public void setCOUNTRYCD__c(java.lang.String COUNTRYCD__c) {
        this.COUNTRYCD__c = COUNTRYCD__c;
    }


    /**
     * Gets the combinedAttachments value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return combinedAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getCombinedAttachments() {
        return combinedAttachments;
    }


    /**
     * Sets the combinedAttachments value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param combinedAttachments
     */
    public void setCombinedAttachments(com.sforce.soap.enterprise.QueryResult combinedAttachments) {
        this.combinedAttachments = combinedAttachments;
    }


    /**
     * Gets the createdBy value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return createdBy
     */
    public com.sforce.soap.enterprise.sobject.User getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param createdBy
     */
    public void setCreatedBy(com.sforce.soap.enterprise.sobject.User createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createdById value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return createdById
     */
    public java.lang.String getCreatedById() {
        return createdById;
    }


    /**
     * Sets the createdById value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param createdById
     */
    public void setCreatedById(java.lang.String createdById) {
        this.createdById = createdById;
    }


    /**
     * Gets the createdDate value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return createdDate
     */
    public java.util.Calendar getCreatedDate() {
        return createdDate;
    }


    /**
     * Sets the createdDate value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param createdDate
     */
    public void setCreatedDate(java.util.Calendar createdDate) {
        this.createdDate = createdDate;
    }


    /**
     * Gets the d002_001__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return d002_001__r
     */
    public com.sforce.soap.enterprise.QueryResult getD002_001__r() {
        return d002_001__r;
    }


    /**
     * Sets the d002_001__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param d002_001__r
     */
    public void setD002_001__r(com.sforce.soap.enterprise.QueryResult d002_001__r) {
        this.d002_001__r = d002_001__r;
    }


    /**
     * Gets the d002_002__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return d002_002__r
     */
    public com.sforce.soap.enterprise.QueryResult getD002_002__r() {
        return d002_002__r;
    }


    /**
     * Sets the d002_002__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param d002_002__r
     */
    public void setD002_002__r(com.sforce.soap.enterprise.QueryResult d002_002__r) {
        this.d002_002__r = d002_002__r;
    }


    /**
     * Gets the d003_001__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return d003_001__r
     */
    public com.sforce.soap.enterprise.QueryResult getD003_001__r() {
        return d003_001__r;
    }


    /**
     * Sets the d003_001__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param d003_001__r
     */
    public void setD003_001__r(com.sforce.soap.enterprise.QueryResult d003_001__r) {
        this.d003_001__r = d003_001__r;
    }


    /**
     * Gets the d003_002__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return d003_002__r
     */
    public com.sforce.soap.enterprise.QueryResult getD003_002__r() {
        return d003_002__r;
    }


    /**
     * Sets the d003_002__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param d003_002__r
     */
    public void setD003_002__r(com.sforce.soap.enterprise.QueryResult d003_002__r) {
        this.d003_002__r = d003_002__r;
    }


    /**
     * Gets the d004_ToDoSnaps02__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return d004_ToDoSnaps02__r
     */
    public com.sforce.soap.enterprise.QueryResult getD004_ToDoSnaps02__r() {
        return d004_ToDoSnaps02__r;
    }


    /**
     * Sets the d004_ToDoSnaps02__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param d004_ToDoSnaps02__r
     */
    public void setD004_ToDoSnaps02__r(com.sforce.soap.enterprise.QueryResult d004_ToDoSnaps02__r) {
        this.d004_ToDoSnaps02__r = d004_ToDoSnaps02__r;
    }


    /**
     * Gets the d004_ToDoSnaps__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return d004_ToDoSnaps__r
     */
    public com.sforce.soap.enterprise.QueryResult getD004_ToDoSnaps__r() {
        return d004_ToDoSnaps__r;
    }


    /**
     * Sets the d004_ToDoSnaps__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param d004_ToDoSnaps__r
     */
    public void setD004_ToDoSnaps__r(com.sforce.soap.enterprise.QueryResult d004_ToDoSnaps__r) {
        this.d004_ToDoSnaps__r = d004_ToDoSnaps__r;
    }


    /**
     * Gets the d004_ToDos02__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return d004_ToDos02__r
     */
    public com.sforce.soap.enterprise.QueryResult getD004_ToDos02__r() {
        return d004_ToDos02__r;
    }


    /**
     * Sets the d004_ToDos02__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param d004_ToDos02__r
     */
    public void setD004_ToDos02__r(com.sforce.soap.enterprise.QueryResult d004_ToDos02__r) {
        this.d004_ToDos02__r = d004_ToDos02__r;
    }


    /**
     * Gets the d004_ToDos__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return d004_ToDos__r
     */
    public com.sforce.soap.enterprise.QueryResult getD004_ToDos__r() {
        return d004_ToDos__r;
    }


    /**
     * Sets the d004_ToDos__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param d004_ToDos__r
     */
    public void setD004_ToDos__r(com.sforce.soap.enterprise.QueryResult d004_ToDos__r) {
        this.d004_ToDos__r = d004_ToDos__r;
    }


    /**
     * Gets the DELFLG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return DELFLG__c
     */
    public java.lang.Boolean getDELFLG__c() {
        return DELFLG__c;
    }


    /**
     * Sets the DELFLG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param DELFLG__c
     */
    public void setDELFLG__c(java.lang.Boolean DELFLG__c) {
        this.DELFLG__c = DELFLG__c;
    }


    /**
     * Gets the DENWABANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return DENWABANGOU__c
     */
    public java.lang.String getDENWABANGOU__c() {
        return DENWABANGOU__c;
    }


    /**
     * Sets the DENWABANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param DENWABANGOU__c
     */
    public void setDENWABANGOU__c(java.lang.String DENWABANGOU__c) {
        this.DENWABANGOU__c = DENWABANGOU__c;
    }


    /**
     * Gets the DMDOUIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return DMDOUIKBN__c
     */
    public java.lang.String getDMDOUIKBN__c() {
        return DMDOUIKBN__c;
    }


    /**
     * Sets the DMDOUIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param DMDOUIKBN__c
     */
    public void setDMDOUIKBN__c(java.lang.String DMDOUIKBN__c) {
        this.DMDOUIKBN__c = DMDOUIKBN__c;
    }


    /**
     * Gets the duplicateRecordItems value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return duplicateRecordItems
     */
    public com.sforce.soap.enterprise.QueryResult getDuplicateRecordItems() {
        return duplicateRecordItems;
    }


    /**
     * Sets the duplicateRecordItems value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param duplicateRecordItems
     */
    public void setDuplicateRecordItems(com.sforce.soap.enterprise.QueryResult duplicateRecordItems) {
        this.duplicateRecordItems = duplicateRecordItems;
    }


    /**
     * Gets the events value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return events
     */
    public com.sforce.soap.enterprise.QueryResult getEvents() {
        return events;
    }


    /**
     * Sets the events value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param events
     */
    public void setEvents(com.sforce.soap.enterprise.QueryResult events) {
        this.events = events;
    }


    /**
     * Gets the GAISHIKEIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return GAISHIKEIKBN__c
     */
    public java.lang.String getGAISHIKEIKBN__c() {
        return GAISHIKEIKBN__c;
    }


    /**
     * Sets the GAISHIKEIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param GAISHIKEIKBN__c
     */
    public void setGAISHIKEIKBN__c(java.lang.String GAISHIKEIKBN__c) {
        this.GAISHIKEIKBN__c = GAISHIKEIKBN__c;
    }


    /**
     * Gets the GAITAMETORIHIKIKAISHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return GAITAMETORIHIKIKAISHIBI__c
     */
    public java.util.Date getGAITAMETORIHIKIKAISHIBI__c() {
        return GAITAMETORIHIKIKAISHIBI__c;
    }


    /**
     * Sets the GAITAMETORIHIKIKAISHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param GAITAMETORIHIKIKAISHIBI__c
     */
    public void setGAITAMETORIHIKIKAISHIBI__c(java.util.Date GAITAMETORIHIKIKAISHIBI__c) {
        this.GAITAMETORIHIKIKAISHIBI__c = GAITAMETORIHIKIKAISHIBI__c;
    }


    /**
     * Gets the GAITAMEYOSHINTORIHIKIKAISHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return GAITAMEYOSHINTORIHIKIKAISHIBI__c
     */
    public java.util.Date getGAITAMEYOSHINTORIHIKIKAISHIBI__c() {
        return GAITAMEYOSHINTORIHIKIKAISHIBI__c;
    }


    /**
     * Sets the GAITAMEYOSHINTORIHIKIKAISHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param GAITAMEYOSHINTORIHIKIKAISHIBI__c
     */
    public void setGAITAMEYOSHINTORIHIKIKAISHIBI__c(java.util.Date GAITAMEYOSHINTORIHIKIKAISHIBI__c) {
        this.GAITAMEYOSHINTORIHIKIKAISHIBI__c = GAITAMEYOSHINTORIHIKIKAISHIBI__c;
    }


    /**
     * Gets the GCIFBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return GCIFBANGOU__c
     */
    public java.lang.String getGCIFBANGOU__c() {
        return GCIFBANGOU__c;
    }


    /**
     * Sets the GCIFBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param GCIFBANGOU__c
     */
    public void setGCIFBANGOU__c(java.lang.String GCIFBANGOU__c) {
        this.GCIFBANGOU__c = GCIFBANGOU__c;
    }


    /**
     * Gets the GYOUSHUCD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return GYOUSHUCD1__c
     */
    public java.lang.String getGYOUSHUCD1__c() {
        return GYOUSHUCD1__c;
    }


    /**
     * Sets the GYOUSHUCD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param GYOUSHUCD1__c
     */
    public void setGYOUSHUCD1__c(java.lang.String GYOUSHUCD1__c) {
        this.GYOUSHUCD1__c = GYOUSHUCD1__c;
    }


    /**
     * Gets the GYOUSHUCD2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return GYOUSHUCD2__c
     */
    public java.lang.String getGYOUSHUCD2__c() {
        return GYOUSHUCD2__c;
    }


    /**
     * Sets the GYOUSHUCD2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param GYOUSHUCD2__c
     */
    public void setGYOUSHUCD2__c(java.lang.String GYOUSHUCD2__c) {
        this.GYOUSHUCD2__c = GYOUSHUCD2__c;
    }


    /**
     * Gets the GYOUSHUCD3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return GYOUSHUCD3__c
     */
    public java.lang.String getGYOUSHUCD3__c() {
        return GYOUSHUCD3__c;
    }


    /**
     * Sets the GYOUSHUCD3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param GYOUSHUCD3__c
     */
    public void setGYOUSHUCD3__c(java.lang.String GYOUSHUCD3__c) {
        this.GYOUSHUCD3__c = GYOUSHUCD3__c;
    }


    /**
     * Gets the HATANSAKISAIKUBUN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return HATANSAKISAIKUBUN__c
     */
    public java.lang.String getHATANSAKISAIKUBUN__c() {
        return HATANSAKISAIKUBUN__c;
    }


    /**
     * Sets the HATANSAKISAIKUBUN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param HATANSAKISAIKUBUN__c
     */
    public void setHATANSAKISAIKUBUN__c(java.lang.String HATANSAKISAIKUBUN__c) {
        this.HATANSAKISAIKUBUN__c = HATANSAKISAIKUBUN__c;
    }


    /**
     * Gets the HIKIATEHYOUKA__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return HIKIATEHYOUKA__c
     */
    public java.lang.String getHIKIATEHYOUKA__c() {
        return HIKIATEHYOUKA__c;
    }


    /**
     * Sets the HIKIATEHYOUKA__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param HIKIATEHYOUKA__c
     */
    public void setHIKIATEHYOUKA__c(java.lang.String HIKIATEHYOUKA__c) {
        this.HIKIATEHYOUKA__c = HIKIATEHYOUKA__c;
    }


    /**
     * Gets the HONBUTANTOUBUMONCD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return HONBUTANTOUBUMONCD1__c
     */
    public java.lang.String getHONBUTANTOUBUMONCD1__c() {
        return HONBUTANTOUBUMONCD1__c;
    }


    /**
     * Sets the HONBUTANTOUBUMONCD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param HONBUTANTOUBUMONCD1__c
     */
    public void setHONBUTANTOUBUMONCD1__c(java.lang.String HONBUTANTOUBUMONCD1__c) {
        this.HONBUTANTOUBUMONCD1__c = HONBUTANTOUBUMONCD1__c;
    }


    /**
     * Gets the HONBUTANTOUSHACD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return HONBUTANTOUSHACD1__c
     */
    public java.lang.String getHONBUTANTOUSHACD1__c() {
        return HONBUTANTOUSHACD1__c;
    }


    /**
     * Sets the HONBUTANTOUSHACD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param HONBUTANTOUSHACD1__c
     */
    public void setHONBUTANTOUSHACD1__c(java.lang.String HONBUTANTOUSHACD1__c) {
        this.HONBUTANTOUSHACD1__c = HONBUTANTOUSHACD1__c;
    }


    /**
     * Gets the HYOUTEN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return HYOUTEN__c
     */
    public java.lang.Double getHYOUTEN__c() {
        return HYOUTEN__c;
    }


    /**
     * Sets the HYOUTEN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param HYOUTEN__c
     */
    public void setHYOUTEN__c(java.lang.Double HYOUTEN__c) {
        this.HYOUTEN__c = HYOUTEN__c;
    }


    /**
     * Gets the histories value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return histories
     */
    public com.sforce.soap.enterprise.QueryResult getHistories() {
        return histories;
    }


    /**
     * Sets the histories value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param histories
     */
    public void setHistories(com.sforce.soap.enterprise.QueryResult histories) {
        this.histories = histories;
    }


    /**
     * Gets the isDeleted value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return isDeleted
     */
    public java.lang.Boolean getIsDeleted() {
        return isDeleted;
    }


    /**
     * Sets the isDeleted value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param isDeleted
     */
    public void setIsDeleted(java.lang.Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }


    /**
     * Gets the JCR_CSKHENKOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_CSKHENKOUKBN__c
     */
    public java.lang.String getJCR_CSKHENKOUKBN__c() {
        return JCR_CSKHENKOUKBN__c;
    }


    /**
     * Sets the JCR_CSKHENKOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_CSKHENKOUKBN__c
     */
    public void setJCR_CSKHENKOUKBN__c(java.lang.String JCR_CSKHENKOUKBN__c) {
        this.JCR_CSKHENKOUKBN__c = JCR_CSKHENKOUKBN__c;
    }


    /**
     * Gets the JCR_CSKKEY1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_CSKKEY1__c
     */
    public java.lang.String getJCR_CSKKEY1__c() {
        return JCR_CSKKEY1__c;
    }


    /**
     * Sets the JCR_CSKKEY1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_CSKKEY1__c
     */
    public void setJCR_CSKKEY1__c(java.lang.String JCR_CSKKEY1__c) {
        this.JCR_CSKKEY1__c = JCR_CSKKEY1__c;
    }


    /**
     * Gets the JCR_CSKKEY2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_CSKKEY2__c
     */
    public java.lang.String getJCR_CSKKEY2__c() {
        return JCR_CSKKEY2__c;
    }


    /**
     * Sets the JCR_CSKKEY2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_CSKKEY2__c
     */
    public void setJCR_CSKKEY2__c(java.lang.String JCR_CSKKEY2__c) {
        this.JCR_CSKKEY2__c = JCR_CSKKEY2__c;
    }


    /**
     * Gets the JCR_CSKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_CSKSTB__c
     */
    public java.util.Date getJCR_CSKSTB__c() {
        return JCR_CSKSTB__c;
    }


    /**
     * Sets the JCR_CSKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_CSKSTB__c
     */
    public void setJCR_CSKSTB__c(java.util.Date JCR_CSKSTB__c) {
        this.JCR_CSKSTB__c = JCR_CSKSTB__c;
    }


    /**
     * Gets the JCR_CSK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_CSK__c
     */
    public java.lang.String getJCR_CSK__c() {
        return JCR_CSK__c;
    }


    /**
     * Sets the JCR_CSK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_CSK__c
     */
    public void setJCR_CSK__c(java.lang.String JCR_CSK__c) {
        this.JCR_CSK__c = JCR_CSK__c;
    }


    /**
     * Gets the JCR_HAKKOUTAIID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_HAKKOUTAIID__c
     */
    public java.lang.String getJCR_HAKKOUTAIID__c() {
        return JCR_HAKKOUTAIID__c;
    }


    /**
     * Sets the JCR_HAKKOUTAIID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_HAKKOUTAIID__c
     */
    public void setJCR_HAKKOUTAIID__c(java.lang.String JCR_HAKKOUTAIID__c) {
        this.JCR_HAKKOUTAIID__c = JCR_HAKKOUTAIID__c;
    }


    /**
     * Gets the JCR_HAKKOUTAI_NM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_HAKKOUTAI_NM__c
     */
    public java.lang.String getJCR_HAKKOUTAI_NM__c() {
        return JCR_HAKKOUTAI_NM__c;
    }


    /**
     * Sets the JCR_HAKKOUTAI_NM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_HAKKOUTAI_NM__c
     */
    public void setJCR_HAKKOUTAI_NM__c(java.lang.String JCR_HAKKOUTAI_NM__c) {
        this.JCR_HAKKOUTAI_NM__c = JCR_HAKKOUTAI_NM__c;
    }


    /**
     * Gets the JCR_KIJUNBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_KIJUNBI__c
     */
    public java.util.Date getJCR_KIJUNBI__c() {
        return JCR_KIJUNBI__c;
    }


    /**
     * Sets the JCR_KIJUNBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_KIJUNBI__c
     */
    public void setJCR_KIJUNBI__c(java.util.Date JCR_KIJUNBI__c) {
        this.JCR_KIJUNBI__c = JCR_KIJUNBI__c;
    }


    /**
     * Gets the JCR_MCKHENKOUKBN_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_MCKHENKOUKBN_CH__c
     */
    public java.lang.String getJCR_MCKHENKOUKBN_CH__c() {
        return JCR_MCKHENKOUKBN_CH__c;
    }


    /**
     * Sets the JCR_MCKHENKOUKBN_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_MCKHENKOUKBN_CH__c
     */
    public void setJCR_MCKHENKOUKBN_CH__c(java.lang.String JCR_MCKHENKOUKBN_CH__c) {
        this.JCR_MCKHENKOUKBN_CH__c = JCR_MCKHENKOUKBN_CH__c;
    }


    /**
     * Gets the JCR_MCKHENKOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_MCKHENKOUKBN__c
     */
    public java.lang.String getJCR_MCKHENKOUKBN__c() {
        return JCR_MCKHENKOUKBN__c;
    }


    /**
     * Sets the JCR_MCKHENKOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_MCKHENKOUKBN__c
     */
    public void setJCR_MCKHENKOUKBN__c(java.lang.String JCR_MCKHENKOUKBN__c) {
        this.JCR_MCKHENKOUKBN__c = JCR_MCKHENKOUKBN__c;
    }


    /**
     * Gets the JCR_MCKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_MCKSTB__c
     */
    public java.util.Date getJCR_MCKSTB__c() {
        return JCR_MCKSTB__c;
    }


    /**
     * Sets the JCR_MCKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_MCKSTB__c
     */
    public void setJCR_MCKSTB__c(java.util.Date JCR_MCKSTB__c) {
        this.JCR_MCKSTB__c = JCR_MCKSTB__c;
    }


    /**
     * Gets the JCR_MCK_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_MCK_CH__c
     */
    public java.lang.String getJCR_MCK_CH__c() {
        return JCR_MCK_CH__c;
    }


    /**
     * Sets the JCR_MCK_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_MCK_CH__c
     */
    public void setJCR_MCK_CH__c(java.lang.String JCR_MCK_CH__c) {
        this.JCR_MCK_CH__c = JCR_MCK_CH__c;
    }


    /**
     * Gets the JCR_MCK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_MCK__c
     */
    public java.lang.String getJCR_MCK__c() {
        return JCR_MCK__c;
    }


    /**
     * Sets the JCR_MCK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_MCK__c
     */
    public void setJCR_MCK__c(java.lang.String JCR_MCK__c) {
        this.JCR_MCK__c = JCR_MCK__c;
    }


    /**
     * Gets the JCR_MINASHIHANBETSUCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_MINASHIHANBETSUCD__c
     */
    public java.lang.String getJCR_MINASHIHANBETSUCD__c() {
        return JCR_MINASHIHANBETSUCD__c;
    }


    /**
     * Sets the JCR_MINASHIHANBETSUCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_MINASHIHANBETSUCD__c
     */
    public void setJCR_MINASHIHANBETSUCD__c(java.lang.String JCR_MINASHIHANBETSUCD__c) {
        this.JCR_MINASHIHANBETSUCD__c = JCR_MINASHIHANBETSUCD__c;
    }


    /**
     * Gets the JCR_YUUKOUKIKANSHUURYOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JCR_YUUKOUKIKANSHUURYOUBI__c
     */
    public java.util.Date getJCR_YUUKOUKIKANSHUURYOUBI__c() {
        return JCR_YUUKOUKIKANSHUURYOUBI__c;
    }


    /**
     * Sets the JCR_YUUKOUKIKANSHUURYOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JCR_YUUKOUKIKANSHUURYOUBI__c
     */
    public void setJCR_YUUKOUKIKANSHUURYOUBI__c(java.util.Date JCR_YUUKOUKIKANSHUURYOUBI__c) {
        this.JCR_YUUKOUKIKANSHUURYOUBI__c = JCR_YUUKOUKIKANSHUURYOUBI__c;
    }


    /**
     * Gets the JIGYOUSHA_HIJIGYOUSHAKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JIGYOUSHA_HIJIGYOUSHAKBN__c
     */
    public java.lang.String getJIGYOUSHA_HIJIGYOUSHAKBN__c() {
        return JIGYOUSHA_HIJIGYOUSHAKBN__c;
    }


    /**
     * Sets the JIGYOUSHA_HIJIGYOUSHAKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JIGYOUSHA_HIJIGYOUSHAKBN__c
     */
    public void setJIGYOUSHA_HIJIGYOUSHAKBN__c(java.lang.String JIGYOUSHA_HIJIGYOUSHAKBN__c) {
        this.JIGYOUSHA_HIJIGYOUSHAKBN__c = JIGYOUSHA_HIJIGYOUSHAKBN__c;
    }


    /**
     * Gets the JINKAKUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JINKAKUKBN__c
     */
    public java.lang.String getJINKAKUKBN__c() {
        return JINKAKUKBN__c;
    }


    /**
     * Sets the JINKAKUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JINKAKUKBN__c
     */
    public void setJINKAKUKBN__c(java.lang.String JINKAKUKBN__c) {
        this.JINKAKUKBN__c = JINKAKUKBN__c;
    }


    /**
     * Gets the JOUJOUKBN1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JOUJOUKBN1__c
     */
    public java.lang.String getJOUJOUKBN1__c() {
        return JOUJOUKBN1__c;
    }


    /**
     * Sets the JOUJOUKBN1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JOUJOUKBN1__c
     */
    public void setJOUJOUKBN1__c(java.lang.String JOUJOUKBN1__c) {
        this.JOUJOUKBN1__c = JOUJOUKBN1__c;
    }


    /**
     * Gets the JOUJOUKBN2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JOUJOUKBN2__c
     */
    public java.lang.String getJOUJOUKBN2__c() {
        return JOUJOUKBN2__c;
    }


    /**
     * Sets the JOUJOUKBN2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JOUJOUKBN2__c
     */
    public void setJOUJOUKBN2__c(java.lang.String JOUJOUKBN2__c) {
        this.JOUJOUKBN2__c = JOUJOUKBN2__c;
    }


    /**
     * Gets the JOUJOUKBN3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JOUJOUKBN3__c
     */
    public java.lang.String getJOUJOUKBN3__c() {
        return JOUJOUKBN3__c;
    }


    /**
     * Sets the JOUJOUKBN3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JOUJOUKBN3__c
     */
    public void setJOUJOUKBN3__c(java.lang.String JOUJOUKBN3__c) {
        this.JOUJOUKBN3__c = JOUJOUKBN3__c;
    }


    /**
     * Gets the JOUJOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JOUJOUKBN__c
     */
    public java.lang.String getJOUJOUKBN__c() {
        return JOUJOUKBN__c;
    }


    /**
     * Sets the JOUJOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JOUJOUKBN__c
     */
    public void setJOUJOUKBN__c(java.lang.String JOUJOUKBN__c) {
        this.JOUJOUKBN__c = JOUJOUKBN__c;
    }


    /**
     * Gets the JUNKYOHOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JUNKYOHOUKBN__c
     */
    public java.lang.String getJUNKYOHOUKBN__c() {
        return JUNKYOHOUKBN__c;
    }


    /**
     * Sets the JUNKYOHOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JUNKYOHOUKBN__c
     */
    public void setJUNKYOHOUKBN__c(java.lang.String JUNKYOHOUKBN__c) {
        this.JUNKYOHOUKBN__c = JUNKYOHOUKBN__c;
    }


    /**
     * Gets the JUUGYOUIN_CNT__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return JUUGYOUIN_CNT__c
     */
    public java.lang.Double getJUUGYOUIN_CNT__c() {
        return JUUGYOUIN_CNT__c;
    }


    /**
     * Sets the JUUGYOUIN_CNT__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param JUUGYOUIN_CNT__c
     */
    public void setJUUGYOUIN_CNT__c(java.lang.Double JUUGYOUIN_CNT__c) {
        this.JUUGYOUIN_CNT__c = JUUGYOUIN_CNT__c;
    }


    /**
     * Gets the KABUSHIKICD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KABUSHIKICD__c
     */
    public java.lang.String getKABUSHIKICD__c() {
        return KABUSHIKICD__c;
    }


    /**
     * Sets the KABUSHIKICD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KABUSHIKICD__c
     */
    public void setKABUSHIKICD__c(java.lang.String KABUSHIKICD__c) {
        this.KABUSHIKICD__c = KABUSHIKICD__c;
    }


    /**
     * Gets the KACD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KACD__c
     */
    public java.lang.String getKACD__c() {
        return KACD__c;
    }


    /**
     * Sets the KACD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KACD__c
     */
    public void setKACD__c(java.lang.String KACD__c) {
        this.KACD__c = KACD__c;
    }


    /**
     * Gets the KAKUDUKEHENKOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KAKUDUKEHENKOUBI__c
     */
    public java.util.Date getKAKUDUKEHENKOUBI__c() {
        return KAKUDUKEHENKOUBI__c;
    }


    /**
     * Sets the KAKUDUKEHENKOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KAKUDUKEHENKOUBI__c
     */
    public void setKAKUDUKEHENKOUBI__c(java.util.Date KAKUDUKEHENKOUBI__c) {
        this.KAKUDUKEHENKOUBI__c = KAKUDUKEHENKOUBI__c;
    }


    /**
     * Gets the KAKUDUKEKOUSHINBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KAKUDUKEKOUSHINBI__c
     */
    public java.util.Date getKAKUDUKEKOUSHINBI__c() {
        return KAKUDUKEKOUSHINBI__c;
    }


    /**
     * Sets the KAKUDUKEKOUSHINBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KAKUDUKEKOUSHINBI__c
     */
    public void setKAKUDUKEKOUSHINBI__c(java.util.Date KAKUDUKEKOUSHINBI__c) {
        this.KAKUDUKEKOUSHINBI__c = KAKUDUKEKOUSHINBI__c;
    }


    /**
     * Gets the KAKUDUKESAIKUBUN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KAKUDUKESAIKUBUN__c
     */
    public java.lang.String getKAKUDUKESAIKUBUN__c() {
        return KAKUDUKESAIKUBUN__c;
    }


    /**
     * Sets the KAKUDUKESAIKUBUN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KAKUDUKESAIKUBUN__c
     */
    public void setKAKUDUKESAIKUBUN__c(java.lang.String KAKUDUKESAIKUBUN__c) {
        this.KAKUDUKESAIKUBUN__c = KAKUDUKESAIKUBUN__c;
    }


    /**
     * Gets the KANJISHIMEI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KANJISHIMEI__c
     */
    public java.lang.String getKANJISHIMEI__c() {
        return KANJISHIMEI__c;
    }


    /**
     * Sets the KANJISHIMEI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KANJISHIMEI__c
     */
    public void setKANJISHIMEI__c(java.lang.String KANJISHIMEI__c) {
        this.KANJISHIMEI__c = KANJISHIMEI__c;
    }


    /**
     * Gets the KANRISAKIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KANRISAKIKBN__c
     */
    public java.lang.String getKANRISAKIKBN__c() {
        return KANRISAKIKBN__c;
    }


    /**
     * Sets the KANRISAKIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KANRISAKIKBN__c
     */
    public void setKANRISAKIKBN__c(java.lang.String KANRISAKIKBN__c) {
        this.KANRISAKIKBN__c = KANRISAKIKBN__c;
    }


    /**
     * Gets the KANSAJISSHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KANSAJISSHIBI__c
     */
    public java.util.Date getKANSAJISSHIBI__c() {
        return KANSAJISSHIBI__c;
    }


    /**
     * Sets the KANSAJISSHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KANSAJISSHIBI__c
     */
    public void setKANSAJISSHIBI__c(java.util.Date KANSAJISSHIBI__c) {
        this.KANSAJISSHIBI__c = KANSAJISSHIBI__c;
    }


    /**
     * Gets the KASHIGAITORIHIKIUMUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KASHIGAITORIHIKIUMUKBN__c
     */
    public java.lang.String getKASHIGAITORIHIKIUMUKBN__c() {
        return KASHIGAITORIHIKIUMUKBN__c;
    }


    /**
     * Sets the KASHIGAITORIHIKIUMUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KASHIGAITORIHIKIUMUKBN__c
     */
    public void setKASHIGAITORIHIKIUMUKBN__c(java.lang.String KASHIGAITORIHIKIUMUKBN__c) {
        this.KASHIGAITORIHIKIUMUKBN__c = KASHIGAITORIHIKIUMUKBN__c;
    }


    /**
     * Gets the KA_GROUPNM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KA_GROUPNM__c
     */
    public java.lang.String getKA_GROUPNM__c() {
        return KA_GROUPNM__c;
    }


    /**
     * Sets the KA_GROUPNM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KA_GROUPNM__c
     */
    public void setKA_GROUPNM__c(java.lang.String KA_GROUPNM__c) {
        this.KA_GROUPNM__c = KA_GROUPNM__c;
    }


    /**
     * Gets the KEIRETSU_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KEIRETSU_KANJI__c
     */
    public java.lang.String getKEIRETSU_KANJI__c() {
        return KEIRETSU_KANJI__c;
    }


    /**
     * Sets the KEIRETSU_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KEIRETSU_KANJI__c
     */
    public void setKEIRETSU_KANJI__c(java.lang.String KEIRETSU_KANJI__c) {
        this.KEIRETSU_KANJI__c = KEIRETSU_KANJI__c;
    }


    /**
     * Gets the KENSAKUYOUKANASHOUGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KENSAKUYOUKANASHOUGOU__c
     */
    public java.lang.String getKENSAKUYOUKANASHOUGOU__c() {
        return KENSAKUYOUKANASHOUGOU__c;
    }


    /**
     * Sets the KENSAKUYOUKANASHOUGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KENSAKUYOUKANASHOUGOU__c
     */
    public void setKENSAKUYOUKANASHOUGOU__c(java.lang.String KENSAKUYOUKANASHOUGOU__c) {
        this.KENSAKUYOUKANASHOUGOU__c = KENSAKUYOUKANASHOUGOU__c;
    }


    /**
     * Gets the KENSAKUYOUKANJISHOUGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KENSAKUYOUKANJISHOUGOU__c
     */
    public java.lang.String getKENSAKUYOUKANJISHOUGOU__c() {
        return KENSAKUYOUKANJISHOUGOU__c;
    }


    /**
     * Sets the KENSAKUYOUKANJISHOUGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KENSAKUYOUKANJISHOUGOU__c
     */
    public void setKENSAKUYOUKANJISHOUGOU__c(java.lang.String KENSAKUYOUKANJISHOUGOU__c) {
        this.KENSAKUYOUKANJISHOUGOU__c = KENSAKUYOUKANJISHOUGOU__c;
    }


    /**
     * Gets the KESSANNENGETSU2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KESSANNENGETSU2__c
     */
    public java.lang.String getKESSANNENGETSU2__c() {
        return KESSANNENGETSU2__c;
    }


    /**
     * Sets the KESSANNENGETSU2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KESSANNENGETSU2__c
     */
    public void setKESSANNENGETSU2__c(java.lang.String KESSANNENGETSU2__c) {
        this.KESSANNENGETSU2__c = KESSANNENGETSU2__c;
    }


    /**
     * Gets the KESSANNENGETSU3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KESSANNENGETSU3__c
     */
    public java.lang.String getKESSANNENGETSU3__c() {
        return KESSANNENGETSU3__c;
    }


    /**
     * Sets the KESSANNENGETSU3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KESSANNENGETSU3__c
     */
    public void setKESSANNENGETSU3__c(java.lang.String KESSANNENGETSU3__c) {
        this.KESSANNENGETSU3__c = KESSANNENGETSU3__c;
    }


    /**
     * Gets the KESSANNENGETSU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KESSANNENGETSU__c
     */
    public java.lang.String getKESSANNENGETSU__c() {
        return KESSANNENGETSU__c;
    }


    /**
     * Sets the KESSANNENGETSU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KESSANNENGETSU__c
     */
    public void setKESSANNENGETSU__c(java.lang.String KESSANNENGETSU__c) {
        this.KESSANNENGETSU__c = KESSANNENGETSU__c;
    }


    /**
     * Gets the KESSANTSUKI_CHUU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KESSANTSUKI_CHUU__c
     */
    public java.lang.String getKESSANTSUKI_CHUU__c() {
        return KESSANTSUKI_CHUU__c;
    }


    /**
     * Sets the KESSANTSUKI_CHUU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KESSANTSUKI_CHUU__c
     */
    public void setKESSANTSUKI_CHUU__c(java.lang.String KESSANTSUKI_CHUU__c) {
        this.KESSANTSUKI_CHUU__c = KESSANTSUKI_CHUU__c;
    }


    /**
     * Gets the KESSANTSUKI_HON__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KESSANTSUKI_HON__c
     */
    public java.lang.String getKESSANTSUKI_HON__c() {
        return KESSANTSUKI_HON__c;
    }


    /**
     * Sets the KESSANTSUKI_HON__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KESSANTSUKI_HON__c
     */
    public void setKESSANTSUKI_HON__c(java.lang.String KESSANTSUKI_HON__c) {
        this.KESSANTSUKI_HON__c = KESSANTSUKI_HON__c;
    }


    /**
     * Gets the KIGYOUBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KIGYOUBANGOU__c
     */
    public java.lang.String getKIGYOUBANGOU__c() {
        return KIGYOUBANGOU__c;
    }


    /**
     * Sets the KIGYOUBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KIGYOUBANGOU__c
     */
    public void setKIGYOUBANGOU__c(java.lang.String KIGYOUBANGOU__c) {
        this.KIGYOUBANGOU__c = KIGYOUBANGOU__c;
    }


    /**
     * Gets the KIGYOUKIBOCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KIGYOUKIBOCD__c
     */
    public java.lang.String getKIGYOUKIBOCD__c() {
        return KIGYOUKIBOCD__c;
    }


    /**
     * Sets the KIGYOUKIBOCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KIGYOUKIBOCD__c
     */
    public void setKIGYOUKIBOCD__c(java.lang.String KIGYOUKIBOCD__c) {
        this.KIGYOUKIBOCD__c = KIGYOUKIBOCD__c;
    }


    /**
     * Gets the KIGYOUSEG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KIGYOUSEG__c
     */
    public java.lang.String getKIGYOUSEG__c() {
        return KIGYOUSEG__c;
    }


    /**
     * Sets the KIGYOUSEG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KIGYOUSEG__c
     */
    public void setKIGYOUSEG__c(java.lang.String KIGYOUSEG__c) {
        this.KIGYOUSEG__c = KIGYOUSEG__c;
    }


    /**
     * Gets the KOKUNAIYOSHINTORIHIKIKAISHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KOKUNAIYOSHINTORIHIKIKAISHIBI__c
     */
    public java.util.Date getKOKUNAIYOSHINTORIHIKIKAISHIBI__c() {
        return KOKUNAIYOSHINTORIHIKIKAISHIBI__c;
    }


    /**
     * Sets the KOKUNAIYOSHINTORIHIKIKAISHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KOKUNAIYOSHINTORIHIKIKAISHIBI__c
     */
    public void setKOKUNAIYOSHINTORIHIKIKAISHIBI__c(java.util.Date KOKUNAIYOSHINTORIHIKIKAISHIBI__c) {
        this.KOKUNAIYOSHINTORIHIKIKAISHIBI__c = KOKUNAIYOSHINTORIHIKIKAISHIBI__c;
    }


    /**
     * Gets the KOKYAKUBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KOKYAKUBANGOU__c
     */
    public java.lang.String getKOKYAKUBANGOU__c() {
        return KOKYAKUBANGOU__c;
    }


    /**
     * Sets the KOKYAKUBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KOKYAKUBANGOU__c
     */
    public void setKOKYAKUBANGOU__c(java.lang.String KOKYAKUBANGOU__c) {
        this.KOKYAKUBANGOU__c = KOKYAKUBANGOU__c;
    }


    /**
     * Gets the KOKYAKUKANRITENBAN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KOKYAKUKANRITENBAN__c
     */
    public java.lang.String getKOKYAKUKANRITENBAN__c() {
        return KOKYAKUKANRITENBAN__c;
    }


    /**
     * Sets the KOKYAKUKANRITENBAN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KOKYAKUKANRITENBAN__c
     */
    public void setKOKYAKUKANRITENBAN__c(java.lang.String KOKYAKUKANRITENBAN__c) {
        this.KOKYAKUKANRITENBAN__c = KOKYAKUKANRITENBAN__c;
    }


    /**
     * Gets the KOUKINCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KOUKINCD__c
     */
    public java.lang.String getKOUKINCD__c() {
        return KOUKINCD__c;
    }


    /**
     * Sets the KOUKINCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KOUKINCD__c
     */
    public void setKOUKINCD__c(java.lang.String KOUKINCD__c) {
        this.KOUKINCD__c = KOUKINCD__c;
    }


    /**
     * Gets the KOUSHINBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KOUSHINBI__c
     */
    public java.util.Date getKOUSHINBI__c() {
        return KOUSHINBI__c;
    }


    /**
     * Sets the KOUSHINBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KOUSHINBI__c
     */
    public void setKOUSHINBI__c(java.util.Date KOUSHINBI__c) {
        this.KOUSHINBI__c = KOUSHINBI__c;
    }


    /**
     * Gets the KOZATEMMEI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KOZATEMMEI__c
     */
    public java.lang.String getKOZATEMMEI__c() {
        return KOZATEMMEI__c;
    }


    /**
     * Sets the KOZATEMMEI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KOZATEMMEI__c
     */
    public void setKOZATEMMEI__c(java.lang.String KOZATEMMEI__c) {
        this.KOZATEMMEI__c = KOZATEMMEI__c;
    }


    /**
     * Gets the KOZATENJOHO__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KOZATENJOHO__c
     */
    public java.lang.String getKOZATENJOHO__c() {
        return KOZATENJOHO__c;
    }


    /**
     * Sets the KOZATENJOHO__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KOZATENJOHO__c
     */
    public void setKOZATENJOHO__c(java.lang.String KOZATENJOHO__c) {
        this.KOZATENJOHO__c = KOZATENJOHO__c;
    }


    /**
     * Gets the KOZATENJOHO__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KOZATENJOHO__r
     */
    public com.sforce.soap.enterprise.sobject.C000_BUSHOINFO__c getKOZATENJOHO__r() {
        return KOZATENJOHO__r;
    }


    /**
     * Sets the KOZATENJOHO__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KOZATENJOHO__r
     */
    public void setKOZATENJOHO__r(com.sforce.soap.enterprise.sobject.C000_BUSHOINFO__c KOZATENJOHO__r) {
        this.KOZATENJOHO__r = KOZATENJOHO__r;
    }


    /**
     * Gets the KYOJUUSEIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KYOJUUSEIKBN__c
     */
    public java.lang.String getKYOJUUSEIKBN__c() {
        return KYOJUUSEIKBN__c;
    }


    /**
     * Sets the KYOJUUSEIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KYOJUUSEIKBN__c
     */
    public void setKYOJUUSEIKBN__c(java.lang.String KYOJUUSEIKBN__c) {
        this.KYOJUUSEIKBN__c = KYOJUUSEIKBN__c;
    }


    /**
     * Gets the KYOTENHAIKAKAISOU1_BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KYOTENHAIKAKAISOU1_BUTENBANGOU__c
     */
    public java.lang.String getKYOTENHAIKAKAISOU1_BUTENBANGOU__c() {
        return KYOTENHAIKAKAISOU1_BUTENBANGOU__c;
    }


    /**
     * Sets the KYOTENHAIKAKAISOU1_BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KYOTENHAIKAKAISOU1_BUTENBANGOU__c
     */
    public void setKYOTENHAIKAKAISOU1_BUTENBANGOU__c(java.lang.String KYOTENHAIKAKAISOU1_BUTENBANGOU__c) {
        this.KYOTENHAIKAKAISOU1_BUTENBANGOU__c = KYOTENHAIKAKAISOU1_BUTENBANGOU__c;
    }


    /**
     * Gets the KYOTENHAIKAKAISOU2_BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KYOTENHAIKAKAISOU2_BUTENBANGOU__c
     */
    public java.lang.String getKYOTENHAIKAKAISOU2_BUTENBANGOU__c() {
        return KYOTENHAIKAKAISOU2_BUTENBANGOU__c;
    }


    /**
     * Sets the KYOTENHAIKAKAISOU2_BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KYOTENHAIKAKAISOU2_BUTENBANGOU__c
     */
    public void setKYOTENHAIKAKAISOU2_BUTENBANGOU__c(java.lang.String KYOTENHAIKAKAISOU2_BUTENBANGOU__c) {
        this.KYOTENHAIKAKAISOU2_BUTENBANGOU__c = KYOTENHAIKAKAISOU2_BUTENBANGOU__c;
    }


    /**
     * Gets the KYOTENHAIKAKAISOU3_BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KYOTENHAIKAKAISOU3_BUTENBANGOU__c
     */
    public java.lang.String getKYOTENHAIKAKAISOU3_BUTENBANGOU__c() {
        return KYOTENHAIKAKAISOU3_BUTENBANGOU__c;
    }


    /**
     * Sets the KYOTENHAIKAKAISOU3_BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KYOTENHAIKAKAISOU3_BUTENBANGOU__c
     */
    public void setKYOTENHAIKAKAISOU3_BUTENBANGOU__c(java.lang.String KYOTENHAIKAKAISOU3_BUTENBANGOU__c) {
        this.KYOTENHAIKAKAISOU3_BUTENBANGOU__c = KYOTENHAIKAKAISOU3_BUTENBANGOU__c;
    }


    /**
     * Gets the KYOTENSEG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KYOTENSEG__c
     */
    public java.lang.String getKYOTENSEG__c() {
        return KYOTENSEG__c;
    }


    /**
     * Sets the KYOTENSEG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KYOTENSEG__c
     */
    public void setKYOTENSEG__c(java.lang.String KYOTENSEG__c) {
        this.KYOTENSEG__c = KYOTENSEG__c;
    }


    /**
     * Gets the KYOTEN_BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KYOTEN_BUTENBANGOU__c
     */
    public java.lang.String getKYOTEN_BUTENBANGOU__c() {
        return KYOTEN_BUTENBANGOU__c;
    }


    /**
     * Sets the KYOTEN_BUTENBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KYOTEN_BUTENBANGOU__c
     */
    public void setKYOTEN_BUTENBANGOU__c(java.lang.String KYOTEN_BUTENBANGOU__c) {
        this.KYOTEN_BUTENBANGOU__c = KYOTEN_BUTENBANGOU__c;
    }


    /**
     * Gets the KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c
     */
    public java.lang.String getKYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c() {
        return KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c;
    }


    /**
     * Sets the KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c
     */
    public void setKYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c(java.lang.String KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c) {
        this.KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c = KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c;
    }


    /**
     * Gets the KYOUTSUUNINSHOUKOUININFO_USERID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KYOUTSUUNINSHOUKOUININFO_USERID__c
     */
    public java.lang.String getKYOUTSUUNINSHOUKOUININFO_USERID__c() {
        return KYOUTSUUNINSHOUKOUININFO_USERID__c;
    }


    /**
     * Sets the KYOUTSUUNINSHOUKOUININFO_USERID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KYOUTSUUNINSHOUKOUININFO_USERID__c
     */
    public void setKYOUTSUUNINSHOUKOUININFO_USERID__c(java.lang.String KYOUTSUUNINSHOUKOUININFO_USERID__c) {
        this.KYOUTSUUNINSHOUKOUININFO_USERID__c = KYOUTSUUNINSHOUKOUININFO_USERID__c;
    }


    /**
     * Gets the KYOUTSUUNINSHOUKOUININFO_USERID__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return KYOUTSUUNINSHOUKOUININFO_USERID__r
     */
    public com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c getKYOUTSUUNINSHOUKOUININFO_USERID__r() {
        return KYOUTSUUNINSHOUKOUININFO_USERID__r;
    }


    /**
     * Sets the KYOUTSUUNINSHOUKOUININFO_USERID__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param KYOUTSUUNINSHOUKOUININFO_USERID__r
     */
    public void setKYOUTSUUNINSHOUKOUININFO_USERID__r(com.sforce.soap.enterprise.sobject.C000_KYOUTSUUNINSHOUKOUININFO__c KYOUTSUUNINSHOUKOUININFO_USERID__r) {
        this.KYOUTSUUNINSHOUKOUININFO_USERID__r = KYOUTSUUNINSHOUKOUININFO_USERID__r;
    }


    /**
     * Gets the lastActivityDate value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return lastActivityDate
     */
    public java.util.Date getLastActivityDate() {
        return lastActivityDate;
    }


    /**
     * Sets the lastActivityDate value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param lastActivityDate
     */
    public void setLastActivityDate(java.util.Date lastActivityDate) {
        this.lastActivityDate = lastActivityDate;
    }


    /**
     * Gets the lastModifiedBy value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return lastModifiedBy
     */
    public com.sforce.soap.enterprise.sobject.User getLastModifiedBy() {
        return lastModifiedBy;
    }


    /**
     * Sets the lastModifiedBy value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param lastModifiedBy
     */
    public void setLastModifiedBy(com.sforce.soap.enterprise.sobject.User lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }


    /**
     * Gets the lastModifiedById value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return lastModifiedById
     */
    public java.lang.String getLastModifiedById() {
        return lastModifiedById;
    }


    /**
     * Sets the lastModifiedById value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param lastModifiedById
     */
    public void setLastModifiedById(java.lang.String lastModifiedById) {
        this.lastModifiedById = lastModifiedById;
    }


    /**
     * Gets the lastModifiedDate value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return lastModifiedDate
     */
    public java.util.Calendar getLastModifiedDate() {
        return lastModifiedDate;
    }


    /**
     * Sets the lastModifiedDate value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param lastModifiedDate
     */
    public void setLastModifiedDate(java.util.Calendar lastModifiedDate) {
        this.lastModifiedDate = lastModifiedDate;
    }


    /**
     * Gets the lookedUpFromActivities value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return lookedUpFromActivities
     */
    public com.sforce.soap.enterprise.QueryResult getLookedUpFromActivities() {
        return lookedUpFromActivities;
    }


    /**
     * Sets the lookedUpFromActivities value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param lookedUpFromActivities
     */
    public void setLookedUpFromActivities(com.sforce.soap.enterprise.QueryResult lookedUpFromActivities) {
        this.lookedUpFromActivities = lookedUpFromActivities;
    }


    /**
     * Gets the MAINKICHOUCIF_SYSTEMKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MAINKICHOUCIF_SYSTEMKBN__c
     */
    public java.lang.String getMAINKICHOUCIF_SYSTEMKBN__c() {
        return MAINKICHOUCIF_SYSTEMKBN__c;
    }


    /**
     * Sets the MAINKICHOUCIF_SYSTEMKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MAINKICHOUCIF_SYSTEMKBN__c
     */
    public void setMAINKICHOUCIF_SYSTEMKBN__c(java.lang.String MAINKICHOUCIF_SYSTEMKBN__c) {
        this.MAINKICHOUCIF_SYSTEMKBN__c = MAINKICHOUCIF_SYSTEMKBN__c;
    }


    /**
     * Gets the MAINKICHOUCIF_ZOKUSEIBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MAINKICHOUCIF_ZOKUSEIBANGOU__c
     */
    public java.lang.String getMAINKICHOUCIF_ZOKUSEIBANGOU__c() {
        return MAINKICHOUCIF_ZOKUSEIBANGOU__c;
    }


    /**
     * Sets the MAINKICHOUCIF_ZOKUSEIBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MAINKICHOUCIF_ZOKUSEIBANGOU__c
     */
    public void setMAINKICHOUCIF_ZOKUSEIBANGOU__c(java.lang.String MAINKICHOUCIF_ZOKUSEIBANGOU__c) {
        this.MAINKICHOUCIF_ZOKUSEIBANGOU__c = MAINKICHOUCIF_ZOKUSEIBANGOU__c;
    }


    /**
     * Gets the MAINKICHOUCIF__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MAINKICHOUCIF__c
     */
    public java.lang.String getMAINKICHOUCIF__c() {
        return MAINKICHOUCIF__c;
    }


    /**
     * Sets the MAINKICHOUCIF__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MAINKICHOUCIF__c
     */
    public void setMAINKICHOUCIF__c(java.lang.String MAINKICHOUCIF__c) {
        this.MAINKICHOUCIF__c = MAINKICHOUCIF__c;
    }


    /**
     * Gets the MAIN_CIF_FLG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MAIN_CIF_FLG__c
     */
    public java.lang.Boolean getMAIN_CIF_FLG__c() {
        return MAIN_CIF_FLG__c;
    }


    /**
     * Sets the MAIN_CIF_FLG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MAIN_CIF_FLG__c
     */
    public void setMAIN_CIF_FLG__c(java.lang.Boolean MAIN_CIF_FLG__c) {
        this.MAIN_CIF_FLG__c = MAIN_CIF_FLG__c;
    }


    /**
     * Gets the MO_HAKKOUTAIID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_HAKKOUTAIID__c
     */
    public java.lang.String getMO_HAKKOUTAIID__c() {
        return MO_HAKKOUTAIID__c;
    }


    /**
     * Sets the MO_HAKKOUTAIID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_HAKKOUTAIID__c
     */
    public void setMO_HAKKOUTAIID__c(java.lang.String MO_HAKKOUTAIID__c) {
        this.MO_HAKKOUTAIID__c = MO_HAKKOUTAIID__c;
    }


    /**
     * Gets the MO_HAKKOUTAI_NM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_HAKKOUTAI_NM__c
     */
    public java.lang.String getMO_HAKKOUTAI_NM__c() {
        return MO_HAKKOUTAI_NM__c;
    }


    /**
     * Sets the MO_HAKKOUTAI_NM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_HAKKOUTAI_NM__c
     */
    public void setMO_HAKKOUTAI_NM__c(java.lang.String MO_HAKKOUTAI_NM__c) {
        this.MO_HAKKOUTAI_NM__c = MO_HAKKOUTAI_NM__c;
    }


    /**
     * Gets the MO_JDCHKKEY__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_JDCHKKEY__c
     */
    public java.lang.String getMO_JDCHKKEY__c() {
        return MO_JDCHKKEY__c;
    }


    /**
     * Sets the MO_JDCHKKEY__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_JDCHKKEY__c
     */
    public void setMO_JDCHKKEY__c(java.lang.String MO_JDCHKKEY__c) {
        this.MO_JDCHKKEY__c = MO_JDCHKKEY__c;
    }


    /**
     * Gets the MO_JDCHKRD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_JDCHKRD__c
     */
    public java.lang.String getMO_JDCHKRD__c() {
        return MO_JDCHKRD__c;
    }


    /**
     * Sets the MO_JDCHKRD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_JDCHKRD__c
     */
    public void setMO_JDCHKRD__c(java.lang.String MO_JDCHKRD__c) {
        this.MO_JDCHKRD__c = MO_JDCHKRD__c;
    }


    /**
     * Gets the MO_JDCHKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_JDCHKSTB__c
     */
    public java.util.Date getMO_JDCHKSTB__c() {
        return MO_JDCHKSTB__c;
    }


    /**
     * Sets the MO_JDCHKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_JDCHKSTB__c
     */
    public void setMO_JDCHKSTB__c(java.util.Date MO_JDCHKSTB__c) {
        this.MO_JDCHKSTB__c = MO_JDCHKSTB__c;
    }


    /**
     * Gets the MO_JDCHKWR__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_JDCHKWR__c
     */
    public java.lang.String getMO_JDCHKWR__c() {
        return MO_JDCHKWR__c;
    }


    /**
     * Sets the MO_JDCHKWR__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_JDCHKWR__c
     */
    public void setMO_JDCHKWR__c(java.lang.String MO_JDCHKWR__c) {
        this.MO_JDCHKWR__c = MO_JDCHKWR__c;
    }


    /**
     * Gets the MO_JDCHK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_JDCHK__c
     */
    public java.lang.String getMO_JDCHK__c() {
        return MO_JDCHK__c;
    }


    /**
     * Sets the MO_JDCHK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_JDCHK__c
     */
    public void setMO_JDCHK__c(java.lang.String MO_JDCHK__c) {
        this.MO_JDCHK__c = MO_JDCHK__c;
    }


    /**
     * Gets the MO_KIJUNBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_KIJUNBI__c
     */
    public java.util.Date getMO_KIJUNBI__c() {
        return MO_KIJUNBI__c;
    }


    /**
     * Sets the MO_KIJUNBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_KIJUNBI__c
     */
    public void setMO_KIJUNBI__c(java.util.Date MO_KIJUNBI__c) {
        this.MO_KIJUNBI__c = MO_KIJUNBI__c;
    }


    /**
     * Gets the MO_MCKHENKOUKBN_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_MCKHENKOUKBN_CH__c
     */
    public java.lang.String getMO_MCKHENKOUKBN_CH__c() {
        return MO_MCKHENKOUKBN_CH__c;
    }


    /**
     * Sets the MO_MCKHENKOUKBN_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_MCKHENKOUKBN_CH__c
     */
    public void setMO_MCKHENKOUKBN_CH__c(java.lang.String MO_MCKHENKOUKBN_CH__c) {
        this.MO_MCKHENKOUKBN_CH__c = MO_MCKHENKOUKBN_CH__c;
    }


    /**
     * Gets the MO_MCKRD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_MCKRD__c
     */
    public java.lang.String getMO_MCKRD__c() {
        return MO_MCKRD__c;
    }


    /**
     * Sets the MO_MCKRD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_MCKRD__c
     */
    public void setMO_MCKRD__c(java.lang.String MO_MCKRD__c) {
        this.MO_MCKRD__c = MO_MCKRD__c;
    }


    /**
     * Gets the MO_MCKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_MCKSTB__c
     */
    public java.util.Date getMO_MCKSTB__c() {
        return MO_MCKSTB__c;
    }


    /**
     * Sets the MO_MCKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_MCKSTB__c
     */
    public void setMO_MCKSTB__c(java.util.Date MO_MCKSTB__c) {
        this.MO_MCKSTB__c = MO_MCKSTB__c;
    }


    /**
     * Gets the MO_MCKWR__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_MCKWR__c
     */
    public java.lang.String getMO_MCKWR__c() {
        return MO_MCKWR__c;
    }


    /**
     * Sets the MO_MCKWR__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_MCKWR__c
     */
    public void setMO_MCKWR__c(java.lang.String MO_MCKWR__c) {
        this.MO_MCKWR__c = MO_MCKWR__c;
    }


    /**
     * Gets the MO_MCK_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_MCK_CH__c
     */
    public java.lang.String getMO_MCK_CH__c() {
        return MO_MCK_CH__c;
    }


    /**
     * Sets the MO_MCK_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_MCK_CH__c
     */
    public void setMO_MCK_CH__c(java.lang.String MO_MCK_CH__c) {
        this.MO_MCK_CH__c = MO_MCK_CH__c;
    }


    /**
     * Gets the MO_MCK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_MCK__c
     */
    public java.lang.String getMO_MCK__c() {
        return MO_MCK__c;
    }


    /**
     * Sets the MO_MCK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_MCK__c
     */
    public void setMO_MCK__c(java.lang.String MO_MCK__c) {
        this.MO_MCK__c = MO_MCK__c;
    }


    /**
     * Gets the MO_MINASHIHANBETSUCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_MINASHIHANBETSUCD__c
     */
    public java.lang.String getMO_MINASHIHANBETSUCD__c() {
        return MO_MINASHIHANBETSUCD__c;
    }


    /**
     * Sets the MO_MINASHIHANBETSUCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_MINASHIHANBETSUCD__c
     */
    public void setMO_MINASHIHANBETSUCD__c(java.lang.String MO_MINASHIHANBETSUCD__c) {
        this.MO_MINASHIHANBETSUCD__c = MO_MINASHIHANBETSUCD__c;
    }


    /**
     * Gets the MO_YUUKOUKIKANSHUURYOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return MO_YUUKOUKIKANSHUURYOUBI__c
     */
    public java.util.Date getMO_YUUKOUKIKANSHUURYOUBI__c() {
        return MO_YUUKOUKIKANSHUURYOUBI__c;
    }


    /**
     * Sets the MO_YUUKOUKIKANSHUURYOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param MO_YUUKOUKIKANSHUURYOUBI__c
     */
    public void setMO_YUUKOUKIKANSHUURYOUBI__c(java.util.Date MO_YUUKOUKIKANSHUURYOUBI__c) {
        this.MO_YUUKOUKIKANSHUURYOUBI__c = MO_YUUKOUKIKANSHUURYOUBI__c;
    }


    /**
     * Gets the m_CIF_FLG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return m_CIF_FLG__c
     */
    public java.lang.String getM_CIF_FLG__c() {
        return m_CIF_FLG__c;
    }


    /**
     * Sets the m_CIF_FLG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param m_CIF_FLG__c
     */
    public void setM_CIF_FLG__c(java.lang.String m_CIF_FLG__c) {
        this.m_CIF_FLG__c = m_CIF_FLG__c;
    }


    /**
     * Gets the NIKKEI_HINIKKEIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return NIKKEI_HINIKKEIKBN__c
     */
    public java.lang.String getNIKKEI_HINIKKEIKBN__c() {
        return NIKKEI_HINIKKEIKBN__c;
    }


    /**
     * Sets the NIKKEI_HINIKKEIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param NIKKEI_HINIKKEIKBN__c
     */
    public void setNIKKEI_HINIKKEIKBN__c(java.lang.String NIKKEI_HINIKKEIKBN__c) {
        this.NIKKEI_HINIKKEIKBN__c = NIKKEI_HINIKKEIKBN__c;
    }


    /**
     * Gets the name value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the notes value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return notes
     */
    public com.sforce.soap.enterprise.QueryResult getNotes() {
        return notes;
    }


    /**
     * Sets the notes value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param notes
     */
    public void setNotes(com.sforce.soap.enterprise.QueryResult notes) {
        this.notes = notes;
    }


    /**
     * Gets the notesAndAttachments value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return notesAndAttachments
     */
    public com.sforce.soap.enterprise.QueryResult getNotesAndAttachments() {
        return notesAndAttachments;
    }


    /**
     * Sets the notesAndAttachments value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param notesAndAttachments
     */
    public void setNotesAndAttachments(com.sforce.soap.enterprise.QueryResult notesAndAttachments) {
        this.notesAndAttachments = notesAndAttachments;
    }


    /**
     * Gets the OUTLOOK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return OUTLOOK__c
     */
    public java.lang.String getOUTLOOK__c() {
        return OUTLOOK__c;
    }


    /**
     * Sets the OUTLOOK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param OUTLOOK__c
     */
    public void setOUTLOOK__c(java.lang.String OUTLOOK__c) {
        this.OUTLOOK__c = OUTLOOK__c;
    }


    /**
     * Gets the openActivities value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return openActivities
     */
    public com.sforce.soap.enterprise.QueryResult getOpenActivities() {
        return openActivities;
    }


    /**
     * Sets the openActivities value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param openActivities
     */
    public void setOpenActivities(com.sforce.soap.enterprise.QueryResult openActivities) {
        this.openActivities = openActivities;
    }


    /**
     * Gets the owner value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return owner
     */
    public com.sforce.soap.enterprise.sobject.Name getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param owner
     */
    public void setOwner(com.sforce.soap.enterprise.sobject.Name owner) {
        this.owner = owner;
    }


    /**
     * Gets the ownerId value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return ownerId
     */
    public java.lang.String getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param ownerId
     */
    public void setOwnerId(java.lang.String ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the processInstances value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return processInstances
     */
    public com.sforce.soap.enterprise.QueryResult getProcessInstances() {
        return processInstances;
    }


    /**
     * Sets the processInstances value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param processInstances
     */
    public void setProcessInstances(com.sforce.soap.enterprise.QueryResult processInstances) {
        this.processInstances = processInstances;
    }


    /**
     * Gets the processSteps value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return processSteps
     */
    public com.sforce.soap.enterprise.QueryResult getProcessSteps() {
        return processSteps;
    }


    /**
     * Sets the processSteps value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param processSteps
     */
    public void setProcessSteps(com.sforce.soap.enterprise.QueryResult processSteps) {
        this.processSteps = processSteps;
    }


    /**
     * Gets the RIEKI_KIN_SENUNIT2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RIEKI_KIN_SENUNIT2__c
     */
    public java.lang.Double getRIEKI_KIN_SENUNIT2__c() {
        return RIEKI_KIN_SENUNIT2__c;
    }


    /**
     * Sets the RIEKI_KIN_SENUNIT2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RIEKI_KIN_SENUNIT2__c
     */
    public void setRIEKI_KIN_SENUNIT2__c(java.lang.Double RIEKI_KIN_SENUNIT2__c) {
        this.RIEKI_KIN_SENUNIT2__c = RIEKI_KIN_SENUNIT2__c;
    }


    /**
     * Gets the RIEKI_KIN_SENUNIT3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RIEKI_KIN_SENUNIT3__c
     */
    public java.lang.Double getRIEKI_KIN_SENUNIT3__c() {
        return RIEKI_KIN_SENUNIT3__c;
    }


    /**
     * Sets the RIEKI_KIN_SENUNIT3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RIEKI_KIN_SENUNIT3__c
     */
    public void setRIEKI_KIN_SENUNIT3__c(java.lang.Double RIEKI_KIN_SENUNIT3__c) {
        this.RIEKI_KIN_SENUNIT3__c = RIEKI_KIN_SENUNIT3__c;
    }


    /**
     * Gets the RIEKI_KIN_SENUNIT__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RIEKI_KIN_SENUNIT__c
     */
    public java.lang.Double getRIEKI_KIN_SENUNIT__c() {
        return RIEKI_KIN_SENUNIT__c;
    }


    /**
     * Sets the RIEKI_KIN_SENUNIT__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RIEKI_KIN_SENUNIT__c
     */
    public void setRIEKI_KIN_SENUNIT__c(java.lang.Double RIEKI_KIN_SENUNIT__c) {
        this.RIEKI_KIN_SENUNIT__c = RIEKI_KIN_SENUNIT__c;
    }


    /**
     * Gets the RINGI_SAIRYOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RINGI_SAIRYOUKBN__c
     */
    public java.lang.String getRINGI_SAIRYOUKBN__c() {
        return RINGI_SAIRYOUKBN__c;
    }


    /**
     * Sets the RINGI_SAIRYOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RINGI_SAIRYOUKBN__c
     */
    public void setRINGI_SAIRYOUKBN__c(java.lang.String RINGI_SAIRYOUKBN__c) {
        this.RINGI_SAIRYOUKBN__c = RINGI_SAIRYOUKBN__c;
    }


    /**
     * Gets the RI_CSKHENKOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_CSKHENKOUKBN__c
     */
    public java.lang.String getRI_CSKHENKOUKBN__c() {
        return RI_CSKHENKOUKBN__c;
    }


    /**
     * Sets the RI_CSKHENKOUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_CSKHENKOUKBN__c
     */
    public void setRI_CSKHENKOUKBN__c(java.lang.String RI_CSKHENKOUKBN__c) {
        this.RI_CSKHENKOUKBN__c = RI_CSKHENKOUKBN__c;
    }


    /**
     * Gets the RI_CSKKEY1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_CSKKEY1__c
     */
    public java.lang.String getRI_CSKKEY1__c() {
        return RI_CSKKEY1__c;
    }


    /**
     * Sets the RI_CSKKEY1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_CSKKEY1__c
     */
    public void setRI_CSKKEY1__c(java.lang.String RI_CSKKEY1__c) {
        this.RI_CSKKEY1__c = RI_CSKKEY1__c;
    }


    /**
     * Gets the RI_CSKKEY2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_CSKKEY2__c
     */
    public java.lang.String getRI_CSKKEY2__c() {
        return RI_CSKKEY2__c;
    }


    /**
     * Sets the RI_CSKKEY2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_CSKKEY2__c
     */
    public void setRI_CSKKEY2__c(java.lang.String RI_CSKKEY2__c) {
        this.RI_CSKKEY2__c = RI_CSKKEY2__c;
    }


    /**
     * Gets the RI_CSKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_CSKSTB__c
     */
    public java.util.Date getRI_CSKSTB__c() {
        return RI_CSKSTB__c;
    }


    /**
     * Sets the RI_CSKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_CSKSTB__c
     */
    public void setRI_CSKSTB__c(java.util.Date RI_CSKSTB__c) {
        this.RI_CSKSTB__c = RI_CSKSTB__c;
    }


    /**
     * Gets the RI_CSK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_CSK__c
     */
    public java.lang.String getRI_CSK__c() {
        return RI_CSK__c;
    }


    /**
     * Sets the RI_CSK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_CSK__c
     */
    public void setRI_CSK__c(java.lang.String RI_CSK__c) {
        this.RI_CSK__c = RI_CSK__c;
    }


    /**
     * Gets the RI_HAKKOUTAIID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_HAKKOUTAIID__c
     */
    public java.lang.String getRI_HAKKOUTAIID__c() {
        return RI_HAKKOUTAIID__c;
    }


    /**
     * Sets the RI_HAKKOUTAIID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_HAKKOUTAIID__c
     */
    public void setRI_HAKKOUTAIID__c(java.lang.String RI_HAKKOUTAIID__c) {
        this.RI_HAKKOUTAIID__c = RI_HAKKOUTAIID__c;
    }


    /**
     * Gets the RI_HAKKOUTAI_NM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_HAKKOUTAI_NM__c
     */
    public java.lang.String getRI_HAKKOUTAI_NM__c() {
        return RI_HAKKOUTAI_NM__c;
    }


    /**
     * Sets the RI_HAKKOUTAI_NM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_HAKKOUTAI_NM__c
     */
    public void setRI_HAKKOUTAI_NM__c(java.lang.String RI_HAKKOUTAI_NM__c) {
        this.RI_HAKKOUTAI_NM__c = RI_HAKKOUTAI_NM__c;
    }


    /**
     * Gets the RI_KIJUNBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_KIJUNBI__c
     */
    public java.util.Date getRI_KIJUNBI__c() {
        return RI_KIJUNBI__c;
    }


    /**
     * Sets the RI_KIJUNBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_KIJUNBI__c
     */
    public void setRI_KIJUNBI__c(java.util.Date RI_KIJUNBI__c) {
        this.RI_KIJUNBI__c = RI_KIJUNBI__c;
    }


    /**
     * Gets the RI_MCKHENKOUKBN_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_MCKHENKOUKBN_CH__c
     */
    public java.lang.String getRI_MCKHENKOUKBN_CH__c() {
        return RI_MCKHENKOUKBN_CH__c;
    }


    /**
     * Sets the RI_MCKHENKOUKBN_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_MCKHENKOUKBN_CH__c
     */
    public void setRI_MCKHENKOUKBN_CH__c(java.lang.String RI_MCKHENKOUKBN_CH__c) {
        this.RI_MCKHENKOUKBN_CH__c = RI_MCKHENKOUKBN_CH__c;
    }


    /**
     * Gets the RI_MCKHK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_MCKHK__c
     */
    public java.lang.String getRI_MCKHK__c() {
        return RI_MCKHK__c;
    }


    /**
     * Sets the RI_MCKHK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_MCKHK__c
     */
    public void setRI_MCKHK__c(java.lang.String RI_MCKHK__c) {
        this.RI_MCKHK__c = RI_MCKHK__c;
    }


    /**
     * Gets the RI_MCKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_MCKSTB__c
     */
    public java.util.Date getRI_MCKSTB__c() {
        return RI_MCKSTB__c;
    }


    /**
     * Sets the RI_MCKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_MCKSTB__c
     */
    public void setRI_MCKSTB__c(java.util.Date RI_MCKSTB__c) {
        this.RI_MCKSTB__c = RI_MCKSTB__c;
    }


    /**
     * Gets the RI_MCK_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_MCK_CH__c
     */
    public java.lang.String getRI_MCK_CH__c() {
        return RI_MCK_CH__c;
    }


    /**
     * Sets the RI_MCK_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_MCK_CH__c
     */
    public void setRI_MCK_CH__c(java.lang.String RI_MCK_CH__c) {
        this.RI_MCK_CH__c = RI_MCK_CH__c;
    }


    /**
     * Gets the RI_MCK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_MCK__c
     */
    public java.lang.String getRI_MCK__c() {
        return RI_MCK__c;
    }


    /**
     * Sets the RI_MCK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_MCK__c
     */
    public void setRI_MCK__c(java.lang.String RI_MCK__c) {
        this.RI_MCK__c = RI_MCK__c;
    }


    /**
     * Gets the RI_MINASHIHANBETSUCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_MINASHIHANBETSUCD__c
     */
    public java.lang.String getRI_MINASHIHANBETSUCD__c() {
        return RI_MINASHIHANBETSUCD__c;
    }


    /**
     * Sets the RI_MINASHIHANBETSUCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_MINASHIHANBETSUCD__c
     */
    public void setRI_MINASHIHANBETSUCD__c(java.lang.String RI_MINASHIHANBETSUCD__c) {
        this.RI_MINASHIHANBETSUCD__c = RI_MINASHIHANBETSUCD__c;
    }


    /**
     * Gets the RI_YUUKOUKIKANSHUURYOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RI_YUUKOUKIKANSHUURYOUBI__c
     */
    public java.util.Date getRI_YUUKOUKIKANSHUURYOUBI__c() {
        return RI_YUUKOUKIKANSHUURYOUBI__c;
    }


    /**
     * Sets the RI_YUUKOUKIKANSHUURYOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RI_YUUKOUKIKANSHUURYOUBI__c
     */
    public void setRI_YUUKOUKIKANSHUURYOUBI__c(java.util.Date RI_YUUKOUKIKANSHUURYOUBI__c) {
        this.RI_YUUKOUKIKANSHUURYOUBI__c = RI_YUUKOUKIKANSHUURYOUBI__c;
    }


    /**
     * Gets the RMFFLG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return RMFFLG__c
     */
    public java.lang.String getRMFFLG__c() {
        return RMFFLG__c;
    }


    /**
     * Sets the RMFFLG__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param RMFFLG__c
     */
    public void setRMFFLG__c(java.lang.String RMFFLG__c) {
        this.RMFFLG__c = RMFFLG__c;
    }


    /**
     * Gets the SAIMUCHOUKASAKIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SAIMUCHOUKASAKIKBN__c
     */
    public java.lang.String getSAIMUCHOUKASAKIKBN__c() {
        return SAIMUCHOUKASAKIKBN__c;
    }


    /**
     * Sets the SAIMUCHOUKASAKIKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SAIMUCHOUKASAKIKBN__c
     */
    public void setSAIMUCHOUKASAKIKBN__c(java.lang.String SAIMUCHOUKASAKIKBN__c) {
        this.SAIMUCHOUKASAKIKBN__c = SAIMUCHOUKASAKIKBN__c;
    }


    /**
     * Gets the SAIMUSHAKAKUDUKEYUUKOUKIGEN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SAIMUSHAKAKUDUKEYUUKOUKIGEN__c
     */
    public java.util.Date getSAIMUSHAKAKUDUKEYUUKOUKIGEN__c() {
        return SAIMUSHAKAKUDUKEYUUKOUKIGEN__c;
    }


    /**
     * Sets the SAIMUSHAKAKUDUKEYUUKOUKIGEN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SAIMUSHAKAKUDUKEYUUKOUKIGEN__c
     */
    public void setSAIMUSHAKAKUDUKEYUUKOUKIGEN__c(java.util.Date SAIMUSHAKAKUDUKEYUUKOUKIGEN__c) {
        this.SAIMUSHAKAKUDUKEYUUKOUKIGEN__c = SAIMUSHAKAKUDUKEYUUKOUKIGEN__c;
    }


    /**
     * Gets the SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c
     */
    public java.lang.String getSAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c() {
        return SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c;
    }


    /**
     * Sets the SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c
     */
    public void setSAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c(java.lang.String SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c) {
        this.SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c = SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c;
    }


    /**
     * Gets the SAIMUSHAKAKUDUKE__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SAIMUSHAKAKUDUKE__c
     */
    public java.lang.String getSAIMUSHAKAKUDUKE__c() {
        return SAIMUSHAKAKUDUKE__c;
    }


    /**
     * Sets the SAIMUSHAKAKUDUKE__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SAIMUSHAKAKUDUKE__c
     */
    public void setSAIMUSHAKAKUDUKE__c(java.lang.String SAIMUSHAKAKUDUKE__c) {
        this.SAIMUSHAKAKUDUKE__c = SAIMUSHAKAKUDUKE__c;
    }


    /**
     * Gets the SAIMUSHAKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SAIMUSHAKBN__c
     */
    public java.lang.String getSAIMUSHAKBN__c() {
        return SAIMUSHAKBN__c;
    }


    /**
     * Sets the SAIMUSHAKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SAIMUSHAKBN__c
     */
    public void setSAIMUSHAKBN__c(java.lang.String SAIMUSHAKBN__c) {
        this.SAIMUSHAKBN__c = SAIMUSHAKBN__c;
    }


    /**
     * Gets the SAIMUSHA_HISAIMUSHAKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SAIMUSHA_HISAIMUSHAKBN__c
     */
    public java.lang.String getSAIMUSHA_HISAIMUSHAKBN__c() {
        return SAIMUSHA_HISAIMUSHAKBN__c;
    }


    /**
     * Sets the SAIMUSHA_HISAIMUSHAKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SAIMUSHA_HISAIMUSHAKBN__c
     */
    public void setSAIMUSHA_HISAIMUSHAKBN__c(java.lang.String SAIMUSHA_HISAIMUSHAKBN__c) {
        this.SAIMUSHA_HISAIMUSHAKBN__c = SAIMUSHA_HISAIMUSHAKBN__c;
    }


    /**
     * Gets the SETAIKANRITANTOUSHA__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SETAIKANRITANTOUSHA__c
     */
    public java.lang.String getSETAIKANRITANTOUSHA__c() {
        return SETAIKANRITANTOUSHA__c;
    }


    /**
     * Sets the SETAIKANRITANTOUSHA__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SETAIKANRITANTOUSHA__c
     */
    public void setSETAIKANRITANTOUSHA__c(java.lang.String SETAIKANRITANTOUSHA__c) {
        this.SETAIKANRITANTOUSHA__c = SETAIKANRITANTOUSHA__c;
    }


    /**
     * Gets the SETSURITSUNENGETSUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SETSURITSUNENGETSUBI__c
     */
    public java.util.Date getSETSURITSUNENGETSUBI__c() {
        return SETSURITSUNENGETSUBI__c;
    }


    /**
     * Sets the SETSURITSUNENGETSUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SETSURITSUNENGETSUBI__c
     */
    public void setSETSURITSUNENGETSUBI__c(java.util.Date SETSURITSUNENGETSUBI__c) {
        this.SETSURITSUNENGETSUBI__c = SETSURITSUNENGETSUBI__c;
    }


    /**
     * Gets the SHIHONKIN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHIHONKIN__c
     */
    public java.lang.Double getSHIHONKIN__c() {
        return SHIHONKIN__c;
    }


    /**
     * Sets the SHIHONKIN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHIHONKIN__c
     */
    public void setSHIHONKIN__c(java.lang.Double SHIHONKIN__c) {
        this.SHIHONKIN__c = SHIHONKIN__c;
    }


    /**
     * Gets the SHINKOKUSHOTOKUKINGAKU2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHINKOKUSHOTOKUKINGAKU2__c
     */
    public java.lang.Double getSHINKOKUSHOTOKUKINGAKU2__c() {
        return SHINKOKUSHOTOKUKINGAKU2__c;
    }


    /**
     * Sets the SHINKOKUSHOTOKUKINGAKU2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHINKOKUSHOTOKUKINGAKU2__c
     */
    public void setSHINKOKUSHOTOKUKINGAKU2__c(java.lang.Double SHINKOKUSHOTOKUKINGAKU2__c) {
        this.SHINKOKUSHOTOKUKINGAKU2__c = SHINKOKUSHOTOKUKINGAKU2__c;
    }


    /**
     * Gets the SHINKOKUSHOTOKUKINGAKU3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHINKOKUSHOTOKUKINGAKU3__c
     */
    public java.lang.Double getSHINKOKUSHOTOKUKINGAKU3__c() {
        return SHINKOKUSHOTOKUKINGAKU3__c;
    }


    /**
     * Sets the SHINKOKUSHOTOKUKINGAKU3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHINKOKUSHOTOKUKINGAKU3__c
     */
    public void setSHINKOKUSHOTOKUKINGAKU3__c(java.lang.Double SHINKOKUSHOTOKUKINGAKU3__c) {
        this.SHINKOKUSHOTOKUKINGAKU3__c = SHINKOKUSHOTOKUKINGAKU3__c;
    }


    /**
     * Gets the SHINKOKUSHOTOKUKINGAKU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHINKOKUSHOTOKUKINGAKU__c
     */
    public java.lang.Double getSHINKOKUSHOTOKUKINGAKU__c() {
        return SHINKOKUSHOTOKUKINGAKU__c;
    }


    /**
     * Sets the SHINKOKUSHOTOKUKINGAKU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHINKOKUSHOTOKUKINGAKU__c
     */
    public void setSHINKOKUSHOTOKUKINGAKU__c(java.lang.Double SHINKOKUSHOTOKUKINGAKU__c) {
        this.SHINKOKUSHOTOKUKINGAKU__c = SHINKOKUSHOTOKUKINGAKU__c;
    }


    /**
     * Gets the SHINMITSUDO__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHINMITSUDO__c
     */
    public java.lang.String getSHINMITSUDO__c() {
        return SHINMITSUDO__c;
    }


    /**
     * Sets the SHINMITSUDO__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHINMITSUDO__c
     */
    public void setSHINMITSUDO__c(java.lang.String SHINMITSUDO__c) {
        this.SHINMITSUDO__c = SHINMITSUDO__c;
    }


    /**
     * Gets the SHOUGOU_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHOUGOU_KANJI__c
     */
    public java.lang.String getSHOUGOU_KANJI__c() {
        return SHOUGOU_KANJI__c;
    }


    /**
     * Sets the SHOUGOU_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHOUGOU_KANJI__c
     */
    public void setSHOUGOU_KANJI__c(java.lang.String SHOUGOU_KANJI__c) {
        this.SHOUGOU_KANJI__c = SHOUGOU_KANJI__c;
    }


    /**
     * Gets the SHOUKYAKUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHOUKYAKUKBN__c
     */
    public java.lang.String getSHOUKYAKUKBN__c() {
        return SHOUKYAKUKBN__c;
    }


    /**
     * Sets the SHOUKYAKUKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHOUKYAKUKBN__c
     */
    public void setSHOUKYAKUKBN__c(java.lang.String SHOUKYAKUKBN__c) {
        this.SHOUKYAKUKBN__c = SHOUKYAKUKBN__c;
    }


    /**
     * Gets the SHOZAICHI_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHOZAICHI_KANJI__c
     */
    public java.lang.String getSHOZAICHI_KANJI__c() {
        return SHOZAICHI_KANJI__c;
    }


    /**
     * Sets the SHOZAICHI_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHOZAICHI_KANJI__c
     */
    public void setSHOZAICHI_KANJI__c(java.lang.String SHOZAICHI_KANJI__c) {
        this.SHOZAICHI_KANJI__c = SHOZAICHI_KANJI__c;
    }


    /**
     * Gets the SHURYOKUTAKOU1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHURYOKUTAKOU1__c
     */
    public java.lang.String getSHURYOKUTAKOU1__c() {
        return SHURYOKUTAKOU1__c;
    }


    /**
     * Sets the SHURYOKUTAKOU1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHURYOKUTAKOU1__c
     */
    public void setSHURYOKUTAKOU1__c(java.lang.String SHURYOKUTAKOU1__c) {
        this.SHURYOKUTAKOU1__c = SHURYOKUTAKOU1__c;
    }


    /**
     * Gets the SHURYOKUTAKOU2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHURYOKUTAKOU2__c
     */
    public java.lang.String getSHURYOKUTAKOU2__c() {
        return SHURYOKUTAKOU2__c;
    }


    /**
     * Sets the SHURYOKUTAKOU2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHURYOKUTAKOU2__c
     */
    public void setSHURYOKUTAKOU2__c(java.lang.String SHURYOKUTAKOU2__c) {
        this.SHURYOKUTAKOU2__c = SHURYOKUTAKOU2__c;
    }


    /**
     * Gets the SHURYOKUTAKOU3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SHURYOKUTAKOU3__c
     */
    public java.lang.String getSHURYOKUTAKOU3__c() {
        return SHURYOKUTAKOU3__c;
    }


    /**
     * Sets the SHURYOKUTAKOU3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SHURYOKUTAKOU3__c
     */
    public void setSHURYOKUTAKOU3__c(java.lang.String SHURYOKUTAKOU3__c) {
        this.SHURYOKUTAKOU3__c = SHURYOKUTAKOU3__c;
    }


    /**
     * Gets the SP_HAKKOUTAIID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_HAKKOUTAIID__c
     */
    public java.lang.String getSP_HAKKOUTAIID__c() {
        return SP_HAKKOUTAIID__c;
    }


    /**
     * Sets the SP_HAKKOUTAIID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_HAKKOUTAIID__c
     */
    public void setSP_HAKKOUTAIID__c(java.lang.String SP_HAKKOUTAIID__c) {
        this.SP_HAKKOUTAIID__c = SP_HAKKOUTAIID__c;
    }


    /**
     * Gets the SP_HAKKOUTAI_NM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_HAKKOUTAI_NM__c
     */
    public java.lang.String getSP_HAKKOUTAI_NM__c() {
        return SP_HAKKOUTAI_NM__c;
    }


    /**
     * Sets the SP_HAKKOUTAI_NM__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_HAKKOUTAI_NM__c
     */
    public void setSP_HAKKOUTAI_NM__c(java.lang.String SP_HAKKOUTAI_NM__c) {
        this.SP_HAKKOUTAI_NM__c = SP_HAKKOUTAI_NM__c;
    }


    /**
     * Gets the SP_JDCHKLOOK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_JDCHKLOOK__c
     */
    public java.lang.String getSP_JDCHKLOOK__c() {
        return SP_JDCHKLOOK__c;
    }


    /**
     * Sets the SP_JDCHKLOOK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_JDCHKLOOK__c
     */
    public void setSP_JDCHKLOOK__c(java.lang.String SP_JDCHKLOOK__c) {
        this.SP_JDCHKLOOK__c = SP_JDCHKLOOK__c;
    }


    /**
     * Gets the SP_JDCHKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_JDCHKSTB__c
     */
    public java.util.Date getSP_JDCHKSTB__c() {
        return SP_JDCHKSTB__c;
    }


    /**
     * Sets the SP_JDCHKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_JDCHKSTB__c
     */
    public void setSP_JDCHKSTB__c(java.util.Date SP_JDCHKSTB__c) {
        this.SP_JDCHKSTB__c = SP_JDCHKSTB__c;
    }


    /**
     * Gets the SP_JDCHKW__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_JDCHKW__c
     */
    public java.lang.String getSP_JDCHKW__c() {
        return SP_JDCHKW__c;
    }


    /**
     * Sets the SP_JDCHKW__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_JDCHKW__c
     */
    public void setSP_JDCHKW__c(java.lang.String SP_JDCHKW__c) {
        this.SP_JDCHKW__c = SP_JDCHKW__c;
    }


    /**
     * Gets the SP_JDCHK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_JDCHK__c
     */
    public java.lang.String getSP_JDCHK__c() {
        return SP_JDCHK__c;
    }


    /**
     * Sets the SP_JDCHK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_JDCHK__c
     */
    public void setSP_JDCHK__c(java.lang.String SP_JDCHK__c) {
        this.SP_JDCHK__c = SP_JDCHK__c;
    }


    /**
     * Gets the SP_KIJUNBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_KIJUNBI__c
     */
    public java.util.Date getSP_KIJUNBI__c() {
        return SP_KIJUNBI__c;
    }


    /**
     * Sets the SP_KIJUNBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_KIJUNBI__c
     */
    public void setSP_KIJUNBI__c(java.util.Date SP_KIJUNBI__c) {
        this.SP_KIJUNBI__c = SP_KIJUNBI__c;
    }


    /**
     * Gets the SP_MCKHENKOUKBN_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_MCKHENKOUKBN_CH__c
     */
    public java.lang.String getSP_MCKHENKOUKBN_CH__c() {
        return SP_MCKHENKOUKBN_CH__c;
    }


    /**
     * Sets the SP_MCKHENKOUKBN_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_MCKHENKOUKBN_CH__c
     */
    public void setSP_MCKHENKOUKBN_CH__c(java.lang.String SP_MCKHENKOUKBN_CH__c) {
        this.SP_MCKHENKOUKBN_CH__c = SP_MCKHENKOUKBN_CH__c;
    }


    /**
     * Gets the SP_MCKLOOK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_MCKLOOK__c
     */
    public java.lang.String getSP_MCKLOOK__c() {
        return SP_MCKLOOK__c;
    }


    /**
     * Sets the SP_MCKLOOK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_MCKLOOK__c
     */
    public void setSP_MCKLOOK__c(java.lang.String SP_MCKLOOK__c) {
        this.SP_MCKLOOK__c = SP_MCKLOOK__c;
    }


    /**
     * Gets the SP_MCKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_MCKSTB__c
     */
    public java.util.Date getSP_MCKSTB__c() {
        return SP_MCKSTB__c;
    }


    /**
     * Sets the SP_MCKSTB__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_MCKSTB__c
     */
    public void setSP_MCKSTB__c(java.util.Date SP_MCKSTB__c) {
        this.SP_MCKSTB__c = SP_MCKSTB__c;
    }


    /**
     * Gets the SP_MCKW__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_MCKW__c
     */
    public java.lang.String getSP_MCKW__c() {
        return SP_MCKW__c;
    }


    /**
     * Sets the SP_MCKW__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_MCKW__c
     */
    public void setSP_MCKW__c(java.lang.String SP_MCKW__c) {
        this.SP_MCKW__c = SP_MCKW__c;
    }


    /**
     * Gets the SP_MCK_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_MCK_CH__c
     */
    public java.lang.String getSP_MCK_CH__c() {
        return SP_MCK_CH__c;
    }


    /**
     * Sets the SP_MCK_CH__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_MCK_CH__c
     */
    public void setSP_MCK_CH__c(java.lang.String SP_MCK_CH__c) {
        this.SP_MCK_CH__c = SP_MCK_CH__c;
    }


    /**
     * Gets the SP_MCK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_MCK__c
     */
    public java.lang.String getSP_MCK__c() {
        return SP_MCK__c;
    }


    /**
     * Sets the SP_MCK__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_MCK__c
     */
    public void setSP_MCK__c(java.lang.String SP_MCK__c) {
        this.SP_MCK__c = SP_MCK__c;
    }


    /**
     * Gets the SP_MINASHIHANBETSUCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_MINASHIHANBETSUCD__c
     */
    public java.lang.String getSP_MINASHIHANBETSUCD__c() {
        return SP_MINASHIHANBETSUCD__c;
    }


    /**
     * Sets the SP_MINASHIHANBETSUCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_MINASHIHANBETSUCD__c
     */
    public void setSP_MINASHIHANBETSUCD__c(java.lang.String SP_MINASHIHANBETSUCD__c) {
        this.SP_MINASHIHANBETSUCD__c = SP_MINASHIHANBETSUCD__c;
    }


    /**
     * Gets the SP_YUUKOUKIKANSHUURYOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return SP_YUUKOUKIKANSHUURYOUBI__c
     */
    public java.util.Date getSP_YUUKOUKIKANSHUURYOUBI__c() {
        return SP_YUUKOUKIKANSHUURYOUBI__c;
    }


    /**
     * Sets the SP_YUUKOUKIKANSHUURYOUBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param SP_YUUKOUKIKANSHUURYOUBI__c
     */
    public void setSP_YUUKOUKIKANSHUURYOUBI__c(java.util.Date SP_YUUKOUKIKANSHUURYOUBI__c) {
        this.SP_YUUKOUKIKANSHUURYOUBI__c = SP_YUUKOUKIKANSHUURYOUBI__c;
    }


    /**
     * Gets the saikenJotoTsuchi_CifzkuseiInfo__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return saikenJotoTsuchi_CifzkuseiInfo__r
     */
    public com.sforce.soap.enterprise.QueryResult getSaikenJotoTsuchi_CifzkuseiInfo__r() {
        return saikenJotoTsuchi_CifzkuseiInfo__r;
    }


    /**
     * Sets the saikenJotoTsuchi_CifzkuseiInfo__r value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param saikenJotoTsuchi_CifzkuseiInfo__r
     */
    public void setSaikenJotoTsuchi_CifzkuseiInfo__r(com.sforce.soap.enterprise.QueryResult saikenJotoTsuchi_CifzkuseiInfo__r) {
        this.saikenJotoTsuchi_CifzkuseiInfo__r = saikenJotoTsuchi_CifzkuseiInfo__r;
    }


    /**
     * Gets the shares value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return shares
     */
    public com.sforce.soap.enterprise.QueryResult getShares() {
        return shares;
    }


    /**
     * Sets the shares value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param shares
     */
    public void setShares(com.sforce.soap.enterprise.QueryResult shares) {
        this.shares = shares;
    }


    /**
     * Gets the systemModstamp value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return systemModstamp
     */
    public java.util.Calendar getSystemModstamp() {
        return systemModstamp;
    }


    /**
     * Sets the systemModstamp value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param systemModstamp
     */
    public void setSystemModstamp(java.util.Calendar systemModstamp) {
        this.systemModstamp = systemModstamp;
    }


    /**
     * Gets the TANTOUSHACD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TANTOUSHACD1__c
     */
    public java.lang.String getTANTOUSHACD1__c() {
        return TANTOUSHACD1__c;
    }


    /**
     * Sets the TANTOUSHACD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TANTOUSHACD1__c
     */
    public void setTANTOUSHACD1__c(java.lang.String TANTOUSHACD1__c) {
        this.TANTOUSHACD1__c = TANTOUSHACD1__c;
    }


    /**
     * Gets the TANTOUSHACD2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TANTOUSHACD2__c
     */
    public java.lang.String getTANTOUSHACD2__c() {
        return TANTOUSHACD2__c;
    }


    /**
     * Sets the TANTOUSHACD2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TANTOUSHACD2__c
     */
    public void setTANTOUSHACD2__c(java.lang.String TANTOUSHACD2__c) {
        this.TANTOUSHACD2__c = TANTOUSHACD2__c;
    }


    /**
     * Gets the TDBSANGYOUBUNRUICD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TDBSANGYOUBUNRUICD1__c
     */
    public java.lang.String getTDBSANGYOUBUNRUICD1__c() {
        return TDBSANGYOUBUNRUICD1__c;
    }


    /**
     * Sets the TDBSANGYOUBUNRUICD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TDBSANGYOUBUNRUICD1__c
     */
    public void setTDBSANGYOUBUNRUICD1__c(java.lang.String TDBSANGYOUBUNRUICD1__c) {
        this.TDBSANGYOUBUNRUICD1__c = TDBSANGYOUBUNRUICD1__c;
    }


    /**
     * Gets the TDBSANGYOUBUNRUICD2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TDBSANGYOUBUNRUICD2__c
     */
    public java.lang.String getTDBSANGYOUBUNRUICD2__c() {
        return TDBSANGYOUBUNRUICD2__c;
    }


    /**
     * Sets the TDBSANGYOUBUNRUICD2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TDBSANGYOUBUNRUICD2__c
     */
    public void setTDBSANGYOUBUNRUICD2__c(java.lang.String TDBSANGYOUBUNRUICD2__c) {
        this.TDBSANGYOUBUNRUICD2__c = TDBSANGYOUBUNRUICD2__c;
    }


    /**
     * Gets the TDBSANGYOUBUNRUICD3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TDBSANGYOUBUNRUICD3__c
     */
    public java.lang.String getTDBSANGYOUBUNRUICD3__c() {
        return TDBSANGYOUBUNRUICD3__c;
    }


    /**
     * Sets the TDBSANGYOUBUNRUICD3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TDBSANGYOUBUNRUICD3__c
     */
    public void setTDBSANGYOUBUNRUICD3__c(java.lang.String TDBSANGYOUBUNRUICD3__c) {
        this.TDBSANGYOUBUNRUICD3__c = TDBSANGYOUBUNRUICD3__c;
    }


    /**
     * Gets the TDBSANGYOUBUNRUICD4__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TDBSANGYOUBUNRUICD4__c
     */
    public java.lang.String getTDBSANGYOUBUNRUICD4__c() {
        return TDBSANGYOUBUNRUICD4__c;
    }


    /**
     * Sets the TDBSANGYOUBUNRUICD4__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TDBSANGYOUBUNRUICD4__c
     */
    public void setTDBSANGYOUBUNRUICD4__c(java.lang.String TDBSANGYOUBUNRUICD4__c) {
        this.TDBSANGYOUBUNRUICD4__c = TDBSANGYOUBUNRUICD4__c;
    }


    /**
     * Gets the TDBSANGYOUBUNRUICD5__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TDBSANGYOUBUNRUICD5__c
     */
    public java.lang.String getTDBSANGYOUBUNRUICD5__c() {
        return TDBSANGYOUBUNRUICD5__c;
    }


    /**
     * Sets the TDBSANGYOUBUNRUICD5__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TDBSANGYOUBUNRUICD5__c
     */
    public void setTDBSANGYOUBUNRUICD5__c(java.lang.String TDBSANGYOUBUNRUICD5__c) {
        this.TDBSANGYOUBUNRUICD5__c = TDBSANGYOUBUNRUICD5__c;
    }


    /**
     * Gets the TEAMCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TEAMCD__c
     */
    public java.lang.String getTEAMCD__c() {
        return TEAMCD__c;
    }


    /**
     * Sets the TEAMCD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TEAMCD__c
     */
    public void setTEAMCD__c(java.lang.String TEAMCD__c) {
        this.TEAMCD__c = TEAMCD__c;
    }


    /**
     * Gets the TEKIKAKUKAISHACD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TEKIKAKUKAISHACD__c
     */
    public java.lang.String getTEKIKAKUKAISHACD__c() {
        return TEKIKAKUKAISHACD__c;
    }


    /**
     * Sets the TEKIKAKUKAISHACD__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TEKIKAKUKAISHACD__c
     */
    public void setTEKIKAKUKAISHACD__c(java.lang.String TEKIKAKUKAISHACD__c) {
        this.TEKIKAKUKAISHACD__c = TEKIKAKUKAISHACD__c;
    }


    /**
     * Gets the TENBAN_3_KOKYAKUBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TENBAN_3_KOKYAKUBANGOU__c
     */
    public java.lang.String getTENBAN_3_KOKYAKUBANGOU__c() {
        return TENBAN_3_KOKYAKUBANGOU__c;
    }


    /**
     * Sets the TENBAN_3_KOKYAKUBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TENBAN_3_KOKYAKUBANGOU__c
     */
    public void setTENBAN_3_KOKYAKUBANGOU__c(java.lang.String TENBAN_3_KOKYAKUBANGOU__c) {
        this.TENBAN_3_KOKYAKUBANGOU__c = TENBAN_3_KOKYAKUBANGOU__c;
    }


    /**
     * Gets the TENBAN_3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TENBAN_3__c
     */
    public java.lang.String getTENBAN_3__c() {
        return TENBAN_3__c;
    }


    /**
     * Sets the TENBAN_3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TENBAN_3__c
     */
    public void setTENBAN_3__c(java.lang.String TENBAN_3__c) {
        this.TENBAN_3__c = TENBAN_3__c;
    }


    /**
     * Gets the TENBAN_KOKYAKUBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TENBAN_KOKYAKUBANGOU__c
     */
    public java.lang.String getTENBAN_KOKYAKUBANGOU__c() {
        return TENBAN_KOKYAKUBANGOU__c;
    }


    /**
     * Sets the TENBAN_KOKYAKUBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TENBAN_KOKYAKUBANGOU__c
     */
    public void setTENBAN_KOKYAKUBANGOU__c(java.lang.String TENBAN_KOKYAKUBANGOU__c) {
        this.TENBAN_KOKYAKUBANGOU__c = TENBAN_KOKYAKUBANGOU__c;
    }


    /**
     * Gets the TENBAN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TENBAN__c
     */
    public java.lang.String getTENBAN__c() {
        return TENBAN__c;
    }


    /**
     * Sets the TENBAN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TENBAN__c
     */
    public void setTENBAN__c(java.lang.String TENBAN__c) {
        this.TENBAN__c = TENBAN__c;
    }


    /**
     * Gets the TKCKAIIN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TKCKAIIN__c
     */
    public java.lang.String getTKCKAIIN__c() {
        return TKCKAIIN__c;
    }


    /**
     * Sets the TKCKAIIN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TKCKAIIN__c
     */
    public void setTKCKAIIN__c(java.lang.String TKCKAIIN__c) {
        this.TKCKAIIN__c = TKCKAIIN__c;
    }


    /**
     * Gets the TKCKANYOSAKI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TKCKANYOSAKI__c
     */
    public java.lang.String getTKCKANYOSAKI__c() {
        return TKCKANYOSAKI__c;
    }


    /**
     * Sets the TKCKANYOSAKI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TKCKANYOSAKI__c
     */
    public void setTKCKANYOSAKI__c(java.lang.String TKCKANYOSAKI__c) {
        this.TKCKANYOSAKI__c = TKCKANYOSAKI__c;
    }


    /**
     * Gets the TORIHIKIBANKCD10__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD10__c
     */
    public java.lang.String getTORIHIKIBANKCD10__c() {
        return TORIHIKIBANKCD10__c;
    }


    /**
     * Sets the TORIHIKIBANKCD10__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD10__c
     */
    public void setTORIHIKIBANKCD10__c(java.lang.String TORIHIKIBANKCD10__c) {
        this.TORIHIKIBANKCD10__c = TORIHIKIBANKCD10__c;
    }


    /**
     * Gets the TORIHIKIBANKCD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD1__c
     */
    public java.lang.String getTORIHIKIBANKCD1__c() {
        return TORIHIKIBANKCD1__c;
    }


    /**
     * Sets the TORIHIKIBANKCD1__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD1__c
     */
    public void setTORIHIKIBANKCD1__c(java.lang.String TORIHIKIBANKCD1__c) {
        this.TORIHIKIBANKCD1__c = TORIHIKIBANKCD1__c;
    }


    /**
     * Gets the TORIHIKIBANKCD2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD2__c
     */
    public java.lang.String getTORIHIKIBANKCD2__c() {
        return TORIHIKIBANKCD2__c;
    }


    /**
     * Sets the TORIHIKIBANKCD2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD2__c
     */
    public void setTORIHIKIBANKCD2__c(java.lang.String TORIHIKIBANKCD2__c) {
        this.TORIHIKIBANKCD2__c = TORIHIKIBANKCD2__c;
    }


    /**
     * Gets the TORIHIKIBANKCD3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD3__c
     */
    public java.lang.String getTORIHIKIBANKCD3__c() {
        return TORIHIKIBANKCD3__c;
    }


    /**
     * Sets the TORIHIKIBANKCD3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD3__c
     */
    public void setTORIHIKIBANKCD3__c(java.lang.String TORIHIKIBANKCD3__c) {
        this.TORIHIKIBANKCD3__c = TORIHIKIBANKCD3__c;
    }


    /**
     * Gets the TORIHIKIBANKCD4__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD4__c
     */
    public java.lang.String getTORIHIKIBANKCD4__c() {
        return TORIHIKIBANKCD4__c;
    }


    /**
     * Sets the TORIHIKIBANKCD4__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD4__c
     */
    public void setTORIHIKIBANKCD4__c(java.lang.String TORIHIKIBANKCD4__c) {
        this.TORIHIKIBANKCD4__c = TORIHIKIBANKCD4__c;
    }


    /**
     * Gets the TORIHIKIBANKCD5__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD5__c
     */
    public java.lang.String getTORIHIKIBANKCD5__c() {
        return TORIHIKIBANKCD5__c;
    }


    /**
     * Sets the TORIHIKIBANKCD5__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD5__c
     */
    public void setTORIHIKIBANKCD5__c(java.lang.String TORIHIKIBANKCD5__c) {
        this.TORIHIKIBANKCD5__c = TORIHIKIBANKCD5__c;
    }


    /**
     * Gets the TORIHIKIBANKCD6__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD6__c
     */
    public java.lang.String getTORIHIKIBANKCD6__c() {
        return TORIHIKIBANKCD6__c;
    }


    /**
     * Sets the TORIHIKIBANKCD6__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD6__c
     */
    public void setTORIHIKIBANKCD6__c(java.lang.String TORIHIKIBANKCD6__c) {
        this.TORIHIKIBANKCD6__c = TORIHIKIBANKCD6__c;
    }


    /**
     * Gets the TORIHIKIBANKCD7__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD7__c
     */
    public java.lang.String getTORIHIKIBANKCD7__c() {
        return TORIHIKIBANKCD7__c;
    }


    /**
     * Sets the TORIHIKIBANKCD7__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD7__c
     */
    public void setTORIHIKIBANKCD7__c(java.lang.String TORIHIKIBANKCD7__c) {
        this.TORIHIKIBANKCD7__c = TORIHIKIBANKCD7__c;
    }


    /**
     * Gets the TORIHIKIBANKCD8__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD8__c
     */
    public java.lang.String getTORIHIKIBANKCD8__c() {
        return TORIHIKIBANKCD8__c;
    }


    /**
     * Sets the TORIHIKIBANKCD8__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD8__c
     */
    public void setTORIHIKIBANKCD8__c(java.lang.String TORIHIKIBANKCD8__c) {
        this.TORIHIKIBANKCD8__c = TORIHIKIBANKCD8__c;
    }


    /**
     * Gets the TORIHIKIBANKCD9__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKIBANKCD9__c
     */
    public java.lang.String getTORIHIKIBANKCD9__c() {
        return TORIHIKIBANKCD9__c;
    }


    /**
     * Sets the TORIHIKIBANKCD9__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKIBANKCD9__c
     */
    public void setTORIHIKIBANKCD9__c(java.lang.String TORIHIKIBANKCD9__c) {
        this.TORIHIKIBANKCD9__c = TORIHIKIBANKCD9__c;
    }


    /**
     * Gets the TORIHIKISAKI_NM_EIJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKISAKI_NM_EIJI__c
     */
    public java.lang.String getTORIHIKISAKI_NM_EIJI__c() {
        return TORIHIKISAKI_NM_EIJI__c;
    }


    /**
     * Sets the TORIHIKISAKI_NM_EIJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKISAKI_NM_EIJI__c
     */
    public void setTORIHIKISAKI_NM_EIJI__c(java.lang.String TORIHIKISAKI_NM_EIJI__c) {
        this.TORIHIKISAKI_NM_EIJI__c = TORIHIKISAKI_NM_EIJI__c;
    }


    /**
     * Gets the TORIHIKISAKI_NM_JOIN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKISAKI_NM_JOIN__c
     */
    public java.lang.String getTORIHIKISAKI_NM_JOIN__c() {
        return TORIHIKISAKI_NM_JOIN__c;
    }


    /**
     * Sets the TORIHIKISAKI_NM_JOIN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKISAKI_NM_JOIN__c
     */
    public void setTORIHIKISAKI_NM_JOIN__c(java.lang.String TORIHIKISAKI_NM_JOIN__c) {
        this.TORIHIKISAKI_NM_JOIN__c = TORIHIKISAKI_NM_JOIN__c;
    }


    /**
     * Gets the TORIHIKISAKI_NM_KANA__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKISAKI_NM_KANA__c
     */
    public java.lang.String getTORIHIKISAKI_NM_KANA__c() {
        return TORIHIKISAKI_NM_KANA__c;
    }


    /**
     * Sets the TORIHIKISAKI_NM_KANA__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKISAKI_NM_KANA__c
     */
    public void setTORIHIKISAKI_NM_KANA__c(java.lang.String TORIHIKISAKI_NM_KANA__c) {
        this.TORIHIKISAKI_NM_KANA__c = TORIHIKISAKI_NM_KANA__c;
    }


    /**
     * Gets the TORIHIKISAKI_NM_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TORIHIKISAKI_NM_KANJI__c
     */
    public java.lang.String getTORIHIKISAKI_NM_KANJI__c() {
        return TORIHIKISAKI_NM_KANJI__c;
    }


    /**
     * Sets the TORIHIKISAKI_NM_KANJI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TORIHIKISAKI_NM_KANJI__c
     */
    public void setTORIHIKISAKI_NM_KANJI__c(java.lang.String TORIHIKISAKI_NM_KANJI__c) {
        this.TORIHIKISAKI_NM_KANJI__c = TORIHIKISAKI_NM_KANJI__c;
    }


    /**
     * Gets the TSUUSHINKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return TSUUSHINKBN__c
     */
    public java.lang.String getTSUUSHINKBN__c() {
        return TSUUSHINKBN__c;
    }


    /**
     * Sets the TSUUSHINKBN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param TSUUSHINKBN__c
     */
    public void setTSUUSHINKBN__c(java.lang.String TSUUSHINKBN__c) {
        this.TSUUSHINKBN__c = TSUUSHINKBN__c;
    }


    /**
     * Gets the tasks value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return tasks
     */
    public com.sforce.soap.enterprise.QueryResult getTasks() {
        return tasks;
    }


    /**
     * Sets the tasks value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param tasks
     */
    public void setTasks(com.sforce.soap.enterprise.QueryResult tasks) {
        this.tasks = tasks;
    }


    /**
     * Gets the topicAssignments value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return topicAssignments
     */
    public com.sforce.soap.enterprise.QueryResult getTopicAssignments() {
        return topicAssignments;
    }


    /**
     * Sets the topicAssignments value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param topicAssignments
     */
    public void setTopicAssignments(com.sforce.soap.enterprise.QueryResult topicAssignments) {
        this.topicAssignments = topicAssignments;
    }


    /**
     * Gets the URIAGEDAKA_HYAKUMANUNIT2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return URIAGEDAKA_HYAKUMANUNIT2__c
     */
    public java.lang.Double getURIAGEDAKA_HYAKUMANUNIT2__c() {
        return URIAGEDAKA_HYAKUMANUNIT2__c;
    }


    /**
     * Sets the URIAGEDAKA_HYAKUMANUNIT2__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param URIAGEDAKA_HYAKUMANUNIT2__c
     */
    public void setURIAGEDAKA_HYAKUMANUNIT2__c(java.lang.Double URIAGEDAKA_HYAKUMANUNIT2__c) {
        this.URIAGEDAKA_HYAKUMANUNIT2__c = URIAGEDAKA_HYAKUMANUNIT2__c;
    }


    /**
     * Gets the URIAGEDAKA_HYAKUMANUNIT3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return URIAGEDAKA_HYAKUMANUNIT3__c
     */
    public java.lang.Double getURIAGEDAKA_HYAKUMANUNIT3__c() {
        return URIAGEDAKA_HYAKUMANUNIT3__c;
    }


    /**
     * Sets the URIAGEDAKA_HYAKUMANUNIT3__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param URIAGEDAKA_HYAKUMANUNIT3__c
     */
    public void setURIAGEDAKA_HYAKUMANUNIT3__c(java.lang.Double URIAGEDAKA_HYAKUMANUNIT3__c) {
        this.URIAGEDAKA_HYAKUMANUNIT3__c = URIAGEDAKA_HYAKUMANUNIT3__c;
    }


    /**
     * Gets the URIAGEDAKA_HYAKUMANUNIT__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return URIAGEDAKA_HYAKUMANUNIT__c
     */
    public java.lang.Double getURIAGEDAKA_HYAKUMANUNIT__c() {
        return URIAGEDAKA_HYAKUMANUNIT__c;
    }


    /**
     * Sets the URIAGEDAKA_HYAKUMANUNIT__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param URIAGEDAKA_HYAKUMANUNIT__c
     */
    public void setURIAGEDAKA_HYAKUMANUNIT__c(java.lang.Double URIAGEDAKA_HYAKUMANUNIT__c) {
        this.URIAGEDAKA_HYAKUMANUNIT__c = URIAGEDAKA_HYAKUMANUNIT__c;
    }


    /**
     * Gets the USERID_EDABAN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return USERID_EDABAN__c
     */
    public java.lang.String getUSERID_EDABAN__c() {
        return USERID_EDABAN__c;
    }


    /**
     * Sets the USERID_EDABAN__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param USERID_EDABAN__c
     */
    public void setUSERID_EDABAN__c(java.lang.String USERID_EDABAN__c) {
        this.USERID_EDABAN__c = USERID_EDABAN__c;
    }


    /**
     * Gets the USERID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return USERID__c
     */
    public java.lang.String getUSERID__c() {
        return USERID__c;
    }


    /**
     * Sets the USERID__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param USERID__c
     */
    public void setUSERID__c(java.lang.String USERID__c) {
        this.USERID__c = USERID__c;
    }


    /**
     * Gets the userRecordAccess value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return userRecordAccess
     */
    public com.sforce.soap.enterprise.sobject.UserRecordAccess getUserRecordAccess() {
        return userRecordAccess;
    }


    /**
     * Sets the userRecordAccess value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param userRecordAccess
     */
    public void setUserRecordAccess(com.sforce.soap.enterprise.sobject.UserRecordAccess userRecordAccess) {
        this.userRecordAccess = userRecordAccess;
    }


    /**
     * Gets the YOKINTORIHIKIKAISHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return YOKINTORIHIKIKAISHIBI__c
     */
    public java.util.Date getYOKINTORIHIKIKAISHIBI__c() {
        return YOKINTORIHIKIKAISHIBI__c;
    }


    /**
     * Sets the YOKINTORIHIKIKAISHIBI__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param YOKINTORIHIKIKAISHIBI__c
     */
    public void setYOKINTORIHIKIKAISHIBI__c(java.util.Date YOKINTORIHIKIKAISHIBI__c) {
        this.YOKINTORIHIKIKAISHIBI__c = YOKINTORIHIKIKAISHIBI__c;
    }


    /**
     * Gets the YUUBINBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @return YUUBINBANGOU__c
     */
    public java.lang.String getYUUBINBANGOU__c() {
        return YUUBINBANGOU__c;
    }


    /**
     * Sets the YUUBINBANGOU__c value for this C000_CIFZOKUSEIINFO__c.
     *
     * @param YUUBINBANGOU__c
     */
    public void setYUUBINBANGOU__c(java.lang.String YUUBINBANGOU__c) {
        this.YUUBINBANGOU__c = YUUBINBANGOU__c;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof C000_CIFZOKUSEIINFO__c)) return false;
        C000_CIFZOKUSEIINFO__c other = (C000_CIFZOKUSEIINFO__c) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) &&
            ((this.a001_ANKEN_MiorikomiJoho_01__r==null && other.getA001_ANKEN_MiorikomiJoho_01__r()==null) ||
             (this.a001_ANKEN_MiorikomiJoho_01__r!=null &&
              this.a001_ANKEN_MiorikomiJoho_01__r.equals(other.getA001_ANKEN_MiorikomiJoho_01__r()))) &&
            ((this.a001_ANKEN_TorikomiJoho_03__r==null && other.getA001_ANKEN_TorikomiJoho_03__r()==null) ||
             (this.a001_ANKEN_TorikomiJoho_03__r!=null &&
              this.a001_ANKEN_TorikomiJoho_03__r.equals(other.getA001_ANKEN_TorikomiJoho_03__r()))) &&
            ((this.a002_ANKEN_Zairyou_001__r==null && other.getA002_ANKEN_Zairyou_001__r()==null) ||
             (this.a002_ANKEN_Zairyou_001__r!=null &&
              this.a002_ANKEN_Zairyou_001__r.equals(other.getA002_ANKEN_Zairyou_001__r()))) &&
            ((this.a004_Kokyaku_01__r==null && other.getA004_Kokyaku_01__r()==null) ||
             (this.a004_Kokyaku_01__r!=null &&
              this.a004_Kokyaku_01__r.equals(other.getA004_Kokyaku_01__r()))) &&
            ((this.a005_SERAs__r==null && other.getA005_SERAs__r()==null) ||
             (this.a005_SERAs__r!=null &&
              this.a005_SERAs__r.equals(other.getA005_SERAs__r()))) &&
            ((this.a019_CIFs_01__r==null && other.getA019_CIFs_01__r()==null) ||
             (this.a019_CIFs_01__r!=null &&
              this.a019_CIFs_01__r.equals(other.getA019_CIFs_01__r()))) &&
            ((this.ADDRESSCD__c==null && other.getADDRESSCD__c()==null) ||
             (this.ADDRESSCD__c!=null &&
              this.ADDRESSCD__c.equals(other.getADDRESSCD__c()))) &&
            ((this.ADDRESS_KANJI__c==null && other.getADDRESS_KANJI__c()==null) ||
             (this.ADDRESS_KANJI__c!=null &&
              this.ADDRESS_KANJI__c.equals(other.getADDRESS_KANJI__c()))) &&
            ((this.AREAINFOCD__c==null && other.getAREAINFOCD__c()==null) ||
             (this.AREAINFOCD__c!=null &&
              this.AREAINFOCD__c.equals(other.getAREAINFOCD__c()))) &&
            ((this.activityHistories==null && other.getActivityHistories()==null) ||
             (this.activityHistories!=null &&
              this.activityHistories.equals(other.getActivityHistories()))) &&
            ((this.attachments==null && other.getAttachments()==null) ||
             (this.attachments!=null &&
              this.attachments.equals(other.getAttachments()))) &&
            ((this.BOUEKIKBN__c==null && other.getBOUEKIKBN__c()==null) ||
             (this.BOUEKIKBN__c!=null &&
              this.BOUEKIKBN__c.equals(other.getBOUEKIKBN__c()))) &&
            ((this.BUMONKBN__c==null && other.getBUMONKBN__c()==null) ||
             (this.BUMONKBN__c!=null &&
              this.BUMONKBN__c.equals(other.getBUMONKBN__c()))) &&
            ((this.BUMONSAIKUBUN1__c==null && other.getBUMONSAIKUBUN1__c()==null) ||
             (this.BUMONSAIKUBUN1__c!=null &&
              this.BUMONSAIKUBUN1__c.equals(other.getBUMONSAIKUBUN1__c()))) &&
            ((this.BUMONSAIKUBUN2__c==null && other.getBUMONSAIKUBUN2__c()==null) ||
             (this.BUMONSAIKUBUN2__c!=null &&
              this.BUMONSAIKUBUN2__c.equals(other.getBUMONSAIKUBUN2__c()))) &&
            ((this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c==null && other.getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c()==null) ||
             (this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c!=null &&
              this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c.equals(other.getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c()))) &&
            ((this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r==null && other.getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r()==null) ||
             (this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r!=null &&
              this.BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r.equals(other.getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r()))) &&
            ((this.BUTENBANGOU__c==null && other.getBUTENBANGOU__c()==null) ||
             (this.BUTENBANGOU__c!=null &&
              this.BUTENBANGOU__c.equals(other.getBUTENBANGOU__c()))) &&
            ((this.BUTENNMRENKETSU__c==null && other.getBUTENNMRENKETSU__c()==null) ||
             (this.BUTENNMRENKETSU__c!=null &&
              this.BUTENNMRENKETSU__c.equals(other.getBUTENNMRENKETSU__c()))) &&
            ((this.c000_059_CIF_RATING_HISTORY_01__r==null && other.getC000_059_CIF_RATING_HISTORY_01__r()==null) ||
             (this.c000_059_CIF_RATING_HISTORY_01__r!=null &&
              this.c000_059_CIF_RATING_HISTORY_01__r.equals(other.getC000_059_CIF_RATING_HISTORY_01__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r==null && other.getC000_CIFZOKUSEIINFO_ChohyoOburiga_01__r()==null) ||
             (this.c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r!=null &&
              this.c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r.equals(other.getC000_CIFZOKUSEIINFO_ChohyoOburiga_01__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_ChohyoSera_01__r==null && other.getC000_CIFZOKUSEIINFO_ChohyoSera_01__r()==null) ||
             (this.c000_CIFZOKUSEIINFO_ChohyoSera_01__r!=null &&
              this.c000_CIFZOKUSEIINFO_ChohyoSera_01__r.equals(other.getC000_CIFZOKUSEIINFO_ChohyoSera_01__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r==null && other.getC000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r()==null) ||
             (this.c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r!=null &&
              this.c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r.equals(other.getC000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r==null && other.getC000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r()==null) ||
             (this.c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r!=null &&
              this.c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r.equals(other.getC000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r==null && other.getC000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r()==null) ||
             (this.c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r!=null &&
              this.c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r.equals(other.getC000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r==null && other.getC000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r()==null) ||
             (this.c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r!=null &&
              this.c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r.equals(other.getC000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r==null && other.getC000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r()==null) ||
             (this.c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r!=null &&
              this.c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r.equals(other.getC000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r()))) &&
            ((this.c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r==null && other.getC000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r()==null) ||
             (this.c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r!=null &&
              this.c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r.equals(other.getC000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r()))) &&
            ((this.c001_CIFs_01__r==null && other.getC001_CIFs_01__r()==null) ||
             (this.c001_CIFs_01__r!=null &&
              this.c001_CIFs_01__r.equals(other.getC001_CIFs_01__r()))) &&
            ((this.c003_CIFs_01__r==null && other.getC003_CIFs_01__r()==null) ||
             (this.c003_CIFs_01__r!=null &&
              this.c003_CIFs_01__r.equals(other.getC003_CIFs_01__r()))) &&
            ((this.CIFZOKUSEIINFO__r==null && other.getCIFZOKUSEIINFO__r()==null) ||
             (this.CIFZOKUSEIINFO__r!=null &&
              this.CIFZOKUSEIINFO__r.equals(other.getCIFZOKUSEIINFO__r()))) &&
            ((this.CIFZOKUSEIINFOs__r==null && other.getCIFZOKUSEIINFOs__r()==null) ||
             (this.CIFZOKUSEIINFOs__r!=null &&
              this.CIFZOKUSEIINFOs__r.equals(other.getCIFZOKUSEIINFOs__r()))) &&
            ((this.COUNTRYCD__c==null && other.getCOUNTRYCD__c()==null) ||
             (this.COUNTRYCD__c!=null &&
              this.COUNTRYCD__c.equals(other.getCOUNTRYCD__c()))) &&
            ((this.combinedAttachments==null && other.getCombinedAttachments()==null) ||
             (this.combinedAttachments!=null &&
              this.combinedAttachments.equals(other.getCombinedAttachments()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) ||
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createdById==null && other.getCreatedById()==null) ||
             (this.createdById!=null &&
              this.createdById.equals(other.getCreatedById()))) &&
            ((this.createdDate==null && other.getCreatedDate()==null) ||
             (this.createdDate!=null &&
              this.createdDate.equals(other.getCreatedDate()))) &&
            ((this.d002_001__r==null && other.getD002_001__r()==null) ||
             (this.d002_001__r!=null &&
              this.d002_001__r.equals(other.getD002_001__r()))) &&
            ((this.d002_002__r==null && other.getD002_002__r()==null) ||
             (this.d002_002__r!=null &&
              this.d002_002__r.equals(other.getD002_002__r()))) &&
            ((this.d003_001__r==null && other.getD003_001__r()==null) ||
             (this.d003_001__r!=null &&
              this.d003_001__r.equals(other.getD003_001__r()))) &&
            ((this.d003_002__r==null && other.getD003_002__r()==null) ||
             (this.d003_002__r!=null &&
              this.d003_002__r.equals(other.getD003_002__r()))) &&
            ((this.d004_ToDoSnaps02__r==null && other.getD004_ToDoSnaps02__r()==null) ||
             (this.d004_ToDoSnaps02__r!=null &&
              this.d004_ToDoSnaps02__r.equals(other.getD004_ToDoSnaps02__r()))) &&
            ((this.d004_ToDoSnaps__r==null && other.getD004_ToDoSnaps__r()==null) ||
             (this.d004_ToDoSnaps__r!=null &&
              this.d004_ToDoSnaps__r.equals(other.getD004_ToDoSnaps__r()))) &&
            ((this.d004_ToDos02__r==null && other.getD004_ToDos02__r()==null) ||
             (this.d004_ToDos02__r!=null &&
              this.d004_ToDos02__r.equals(other.getD004_ToDos02__r()))) &&
            ((this.d004_ToDos__r==null && other.getD004_ToDos__r()==null) ||
             (this.d004_ToDos__r!=null &&
              this.d004_ToDos__r.equals(other.getD004_ToDos__r()))) &&
            ((this.DELFLG__c==null && other.getDELFLG__c()==null) ||
             (this.DELFLG__c!=null &&
              this.DELFLG__c.equals(other.getDELFLG__c()))) &&
            ((this.DENWABANGOU__c==null && other.getDENWABANGOU__c()==null) ||
             (this.DENWABANGOU__c!=null &&
              this.DENWABANGOU__c.equals(other.getDENWABANGOU__c()))) &&
            ((this.DMDOUIKBN__c==null && other.getDMDOUIKBN__c()==null) ||
             (this.DMDOUIKBN__c!=null &&
              this.DMDOUIKBN__c.equals(other.getDMDOUIKBN__c()))) &&
            ((this.duplicateRecordItems==null && other.getDuplicateRecordItems()==null) ||
             (this.duplicateRecordItems!=null &&
              this.duplicateRecordItems.equals(other.getDuplicateRecordItems()))) &&
            ((this.events==null && other.getEvents()==null) ||
             (this.events!=null &&
              this.events.equals(other.getEvents()))) &&
            ((this.GAISHIKEIKBN__c==null && other.getGAISHIKEIKBN__c()==null) ||
             (this.GAISHIKEIKBN__c!=null &&
              this.GAISHIKEIKBN__c.equals(other.getGAISHIKEIKBN__c()))) &&
            ((this.GAITAMETORIHIKIKAISHIBI__c==null && other.getGAITAMETORIHIKIKAISHIBI__c()==null) ||
             (this.GAITAMETORIHIKIKAISHIBI__c!=null &&
              this.GAITAMETORIHIKIKAISHIBI__c.equals(other.getGAITAMETORIHIKIKAISHIBI__c()))) &&
            ((this.GAITAMEYOSHINTORIHIKIKAISHIBI__c==null && other.getGAITAMEYOSHINTORIHIKIKAISHIBI__c()==null) ||
             (this.GAITAMEYOSHINTORIHIKIKAISHIBI__c!=null &&
              this.GAITAMEYOSHINTORIHIKIKAISHIBI__c.equals(other.getGAITAMEYOSHINTORIHIKIKAISHIBI__c()))) &&
            ((this.GCIFBANGOU__c==null && other.getGCIFBANGOU__c()==null) ||
             (this.GCIFBANGOU__c!=null &&
              this.GCIFBANGOU__c.equals(other.getGCIFBANGOU__c()))) &&
            ((this.GYOUSHUCD1__c==null && other.getGYOUSHUCD1__c()==null) ||
             (this.GYOUSHUCD1__c!=null &&
              this.GYOUSHUCD1__c.equals(other.getGYOUSHUCD1__c()))) &&
            ((this.GYOUSHUCD2__c==null && other.getGYOUSHUCD2__c()==null) ||
             (this.GYOUSHUCD2__c!=null &&
              this.GYOUSHUCD2__c.equals(other.getGYOUSHUCD2__c()))) &&
            ((this.GYOUSHUCD3__c==null && other.getGYOUSHUCD3__c()==null) ||
             (this.GYOUSHUCD3__c!=null &&
              this.GYOUSHUCD3__c.equals(other.getGYOUSHUCD3__c()))) &&
            ((this.HATANSAKISAIKUBUN__c==null && other.getHATANSAKISAIKUBUN__c()==null) ||
             (this.HATANSAKISAIKUBUN__c!=null &&
              this.HATANSAKISAIKUBUN__c.equals(other.getHATANSAKISAIKUBUN__c()))) &&
            ((this.HIKIATEHYOUKA__c==null && other.getHIKIATEHYOUKA__c()==null) ||
             (this.HIKIATEHYOUKA__c!=null &&
              this.HIKIATEHYOUKA__c.equals(other.getHIKIATEHYOUKA__c()))) &&
            ((this.HONBUTANTOUBUMONCD1__c==null && other.getHONBUTANTOUBUMONCD1__c()==null) ||
             (this.HONBUTANTOUBUMONCD1__c!=null &&
              this.HONBUTANTOUBUMONCD1__c.equals(other.getHONBUTANTOUBUMONCD1__c()))) &&
            ((this.HONBUTANTOUSHACD1__c==null && other.getHONBUTANTOUSHACD1__c()==null) ||
             (this.HONBUTANTOUSHACD1__c!=null &&
              this.HONBUTANTOUSHACD1__c.equals(other.getHONBUTANTOUSHACD1__c()))) &&
            ((this.HYOUTEN__c==null && other.getHYOUTEN__c()==null) ||
             (this.HYOUTEN__c!=null &&
              this.HYOUTEN__c.equals(other.getHYOUTEN__c()))) &&
            ((this.histories==null && other.getHistories()==null) ||
             (this.histories!=null &&
              this.histories.equals(other.getHistories()))) &&
            ((this.isDeleted==null && other.getIsDeleted()==null) ||
             (this.isDeleted!=null &&
              this.isDeleted.equals(other.getIsDeleted()))) &&
            ((this.JCR_CSKHENKOUKBN__c==null && other.getJCR_CSKHENKOUKBN__c()==null) ||
             (this.JCR_CSKHENKOUKBN__c!=null &&
              this.JCR_CSKHENKOUKBN__c.equals(other.getJCR_CSKHENKOUKBN__c()))) &&
            ((this.JCR_CSKKEY1__c==null && other.getJCR_CSKKEY1__c()==null) ||
             (this.JCR_CSKKEY1__c!=null &&
              this.JCR_CSKKEY1__c.equals(other.getJCR_CSKKEY1__c()))) &&
            ((this.JCR_CSKKEY2__c==null && other.getJCR_CSKKEY2__c()==null) ||
             (this.JCR_CSKKEY2__c!=null &&
              this.JCR_CSKKEY2__c.equals(other.getJCR_CSKKEY2__c()))) &&
            ((this.JCR_CSKSTB__c==null && other.getJCR_CSKSTB__c()==null) ||
             (this.JCR_CSKSTB__c!=null &&
              this.JCR_CSKSTB__c.equals(other.getJCR_CSKSTB__c()))) &&
            ((this.JCR_CSK__c==null && other.getJCR_CSK__c()==null) ||
             (this.JCR_CSK__c!=null &&
              this.JCR_CSK__c.equals(other.getJCR_CSK__c()))) &&
            ((this.JCR_HAKKOUTAIID__c==null && other.getJCR_HAKKOUTAIID__c()==null) ||
             (this.JCR_HAKKOUTAIID__c!=null &&
              this.JCR_HAKKOUTAIID__c.equals(other.getJCR_HAKKOUTAIID__c()))) &&
            ((this.JCR_HAKKOUTAI_NM__c==null && other.getJCR_HAKKOUTAI_NM__c()==null) ||
             (this.JCR_HAKKOUTAI_NM__c!=null &&
              this.JCR_HAKKOUTAI_NM__c.equals(other.getJCR_HAKKOUTAI_NM__c()))) &&
            ((this.JCR_KIJUNBI__c==null && other.getJCR_KIJUNBI__c()==null) ||
             (this.JCR_KIJUNBI__c!=null &&
              this.JCR_KIJUNBI__c.equals(other.getJCR_KIJUNBI__c()))) &&
            ((this.JCR_MCKHENKOUKBN_CH__c==null && other.getJCR_MCKHENKOUKBN_CH__c()==null) ||
             (this.JCR_MCKHENKOUKBN_CH__c!=null &&
              this.JCR_MCKHENKOUKBN_CH__c.equals(other.getJCR_MCKHENKOUKBN_CH__c()))) &&
            ((this.JCR_MCKHENKOUKBN__c==null && other.getJCR_MCKHENKOUKBN__c()==null) ||
             (this.JCR_MCKHENKOUKBN__c!=null &&
              this.JCR_MCKHENKOUKBN__c.equals(other.getJCR_MCKHENKOUKBN__c()))) &&
            ((this.JCR_MCKSTB__c==null && other.getJCR_MCKSTB__c()==null) ||
             (this.JCR_MCKSTB__c!=null &&
              this.JCR_MCKSTB__c.equals(other.getJCR_MCKSTB__c()))) &&
            ((this.JCR_MCK_CH__c==null && other.getJCR_MCK_CH__c()==null) ||
             (this.JCR_MCK_CH__c!=null &&
              this.JCR_MCK_CH__c.equals(other.getJCR_MCK_CH__c()))) &&
            ((this.JCR_MCK__c==null && other.getJCR_MCK__c()==null) ||
             (this.JCR_MCK__c!=null &&
              this.JCR_MCK__c.equals(other.getJCR_MCK__c()))) &&
            ((this.JCR_MINASHIHANBETSUCD__c==null && other.getJCR_MINASHIHANBETSUCD__c()==null) ||
             (this.JCR_MINASHIHANBETSUCD__c!=null &&
              this.JCR_MINASHIHANBETSUCD__c.equals(other.getJCR_MINASHIHANBETSUCD__c()))) &&
            ((this.JCR_YUUKOUKIKANSHUURYOUBI__c==null && other.getJCR_YUUKOUKIKANSHUURYOUBI__c()==null) ||
             (this.JCR_YUUKOUKIKANSHUURYOUBI__c!=null &&
              this.JCR_YUUKOUKIKANSHUURYOUBI__c.equals(other.getJCR_YUUKOUKIKANSHUURYOUBI__c()))) &&
            ((this.JIGYOUSHA_HIJIGYOUSHAKBN__c==null && other.getJIGYOUSHA_HIJIGYOUSHAKBN__c()==null) ||
             (this.JIGYOUSHA_HIJIGYOUSHAKBN__c!=null &&
              this.JIGYOUSHA_HIJIGYOUSHAKBN__c.equals(other.getJIGYOUSHA_HIJIGYOUSHAKBN__c()))) &&
            ((this.JINKAKUKBN__c==null && other.getJINKAKUKBN__c()==null) ||
             (this.JINKAKUKBN__c!=null &&
              this.JINKAKUKBN__c.equals(other.getJINKAKUKBN__c()))) &&
            ((this.JOUJOUKBN1__c==null && other.getJOUJOUKBN1__c()==null) ||
             (this.JOUJOUKBN1__c!=null &&
              this.JOUJOUKBN1__c.equals(other.getJOUJOUKBN1__c()))) &&
            ((this.JOUJOUKBN2__c==null && other.getJOUJOUKBN2__c()==null) ||
             (this.JOUJOUKBN2__c!=null &&
              this.JOUJOUKBN2__c.equals(other.getJOUJOUKBN2__c()))) &&
            ((this.JOUJOUKBN3__c==null && other.getJOUJOUKBN3__c()==null) ||
             (this.JOUJOUKBN3__c!=null &&
              this.JOUJOUKBN3__c.equals(other.getJOUJOUKBN3__c()))) &&
            ((this.JOUJOUKBN__c==null && other.getJOUJOUKBN__c()==null) ||
             (this.JOUJOUKBN__c!=null &&
              this.JOUJOUKBN__c.equals(other.getJOUJOUKBN__c()))) &&
            ((this.JUNKYOHOUKBN__c==null && other.getJUNKYOHOUKBN__c()==null) ||
             (this.JUNKYOHOUKBN__c!=null &&
              this.JUNKYOHOUKBN__c.equals(other.getJUNKYOHOUKBN__c()))) &&
            ((this.JUUGYOUIN_CNT__c==null && other.getJUUGYOUIN_CNT__c()==null) ||
             (this.JUUGYOUIN_CNT__c!=null &&
              this.JUUGYOUIN_CNT__c.equals(other.getJUUGYOUIN_CNT__c()))) &&
            ((this.KABUSHIKICD__c==null && other.getKABUSHIKICD__c()==null) ||
             (this.KABUSHIKICD__c!=null &&
              this.KABUSHIKICD__c.equals(other.getKABUSHIKICD__c()))) &&
            ((this.KACD__c==null && other.getKACD__c()==null) ||
             (this.KACD__c!=null &&
              this.KACD__c.equals(other.getKACD__c()))) &&
            ((this.KAKUDUKEHENKOUBI__c==null && other.getKAKUDUKEHENKOUBI__c()==null) ||
             (this.KAKUDUKEHENKOUBI__c!=null &&
              this.KAKUDUKEHENKOUBI__c.equals(other.getKAKUDUKEHENKOUBI__c()))) &&
            ((this.KAKUDUKEKOUSHINBI__c==null && other.getKAKUDUKEKOUSHINBI__c()==null) ||
             (this.KAKUDUKEKOUSHINBI__c!=null &&
              this.KAKUDUKEKOUSHINBI__c.equals(other.getKAKUDUKEKOUSHINBI__c()))) &&
            ((this.KAKUDUKESAIKUBUN__c==null && other.getKAKUDUKESAIKUBUN__c()==null) ||
             (this.KAKUDUKESAIKUBUN__c!=null &&
              this.KAKUDUKESAIKUBUN__c.equals(other.getKAKUDUKESAIKUBUN__c()))) &&
            ((this.KANJISHIMEI__c==null && other.getKANJISHIMEI__c()==null) ||
             (this.KANJISHIMEI__c!=null &&
              this.KANJISHIMEI__c.equals(other.getKANJISHIMEI__c()))) &&
            ((this.KANRISAKIKBN__c==null && other.getKANRISAKIKBN__c()==null) ||
             (this.KANRISAKIKBN__c!=null &&
              this.KANRISAKIKBN__c.equals(other.getKANRISAKIKBN__c()))) &&
            ((this.KANSAJISSHIBI__c==null && other.getKANSAJISSHIBI__c()==null) ||
             (this.KANSAJISSHIBI__c!=null &&
              this.KANSAJISSHIBI__c.equals(other.getKANSAJISSHIBI__c()))) &&
            ((this.KASHIGAITORIHIKIUMUKBN__c==null && other.getKASHIGAITORIHIKIUMUKBN__c()==null) ||
             (this.KASHIGAITORIHIKIUMUKBN__c!=null &&
              this.KASHIGAITORIHIKIUMUKBN__c.equals(other.getKASHIGAITORIHIKIUMUKBN__c()))) &&
            ((this.KA_GROUPNM__c==null && other.getKA_GROUPNM__c()==null) ||
             (this.KA_GROUPNM__c!=null &&
              this.KA_GROUPNM__c.equals(other.getKA_GROUPNM__c()))) &&
            ((this.KEIRETSU_KANJI__c==null && other.getKEIRETSU_KANJI__c()==null) ||
             (this.KEIRETSU_KANJI__c!=null &&
              this.KEIRETSU_KANJI__c.equals(other.getKEIRETSU_KANJI__c()))) &&
            ((this.KENSAKUYOUKANASHOUGOU__c==null && other.getKENSAKUYOUKANASHOUGOU__c()==null) ||
             (this.KENSAKUYOUKANASHOUGOU__c!=null &&
              this.KENSAKUYOUKANASHOUGOU__c.equals(other.getKENSAKUYOUKANASHOUGOU__c()))) &&
            ((this.KENSAKUYOUKANJISHOUGOU__c==null && other.getKENSAKUYOUKANJISHOUGOU__c()==null) ||
             (this.KENSAKUYOUKANJISHOUGOU__c!=null &&
              this.KENSAKUYOUKANJISHOUGOU__c.equals(other.getKENSAKUYOUKANJISHOUGOU__c()))) &&
            ((this.KESSANNENGETSU2__c==null && other.getKESSANNENGETSU2__c()==null) ||
             (this.KESSANNENGETSU2__c!=null &&
              this.KESSANNENGETSU2__c.equals(other.getKESSANNENGETSU2__c()))) &&
            ((this.KESSANNENGETSU3__c==null && other.getKESSANNENGETSU3__c()==null) ||
             (this.KESSANNENGETSU3__c!=null &&
              this.KESSANNENGETSU3__c.equals(other.getKESSANNENGETSU3__c()))) &&
            ((this.KESSANNENGETSU__c==null && other.getKESSANNENGETSU__c()==null) ||
             (this.KESSANNENGETSU__c!=null &&
              this.KESSANNENGETSU__c.equals(other.getKESSANNENGETSU__c()))) &&
            ((this.KESSANTSUKI_CHUU__c==null && other.getKESSANTSUKI_CHUU__c()==null) ||
             (this.KESSANTSUKI_CHUU__c!=null &&
              this.KESSANTSUKI_CHUU__c.equals(other.getKESSANTSUKI_CHUU__c()))) &&
            ((this.KESSANTSUKI_HON__c==null && other.getKESSANTSUKI_HON__c()==null) ||
             (this.KESSANTSUKI_HON__c!=null &&
              this.KESSANTSUKI_HON__c.equals(other.getKESSANTSUKI_HON__c()))) &&
            ((this.KIGYOUBANGOU__c==null && other.getKIGYOUBANGOU__c()==null) ||
             (this.KIGYOUBANGOU__c!=null &&
              this.KIGYOUBANGOU__c.equals(other.getKIGYOUBANGOU__c()))) &&
            ((this.KIGYOUKIBOCD__c==null && other.getKIGYOUKIBOCD__c()==null) ||
             (this.KIGYOUKIBOCD__c!=null &&
              this.KIGYOUKIBOCD__c.equals(other.getKIGYOUKIBOCD__c()))) &&
            ((this.KIGYOUSEG__c==null && other.getKIGYOUSEG__c()==null) ||
             (this.KIGYOUSEG__c!=null &&
              this.KIGYOUSEG__c.equals(other.getKIGYOUSEG__c()))) &&
            ((this.KOKUNAIYOSHINTORIHIKIKAISHIBI__c==null && other.getKOKUNAIYOSHINTORIHIKIKAISHIBI__c()==null) ||
             (this.KOKUNAIYOSHINTORIHIKIKAISHIBI__c!=null &&
              this.KOKUNAIYOSHINTORIHIKIKAISHIBI__c.equals(other.getKOKUNAIYOSHINTORIHIKIKAISHIBI__c()))) &&
            ((this.KOKYAKUBANGOU__c==null && other.getKOKYAKUBANGOU__c()==null) ||
             (this.KOKYAKUBANGOU__c!=null &&
              this.KOKYAKUBANGOU__c.equals(other.getKOKYAKUBANGOU__c()))) &&
            ((this.KOKYAKUKANRITENBAN__c==null && other.getKOKYAKUKANRITENBAN__c()==null) ||
             (this.KOKYAKUKANRITENBAN__c!=null &&
              this.KOKYAKUKANRITENBAN__c.equals(other.getKOKYAKUKANRITENBAN__c()))) &&
            ((this.KOUKINCD__c==null && other.getKOUKINCD__c()==null) ||
             (this.KOUKINCD__c!=null &&
              this.KOUKINCD__c.equals(other.getKOUKINCD__c()))) &&
            ((this.KOUSHINBI__c==null && other.getKOUSHINBI__c()==null) ||
             (this.KOUSHINBI__c!=null &&
              this.KOUSHINBI__c.equals(other.getKOUSHINBI__c()))) &&
            ((this.KOZATEMMEI__c==null && other.getKOZATEMMEI__c()==null) ||
             (this.KOZATEMMEI__c!=null &&
              this.KOZATEMMEI__c.equals(other.getKOZATEMMEI__c()))) &&
            ((this.KOZATENJOHO__c==null && other.getKOZATENJOHO__c()==null) ||
             (this.KOZATENJOHO__c!=null &&
              this.KOZATENJOHO__c.equals(other.getKOZATENJOHO__c()))) &&
            ((this.KOZATENJOHO__r==null && other.getKOZATENJOHO__r()==null) ||
             (this.KOZATENJOHO__r!=null &&
              this.KOZATENJOHO__r.equals(other.getKOZATENJOHO__r()))) &&
            ((this.KYOJUUSEIKBN__c==null && other.getKYOJUUSEIKBN__c()==null) ||
             (this.KYOJUUSEIKBN__c!=null &&
              this.KYOJUUSEIKBN__c.equals(other.getKYOJUUSEIKBN__c()))) &&
            ((this.KYOTENHAIKAKAISOU1_BUTENBANGOU__c==null && other.getKYOTENHAIKAKAISOU1_BUTENBANGOU__c()==null) ||
             (this.KYOTENHAIKAKAISOU1_BUTENBANGOU__c!=null &&
              this.KYOTENHAIKAKAISOU1_BUTENBANGOU__c.equals(other.getKYOTENHAIKAKAISOU1_BUTENBANGOU__c()))) &&
            ((this.KYOTENHAIKAKAISOU2_BUTENBANGOU__c==null && other.getKYOTENHAIKAKAISOU2_BUTENBANGOU__c()==null) ||
             (this.KYOTENHAIKAKAISOU2_BUTENBANGOU__c!=null &&
              this.KYOTENHAIKAKAISOU2_BUTENBANGOU__c.equals(other.getKYOTENHAIKAKAISOU2_BUTENBANGOU__c()))) &&
            ((this.KYOTENHAIKAKAISOU3_BUTENBANGOU__c==null && other.getKYOTENHAIKAKAISOU3_BUTENBANGOU__c()==null) ||
             (this.KYOTENHAIKAKAISOU3_BUTENBANGOU__c!=null &&
              this.KYOTENHAIKAKAISOU3_BUTENBANGOU__c.equals(other.getKYOTENHAIKAKAISOU3_BUTENBANGOU__c()))) &&
            ((this.KYOTENSEG__c==null && other.getKYOTENSEG__c()==null) ||
             (this.KYOTENSEG__c!=null &&
              this.KYOTENSEG__c.equals(other.getKYOTENSEG__c()))) &&
            ((this.KYOTEN_BUTENBANGOU__c==null && other.getKYOTEN_BUTENBANGOU__c()==null) ||
             (this.KYOTEN_BUTENBANGOU__c!=null &&
              this.KYOTEN_BUTENBANGOU__c.equals(other.getKYOTEN_BUTENBANGOU__c()))) &&
            ((this.KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c==null && other.getKYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c()==null) ||
             (this.KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c!=null &&
              this.KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c.equals(other.getKYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c()))) &&
            ((this.KYOUTSUUNINSHOUKOUININFO_USERID__c==null && other.getKYOUTSUUNINSHOUKOUININFO_USERID__c()==null) ||
             (this.KYOUTSUUNINSHOUKOUININFO_USERID__c!=null &&
              this.KYOUTSUUNINSHOUKOUININFO_USERID__c.equals(other.getKYOUTSUUNINSHOUKOUININFO_USERID__c()))) &&
            ((this.KYOUTSUUNINSHOUKOUININFO_USERID__r==null && other.getKYOUTSUUNINSHOUKOUININFO_USERID__r()==null) ||
             (this.KYOUTSUUNINSHOUKOUININFO_USERID__r!=null &&
              this.KYOUTSUUNINSHOUKOUININFO_USERID__r.equals(other.getKYOUTSUUNINSHOUKOUININFO_USERID__r()))) &&
            ((this.lastActivityDate==null && other.getLastActivityDate()==null) ||
             (this.lastActivityDate!=null &&
              this.lastActivityDate.equals(other.getLastActivityDate()))) &&
            ((this.lastModifiedBy==null && other.getLastModifiedBy()==null) ||
             (this.lastModifiedBy!=null &&
              this.lastModifiedBy.equals(other.getLastModifiedBy()))) &&
            ((this.lastModifiedById==null && other.getLastModifiedById()==null) ||
             (this.lastModifiedById!=null &&
              this.lastModifiedById.equals(other.getLastModifiedById()))) &&
            ((this.lastModifiedDate==null && other.getLastModifiedDate()==null) ||
             (this.lastModifiedDate!=null &&
              this.lastModifiedDate.equals(other.getLastModifiedDate()))) &&
            ((this.lookedUpFromActivities==null && other.getLookedUpFromActivities()==null) ||
             (this.lookedUpFromActivities!=null &&
              this.lookedUpFromActivities.equals(other.getLookedUpFromActivities()))) &&
            ((this.MAINKICHOUCIF_SYSTEMKBN__c==null && other.getMAINKICHOUCIF_SYSTEMKBN__c()==null) ||
             (this.MAINKICHOUCIF_SYSTEMKBN__c!=null &&
              this.MAINKICHOUCIF_SYSTEMKBN__c.equals(other.getMAINKICHOUCIF_SYSTEMKBN__c()))) &&
            ((this.MAINKICHOUCIF_ZOKUSEIBANGOU__c==null && other.getMAINKICHOUCIF_ZOKUSEIBANGOU__c()==null) ||
             (this.MAINKICHOUCIF_ZOKUSEIBANGOU__c!=null &&
              this.MAINKICHOUCIF_ZOKUSEIBANGOU__c.equals(other.getMAINKICHOUCIF_ZOKUSEIBANGOU__c()))) &&
            ((this.MAINKICHOUCIF__c==null && other.getMAINKICHOUCIF__c()==null) ||
             (this.MAINKICHOUCIF__c!=null &&
              this.MAINKICHOUCIF__c.equals(other.getMAINKICHOUCIF__c()))) &&
            ((this.MAIN_CIF_FLG__c==null && other.getMAIN_CIF_FLG__c()==null) ||
             (this.MAIN_CIF_FLG__c!=null &&
              this.MAIN_CIF_FLG__c.equals(other.getMAIN_CIF_FLG__c()))) &&
            ((this.MO_HAKKOUTAIID__c==null && other.getMO_HAKKOUTAIID__c()==null) ||
             (this.MO_HAKKOUTAIID__c!=null &&
              this.MO_HAKKOUTAIID__c.equals(other.getMO_HAKKOUTAIID__c()))) &&
            ((this.MO_HAKKOUTAI_NM__c==null && other.getMO_HAKKOUTAI_NM__c()==null) ||
             (this.MO_HAKKOUTAI_NM__c!=null &&
              this.MO_HAKKOUTAI_NM__c.equals(other.getMO_HAKKOUTAI_NM__c()))) &&
            ((this.MO_JDCHKKEY__c==null && other.getMO_JDCHKKEY__c()==null) ||
             (this.MO_JDCHKKEY__c!=null &&
              this.MO_JDCHKKEY__c.equals(other.getMO_JDCHKKEY__c()))) &&
            ((this.MO_JDCHKRD__c==null && other.getMO_JDCHKRD__c()==null) ||
             (this.MO_JDCHKRD__c!=null &&
              this.MO_JDCHKRD__c.equals(other.getMO_JDCHKRD__c()))) &&
            ((this.MO_JDCHKSTB__c==null && other.getMO_JDCHKSTB__c()==null) ||
             (this.MO_JDCHKSTB__c!=null &&
              this.MO_JDCHKSTB__c.equals(other.getMO_JDCHKSTB__c()))) &&
            ((this.MO_JDCHKWR__c==null && other.getMO_JDCHKWR__c()==null) ||
             (this.MO_JDCHKWR__c!=null &&
              this.MO_JDCHKWR__c.equals(other.getMO_JDCHKWR__c()))) &&
            ((this.MO_JDCHK__c==null && other.getMO_JDCHK__c()==null) ||
             (this.MO_JDCHK__c!=null &&
              this.MO_JDCHK__c.equals(other.getMO_JDCHK__c()))) &&
            ((this.MO_KIJUNBI__c==null && other.getMO_KIJUNBI__c()==null) ||
             (this.MO_KIJUNBI__c!=null &&
              this.MO_KIJUNBI__c.equals(other.getMO_KIJUNBI__c()))) &&
            ((this.MO_MCKHENKOUKBN_CH__c==null && other.getMO_MCKHENKOUKBN_CH__c()==null) ||
             (this.MO_MCKHENKOUKBN_CH__c!=null &&
              this.MO_MCKHENKOUKBN_CH__c.equals(other.getMO_MCKHENKOUKBN_CH__c()))) &&
            ((this.MO_MCKRD__c==null && other.getMO_MCKRD__c()==null) ||
             (this.MO_MCKRD__c!=null &&
              this.MO_MCKRD__c.equals(other.getMO_MCKRD__c()))) &&
            ((this.MO_MCKSTB__c==null && other.getMO_MCKSTB__c()==null) ||
             (this.MO_MCKSTB__c!=null &&
              this.MO_MCKSTB__c.equals(other.getMO_MCKSTB__c()))) &&
            ((this.MO_MCKWR__c==null && other.getMO_MCKWR__c()==null) ||
             (this.MO_MCKWR__c!=null &&
              this.MO_MCKWR__c.equals(other.getMO_MCKWR__c()))) &&
            ((this.MO_MCK_CH__c==null && other.getMO_MCK_CH__c()==null) ||
             (this.MO_MCK_CH__c!=null &&
              this.MO_MCK_CH__c.equals(other.getMO_MCK_CH__c()))) &&
            ((this.MO_MCK__c==null && other.getMO_MCK__c()==null) ||
             (this.MO_MCK__c!=null &&
              this.MO_MCK__c.equals(other.getMO_MCK__c()))) &&
            ((this.MO_MINASHIHANBETSUCD__c==null && other.getMO_MINASHIHANBETSUCD__c()==null) ||
             (this.MO_MINASHIHANBETSUCD__c!=null &&
              this.MO_MINASHIHANBETSUCD__c.equals(other.getMO_MINASHIHANBETSUCD__c()))) &&
            ((this.MO_YUUKOUKIKANSHUURYOUBI__c==null && other.getMO_YUUKOUKIKANSHUURYOUBI__c()==null) ||
             (this.MO_YUUKOUKIKANSHUURYOUBI__c!=null &&
              this.MO_YUUKOUKIKANSHUURYOUBI__c.equals(other.getMO_YUUKOUKIKANSHUURYOUBI__c()))) &&
            ((this.m_CIF_FLG__c==null && other.getM_CIF_FLG__c()==null) ||
             (this.m_CIF_FLG__c!=null &&
              this.m_CIF_FLG__c.equals(other.getM_CIF_FLG__c()))) &&
            ((this.NIKKEI_HINIKKEIKBN__c==null && other.getNIKKEI_HINIKKEIKBN__c()==null) ||
             (this.NIKKEI_HINIKKEIKBN__c!=null &&
              this.NIKKEI_HINIKKEIKBN__c.equals(other.getNIKKEI_HINIKKEIKBN__c()))) &&
            ((this.name==null && other.getName()==null) ||
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.notes==null && other.getNotes()==null) ||
             (this.notes!=null &&
              this.notes.equals(other.getNotes()))) &&
            ((this.notesAndAttachments==null && other.getNotesAndAttachments()==null) ||
             (this.notesAndAttachments!=null &&
              this.notesAndAttachments.equals(other.getNotesAndAttachments()))) &&
            ((this.OUTLOOK__c==null && other.getOUTLOOK__c()==null) ||
             (this.OUTLOOK__c!=null &&
              this.OUTLOOK__c.equals(other.getOUTLOOK__c()))) &&
            ((this.openActivities==null && other.getOpenActivities()==null) ||
             (this.openActivities!=null &&
              this.openActivities.equals(other.getOpenActivities()))) &&
            ((this.owner==null && other.getOwner()==null) ||
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.ownerId==null && other.getOwnerId()==null) ||
             (this.ownerId!=null &&
              this.ownerId.equals(other.getOwnerId()))) &&
            ((this.processInstances==null && other.getProcessInstances()==null) ||
             (this.processInstances!=null &&
              this.processInstances.equals(other.getProcessInstances()))) &&
            ((this.processSteps==null && other.getProcessSteps()==null) ||
             (this.processSteps!=null &&
              this.processSteps.equals(other.getProcessSteps()))) &&
            ((this.RIEKI_KIN_SENUNIT2__c==null && other.getRIEKI_KIN_SENUNIT2__c()==null) ||
             (this.RIEKI_KIN_SENUNIT2__c!=null &&
              this.RIEKI_KIN_SENUNIT2__c.equals(other.getRIEKI_KIN_SENUNIT2__c()))) &&
            ((this.RIEKI_KIN_SENUNIT3__c==null && other.getRIEKI_KIN_SENUNIT3__c()==null) ||
             (this.RIEKI_KIN_SENUNIT3__c!=null &&
              this.RIEKI_KIN_SENUNIT3__c.equals(other.getRIEKI_KIN_SENUNIT3__c()))) &&
            ((this.RIEKI_KIN_SENUNIT__c==null && other.getRIEKI_KIN_SENUNIT__c()==null) ||
             (this.RIEKI_KIN_SENUNIT__c!=null &&
              this.RIEKI_KIN_SENUNIT__c.equals(other.getRIEKI_KIN_SENUNIT__c()))) &&
            ((this.RINGI_SAIRYOUKBN__c==null && other.getRINGI_SAIRYOUKBN__c()==null) ||
             (this.RINGI_SAIRYOUKBN__c!=null &&
              this.RINGI_SAIRYOUKBN__c.equals(other.getRINGI_SAIRYOUKBN__c()))) &&
            ((this.RI_CSKHENKOUKBN__c==null && other.getRI_CSKHENKOUKBN__c()==null) ||
             (this.RI_CSKHENKOUKBN__c!=null &&
              this.RI_CSKHENKOUKBN__c.equals(other.getRI_CSKHENKOUKBN__c()))) &&
            ((this.RI_CSKKEY1__c==null && other.getRI_CSKKEY1__c()==null) ||
             (this.RI_CSKKEY1__c!=null &&
              this.RI_CSKKEY1__c.equals(other.getRI_CSKKEY1__c()))) &&
            ((this.RI_CSKKEY2__c==null && other.getRI_CSKKEY2__c()==null) ||
             (this.RI_CSKKEY2__c!=null &&
              this.RI_CSKKEY2__c.equals(other.getRI_CSKKEY2__c()))) &&
            ((this.RI_CSKSTB__c==null && other.getRI_CSKSTB__c()==null) ||
             (this.RI_CSKSTB__c!=null &&
              this.RI_CSKSTB__c.equals(other.getRI_CSKSTB__c()))) &&
            ((this.RI_CSK__c==null && other.getRI_CSK__c()==null) ||
             (this.RI_CSK__c!=null &&
              this.RI_CSK__c.equals(other.getRI_CSK__c()))) &&
            ((this.RI_HAKKOUTAIID__c==null && other.getRI_HAKKOUTAIID__c()==null) ||
             (this.RI_HAKKOUTAIID__c!=null &&
              this.RI_HAKKOUTAIID__c.equals(other.getRI_HAKKOUTAIID__c()))) &&
            ((this.RI_HAKKOUTAI_NM__c==null && other.getRI_HAKKOUTAI_NM__c()==null) ||
             (this.RI_HAKKOUTAI_NM__c!=null &&
              this.RI_HAKKOUTAI_NM__c.equals(other.getRI_HAKKOUTAI_NM__c()))) &&
            ((this.RI_KIJUNBI__c==null && other.getRI_KIJUNBI__c()==null) ||
             (this.RI_KIJUNBI__c!=null &&
              this.RI_KIJUNBI__c.equals(other.getRI_KIJUNBI__c()))) &&
            ((this.RI_MCKHENKOUKBN_CH__c==null && other.getRI_MCKHENKOUKBN_CH__c()==null) ||
             (this.RI_MCKHENKOUKBN_CH__c!=null &&
              this.RI_MCKHENKOUKBN_CH__c.equals(other.getRI_MCKHENKOUKBN_CH__c()))) &&
            ((this.RI_MCKHK__c==null && other.getRI_MCKHK__c()==null) ||
             (this.RI_MCKHK__c!=null &&
              this.RI_MCKHK__c.equals(other.getRI_MCKHK__c()))) &&
            ((this.RI_MCKSTB__c==null && other.getRI_MCKSTB__c()==null) ||
             (this.RI_MCKSTB__c!=null &&
              this.RI_MCKSTB__c.equals(other.getRI_MCKSTB__c()))) &&
            ((this.RI_MCK_CH__c==null && other.getRI_MCK_CH__c()==null) ||
             (this.RI_MCK_CH__c!=null &&
              this.RI_MCK_CH__c.equals(other.getRI_MCK_CH__c()))) &&
            ((this.RI_MCK__c==null && other.getRI_MCK__c()==null) ||
             (this.RI_MCK__c!=null &&
              this.RI_MCK__c.equals(other.getRI_MCK__c()))) &&
            ((this.RI_MINASHIHANBETSUCD__c==null && other.getRI_MINASHIHANBETSUCD__c()==null) ||
             (this.RI_MINASHIHANBETSUCD__c!=null &&
              this.RI_MINASHIHANBETSUCD__c.equals(other.getRI_MINASHIHANBETSUCD__c()))) &&
            ((this.RI_YUUKOUKIKANSHUURYOUBI__c==null && other.getRI_YUUKOUKIKANSHUURYOUBI__c()==null) ||
             (this.RI_YUUKOUKIKANSHUURYOUBI__c!=null &&
              this.RI_YUUKOUKIKANSHUURYOUBI__c.equals(other.getRI_YUUKOUKIKANSHUURYOUBI__c()))) &&
            ((this.RMFFLG__c==null && other.getRMFFLG__c()==null) ||
             (this.RMFFLG__c!=null &&
              this.RMFFLG__c.equals(other.getRMFFLG__c()))) &&
            ((this.SAIMUCHOUKASAKIKBN__c==null && other.getSAIMUCHOUKASAKIKBN__c()==null) ||
             (this.SAIMUCHOUKASAKIKBN__c!=null &&
              this.SAIMUCHOUKASAKIKBN__c.equals(other.getSAIMUCHOUKASAKIKBN__c()))) &&
            ((this.SAIMUSHAKAKUDUKEYUUKOUKIGEN__c==null && other.getSAIMUSHAKAKUDUKEYUUKOUKIGEN__c()==null) ||
             (this.SAIMUSHAKAKUDUKEYUUKOUKIGEN__c!=null &&
              this.SAIMUSHAKAKUDUKEYUUKOUKIGEN__c.equals(other.getSAIMUSHAKAKUDUKEYUUKOUKIGEN__c()))) &&
            ((this.SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c==null && other.getSAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c()==null) ||
             (this.SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c!=null &&
              this.SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c.equals(other.getSAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c()))) &&
            ((this.SAIMUSHAKAKUDUKE__c==null && other.getSAIMUSHAKAKUDUKE__c()==null) ||
             (this.SAIMUSHAKAKUDUKE__c!=null &&
              this.SAIMUSHAKAKUDUKE__c.equals(other.getSAIMUSHAKAKUDUKE__c()))) &&
            ((this.SAIMUSHAKBN__c==null && other.getSAIMUSHAKBN__c()==null) ||
             (this.SAIMUSHAKBN__c!=null &&
              this.SAIMUSHAKBN__c.equals(other.getSAIMUSHAKBN__c()))) &&
            ((this.SAIMUSHA_HISAIMUSHAKBN__c==null && other.getSAIMUSHA_HISAIMUSHAKBN__c()==null) ||
             (this.SAIMUSHA_HISAIMUSHAKBN__c!=null &&
              this.SAIMUSHA_HISAIMUSHAKBN__c.equals(other.getSAIMUSHA_HISAIMUSHAKBN__c()))) &&
            ((this.SETAIKANRITANTOUSHA__c==null && other.getSETAIKANRITANTOUSHA__c()==null) ||
             (this.SETAIKANRITANTOUSHA__c!=null &&
              this.SETAIKANRITANTOUSHA__c.equals(other.getSETAIKANRITANTOUSHA__c()))) &&
            ((this.SETSURITSUNENGETSUBI__c==null && other.getSETSURITSUNENGETSUBI__c()==null) ||
             (this.SETSURITSUNENGETSUBI__c!=null &&
              this.SETSURITSUNENGETSUBI__c.equals(other.getSETSURITSUNENGETSUBI__c()))) &&
            ((this.SHIHONKIN__c==null && other.getSHIHONKIN__c()==null) ||
             (this.SHIHONKIN__c!=null &&
              this.SHIHONKIN__c.equals(other.getSHIHONKIN__c()))) &&
            ((this.SHINKOKUSHOTOKUKINGAKU2__c==null && other.getSHINKOKUSHOTOKUKINGAKU2__c()==null) ||
             (this.SHINKOKUSHOTOKUKINGAKU2__c!=null &&
              this.SHINKOKUSHOTOKUKINGAKU2__c.equals(other.getSHINKOKUSHOTOKUKINGAKU2__c()))) &&
            ((this.SHINKOKUSHOTOKUKINGAKU3__c==null && other.getSHINKOKUSHOTOKUKINGAKU3__c()==null) ||
             (this.SHINKOKUSHOTOKUKINGAKU3__c!=null &&
              this.SHINKOKUSHOTOKUKINGAKU3__c.equals(other.getSHINKOKUSHOTOKUKINGAKU3__c()))) &&
            ((this.SHINKOKUSHOTOKUKINGAKU__c==null && other.getSHINKOKUSHOTOKUKINGAKU__c()==null) ||
             (this.SHINKOKUSHOTOKUKINGAKU__c!=null &&
              this.SHINKOKUSHOTOKUKINGAKU__c.equals(other.getSHINKOKUSHOTOKUKINGAKU__c()))) &&
            ((this.SHINMITSUDO__c==null && other.getSHINMITSUDO__c()==null) ||
             (this.SHINMITSUDO__c!=null &&
              this.SHINMITSUDO__c.equals(other.getSHINMITSUDO__c()))) &&
            ((this.SHOUGOU_KANJI__c==null && other.getSHOUGOU_KANJI__c()==null) ||
             (this.SHOUGOU_KANJI__c!=null &&
              this.SHOUGOU_KANJI__c.equals(other.getSHOUGOU_KANJI__c()))) &&
            ((this.SHOUKYAKUKBN__c==null && other.getSHOUKYAKUKBN__c()==null) ||
             (this.SHOUKYAKUKBN__c!=null &&
              this.SHOUKYAKUKBN__c.equals(other.getSHOUKYAKUKBN__c()))) &&
            ((this.SHOZAICHI_KANJI__c==null && other.getSHOZAICHI_KANJI__c()==null) ||
             (this.SHOZAICHI_KANJI__c!=null &&
              this.SHOZAICHI_KANJI__c.equals(other.getSHOZAICHI_KANJI__c()))) &&
            ((this.SHURYOKUTAKOU1__c==null && other.getSHURYOKUTAKOU1__c()==null) ||
             (this.SHURYOKUTAKOU1__c!=null &&
              this.SHURYOKUTAKOU1__c.equals(other.getSHURYOKUTAKOU1__c()))) &&
            ((this.SHURYOKUTAKOU2__c==null && other.getSHURYOKUTAKOU2__c()==null) ||
             (this.SHURYOKUTAKOU2__c!=null &&
              this.SHURYOKUTAKOU2__c.equals(other.getSHURYOKUTAKOU2__c()))) &&
            ((this.SHURYOKUTAKOU3__c==null && other.getSHURYOKUTAKOU3__c()==null) ||
             (this.SHURYOKUTAKOU3__c!=null &&
              this.SHURYOKUTAKOU3__c.equals(other.getSHURYOKUTAKOU3__c()))) &&
            ((this.SP_HAKKOUTAIID__c==null && other.getSP_HAKKOUTAIID__c()==null) ||
             (this.SP_HAKKOUTAIID__c!=null &&
              this.SP_HAKKOUTAIID__c.equals(other.getSP_HAKKOUTAIID__c()))) &&
            ((this.SP_HAKKOUTAI_NM__c==null && other.getSP_HAKKOUTAI_NM__c()==null) ||
             (this.SP_HAKKOUTAI_NM__c!=null &&
              this.SP_HAKKOUTAI_NM__c.equals(other.getSP_HAKKOUTAI_NM__c()))) &&
            ((this.SP_JDCHKLOOK__c==null && other.getSP_JDCHKLOOK__c()==null) ||
             (this.SP_JDCHKLOOK__c!=null &&
              this.SP_JDCHKLOOK__c.equals(other.getSP_JDCHKLOOK__c()))) &&
            ((this.SP_JDCHKSTB__c==null && other.getSP_JDCHKSTB__c()==null) ||
             (this.SP_JDCHKSTB__c!=null &&
              this.SP_JDCHKSTB__c.equals(other.getSP_JDCHKSTB__c()))) &&
            ((this.SP_JDCHKW__c==null && other.getSP_JDCHKW__c()==null) ||
             (this.SP_JDCHKW__c!=null &&
              this.SP_JDCHKW__c.equals(other.getSP_JDCHKW__c()))) &&
            ((this.SP_JDCHK__c==null && other.getSP_JDCHK__c()==null) ||
             (this.SP_JDCHK__c!=null &&
              this.SP_JDCHK__c.equals(other.getSP_JDCHK__c()))) &&
            ((this.SP_KIJUNBI__c==null && other.getSP_KIJUNBI__c()==null) ||
             (this.SP_KIJUNBI__c!=null &&
              this.SP_KIJUNBI__c.equals(other.getSP_KIJUNBI__c()))) &&
            ((this.SP_MCKHENKOUKBN_CH__c==null && other.getSP_MCKHENKOUKBN_CH__c()==null) ||
             (this.SP_MCKHENKOUKBN_CH__c!=null &&
              this.SP_MCKHENKOUKBN_CH__c.equals(other.getSP_MCKHENKOUKBN_CH__c()))) &&
            ((this.SP_MCKLOOK__c==null && other.getSP_MCKLOOK__c()==null) ||
             (this.SP_MCKLOOK__c!=null &&
              this.SP_MCKLOOK__c.equals(other.getSP_MCKLOOK__c()))) &&
            ((this.SP_MCKSTB__c==null && other.getSP_MCKSTB__c()==null) ||
             (this.SP_MCKSTB__c!=null &&
              this.SP_MCKSTB__c.equals(other.getSP_MCKSTB__c()))) &&
            ((this.SP_MCKW__c==null && other.getSP_MCKW__c()==null) ||
             (this.SP_MCKW__c!=null &&
              this.SP_MCKW__c.equals(other.getSP_MCKW__c()))) &&
            ((this.SP_MCK_CH__c==null && other.getSP_MCK_CH__c()==null) ||
             (this.SP_MCK_CH__c!=null &&
              this.SP_MCK_CH__c.equals(other.getSP_MCK_CH__c()))) &&
            ((this.SP_MCK__c==null && other.getSP_MCK__c()==null) ||
             (this.SP_MCK__c!=null &&
              this.SP_MCK__c.equals(other.getSP_MCK__c()))) &&
            ((this.SP_MINASHIHANBETSUCD__c==null && other.getSP_MINASHIHANBETSUCD__c()==null) ||
             (this.SP_MINASHIHANBETSUCD__c!=null &&
              this.SP_MINASHIHANBETSUCD__c.equals(other.getSP_MINASHIHANBETSUCD__c()))) &&
            ((this.SP_YUUKOUKIKANSHUURYOUBI__c==null && other.getSP_YUUKOUKIKANSHUURYOUBI__c()==null) ||
             (this.SP_YUUKOUKIKANSHUURYOUBI__c!=null &&
              this.SP_YUUKOUKIKANSHUURYOUBI__c.equals(other.getSP_YUUKOUKIKANSHUURYOUBI__c()))) &&
            ((this.saikenJotoTsuchi_CifzkuseiInfo__r==null && other.getSaikenJotoTsuchi_CifzkuseiInfo__r()==null) ||
             (this.saikenJotoTsuchi_CifzkuseiInfo__r!=null &&
              this.saikenJotoTsuchi_CifzkuseiInfo__r.equals(other.getSaikenJotoTsuchi_CifzkuseiInfo__r()))) &&
            ((this.shares==null && other.getShares()==null) ||
             (this.shares!=null &&
              this.shares.equals(other.getShares()))) &&
            ((this.systemModstamp==null && other.getSystemModstamp()==null) ||
             (this.systemModstamp!=null &&
              this.systemModstamp.equals(other.getSystemModstamp()))) &&
            ((this.TANTOUSHACD1__c==null && other.getTANTOUSHACD1__c()==null) ||
             (this.TANTOUSHACD1__c!=null &&
              this.TANTOUSHACD1__c.equals(other.getTANTOUSHACD1__c()))) &&
            ((this.TANTOUSHACD2__c==null && other.getTANTOUSHACD2__c()==null) ||
             (this.TANTOUSHACD2__c!=null &&
              this.TANTOUSHACD2__c.equals(other.getTANTOUSHACD2__c()))) &&
            ((this.TDBSANGYOUBUNRUICD1__c==null && other.getTDBSANGYOUBUNRUICD1__c()==null) ||
             (this.TDBSANGYOUBUNRUICD1__c!=null &&
              this.TDBSANGYOUBUNRUICD1__c.equals(other.getTDBSANGYOUBUNRUICD1__c()))) &&
            ((this.TDBSANGYOUBUNRUICD2__c==null && other.getTDBSANGYOUBUNRUICD2__c()==null) ||
             (this.TDBSANGYOUBUNRUICD2__c!=null &&
              this.TDBSANGYOUBUNRUICD2__c.equals(other.getTDBSANGYOUBUNRUICD2__c()))) &&
            ((this.TDBSANGYOUBUNRUICD3__c==null && other.getTDBSANGYOUBUNRUICD3__c()==null) ||
             (this.TDBSANGYOUBUNRUICD3__c!=null &&
              this.TDBSANGYOUBUNRUICD3__c.equals(other.getTDBSANGYOUBUNRUICD3__c()))) &&
            ((this.TDBSANGYOUBUNRUICD4__c==null && other.getTDBSANGYOUBUNRUICD4__c()==null) ||
             (this.TDBSANGYOUBUNRUICD4__c!=null &&
              this.TDBSANGYOUBUNRUICD4__c.equals(other.getTDBSANGYOUBUNRUICD4__c()))) &&
            ((this.TDBSANGYOUBUNRUICD5__c==null && other.getTDBSANGYOUBUNRUICD5__c()==null) ||
             (this.TDBSANGYOUBUNRUICD5__c!=null &&
              this.TDBSANGYOUBUNRUICD5__c.equals(other.getTDBSANGYOUBUNRUICD5__c()))) &&
            ((this.TEAMCD__c==null && other.getTEAMCD__c()==null) ||
             (this.TEAMCD__c!=null &&
              this.TEAMCD__c.equals(other.getTEAMCD__c()))) &&
            ((this.TEKIKAKUKAISHACD__c==null && other.getTEKIKAKUKAISHACD__c()==null) ||
             (this.TEKIKAKUKAISHACD__c!=null &&
              this.TEKIKAKUKAISHACD__c.equals(other.getTEKIKAKUKAISHACD__c()))) &&
            ((this.TENBAN_3_KOKYAKUBANGOU__c==null && other.getTENBAN_3_KOKYAKUBANGOU__c()==null) ||
             (this.TENBAN_3_KOKYAKUBANGOU__c!=null &&
              this.TENBAN_3_KOKYAKUBANGOU__c.equals(other.getTENBAN_3_KOKYAKUBANGOU__c()))) &&
            ((this.TENBAN_3__c==null && other.getTENBAN_3__c()==null) ||
             (this.TENBAN_3__c!=null &&
              this.TENBAN_3__c.equals(other.getTENBAN_3__c()))) &&
            ((this.TENBAN_KOKYAKUBANGOU__c==null && other.getTENBAN_KOKYAKUBANGOU__c()==null) ||
             (this.TENBAN_KOKYAKUBANGOU__c!=null &&
              this.TENBAN_KOKYAKUBANGOU__c.equals(other.getTENBAN_KOKYAKUBANGOU__c()))) &&
            ((this.TENBAN__c==null && other.getTENBAN__c()==null) ||
             (this.TENBAN__c!=null &&
              this.TENBAN__c.equals(other.getTENBAN__c()))) &&
            ((this.TKCKAIIN__c==null && other.getTKCKAIIN__c()==null) ||
             (this.TKCKAIIN__c!=null &&
              this.TKCKAIIN__c.equals(other.getTKCKAIIN__c()))) &&
            ((this.TKCKANYOSAKI__c==null && other.getTKCKANYOSAKI__c()==null) ||
             (this.TKCKANYOSAKI__c!=null &&
              this.TKCKANYOSAKI__c.equals(other.getTKCKANYOSAKI__c()))) &&
            ((this.TORIHIKIBANKCD10__c==null && other.getTORIHIKIBANKCD10__c()==null) ||
             (this.TORIHIKIBANKCD10__c!=null &&
              this.TORIHIKIBANKCD10__c.equals(other.getTORIHIKIBANKCD10__c()))) &&
            ((this.TORIHIKIBANKCD1__c==null && other.getTORIHIKIBANKCD1__c()==null) ||
             (this.TORIHIKIBANKCD1__c!=null &&
              this.TORIHIKIBANKCD1__c.equals(other.getTORIHIKIBANKCD1__c()))) &&
            ((this.TORIHIKIBANKCD2__c==null && other.getTORIHIKIBANKCD2__c()==null) ||
             (this.TORIHIKIBANKCD2__c!=null &&
              this.TORIHIKIBANKCD2__c.equals(other.getTORIHIKIBANKCD2__c()))) &&
            ((this.TORIHIKIBANKCD3__c==null && other.getTORIHIKIBANKCD3__c()==null) ||
             (this.TORIHIKIBANKCD3__c!=null &&
              this.TORIHIKIBANKCD3__c.equals(other.getTORIHIKIBANKCD3__c()))) &&
            ((this.TORIHIKIBANKCD4__c==null && other.getTORIHIKIBANKCD4__c()==null) ||
             (this.TORIHIKIBANKCD4__c!=null &&
              this.TORIHIKIBANKCD4__c.equals(other.getTORIHIKIBANKCD4__c()))) &&
            ((this.TORIHIKIBANKCD5__c==null && other.getTORIHIKIBANKCD5__c()==null) ||
             (this.TORIHIKIBANKCD5__c!=null &&
              this.TORIHIKIBANKCD5__c.equals(other.getTORIHIKIBANKCD5__c()))) &&
            ((this.TORIHIKIBANKCD6__c==null && other.getTORIHIKIBANKCD6__c()==null) ||
             (this.TORIHIKIBANKCD6__c!=null &&
              this.TORIHIKIBANKCD6__c.equals(other.getTORIHIKIBANKCD6__c()))) &&
            ((this.TORIHIKIBANKCD7__c==null && other.getTORIHIKIBANKCD7__c()==null) ||
             (this.TORIHIKIBANKCD7__c!=null &&
              this.TORIHIKIBANKCD7__c.equals(other.getTORIHIKIBANKCD7__c()))) &&
            ((this.TORIHIKIBANKCD8__c==null && other.getTORIHIKIBANKCD8__c()==null) ||
             (this.TORIHIKIBANKCD8__c!=null &&
              this.TORIHIKIBANKCD8__c.equals(other.getTORIHIKIBANKCD8__c()))) &&
            ((this.TORIHIKIBANKCD9__c==null && other.getTORIHIKIBANKCD9__c()==null) ||
             (this.TORIHIKIBANKCD9__c!=null &&
              this.TORIHIKIBANKCD9__c.equals(other.getTORIHIKIBANKCD9__c()))) &&
            ((this.TORIHIKISAKI_NM_EIJI__c==null && other.getTORIHIKISAKI_NM_EIJI__c()==null) ||
             (this.TORIHIKISAKI_NM_EIJI__c!=null &&
              this.TORIHIKISAKI_NM_EIJI__c.equals(other.getTORIHIKISAKI_NM_EIJI__c()))) &&
            ((this.TORIHIKISAKI_NM_JOIN__c==null && other.getTORIHIKISAKI_NM_JOIN__c()==null) ||
             (this.TORIHIKISAKI_NM_JOIN__c!=null &&
              this.TORIHIKISAKI_NM_JOIN__c.equals(other.getTORIHIKISAKI_NM_JOIN__c()))) &&
            ((this.TORIHIKISAKI_NM_KANA__c==null && other.getTORIHIKISAKI_NM_KANA__c()==null) ||
             (this.TORIHIKISAKI_NM_KANA__c!=null &&
              this.TORIHIKISAKI_NM_KANA__c.equals(other.getTORIHIKISAKI_NM_KANA__c()))) &&
            ((this.TORIHIKISAKI_NM_KANJI__c==null && other.getTORIHIKISAKI_NM_KANJI__c()==null) ||
             (this.TORIHIKISAKI_NM_KANJI__c!=null &&
              this.TORIHIKISAKI_NM_KANJI__c.equals(other.getTORIHIKISAKI_NM_KANJI__c()))) &&
            ((this.TSUUSHINKBN__c==null && other.getTSUUSHINKBN__c()==null) ||
             (this.TSUUSHINKBN__c!=null &&
              this.TSUUSHINKBN__c.equals(other.getTSUUSHINKBN__c()))) &&
            ((this.tasks==null && other.getTasks()==null) ||
             (this.tasks!=null &&
              this.tasks.equals(other.getTasks()))) &&
            ((this.topicAssignments==null && other.getTopicAssignments()==null) ||
             (this.topicAssignments!=null &&
              this.topicAssignments.equals(other.getTopicAssignments()))) &&
            ((this.URIAGEDAKA_HYAKUMANUNIT2__c==null && other.getURIAGEDAKA_HYAKUMANUNIT2__c()==null) ||
             (this.URIAGEDAKA_HYAKUMANUNIT2__c!=null &&
              this.URIAGEDAKA_HYAKUMANUNIT2__c.equals(other.getURIAGEDAKA_HYAKUMANUNIT2__c()))) &&
            ((this.URIAGEDAKA_HYAKUMANUNIT3__c==null && other.getURIAGEDAKA_HYAKUMANUNIT3__c()==null) ||
             (this.URIAGEDAKA_HYAKUMANUNIT3__c!=null &&
              this.URIAGEDAKA_HYAKUMANUNIT3__c.equals(other.getURIAGEDAKA_HYAKUMANUNIT3__c()))) &&
            ((this.URIAGEDAKA_HYAKUMANUNIT__c==null && other.getURIAGEDAKA_HYAKUMANUNIT__c()==null) ||
             (this.URIAGEDAKA_HYAKUMANUNIT__c!=null &&
              this.URIAGEDAKA_HYAKUMANUNIT__c.equals(other.getURIAGEDAKA_HYAKUMANUNIT__c()))) &&
            ((this.USERID_EDABAN__c==null && other.getUSERID_EDABAN__c()==null) ||
             (this.USERID_EDABAN__c!=null &&
              this.USERID_EDABAN__c.equals(other.getUSERID_EDABAN__c()))) &&
            ((this.USERID__c==null && other.getUSERID__c()==null) ||
             (this.USERID__c!=null &&
              this.USERID__c.equals(other.getUSERID__c()))) &&
            ((this.userRecordAccess==null && other.getUserRecordAccess()==null) ||
             (this.userRecordAccess!=null &&
              this.userRecordAccess.equals(other.getUserRecordAccess()))) &&
            ((this.YOKINTORIHIKIKAISHIBI__c==null && other.getYOKINTORIHIKIKAISHIBI__c()==null) ||
             (this.YOKINTORIHIKIKAISHIBI__c!=null &&
              this.YOKINTORIHIKIKAISHIBI__c.equals(other.getYOKINTORIHIKIKAISHIBI__c()))) &&
            ((this.YUUBINBANGOU__c==null && other.getYUUBINBANGOU__c()==null) ||
             (this.YUUBINBANGOU__c!=null &&
              this.YUUBINBANGOU__c.equals(other.getYUUBINBANGOU__c())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getA001_ANKEN_MiorikomiJoho_01__r() != null) {
            _hashCode += getA001_ANKEN_MiorikomiJoho_01__r().hashCode();
        }
        if (getA001_ANKEN_TorikomiJoho_03__r() != null) {
            _hashCode += getA001_ANKEN_TorikomiJoho_03__r().hashCode();
        }
        if (getA002_ANKEN_Zairyou_001__r() != null) {
            _hashCode += getA002_ANKEN_Zairyou_001__r().hashCode();
        }
        if (getA004_Kokyaku_01__r() != null) {
            _hashCode += getA004_Kokyaku_01__r().hashCode();
        }
        if (getA005_SERAs__r() != null) {
            _hashCode += getA005_SERAs__r().hashCode();
        }
        if (getA019_CIFs_01__r() != null) {
            _hashCode += getA019_CIFs_01__r().hashCode();
        }
        if (getADDRESSCD__c() != null) {
            _hashCode += getADDRESSCD__c().hashCode();
        }
        if (getADDRESS_KANJI__c() != null) {
            _hashCode += getADDRESS_KANJI__c().hashCode();
        }
        if (getAREAINFOCD__c() != null) {
            _hashCode += getAREAINFOCD__c().hashCode();
        }
        if (getActivityHistories() != null) {
            _hashCode += getActivityHistories().hashCode();
        }
        if (getAttachments() != null) {
            _hashCode += getAttachments().hashCode();
        }
        if (getBOUEKIKBN__c() != null) {
            _hashCode += getBOUEKIKBN__c().hashCode();
        }
        if (getBUMONKBN__c() != null) {
            _hashCode += getBUMONKBN__c().hashCode();
        }
        if (getBUMONSAIKUBUN1__c() != null) {
            _hashCode += getBUMONSAIKUBUN1__c().hashCode();
        }
        if (getBUMONSAIKUBUN2__c() != null) {
            _hashCode += getBUMONSAIKUBUN2__c().hashCode();
        }
        if (getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c() != null) {
            _hashCode += getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c().hashCode();
        }
        if (getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r() != null) {
            _hashCode += getBUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r().hashCode();
        }
        if (getBUTENBANGOU__c() != null) {
            _hashCode += getBUTENBANGOU__c().hashCode();
        }
        if (getBUTENNMRENKETSU__c() != null) {
            _hashCode += getBUTENNMRENKETSU__c().hashCode();
        }
        if (getC000_059_CIF_RATING_HISTORY_01__r() != null) {
            _hashCode += getC000_059_CIF_RATING_HISTORY_01__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_ChohyoOburiga_01__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_ChohyoOburiga_01__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_ChohyoSera_01__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_ChohyoSera_01__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r().hashCode();
        }
        if (getC000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r() != null) {
            _hashCode += getC000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r().hashCode();
        }
        if (getC001_CIFs_01__r() != null) {
            _hashCode += getC001_CIFs_01__r().hashCode();
        }
        if (getC003_CIFs_01__r() != null) {
            _hashCode += getC003_CIFs_01__r().hashCode();
        }
        if (getCIFZOKUSEIINFO__r() != null) {
            _hashCode += getCIFZOKUSEIINFO__r().hashCode();
        }
        if (getCIFZOKUSEIINFOs__r() != null) {
            _hashCode += getCIFZOKUSEIINFOs__r().hashCode();
        }
        if (getCOUNTRYCD__c() != null) {
            _hashCode += getCOUNTRYCD__c().hashCode();
        }
        if (getCombinedAttachments() != null) {
            _hashCode += getCombinedAttachments().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreatedById() != null) {
            _hashCode += getCreatedById().hashCode();
        }
        if (getCreatedDate() != null) {
            _hashCode += getCreatedDate().hashCode();
        }
        if (getD002_001__r() != null) {
            _hashCode += getD002_001__r().hashCode();
        }
        if (getD002_002__r() != null) {
            _hashCode += getD002_002__r().hashCode();
        }
        if (getD003_001__r() != null) {
            _hashCode += getD003_001__r().hashCode();
        }
        if (getD003_002__r() != null) {
            _hashCode += getD003_002__r().hashCode();
        }
        if (getD004_ToDoSnaps02__r() != null) {
            _hashCode += getD004_ToDoSnaps02__r().hashCode();
        }
        if (getD004_ToDoSnaps__r() != null) {
            _hashCode += getD004_ToDoSnaps__r().hashCode();
        }
        if (getD004_ToDos02__r() != null) {
            _hashCode += getD004_ToDos02__r().hashCode();
        }
        if (getD004_ToDos__r() != null) {
            _hashCode += getD004_ToDos__r().hashCode();
        }
        if (getDELFLG__c() != null) {
            _hashCode += getDELFLG__c().hashCode();
        }
        if (getDENWABANGOU__c() != null) {
            _hashCode += getDENWABANGOU__c().hashCode();
        }
        if (getDMDOUIKBN__c() != null) {
            _hashCode += getDMDOUIKBN__c().hashCode();
        }
        if (getDuplicateRecordItems() != null) {
            _hashCode += getDuplicateRecordItems().hashCode();
        }
        if (getEvents() != null) {
            _hashCode += getEvents().hashCode();
        }
        if (getGAISHIKEIKBN__c() != null) {
            _hashCode += getGAISHIKEIKBN__c().hashCode();
        }
        if (getGAITAMETORIHIKIKAISHIBI__c() != null) {
            _hashCode += getGAITAMETORIHIKIKAISHIBI__c().hashCode();
        }
        if (getGAITAMEYOSHINTORIHIKIKAISHIBI__c() != null) {
            _hashCode += getGAITAMEYOSHINTORIHIKIKAISHIBI__c().hashCode();
        }
        if (getGCIFBANGOU__c() != null) {
            _hashCode += getGCIFBANGOU__c().hashCode();
        }
        if (getGYOUSHUCD1__c() != null) {
            _hashCode += getGYOUSHUCD1__c().hashCode();
        }
        if (getGYOUSHUCD2__c() != null) {
            _hashCode += getGYOUSHUCD2__c().hashCode();
        }
        if (getGYOUSHUCD3__c() != null) {
            _hashCode += getGYOUSHUCD3__c().hashCode();
        }
        if (getHATANSAKISAIKUBUN__c() != null) {
            _hashCode += getHATANSAKISAIKUBUN__c().hashCode();
        }
        if (getHIKIATEHYOUKA__c() != null) {
            _hashCode += getHIKIATEHYOUKA__c().hashCode();
        }
        if (getHONBUTANTOUBUMONCD1__c() != null) {
            _hashCode += getHONBUTANTOUBUMONCD1__c().hashCode();
        }
        if (getHONBUTANTOUSHACD1__c() != null) {
            _hashCode += getHONBUTANTOUSHACD1__c().hashCode();
        }
        if (getHYOUTEN__c() != null) {
            _hashCode += getHYOUTEN__c().hashCode();
        }
        if (getHistories() != null) {
            _hashCode += getHistories().hashCode();
        }
        if (getIsDeleted() != null) {
            _hashCode += getIsDeleted().hashCode();
        }
        if (getJCR_CSKHENKOUKBN__c() != null) {
            _hashCode += getJCR_CSKHENKOUKBN__c().hashCode();
        }
        if (getJCR_CSKKEY1__c() != null) {
            _hashCode += getJCR_CSKKEY1__c().hashCode();
        }
        if (getJCR_CSKKEY2__c() != null) {
            _hashCode += getJCR_CSKKEY2__c().hashCode();
        }
        if (getJCR_CSKSTB__c() != null) {
            _hashCode += getJCR_CSKSTB__c().hashCode();
        }
        if (getJCR_CSK__c() != null) {
            _hashCode += getJCR_CSK__c().hashCode();
        }
        if (getJCR_HAKKOUTAIID__c() != null) {
            _hashCode += getJCR_HAKKOUTAIID__c().hashCode();
        }
        if (getJCR_HAKKOUTAI_NM__c() != null) {
            _hashCode += getJCR_HAKKOUTAI_NM__c().hashCode();
        }
        if (getJCR_KIJUNBI__c() != null) {
            _hashCode += getJCR_KIJUNBI__c().hashCode();
        }
        if (getJCR_MCKHENKOUKBN_CH__c() != null) {
            _hashCode += getJCR_MCKHENKOUKBN_CH__c().hashCode();
        }
        if (getJCR_MCKHENKOUKBN__c() != null) {
            _hashCode += getJCR_MCKHENKOUKBN__c().hashCode();
        }
        if (getJCR_MCKSTB__c() != null) {
            _hashCode += getJCR_MCKSTB__c().hashCode();
        }
        if (getJCR_MCK_CH__c() != null) {
            _hashCode += getJCR_MCK_CH__c().hashCode();
        }
        if (getJCR_MCK__c() != null) {
            _hashCode += getJCR_MCK__c().hashCode();
        }
        if (getJCR_MINASHIHANBETSUCD__c() != null) {
            _hashCode += getJCR_MINASHIHANBETSUCD__c().hashCode();
        }
        if (getJCR_YUUKOUKIKANSHUURYOUBI__c() != null) {
            _hashCode += getJCR_YUUKOUKIKANSHUURYOUBI__c().hashCode();
        }
        if (getJIGYOUSHA_HIJIGYOUSHAKBN__c() != null) {
            _hashCode += getJIGYOUSHA_HIJIGYOUSHAKBN__c().hashCode();
        }
        if (getJINKAKUKBN__c() != null) {
            _hashCode += getJINKAKUKBN__c().hashCode();
        }
        if (getJOUJOUKBN1__c() != null) {
            _hashCode += getJOUJOUKBN1__c().hashCode();
        }
        if (getJOUJOUKBN2__c() != null) {
            _hashCode += getJOUJOUKBN2__c().hashCode();
        }
        if (getJOUJOUKBN3__c() != null) {
            _hashCode += getJOUJOUKBN3__c().hashCode();
        }
        if (getJOUJOUKBN__c() != null) {
            _hashCode += getJOUJOUKBN__c().hashCode();
        }
        if (getJUNKYOHOUKBN__c() != null) {
            _hashCode += getJUNKYOHOUKBN__c().hashCode();
        }
        if (getJUUGYOUIN_CNT__c() != null) {
            _hashCode += getJUUGYOUIN_CNT__c().hashCode();
        }
        if (getKABUSHIKICD__c() != null) {
            _hashCode += getKABUSHIKICD__c().hashCode();
        }
        if (getKACD__c() != null) {
            _hashCode += getKACD__c().hashCode();
        }
        if (getKAKUDUKEHENKOUBI__c() != null) {
            _hashCode += getKAKUDUKEHENKOUBI__c().hashCode();
        }
        if (getKAKUDUKEKOUSHINBI__c() != null) {
            _hashCode += getKAKUDUKEKOUSHINBI__c().hashCode();
        }
        if (getKAKUDUKESAIKUBUN__c() != null) {
            _hashCode += getKAKUDUKESAIKUBUN__c().hashCode();
        }
        if (getKANJISHIMEI__c() != null) {
            _hashCode += getKANJISHIMEI__c().hashCode();
        }
        if (getKANRISAKIKBN__c() != null) {
            _hashCode += getKANRISAKIKBN__c().hashCode();
        }
        if (getKANSAJISSHIBI__c() != null) {
            _hashCode += getKANSAJISSHIBI__c().hashCode();
        }
        if (getKASHIGAITORIHIKIUMUKBN__c() != null) {
            _hashCode += getKASHIGAITORIHIKIUMUKBN__c().hashCode();
        }
        if (getKA_GROUPNM__c() != null) {
            _hashCode += getKA_GROUPNM__c().hashCode();
        }
        if (getKEIRETSU_KANJI__c() != null) {
            _hashCode += getKEIRETSU_KANJI__c().hashCode();
        }
        if (getKENSAKUYOUKANASHOUGOU__c() != null) {
            _hashCode += getKENSAKUYOUKANASHOUGOU__c().hashCode();
        }
        if (getKENSAKUYOUKANJISHOUGOU__c() != null) {
            _hashCode += getKENSAKUYOUKANJISHOUGOU__c().hashCode();
        }
        if (getKESSANNENGETSU2__c() != null) {
            _hashCode += getKESSANNENGETSU2__c().hashCode();
        }
        if (getKESSANNENGETSU3__c() != null) {
            _hashCode += getKESSANNENGETSU3__c().hashCode();
        }
        if (getKESSANNENGETSU__c() != null) {
            _hashCode += getKESSANNENGETSU__c().hashCode();
        }
        if (getKESSANTSUKI_CHUU__c() != null) {
            _hashCode += getKESSANTSUKI_CHUU__c().hashCode();
        }
        if (getKESSANTSUKI_HON__c() != null) {
            _hashCode += getKESSANTSUKI_HON__c().hashCode();
        }
        if (getKIGYOUBANGOU__c() != null) {
            _hashCode += getKIGYOUBANGOU__c().hashCode();
        }
        if (getKIGYOUKIBOCD__c() != null) {
            _hashCode += getKIGYOUKIBOCD__c().hashCode();
        }
        if (getKIGYOUSEG__c() != null) {
            _hashCode += getKIGYOUSEG__c().hashCode();
        }
        if (getKOKUNAIYOSHINTORIHIKIKAISHIBI__c() != null) {
            _hashCode += getKOKUNAIYOSHINTORIHIKIKAISHIBI__c().hashCode();
        }
        if (getKOKYAKUBANGOU__c() != null) {
            _hashCode += getKOKYAKUBANGOU__c().hashCode();
        }
        if (getKOKYAKUKANRITENBAN__c() != null) {
            _hashCode += getKOKYAKUKANRITENBAN__c().hashCode();
        }
        if (getKOUKINCD__c() != null) {
            _hashCode += getKOUKINCD__c().hashCode();
        }
        if (getKOUSHINBI__c() != null) {
            _hashCode += getKOUSHINBI__c().hashCode();
        }
        if (getKOZATEMMEI__c() != null) {
            _hashCode += getKOZATEMMEI__c().hashCode();
        }
        if (getKOZATENJOHO__c() != null) {
            _hashCode += getKOZATENJOHO__c().hashCode();
        }
        if (getKOZATENJOHO__r() != null) {
            _hashCode += getKOZATENJOHO__r().hashCode();
        }
        if (getKYOJUUSEIKBN__c() != null) {
            _hashCode += getKYOJUUSEIKBN__c().hashCode();
        }
        if (getKYOTENHAIKAKAISOU1_BUTENBANGOU__c() != null) {
            _hashCode += getKYOTENHAIKAKAISOU1_BUTENBANGOU__c().hashCode();
        }
        if (getKYOTENHAIKAKAISOU2_BUTENBANGOU__c() != null) {
            _hashCode += getKYOTENHAIKAKAISOU2_BUTENBANGOU__c().hashCode();
        }
        if (getKYOTENHAIKAKAISOU3_BUTENBANGOU__c() != null) {
            _hashCode += getKYOTENHAIKAKAISOU3_BUTENBANGOU__c().hashCode();
        }
        if (getKYOTENSEG__c() != null) {
            _hashCode += getKYOTENSEG__c().hashCode();
        }
        if (getKYOTEN_BUTENBANGOU__c() != null) {
            _hashCode += getKYOTEN_BUTENBANGOU__c().hashCode();
        }
        if (getKYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c() != null) {
            _hashCode += getKYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c().hashCode();
        }
        if (getKYOUTSUUNINSHOUKOUININFO_USERID__c() != null) {
            _hashCode += getKYOUTSUUNINSHOUKOUININFO_USERID__c().hashCode();
        }
        if (getKYOUTSUUNINSHOUKOUININFO_USERID__r() != null) {
            _hashCode += getKYOUTSUUNINSHOUKOUININFO_USERID__r().hashCode();
        }
        if (getLastActivityDate() != null) {
            _hashCode += getLastActivityDate().hashCode();
        }
        if (getLastModifiedBy() != null) {
            _hashCode += getLastModifiedBy().hashCode();
        }
        if (getLastModifiedById() != null) {
            _hashCode += getLastModifiedById().hashCode();
        }
        if (getLastModifiedDate() != null) {
            _hashCode += getLastModifiedDate().hashCode();
        }
        if (getLookedUpFromActivities() != null) {
            _hashCode += getLookedUpFromActivities().hashCode();
        }
        if (getMAINKICHOUCIF_SYSTEMKBN__c() != null) {
            _hashCode += getMAINKICHOUCIF_SYSTEMKBN__c().hashCode();
        }
        if (getMAINKICHOUCIF_ZOKUSEIBANGOU__c() != null) {
            _hashCode += getMAINKICHOUCIF_ZOKUSEIBANGOU__c().hashCode();
        }
        if (getMAINKICHOUCIF__c() != null) {
            _hashCode += getMAINKICHOUCIF__c().hashCode();
        }
        if (getMAIN_CIF_FLG__c() != null) {
            _hashCode += getMAIN_CIF_FLG__c().hashCode();
        }
        if (getMO_HAKKOUTAIID__c() != null) {
            _hashCode += getMO_HAKKOUTAIID__c().hashCode();
        }
        if (getMO_HAKKOUTAI_NM__c() != null) {
            _hashCode += getMO_HAKKOUTAI_NM__c().hashCode();
        }
        if (getMO_JDCHKKEY__c() != null) {
            _hashCode += getMO_JDCHKKEY__c().hashCode();
        }
        if (getMO_JDCHKRD__c() != null) {
            _hashCode += getMO_JDCHKRD__c().hashCode();
        }
        if (getMO_JDCHKSTB__c() != null) {
            _hashCode += getMO_JDCHKSTB__c().hashCode();
        }
        if (getMO_JDCHKWR__c() != null) {
            _hashCode += getMO_JDCHKWR__c().hashCode();
        }
        if (getMO_JDCHK__c() != null) {
            _hashCode += getMO_JDCHK__c().hashCode();
        }
        if (getMO_KIJUNBI__c() != null) {
            _hashCode += getMO_KIJUNBI__c().hashCode();
        }
        if (getMO_MCKHENKOUKBN_CH__c() != null) {
            _hashCode += getMO_MCKHENKOUKBN_CH__c().hashCode();
        }
        if (getMO_MCKRD__c() != null) {
            _hashCode += getMO_MCKRD__c().hashCode();
        }
        if (getMO_MCKSTB__c() != null) {
            _hashCode += getMO_MCKSTB__c().hashCode();
        }
        if (getMO_MCKWR__c() != null) {
            _hashCode += getMO_MCKWR__c().hashCode();
        }
        if (getMO_MCK_CH__c() != null) {
            _hashCode += getMO_MCK_CH__c().hashCode();
        }
        if (getMO_MCK__c() != null) {
            _hashCode += getMO_MCK__c().hashCode();
        }
        if (getMO_MINASHIHANBETSUCD__c() != null) {
            _hashCode += getMO_MINASHIHANBETSUCD__c().hashCode();
        }
        if (getMO_YUUKOUKIKANSHUURYOUBI__c() != null) {
            _hashCode += getMO_YUUKOUKIKANSHUURYOUBI__c().hashCode();
        }
        if (getM_CIF_FLG__c() != null) {
            _hashCode += getM_CIF_FLG__c().hashCode();
        }
        if (getNIKKEI_HINIKKEIKBN__c() != null) {
            _hashCode += getNIKKEI_HINIKKEIKBN__c().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getNotes() != null) {
            _hashCode += getNotes().hashCode();
        }
        if (getNotesAndAttachments() != null) {
            _hashCode += getNotesAndAttachments().hashCode();
        }
        if (getOUTLOOK__c() != null) {
            _hashCode += getOUTLOOK__c().hashCode();
        }
        if (getOpenActivities() != null) {
            _hashCode += getOpenActivities().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getOwnerId() != null) {
            _hashCode += getOwnerId().hashCode();
        }
        if (getProcessInstances() != null) {
            _hashCode += getProcessInstances().hashCode();
        }
        if (getProcessSteps() != null) {
            _hashCode += getProcessSteps().hashCode();
        }
        if (getRIEKI_KIN_SENUNIT2__c() != null) {
            _hashCode += getRIEKI_KIN_SENUNIT2__c().hashCode();
        }
        if (getRIEKI_KIN_SENUNIT3__c() != null) {
            _hashCode += getRIEKI_KIN_SENUNIT3__c().hashCode();
        }
        if (getRIEKI_KIN_SENUNIT__c() != null) {
            _hashCode += getRIEKI_KIN_SENUNIT__c().hashCode();
        }
        if (getRINGI_SAIRYOUKBN__c() != null) {
            _hashCode += getRINGI_SAIRYOUKBN__c().hashCode();
        }
        if (getRI_CSKHENKOUKBN__c() != null) {
            _hashCode += getRI_CSKHENKOUKBN__c().hashCode();
        }
        if (getRI_CSKKEY1__c() != null) {
            _hashCode += getRI_CSKKEY1__c().hashCode();
        }
        if (getRI_CSKKEY2__c() != null) {
            _hashCode += getRI_CSKKEY2__c().hashCode();
        }
        if (getRI_CSKSTB__c() != null) {
            _hashCode += getRI_CSKSTB__c().hashCode();
        }
        if (getRI_CSK__c() != null) {
            _hashCode += getRI_CSK__c().hashCode();
        }
        if (getRI_HAKKOUTAIID__c() != null) {
            _hashCode += getRI_HAKKOUTAIID__c().hashCode();
        }
        if (getRI_HAKKOUTAI_NM__c() != null) {
            _hashCode += getRI_HAKKOUTAI_NM__c().hashCode();
        }
        if (getRI_KIJUNBI__c() != null) {
            _hashCode += getRI_KIJUNBI__c().hashCode();
        }
        if (getRI_MCKHENKOUKBN_CH__c() != null) {
            _hashCode += getRI_MCKHENKOUKBN_CH__c().hashCode();
        }
        if (getRI_MCKHK__c() != null) {
            _hashCode += getRI_MCKHK__c().hashCode();
        }
        if (getRI_MCKSTB__c() != null) {
            _hashCode += getRI_MCKSTB__c().hashCode();
        }
        if (getRI_MCK_CH__c() != null) {
            _hashCode += getRI_MCK_CH__c().hashCode();
        }
        if (getRI_MCK__c() != null) {
            _hashCode += getRI_MCK__c().hashCode();
        }
        if (getRI_MINASHIHANBETSUCD__c() != null) {
            _hashCode += getRI_MINASHIHANBETSUCD__c().hashCode();
        }
        if (getRI_YUUKOUKIKANSHUURYOUBI__c() != null) {
            _hashCode += getRI_YUUKOUKIKANSHUURYOUBI__c().hashCode();
        }
        if (getRMFFLG__c() != null) {
            _hashCode += getRMFFLG__c().hashCode();
        }
        if (getSAIMUCHOUKASAKIKBN__c() != null) {
            _hashCode += getSAIMUCHOUKASAKIKBN__c().hashCode();
        }
        if (getSAIMUSHAKAKUDUKEYUUKOUKIGEN__c() != null) {
            _hashCode += getSAIMUSHAKAKUDUKEYUUKOUKIGEN__c().hashCode();
        }
        if (getSAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c() != null) {
            _hashCode += getSAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c().hashCode();
        }
        if (getSAIMUSHAKAKUDUKE__c() != null) {
            _hashCode += getSAIMUSHAKAKUDUKE__c().hashCode();
        }
        if (getSAIMUSHAKBN__c() != null) {
            _hashCode += getSAIMUSHAKBN__c().hashCode();
        }
        if (getSAIMUSHA_HISAIMUSHAKBN__c() != null) {
            _hashCode += getSAIMUSHA_HISAIMUSHAKBN__c().hashCode();
        }
        if (getSETAIKANRITANTOUSHA__c() != null) {
            _hashCode += getSETAIKANRITANTOUSHA__c().hashCode();
        }
        if (getSETSURITSUNENGETSUBI__c() != null) {
            _hashCode += getSETSURITSUNENGETSUBI__c().hashCode();
        }
        if (getSHIHONKIN__c() != null) {
            _hashCode += getSHIHONKIN__c().hashCode();
        }
        if (getSHINKOKUSHOTOKUKINGAKU2__c() != null) {
            _hashCode += getSHINKOKUSHOTOKUKINGAKU2__c().hashCode();
        }
        if (getSHINKOKUSHOTOKUKINGAKU3__c() != null) {
            _hashCode += getSHINKOKUSHOTOKUKINGAKU3__c().hashCode();
        }
        if (getSHINKOKUSHOTOKUKINGAKU__c() != null) {
            _hashCode += getSHINKOKUSHOTOKUKINGAKU__c().hashCode();
        }
        if (getSHINMITSUDO__c() != null) {
            _hashCode += getSHINMITSUDO__c().hashCode();
        }
        if (getSHOUGOU_KANJI__c() != null) {
            _hashCode += getSHOUGOU_KANJI__c().hashCode();
        }
        if (getSHOUKYAKUKBN__c() != null) {
            _hashCode += getSHOUKYAKUKBN__c().hashCode();
        }
        if (getSHOZAICHI_KANJI__c() != null) {
            _hashCode += getSHOZAICHI_KANJI__c().hashCode();
        }
        if (getSHURYOKUTAKOU1__c() != null) {
            _hashCode += getSHURYOKUTAKOU1__c().hashCode();
        }
        if (getSHURYOKUTAKOU2__c() != null) {
            _hashCode += getSHURYOKUTAKOU2__c().hashCode();
        }
        if (getSHURYOKUTAKOU3__c() != null) {
            _hashCode += getSHURYOKUTAKOU3__c().hashCode();
        }
        if (getSP_HAKKOUTAIID__c() != null) {
            _hashCode += getSP_HAKKOUTAIID__c().hashCode();
        }
        if (getSP_HAKKOUTAI_NM__c() != null) {
            _hashCode += getSP_HAKKOUTAI_NM__c().hashCode();
        }
        if (getSP_JDCHKLOOK__c() != null) {
            _hashCode += getSP_JDCHKLOOK__c().hashCode();
        }
        if (getSP_JDCHKSTB__c() != null) {
            _hashCode += getSP_JDCHKSTB__c().hashCode();
        }
        if (getSP_JDCHKW__c() != null) {
            _hashCode += getSP_JDCHKW__c().hashCode();
        }
        if (getSP_JDCHK__c() != null) {
            _hashCode += getSP_JDCHK__c().hashCode();
        }
        if (getSP_KIJUNBI__c() != null) {
            _hashCode += getSP_KIJUNBI__c().hashCode();
        }
        if (getSP_MCKHENKOUKBN_CH__c() != null) {
            _hashCode += getSP_MCKHENKOUKBN_CH__c().hashCode();
        }
        if (getSP_MCKLOOK__c() != null) {
            _hashCode += getSP_MCKLOOK__c().hashCode();
        }
        if (getSP_MCKSTB__c() != null) {
            _hashCode += getSP_MCKSTB__c().hashCode();
        }
        if (getSP_MCKW__c() != null) {
            _hashCode += getSP_MCKW__c().hashCode();
        }
        if (getSP_MCK_CH__c() != null) {
            _hashCode += getSP_MCK_CH__c().hashCode();
        }
        if (getSP_MCK__c() != null) {
            _hashCode += getSP_MCK__c().hashCode();
        }
        if (getSP_MINASHIHANBETSUCD__c() != null) {
            _hashCode += getSP_MINASHIHANBETSUCD__c().hashCode();
        }
        if (getSP_YUUKOUKIKANSHUURYOUBI__c() != null) {
            _hashCode += getSP_YUUKOUKIKANSHUURYOUBI__c().hashCode();
        }
        if (getSaikenJotoTsuchi_CifzkuseiInfo__r() != null) {
            _hashCode += getSaikenJotoTsuchi_CifzkuseiInfo__r().hashCode();
        }
        if (getShares() != null) {
            _hashCode += getShares().hashCode();
        }
        if (getSystemModstamp() != null) {
            _hashCode += getSystemModstamp().hashCode();
        }
        if (getTANTOUSHACD1__c() != null) {
            _hashCode += getTANTOUSHACD1__c().hashCode();
        }
        if (getTANTOUSHACD2__c() != null) {
            _hashCode += getTANTOUSHACD2__c().hashCode();
        }
        if (getTDBSANGYOUBUNRUICD1__c() != null) {
            _hashCode += getTDBSANGYOUBUNRUICD1__c().hashCode();
        }
        if (getTDBSANGYOUBUNRUICD2__c() != null) {
            _hashCode += getTDBSANGYOUBUNRUICD2__c().hashCode();
        }
        if (getTDBSANGYOUBUNRUICD3__c() != null) {
            _hashCode += getTDBSANGYOUBUNRUICD3__c().hashCode();
        }
        if (getTDBSANGYOUBUNRUICD4__c() != null) {
            _hashCode += getTDBSANGYOUBUNRUICD4__c().hashCode();
        }
        if (getTDBSANGYOUBUNRUICD5__c() != null) {
            _hashCode += getTDBSANGYOUBUNRUICD5__c().hashCode();
        }
        if (getTEAMCD__c() != null) {
            _hashCode += getTEAMCD__c().hashCode();
        }
        if (getTEKIKAKUKAISHACD__c() != null) {
            _hashCode += getTEKIKAKUKAISHACD__c().hashCode();
        }
        if (getTENBAN_3_KOKYAKUBANGOU__c() != null) {
            _hashCode += getTENBAN_3_KOKYAKUBANGOU__c().hashCode();
        }
        if (getTENBAN_3__c() != null) {
            _hashCode += getTENBAN_3__c().hashCode();
        }
        if (getTENBAN_KOKYAKUBANGOU__c() != null) {
            _hashCode += getTENBAN_KOKYAKUBANGOU__c().hashCode();
        }
        if (getTENBAN__c() != null) {
            _hashCode += getTENBAN__c().hashCode();
        }
        if (getTKCKAIIN__c() != null) {
            _hashCode += getTKCKAIIN__c().hashCode();
        }
        if (getTKCKANYOSAKI__c() != null) {
            _hashCode += getTKCKANYOSAKI__c().hashCode();
        }
        if (getTORIHIKIBANKCD10__c() != null) {
            _hashCode += getTORIHIKIBANKCD10__c().hashCode();
        }
        if (getTORIHIKIBANKCD1__c() != null) {
            _hashCode += getTORIHIKIBANKCD1__c().hashCode();
        }
        if (getTORIHIKIBANKCD2__c() != null) {
            _hashCode += getTORIHIKIBANKCD2__c().hashCode();
        }
        if (getTORIHIKIBANKCD3__c() != null) {
            _hashCode += getTORIHIKIBANKCD3__c().hashCode();
        }
        if (getTORIHIKIBANKCD4__c() != null) {
            _hashCode += getTORIHIKIBANKCD4__c().hashCode();
        }
        if (getTORIHIKIBANKCD5__c() != null) {
            _hashCode += getTORIHIKIBANKCD5__c().hashCode();
        }
        if (getTORIHIKIBANKCD6__c() != null) {
            _hashCode += getTORIHIKIBANKCD6__c().hashCode();
        }
        if (getTORIHIKIBANKCD7__c() != null) {
            _hashCode += getTORIHIKIBANKCD7__c().hashCode();
        }
        if (getTORIHIKIBANKCD8__c() != null) {
            _hashCode += getTORIHIKIBANKCD8__c().hashCode();
        }
        if (getTORIHIKIBANKCD9__c() != null) {
            _hashCode += getTORIHIKIBANKCD9__c().hashCode();
        }
        if (getTORIHIKISAKI_NM_EIJI__c() != null) {
            _hashCode += getTORIHIKISAKI_NM_EIJI__c().hashCode();
        }
        if (getTORIHIKISAKI_NM_JOIN__c() != null) {
            _hashCode += getTORIHIKISAKI_NM_JOIN__c().hashCode();
        }
        if (getTORIHIKISAKI_NM_KANA__c() != null) {
            _hashCode += getTORIHIKISAKI_NM_KANA__c().hashCode();
        }
        if (getTORIHIKISAKI_NM_KANJI__c() != null) {
            _hashCode += getTORIHIKISAKI_NM_KANJI__c().hashCode();
        }
        if (getTSUUSHINKBN__c() != null) {
            _hashCode += getTSUUSHINKBN__c().hashCode();
        }
        if (getTasks() != null) {
            _hashCode += getTasks().hashCode();
        }
        if (getTopicAssignments() != null) {
            _hashCode += getTopicAssignments().hashCode();
        }
        if (getURIAGEDAKA_HYAKUMANUNIT2__c() != null) {
            _hashCode += getURIAGEDAKA_HYAKUMANUNIT2__c().hashCode();
        }
        if (getURIAGEDAKA_HYAKUMANUNIT3__c() != null) {
            _hashCode += getURIAGEDAKA_HYAKUMANUNIT3__c().hashCode();
        }
        if (getURIAGEDAKA_HYAKUMANUNIT__c() != null) {
            _hashCode += getURIAGEDAKA_HYAKUMANUNIT__c().hashCode();
        }
        if (getUSERID_EDABAN__c() != null) {
            _hashCode += getUSERID_EDABAN__c().hashCode();
        }
        if (getUSERID__c() != null) {
            _hashCode += getUSERID__c().hashCode();
        }
        if (getUserRecordAccess() != null) {
            _hashCode += getUserRecordAccess().hashCode();
        }
        if (getYOKINTORIHIKIKAISHIBI__c() != null) {
            _hashCode += getYOKINTORIHIKIKAISHIBI__c().hashCode();
        }
        if (getYUUBINBANGOU__c() != null) {
            _hashCode += getYUUBINBANGOU__c().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // メタデータ型 / [en]-(Type metadata)
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(C000_CIFZOKUSEIINFO__c.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO__c"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a001_ANKEN_MiorikomiJoho_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A001_ANKEN_MiorikomiJoho_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a001_ANKEN_TorikomiJoho_03__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A001_ANKEN_TorikomiJoho_03__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a002_ANKEN_Zairyou_001__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A002_ANKEN_Zairyou_001__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a004_Kokyaku_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A004_Kokyaku_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a005_SERAs__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A005_SERAs__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("a019_CIFs_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "A019_CIFs_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ADDRESSCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ADDRESSCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ADDRESS_KANJI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ADDRESS_KANJI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AREAINFOCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "AREAINFOCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activityHistories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ActivityHistories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("attachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Attachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BOUEKIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BOUEKIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUMONKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUMONKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUMONSAIKUBUN1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUMONSAIKUBUN1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUMONSAIKUBUN2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUMONSAIKUBUN2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENBANGOU_KACD_AREAINFOCD_TEAMCD__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_BUSHOINFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("BUTENNMRENKETSU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "BUTENNMRENKETSU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_059_CIF_RATING_HISTORY_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_059_CIF_RATING_HISTORY_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_ChohyoOburiga_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_ChohyoOburiga_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_ChohyoSera_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_ChohyoSera_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_RyudoTorihikiJoho_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_SaiKakuTorihiki_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_TorihikiJoho_K_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_TorihikiJoho_OK_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_TorihikiJoho_O_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_CIFZOKUSEIINFO_TorihikiJoho_S_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c001_CIFs_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C001_CIFs_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("c003_CIFs_01__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C003_CIFs_01__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIFZOKUSEIINFO__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIFZOKUSEIINFO__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CIFZOKUSEIINFOs__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CIFZOKUSEIINFOs__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("COUNTRYCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "COUNTRYCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("combinedAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CombinedAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "CreatedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d002_001__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D002_001__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d002_002__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D002_002__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d003_001__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D003_001__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d003_002__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D003_002__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d004_ToDoSnaps02__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D004_ToDoSnaps02__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d004_ToDoSnaps__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D004_ToDoSnaps__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d004_ToDos02__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D004_ToDos02__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("d004_ToDos__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "D004_ToDos__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DELFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DELFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DENWABANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DENWABANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DMDOUIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DMDOUIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duplicateRecordItems");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "DuplicateRecordItems"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("events");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Events"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GAISHIKEIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GAISHIKEIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GAITAMETORIHIKIKAISHIBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GAITAMETORIHIKIKAISHIBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GAITAMEYOSHINTORIHIKIKAISHIBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GAITAMEYOSHINTORIHIKIKAISHIBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GCIFBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GCIFBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GYOUSHUCD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GYOUSHUCD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GYOUSHUCD2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GYOUSHUCD2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GYOUSHUCD3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "GYOUSHUCD3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HATANSAKISAIKUBUN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HATANSAKISAIKUBUN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HIKIATEHYOUKA__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HIKIATEHYOUKA__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HONBUTANTOUBUMONCD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HONBUTANTOUBUMONCD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HONBUTANTOUSHACD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HONBUTANTOUSHACD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("HYOUTEN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "HYOUTEN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("histories");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Histories"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isDeleted");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "IsDeleted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_CSKHENKOUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_CSKHENKOUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_CSKKEY1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_CSKKEY1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_CSKKEY2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_CSKKEY2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_CSKSTB__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_CSKSTB__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_CSK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_CSK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_HAKKOUTAIID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_HAKKOUTAIID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_HAKKOUTAI_NM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_HAKKOUTAI_NM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_KIJUNBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_KIJUNBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_MCKHENKOUKBN_CH__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_MCKHENKOUKBN_CH__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_MCKHENKOUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_MCKHENKOUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_MCKSTB__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_MCKSTB__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_MCK_CH__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_MCK_CH__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_MCK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_MCK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_MINASHIHANBETSUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_MINASHIHANBETSUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JCR_YUUKOUKIKANSHUURYOUBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JCR_YUUKOUKIKANSHUURYOUBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JIGYOUSHA_HIJIGYOUSHAKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JIGYOUSHA_HIJIGYOUSHAKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JINKAKUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JINKAKUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUJOUKBN1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUJOUKBN1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUJOUKBN2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUJOUKBN2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUJOUKBN3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUJOUKBN3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JOUJOUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JOUJOUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JUNKYOHOUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JUNKYOHOUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("JUUGYOUIN_CNT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "JUUGYOUIN_CNT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KABUSHIKICD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KABUSHIKICD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KACD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KACD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAKUDUKEHENKOUBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAKUDUKEHENKOUBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAKUDUKEKOUSHINBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAKUDUKEKOUSHINBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KAKUDUKESAIKUBUN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KAKUDUKESAIKUBUN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KANJISHIMEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KANJISHIMEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KANRISAKIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KANRISAKIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KANSAJISSHIBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KANSAJISSHIBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KASHIGAITORIHIKIUMUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KASHIGAITORIHIKIUMUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KA_GROUPNM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KA_GROUPNM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KEIRETSU_KANJI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KEIRETSU_KANJI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENSAKUYOUKANASHOUGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENSAKUYOUKANASHOUGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KENSAKUYOUKANJISHOUGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KENSAKUYOUKANJISHOUGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KESSANNENGETSU2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KESSANNENGETSU2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KESSANNENGETSU3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KESSANNENGETSU3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KESSANNENGETSU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KESSANNENGETSU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KESSANTSUKI_CHUU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KESSANTSUKI_CHUU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KESSANTSUKI_HON__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KESSANTSUKI_HON__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KIGYOUBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KIGYOUBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KIGYOUKIBOCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KIGYOUKIBOCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KIGYOUSEG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KIGYOUSEG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKUNAIYOSHINTORIHIKIKAISHIBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKUNAIYOSHINTORIHIKIKAISHIBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKYAKUBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKYAKUBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOKYAKUKANRITENBAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOKYAKUKANRITENBAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUKINCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUKINCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOUSHINBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOUSHINBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOZATEMMEI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOZATEMMEI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOZATENJOHO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOZATENJOHO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KOZATENJOHO__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KOZATENJOHO__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_BUSHOINFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOJUUSEIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOJUUSEIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOTENHAIKAKAISOU1_BUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOTENHAIKAKAISOU1_BUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOTENHAIKAKAISOU2_BUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOTENHAIKAKAISOU2_BUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOTENHAIKAKAISOU3_BUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOTENHAIKAKAISOU3_BUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOTENSEG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOTENSEG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOTEN_BUTENBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOTEN_BUTENBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOUTSUUNINSHOUKOUININFO_BUTENNMRENKETSU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOUTSUUNINSHOUKOUININFO_USERID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOUTSUUNINSHOUKOUININFO_USERID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KYOUTSUUNINSHOUKOUININFO_USERID__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "KYOUTSUUNINSHOUKOUININFO_USERID__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "C000_KYOUTSUUNINSHOUKOUININFO__c"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastActivityDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastActivityDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "User"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedById");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedById"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastModifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LastModifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lookedUpFromActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "LookedUpFromActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAINKICHOUCIF_SYSTEMKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MAINKICHOUCIF_SYSTEMKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAINKICHOUCIF_ZOKUSEIBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MAINKICHOUCIF_ZOKUSEIBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAINKICHOUCIF__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MAINKICHOUCIF__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAIN_CIF_FLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MAIN_CIF_FLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_HAKKOUTAIID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_HAKKOUTAIID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_HAKKOUTAI_NM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_HAKKOUTAI_NM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_JDCHKKEY__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_JDCHKKEY__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_JDCHKRD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_JDCHKRD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_JDCHKSTB__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_JDCHKSTB__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_JDCHKWR__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_JDCHKWR__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_JDCHK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_JDCHK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_KIJUNBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_KIJUNBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_MCKHENKOUKBN_CH__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_MCKHENKOUKBN_CH__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_MCKRD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_MCKRD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_MCKSTB__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_MCKSTB__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_MCKWR__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_MCKWR__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_MCK_CH__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_MCK_CH__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_MCK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_MCK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_MINASHIHANBETSUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_MINASHIHANBETSUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MO_YUUKOUKIKANSHUURYOUBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "MO_YUUKOUKIKANSHUURYOUBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("m_CIF_FLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "M_CIF_FLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NIKKEI_HINIKKEIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NIKKEI_HINIKKEIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Notes"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("notesAndAttachments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "NotesAndAttachments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OUTLOOK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OUTLOOK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("openActivities");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OpenActivities"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Name"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("processSteps");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "ProcessSteps"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RIEKI_KIN_SENUNIT2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RIEKI_KIN_SENUNIT2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RIEKI_KIN_SENUNIT3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RIEKI_KIN_SENUNIT3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RIEKI_KIN_SENUNIT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RIEKI_KIN_SENUNIT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RINGI_SAIRYOUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RINGI_SAIRYOUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_CSKHENKOUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_CSKHENKOUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_CSKKEY1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_CSKKEY1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_CSKKEY2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_CSKKEY2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_CSKSTB__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_CSKSTB__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_CSK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_CSK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_HAKKOUTAIID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_HAKKOUTAIID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_HAKKOUTAI_NM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_HAKKOUTAI_NM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_KIJUNBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_KIJUNBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_MCKHENKOUKBN_CH__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_MCKHENKOUKBN_CH__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_MCKHK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_MCKHK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_MCKSTB__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_MCKSTB__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_MCK_CH__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_MCK_CH__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_MCK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_MCK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_MINASHIHANBETSUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_MINASHIHANBETSUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RI_YUUKOUKIKANSHUURYOUBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RI_YUUKOUKIKANSHUURYOUBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RMFFLG__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "RMFFLG__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAIMUCHOUKASAKIKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAIMUCHOUKASAKIKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAIMUSHAKAKUDUKEYUUKOUKIGEN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAIMUSHAKAKUDUKEYUUKOUKIGEN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAIMUSHAKAKUDUKE_KAKUDUKESAIKUBUN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAIMUSHAKAKUDUKE__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAIMUSHAKAKUDUKE__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAIMUSHAKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAIMUSHAKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SAIMUSHA_HISAIMUSHAKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SAIMUSHA_HISAIMUSHAKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SETAIKANRITANTOUSHA__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SETAIKANRITANTOUSHA__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SETSURITSUNENGETSUBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SETSURITSUNENGETSUBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHIHONKIN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHIHONKIN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHINKOKUSHOTOKUKINGAKU2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHINKOKUSHOTOKUKINGAKU2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHINKOKUSHOTOKUKINGAKU3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHINKOKUSHOTOKUKINGAKU3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHINKOKUSHOTOKUKINGAKU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHINKOKUSHOTOKUKINGAKU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHINMITSUDO__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHINMITSUDO__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOUGOU_KANJI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOUGOU_KANJI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOUKYAKUKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOUKYAKUKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOZAICHI_KANJI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHOZAICHI_KANJI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHURYOKUTAKOU1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHURYOKUTAKOU1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHURYOKUTAKOU2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHURYOKUTAKOU2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHURYOKUTAKOU3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SHURYOKUTAKOU3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_HAKKOUTAIID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_HAKKOUTAIID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_HAKKOUTAI_NM__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_HAKKOUTAI_NM__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_JDCHKLOOK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_JDCHKLOOK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_JDCHKSTB__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_JDCHKSTB__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_JDCHKW__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_JDCHKW__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_JDCHK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_JDCHK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_KIJUNBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_KIJUNBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_MCKHENKOUKBN_CH__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_MCKHENKOUKBN_CH__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_MCKLOOK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_MCKLOOK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_MCKSTB__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_MCKSTB__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_MCKW__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_MCKW__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_MCK_CH__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_MCK_CH__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_MCK__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_MCK__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_MINASHIHANBETSUCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_MINASHIHANBETSUCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SP_YUUKOUKIKANSHUURYOUBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SP_YUUKOUKIKANSHUURYOUBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("saikenJotoTsuchi_CifzkuseiInfo__r");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SaikenJotoTsuchi_CifzkuseiInfo__r"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("shares");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Shares"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemModstamp");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "SystemModstamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TANTOUSHACD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TANTOUSHACD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TANTOUSHACD2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TANTOUSHACD2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TDBSANGYOUBUNRUICD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TDBSANGYOUBUNRUICD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TDBSANGYOUBUNRUICD2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TDBSANGYOUBUNRUICD2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TDBSANGYOUBUNRUICD3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TDBSANGYOUBUNRUICD3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TDBSANGYOUBUNRUICD4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TDBSANGYOUBUNRUICD4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TDBSANGYOUBUNRUICD5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TDBSANGYOUBUNRUICD5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TEAMCD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TEAMCD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TEKIKAKUKAISHACD__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TEKIKAKUKAISHACD__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENBAN_3_KOKYAKUBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENBAN_3_KOKYAKUBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENBAN_3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENBAN_3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENBAN_KOKYAKUBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENBAN_KOKYAKUBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TENBAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TENBAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TKCKAIIN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TKCKAIIN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TKCKANYOSAKI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TKCKANYOSAKI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD10__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD10__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD1__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD1__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD4__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD4__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD5__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD5__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD6__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD6__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD7__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD7__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD8__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD8__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKIBANKCD9__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKIBANKCD9__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKISAKI_NM_EIJI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKISAKI_NM_EIJI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKISAKI_NM_JOIN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKISAKI_NM_JOIN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKISAKI_NM_KANA__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKISAKI_NM_KANA__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TORIHIKISAKI_NM_KANJI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TORIHIKISAKI_NM_KANJI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TSUUSHINKBN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TSUUSHINKBN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tasks");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "Tasks"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("topicAssignments");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "TopicAssignments"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:enterprise.soap.sforce.com", "QueryResult"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URIAGEDAKA_HYAKUMANUNIT2__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "URIAGEDAKA_HYAKUMANUNIT2__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URIAGEDAKA_HYAKUMANUNIT3__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "URIAGEDAKA_HYAKUMANUNIT3__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URIAGEDAKA_HYAKUMANUNIT__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "URIAGEDAKA_HYAKUMANUNIT__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("USERID_EDABAN__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "USERID_EDABAN__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("USERID__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "USERID__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userRecordAccess");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "UserRecordAccess"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YOKINTORIHIKIKAISHIBI__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YOKINTORIHIKIKAISHIBI__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("YUUBINBANGOU__c");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:sobject.enterprise.soap.sforce.com", "YUUBINBANGOU__c"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * メタデータオブジェクトの型を返却 / [en]-(Return type metadata object)
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
