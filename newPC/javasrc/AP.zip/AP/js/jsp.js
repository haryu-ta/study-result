
//接続コネクタ取得
function connect(){

	//IE以外をサポート
	if(window.XMLHttpRequest){

		//Win ie以外のXMLHttpRequestオブジェクト実装ブラウザ用
		return new XMLHttpRequest() //[1]'

	} else {

		return null

	}
}

/*
 * AJAX通信用関数
 */

//ajax通信実行関数
function dologic(){

	if( !window.JSON ){
		alert("JSON未対応のブラウザです。");
		return false;
	}

	//httpオブジェクトを作成
	var httpoj = connect();

	if ( httpoj == null ){

		alert("このブラウザは非同期通信に対応できません");
		return false;

	}

	//通信方法設定
	httpoj.open(
			"POST" ,                              //通信方法
			"/mobile/jsp/doinit" ,  //URL
			true                                  //非同期
			);
	httpoj.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );

	httpoj.onreadystatechange = function(){

		if( this.readyState == 4 ){

			if( this.status == 200 ){

				// サーバから受信したレスポンスを表示する(テキストの場合)
//				var data = this.responseText;
				// サーバから受信したレスポンスを表示する(JSONの場合)
				var jsondata = this.responseText;
				var data = JSON.parse(jsondata)
				for (var cnt = 0 ; cnt < data.length ;cnt++ ){
					alert(data[cnt].name);
				}
				var obj = document.getElementById("resultarea");
				obj.innerHTML = data[0].name;
		        obj.style.display="block";
			}else{
				// エラーを表示する
				alert( this.status + this.statusText );
			}

		}

	}

//	var data = {"name":"板村","old":"31","adress":"東京"};
	var data = {"outlist":[{"name":"板村","old":"31","adress":"千葉"},{"name":"佳奈","old":"31","adress":"東京"}]};
	httpoj.send(JSON.stringify(data));

}

/*
 * JSONP用<script>タグ生成用関数
 */
function jsonp(){

	var stag = document.createElement("script");
	stag.charset = 'utf-8';
	stag.src = "/mobile/js/jsonp.txt";
	document.body.appendChild(stag);

}

/*
* JSONPにて返却された関数実行用
* 返却される関数名と一致させる必要あり
*/
function dojsonp( data ){

	if( data instanceof Array ){
		for(var cnt = 0; cnt < data.length ;cnt++ ){
			alert(data[cnt].no1)
		}
	}else{
		alert("配列じゃないよ");
	}n

}

function confirm(){
	alert("aaa");
}