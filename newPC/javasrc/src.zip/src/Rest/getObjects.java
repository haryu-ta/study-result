import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;


public class getObjects {


	public static void getObjectsList(String sessionid) throws IOException{

		HttpURLConnection connection = null;

		URL url = new URL("https://ap.salesforce.com/services/data/v35.0/sobjects/");

		connection = (HttpURLConnection) url.openConnection();

		//connection.setDoOutput(true);
		connection.setInstanceFollowRedirects(false);
		connection.setRequestMethod("GET");
		connection.setRequestProperty("Content-Type", "Application/json");
		connection.setRequestProperty("Authorization", "Bearer " + sessionid);
		connection.setRequestProperty("Accept", "Application/json");
		connection.connect();

		if( connection.getResponseCode() == HttpURLConnection.HTTP_OK){
			//返却された値を文字列に取得
			BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
			String reply = reader.readLine();

			//JSON形式に変換
			ObjectMapper mapper = new ObjectMapper();

			//まじめに読込
//			@SuppressWarnings("unchecked")
//			Map<String,Object> result = mapper.readValue(reply, Map.class);
//			for(String key : result.keySet()){
//				if( result.get(key) instanceof String ){
//					System.out.println(key + " : " + result.get(key));
//				}else if( result.get(key) instanceof Integer ){
//					System.out.println(key + " : " + result.get(key));
//				}else if( result.get(key) instanceof Map ){
//					Map<String,Object> resultnes = (Map)result.get(key);
//					for( String key2 : resultnes.keySet() ){
//						System.out.println("\t" + key2 + " : " + resultnes.get(key2));
//					}
//
//				}else if( result.get(key) instanceof List ){
//					for( Object val : (List) result.get(key) ){
//						if( val instanceof Map){
//							Map<String,Object> resultnest = (Map)val;
//							for( String key3 : resultnest.keySet() ){
//								System.out.println("\t" + key3 + " : " +  resultnest.get(key3));
//							}
//						}
//					}
//				}
//			}

			JsonNode root = mapper.readTree(reply);
			for( JsonNode child : root.get("sobjects") ){
				if( child.get("label").isTextual() ){
					System.out.println(child.get("label").asText() + "," + child.get("name") + "," +  child.get("keyPrefix"));
				}
			}

		}else{
			System.out.println( connection.getResponseCode() );
		}

//		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream(), "utf-8"));
//		writer.write("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
//		writer.write("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:partner.soap.sforce.com\">");
//		writer.write("<soapenv:Body>");
//		writer.write("<urn:login>");
//		writer.write("<urn:username>ita@mail.com</urn:username>");
//		writer.write("<urn:password>xsw2#EDC</urn:password>");
//		writer.write("</urn:login>");
//		writer.write("</soapenv:Body>");
//		writer.write("</soapenv:Envelope>");
//		writer.close();


	}

}
