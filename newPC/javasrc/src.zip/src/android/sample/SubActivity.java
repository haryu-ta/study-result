package common.android.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import common.android.action.Action_addbtn;

public class SubActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		//画面のレイアウト設定
		setContentView(R.layout.activity_sub);

		Button btn = (Button)findViewById(R.id.send_btn_sub);

		btn.setOnClickListener(
				new OnClickListener(){

					//送信ボタンを押下時に
					public void onClick(View v) {

						//動的にボタンを追加
						LinearLayout layout1 = (LinearLayout)findViewById(R.id.add_btn_area);
						Button addbtn = new  Button(SubActivity.this);
						//addbtn.setId(R.id.decide_btn);

						//ボタンテキストの設定(文字列をXMLファイルから取得)
						addbtn.setText(getResources().getText(R.string.back));

						//ボタンの横幅等の指定
						LayoutParams lp3 = new LayoutParams(LayoutParams.FILL_PARENT
								,LayoutParams.WRAP_CONTENT);

						//別ファイルに定義したイベントをバインド
						//閉じるイベント
						addbtn.setOnClickListener(new Action_addbtn(SubActivity.this));

						layout1.addView(addbtn);

						/* ボタン名の変更およびイベント替え */
						Button btn2 = (Button)findViewById(R.id.send_btn_sub);
						btn2.setText(getResources().getText(R.string.ok));

						btn2.setOnClickListener(
							new OnClickListener(){

								@Override
								public void onClick(View v) {

									//Toast.makeText(SubActivity.this,"次へ画面を実装予定です。", Toast.LENGTH_LONG).show();

									Intent nextScreen = new Intent(SubActivity.this,SecondActivity.class);


									//画面内容を次画面に引継ぐ
									//●名前
									TextView personname = (TextView)findViewById(R.id.personname_sub);
									nextScreen.putExtra("name", personname.getText().toString());
									//●住所
									TextView adress = (TextView)findViewById(R.id.adress_sub);
									nextScreen.putExtra("adress", adress.getText().toString());
									//●生月日
									Spinner month = (Spinner)findViewById(R.id.month_sub);
									nextScreen.putExtra("month", month.getSelectedItem().toString());
									//●性別
									RadioGroup sexboth = (RadioGroup)findViewById(R.id.sex_radio_group);
									int checkid = sexboth.getCheckedRadioButtonId();
									RadioButton sex = (RadioButton)findViewById(checkid);
									nextScreen.putExtra("sex", sex.getText().toString());
									//●みかん選択値
									CheckBox orange = (CheckBox)findViewById(R.id.ora_chk_sub);
									nextScreen.putExtra("orange", orange.getText().toString());

									startActivity(nextScreen);

								}

							}
						);

					}
				}
		);

	}

}
