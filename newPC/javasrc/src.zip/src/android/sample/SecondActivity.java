package common.android.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import common.android.action.Action_addbtn;

public class SecondActivity extends Activity {

	ArrayAdapter<String> screencontent;

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second);

		//TODO 画面表示項目の実行
		Intent data = getIntent();
		Bundle extras = data.getExtras();


		//TODO 前画面からの情報引継
		screencontent = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1);
		screencontent.add(extras.getString("name"));
		screencontent.add(extras.getString("adress"));
		screencontent.add(extras.getString("month"));
		screencontent.add(extras.getString("sex"));
		screencontent.add(extras.getString("orange"));

		ListView list = (ListView)findViewById(R.id.list_display_area);
		list.setAdapter(screencontent);

		//イベントバインド
		Button backbtn = (Button)findViewById(R.id.back_btn);
		backbtn.setOnClickListener(new Action_addbtn(SecondActivity.this));

		//追加ボタンバインド
		Button addbtn = (Button)findViewById(R.id.addItem_btn);
		addbtn.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {

				//追加ボタンが押された場合にはテキストに入力があればリストビューに追加
				EditText additem = (EditText)findViewById(R.id.editText1);
				//null場合には処理しない
				if ( additem.getText() != null && !additem.getText().equals("") ){

					screencontent.add(additem.getText().toString());

					ListView list = (ListView)findViewById(R.id.list_display_area);
					list.setAdapter(screencontent);

				}



			}

		});

		//リストビューが選択された場合
		list.setOnItemClickListener(
				new OnItemClickListener(){

					@Override
					public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

						ListView list = (ListView) parent;
						String item = (String)list.getItemAtPosition(position);
						Toast.makeText(SecondActivity.this, item, Toast.LENGTH_SHORT).show();


					}



		});

		//ボタン追加押下時の動作
		Button btnadd = (Button)findViewById(R.id.btn_add_btn);
		btnadd.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {

				//ボタンの非活性
				findViewById(R.id.btn_add_btn).setEnabled(false);

				//xmlよりレイアウト読込
				Button newBtn = (Button)getLayoutInflater().inflate(R.layout.button_layout, null);
				newBtn.setText(R.string.gonext);

				LinearLayout layout = (LinearLayout)findViewById(R.id.btn_add_area);
				layout.addView(newBtn);



			}

		});


	}

}
