package common.android.sample;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		System.out.println("onCreate");
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		//ボタン押下時のイベント定義
		Button btn = (Button)findViewById(R.id.send_btn_main);
		btn.setOnClickListener(
					new OnClickListener() {

			@Override
			public void onClick(View v) {
				// インテントのインスタンス生成
				Intent intent = new Intent(MainActivity.this, SubActivity.class);
				// 次画面のアクティビティ起動
				startActivity(intent);
			}

		});
	}

//		btn.setOnClickListener(new ButtonClickListner());
//
//	}
//
//	class ButtonClickListner implements OnClickListener{
//
//		@Override
//		public void onClick(View v) {
//
//			Intent intent = new Intent(MainActivity.this,SubActivity.class);
//			startActivity(intent);
//
//		}
//
//	}

	@Override
	//メニューボタン押下時の処理
	public boolean onCreateOptionsMenu(Menu menu) {

		getMenuInflater().inflate(R.menu.main,menu);
		return super.onCreateOptionsMenu(menu);

	}

	@Override
	//メニュー内ボタン押下時の処理
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch(item.getItemId()){
		case R.id.close1:
			Toast ts = Toast.makeText(this, item.getTitle() + "が選択されました", Toast.LENGTH_LONG);
		    ts.show();
		}
		return super.onMenuItemSelected(featureId, item);
	}




}
