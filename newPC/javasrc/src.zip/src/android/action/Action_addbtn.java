package common.android.action;

import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;

/*
 * 追加ボタンの動作を定義するクラス
 * 画面を閉じるクラス
 */

public class Action_addbtn extends Activity implements OnClickListener  {

	Activity screen;

	public Action_addbtn(Activity subActivity) {

		screen = subActivity;

	}

	@Override
	//サブ画面の追加ボタンがクリックされた場合
	public void onClick(View v) {

		screen.finish();

	}



}
