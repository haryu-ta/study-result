import java.util.Date;


public class bean {
	private int componentcnt;					//コンポーネント数
	private String Id;							//Id
	private String Commodity_Code;				//商品コード
	private String Commodity_Name;				//商品名
	private String Category;					//カテゴリ
	private String OfficeRef;					//商品所管部
	private Date EndDate;						//廃止日
	private String Note;						//備考
	private Date StartDate;						//リリース日
	private String Status;						//商品状況
	private boolean Text_01_IsActive;			//汎用テキスト01_有効
	private String Text_01_Label;				//汎用テキスト01_表示ラベル
	private int Text_01_Layout;					//汎用テキスト01_レイアウト
	private boolean Text_01_Required;			//汎用テキスト01_必須
	private boolean Text_02_IsActive;			//汎用テキスト02_有効
	private String Text_02_Label;				//汎用テキスト02_表示ラベル
	private int Text_02_Layout;					//汎用テキスト02_レイアウト
	private boolean Text_02_Required;			//汎用テキスト02_必須
	private boolean Text_03_IsActive;			//汎用テキスト03_有効
	private String Text_03_Label;				//汎用テキスト03_表示ラベル
	private int Text_03_Layout;					//汎用テキスト03_レイアウト
	private boolean Text_03_Required;			//汎用テキスト03_必須
	private boolean Text_04_IsActive;			//汎用テキスト04_有効
	private String Text_04_Label;				//汎用テキスト04_表示ラベル
	private int Text_04_Layout;					//汎用テキスト04_レイアウト
	private boolean Text_04_Required;			//汎用テキスト04_必須
	private boolean Text_05_IsActive;			//汎用テキスト05_有効
	private String Text_05_Label;				//汎用テキスト05_表示ラベル
	private int Text_05_Layout;					//汎用テキスト05_レイアウト
	private boolean Text_05_Required;			//汎用テキスト05_必須
	private boolean Text_06_IsActive;			//汎用テキスト06_有効
	private String Text_06_Label;				//汎用テキスト06_表示ラベル
	private int Text_06_Layout;					//汎用テキスト06_レイアウト
	private boolean Text_06_Required;			//汎用テキスト06_必須
	private boolean Text_07_IsActive;			//汎用テキスト07_有効
	private String Text_07_Label;				//汎用テキスト07_表示ラベル
	private int Text_07_Layout;					//汎用テキスト07_レイアウト
	private boolean Text_07_Required;			//汎用テキスト07_必須
	private boolean Text_08_IsActive;			//汎用テキスト08_有効
	private String Text_08_Label;				//汎用テキスト08_表示ラベル
	private int Text_08_Layout;					//汎用テキスト08_レイアウト
	private boolean Text_08_Required;			//汎用テキスト08_必須
	private boolean Text_09_IsActive;			//汎用テキスト09_有効
	private String Text_09_Label;				//汎用テキスト09_表示ラベル
	private int Text_09_Layout;					//汎用テキスト09_レイアウト
	private boolean Text_09_Required;			//汎用テキスト09_必須
	private boolean Text_10_IsActive;			//汎用テキスト10_有効
	private String Text_10_Label;				//汎用テキスト10_表示ラベル
	private int Text_10_Layout;					//汎用テキスト10_レイアウト
	private boolean Text_10_Required;			//汎用テキスト10_必須
	private boolean Check_01_IsActive;			//汎用チェックボックス01_有効
	private String Check_01_Label;				//汎用チェックボックス01_表示ラベル
	private int Check_01_Layout;				//汎用チェックボックス01_レイアウト
	private boolean Check_02_IsActive;			//汎用チェックボックス02_有効
	private String Check_02_Label;				//汎用チェックボックス02_表示ラベル
	private int Check_02_Layout;				//汎用チェックボックス02_レイアウト
	private boolean Check_03_IsActive;			//汎用チェックボックス03_有効
	private String Check_03_Label;				//汎用チェックボックス03_表示ラベル
	private int Check_03_Layout;				//汎用チェックボックス03_レイアウト
	private boolean Check_04_IsActive;			//汎用チェックボックス04_有効
	private String Check_04_Label;				//汎用チェックボックス04_表示ラベル
	private int Check_04_Layout;				//汎用チェックボックス04_レイアウト
	private boolean Check_05_IsActive;			//汎用チェックボックス05_有効
	private String Check_05_Label;				//汎用チェックボックス05_表示ラベル
	private int Check_05_Layout;				//汎用チェックボックス05_レイアウト
	private boolean Check_06_IsActive;			//汎用チェックボックス06_有効
	private String Check_06_Label;				//汎用チェックボックス06_表示ラベル
	private int Check_06_Layout;				//汎用チェックボックス06_レイアウト
	private boolean Check_07_IsActive;			//汎用チェックボックス07_有効
	private String Check_07_Label;				//汎用チェックボックス07_表示ラベル
	private int Check_07_Layout;				//汎用チェックボックス07_レイアウト
	private boolean Check_08_IsActive;			//汎用チェックボックス08_有効
	private String Check_08_Label;				//汎用チェックボックス08_表示ラベル
	private int Check_08_Layout;				//汎用チェックボックス08_レイアウト
	private boolean Check_09_IsActive;			//汎用チェックボックス09_有効
	private String Check_09_Label;				//汎用チェックボックス09_表示ラベル
	private int Check_09_Layout;				//汎用チェックボックス09_レイアウト
	private boolean Check_10_IsActive;			//汎用チェックボックス10_有効
	private String Check_10_Label;				//汎用チェックボックス10_表示ラベル
	private int Check_10_Layout;				//汎用チェックボックス10_レイアウト
	private boolean Date_01_IsActive;			//汎用日付01_有効
	private String Date_01_Label;				//汎用日付01_表示ラベル
	private int Date_01_Layout;					//汎用日付01_レイアウト
	private boolean Date_01_Required;			//汎用日付01_必須
	private boolean Date_02_IsActive;			//汎用日付02_有効
	private String Date_02_Label;				//汎用日付02_表示ラベル
	private int Date_02_Layout;					//汎用日付02_レイアウト
	private boolean Date_02_Required;			//汎用日付02_必須
	private boolean Date_03_IsActive;			//汎用日付03_有効
	private String Date_03_Label;				//汎用日付03_表示ラベル
	private int Date_03_Layout;					//汎用日付03_レイアウト
	private boolean Date_03_Required;			//汎用日付03_必須
	private boolean Date_04_IsActive;			//汎用日付04_有効
	private String Date_04_Label;				//汎用日付04_表示ラベル
	private int Date_04_Layout;					//汎用日付04_レイアウト
	private boolean Date_04_Required;			//汎用日付04_必須
	private boolean Date_05_IsActive;			//汎用日付05_有効
	private String Date_05_Label;				//汎用日付05_表示ラベル
	private int Date_05_Layout;					//汎用日付05_レイアウト
	private boolean Date_05_Required;			//汎用日付05_必須
	private boolean Date_06_IsActive;			//汎用日付06_有効
	private String Date_06_Label;				//汎用日付06_表示ラベル
	private int Date_06_Layout;					//汎用日付06_レイアウト
	private boolean Date_06_Required;			//汎用日付06_必須
	private boolean Date_07_IsActive;			//汎用日付07_有効
	private String Date_07_Label;				//汎用日付07_表示ラベル
	private int Date_07_Layout;					//汎用日付07_レイアウト
	private boolean Date_07_Required;			//汎用日付07_必須
	private boolean Date_08_IsActive;			//汎用日付08_有効
	private String Date_08_Label;				//汎用日付08_表示ラベル
	private int Date_08_Layout;					//汎用日付08_レイアウト
	private boolean Date_08_Required;			//汎用日付08_必須
	private boolean Date_09_IsActive;			//汎用日付09_有効
	private String Date_09_Label;				//汎用日付09_表示ラベル
	private int Date_09_Layout;					//汎用日付09_レイアウト
	private boolean Date_09_Required;			//汎用日付09_必須
	private boolean Date_10_IsActive;			//汎用日付10_有効
	private String Date_10_Label;				//汎用日付10_表示ラベル
	private int Date_10_Layout;					//汎用日付10_レイアウト
	private boolean Date_10_Required;			//汎用日付10_必須
	private boolean List_01_IsActive;			//汎用選択リスト01_有効
	private String List_01_Label;				//汎用選択リスト01_表示ラベル
	private int List_01_Layout;					//汎用選択リスト01_レイアウト
	private String List_01_ListValues;			//汎用選択リスト01_リスト値
	private boolean List_01_Required;			//汎用選択リスト01_必須
	private boolean List_02_IsActive;			//汎用選択リスト02_有効
	private String List_02_Label;				//汎用選択リスト02_表示ラベル
	private int List_02_Layout;					//汎用選択リスト02_レイアウト
	private String List_02_ListValues;			//汎用選択リスト02_リスト値
	private boolean List_02_Required;			//汎用選択リスト02_必須
	private boolean List_03_IsActive;			//汎用選択リスト03_有効
	private String List_03_Label;				//汎用選択リスト03_表示ラベル
	private int List_03_Layout;					//汎用選択リスト03_レイアウト
	private String List_03_ListValues;			//汎用選択リスト03_リスト値
	private boolean List_03_Required;			//汎用選択リスト03_必須
	private boolean List_04_IsActive;			//汎用選択リスト04_有効
	private String List_04_Label;				//汎用選択リスト04_表示ラベル
	private int List_04_Layout;					//汎用選択リスト04_レイアウト
	private String List_04_ListValues;			//汎用選択リスト04_リスト値
	private boolean List_04_Required;			//汎用選択リスト04_必須
	private boolean List_05_IsActive;			//汎用選択リスト05_有効
	private String List_05_Label;				//汎用選択リスト05_表示ラベル
	private int List_05_Layout;					//汎用選択リスト05_レイアウト
	private String List_05_ListValues;			//汎用選択リスト05_リスト値
	private boolean List_05_Required;			//汎用選択リスト05_必須
	private boolean List_06_IsActive;			//汎用選択リスト06_有効
	private String List_06_Label;				//汎用選択リスト06_表示ラベル
	private int List_06_Layout;					//汎用選択リスト06_レイアウト
	private String List_06_ListValues;			//汎用選択リスト06_リスト値
	private boolean List_06_Required;			//汎用選択リスト06_必須
	private boolean List_07_IsActive;			//汎用選択リスト07_有効
	private String List_07_Label;				//汎用選択リスト07_表示ラベル
	private int List_07_Layout;					//汎用選択リスト07_レイアウト
	private String List_07_ListValues;			//汎用選択リスト07_リスト値
	private boolean List_07_Required;			//汎用選択リスト07_必須
	private boolean List_08_IsActive;			//汎用選択リスト08_有効
	private String List_08_Label;				//汎用選択リスト08_表示ラベル
	private int List_08_Layout;					//汎用選択リスト08_レイアウト
	private String List_08_ListValues;			//汎用選択リスト08_リスト値
	private boolean List_08_Required;			//汎用選択リスト08_必須
	private boolean List_09_IsActive;			//汎用選択リスト09_有効
	private String List_09_Label;				//汎用選択リスト09_表示ラベル
	private int List_09_Layout;					//汎用選択リスト09_レイアウト
	private String List_09_ListValues;			//汎用選択リスト09_リスト値
	private boolean List_09_Required;			//汎用選択リスト09_必須
	private boolean List_10_IsActive;			//汎用選択リスト10_有効
	private String List_10_Label;				//汎用選択リスト10_表示ラベル
	private int List_10_Layout;					//汎用選択リスト10_レイアウト
	private String List_10_ListValues;			//汎用選択リスト10_リスト値
	private boolean List_10_Required;			//汎用選択リスト10_必須
	private boolean Number_01_IsActive;			//汎用数値01_有効
	private String Number_01_Label;				//汎用数値01_表示ラベル
	private int Number_01_Layout;				//汎用数値01_レイアウト
	private boolean Number_01_Required;			//汎用数値01_必須
	private boolean Number_02_IsActive;			//汎用数値02_有効
	private String Number_02_Label;				//汎用数値02_表示ラベル
	private int Number_02_Layout;				//汎用数値02_レイアウト
	private boolean Number_02_Required;			//汎用数値02_必須
	private boolean Number_03_IsActive;			//汎用数値03_有効
	private String Number_03_Label;				//汎用数値03_表示ラベル
	private int Number_03_Layout;				//汎用数値03_レイアウト
	private boolean Number_03_Required;			//汎用数値03_必須
	private boolean Number_04_IsActive;			//汎用数値04_有効
	private String Number_04_Label;				//汎用数値04_表示ラベル
	private int Number_04_Layout;				//汎用数値04_レイアウト
	private boolean Number_04_Required;			//汎用数値04_必須
	private boolean Number_05_IsActive;			//汎用数値05_有効
	private String Number_05_Label;				//汎用数値05_表示ラベル
	private int Number_05_Layout;				//汎用数値05_レイアウト
	private boolean Number_05_Required;			//汎用数値05_必須
	private boolean Number_06_IsActive;			//汎用数値06_有効
	private String Number_06_Label;				//汎用数値06_表示ラベル
	private int Number_06_Layout;				//汎用数値06_レイアウト
	private boolean Number_06_Required;			//汎用数値06_必須
	private boolean Number_07_IsActive;			//汎用数値07_有効
	private String Number_07_Label;				//汎用数値07_表示ラベル
	private int Number_07_Layout;				//汎用数値07_レイアウト
	private boolean Number_07_Required;			//汎用数値07_必須
	private boolean Number_08_IsActive;			//汎用数値08_有効
	private String Number_08_Label;				//汎用数値08_表示ラベル
	private int Number_08_Layout;				//汎用数値08_レイアウト
	private boolean Number_08_Required;			//汎用数値08_必須
	private boolean Number_09_IsActive;			//汎用数値09_有効
	private String Number_09_Label;				//汎用数値09_表示ラベル
	private int Number_09_Layout;				//汎用数値09_レイアウト
	private boolean Number_09_Required;			//汎用数値09_必須
	private boolean Number_10_IsActive;			//汎用数値10_有効
	private String Number_10_Label;				//汎用数値10_表示ラベル
	private int Number_10_Layout;				//汎用数値10_レイアウト
	private boolean Number_10_Required;			//汎用数値10_必須
	private boolean Area_01_IsActive;			//汎用テキストエリア01_有効
	private String Area_01_Label;				//汎用テキストエリア01_表示ラベル
	private boolean Area_01_Required;			//汎用テキストエリア01_必須
	private boolean Area_02_IsActive;			//汎用テキストエリア02_有効
	private String Area_02_Label;				//汎用テキストエリア02_表示ラベル
	private boolean Area_02_Required;			//汎用テキストエリア02_必須
	private boolean Area_03_IsActive;			//汎用テキストエリア03_有効
	private String Area_03_Label;				//汎用テキストエリア03_表示ラベル
	private boolean Area_03_Required;			//汎用テキストエリア03_必須
	private boolean Area_04_IsActive;			//汎用テキストエリア04_有効
	private String Area_04_Label;				//汎用テキストエリア04_表示ラベル
	private boolean Area_04_Required;			//汎用テキストエリア04_必須
	private boolean Area_05_IsActive;			//汎用テキストエリア05_有効
	private String Area_05_Label;				//汎用テキストエリア05_表示ラベル
	private boolean Area_05_Required;			//汎用テキストエリア05_必須
	private boolean Area_06_IsActive;			//汎用テキストエリア06_有効
	private String Area_06_Label;				//汎用テキストエリア06_表示ラベル
	private boolean Area_06_Required;			//汎用テキストエリア06_必須
	private boolean Area_07_IsActive;			//汎用テキストエリア07_有効
	private String Area_07_Label;				//汎用テキストエリア07_表示ラベル
	private boolean Area_07_Required;			//汎用テキストエリア07_必須
	private boolean Area_08_IsActive;			//汎用テキストエリア08_有効
	private String Area_08_Label;				//汎用テキストエリア08_表示ラベル
	private boolean Area_08_Required;			//汎用テキストエリア08_必須
	private boolean Area_09_IsActive;			//汎用テキストエリア09_有効
	private String Area_09_Label;				//汎用テキストエリア09_表示ラベル
	private boolean Area_09_Required;			//汎用テキストエリア09_必須
	private boolean Area_10_IsActive;			//汎用テキストエリア10_有効
	private String Area_10_Label;				//汎用テキストエリア10_表示ラベル
	private boolean Area_10_Required;			//汎用テキストエリア10_必須


	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getCommodity_Code() {
		return Commodity_Code;
	}
	public void setCommodity_Code(String commodity_Code) {
		Commodity_Code = commodity_Code;
	}
	public String getCommodity_Name() {
		return Commodity_Name;
	}
	public void setCommodity_Name(String commodity_Name) {
		Commodity_Name = commodity_Name;
	}
	public String getCategory() {
		return Category;
	}
	public void setCategory(String category) {
		Category = category;
	}
	public String getOfficeRef() {
		return OfficeRef;
	}
	public void setOfficeRef(String officeRef) {
		OfficeRef = officeRef;
	}
	public Date getEndDate() {
		return EndDate;
	}
	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}
	public Date getStartDate() {
		return StartDate;
	}
	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public boolean isText_01_IsActive() {
		return Text_01_IsActive;
	}
	public void setText_01_IsActive(boolean text_01_IsActive) {
		Text_01_IsActive = text_01_IsActive;
	}
	public String getText_01_Label() {
		return Text_01_Label;
	}
	public void setText_01_Label(String text_01_Label) {
		Text_01_Label = text_01_Label;
	}
	public int getText_01_Layout() {
		return Text_01_Layout;
	}
	public void setText_01_Layout(int text_01_Layout) {
		Text_01_Layout = text_01_Layout;
	}
	public boolean isText_01_Required() {
		return Text_01_Required;
	}
	public void setText_01_Required(boolean text_01_Required) {
		Text_01_Required = text_01_Required;
	}
	public boolean isText_02_IsActive() {
		return Text_02_IsActive;
	}
	public void setText_02_IsActive(boolean text_02_IsActive) {
		Text_02_IsActive = text_02_IsActive;
	}
	public String getText_02_Label() {
		return Text_02_Label;
	}
	public void setText_02_Label(String text_02_Label) {
		Text_02_Label = text_02_Label;
	}
	public int getText_02_Layout() {
		return Text_02_Layout;
	}
	public void setText_02_Layout(int text_02_Layout) {
		Text_02_Layout = text_02_Layout;
	}
	public boolean isText_02_Required() {
		return Text_02_Required;
	}
	public void setText_02_Required(boolean text_02_Required) {
		Text_02_Required = text_02_Required;
	}
	public boolean isText_03_IsActive() {
		return Text_03_IsActive;
	}
	public void setText_03_IsActive(boolean text_03_IsActive) {
		Text_03_IsActive = text_03_IsActive;
	}
	public String getText_03_Label() {
		return Text_03_Label;
	}
	public void setText_03_Label(String text_03_Label) {
		Text_03_Label = text_03_Label;
	}
	public int getText_03_Layout() {
		return Text_03_Layout;
	}
	public void setText_03_Layout(int text_03_Layout) {
		Text_03_Layout = text_03_Layout;
	}
	public boolean isText_03_Required() {
		return Text_03_Required;
	}
	public void setText_03_Required(boolean text_03_Required) {
		Text_03_Required = text_03_Required;
	}
	public boolean isText_04_IsActive() {
		return Text_04_IsActive;
	}
	public void setText_04_IsActive(boolean text_04_IsActive) {
		Text_04_IsActive = text_04_IsActive;
	}
	public String getText_04_Label() {
		return Text_04_Label;
	}
	public void setText_04_Label(String text_04_Label) {
		Text_04_Label = text_04_Label;
	}
	public int getText_04_Layout() {
		return Text_04_Layout;
	}
	public void setText_04_Layout(int text_04_Layout) {
		Text_04_Layout = text_04_Layout;
	}
	public boolean isText_04_Required() {
		return Text_04_Required;
	}
	public void setText_04_Required(boolean text_04_Required) {
		Text_04_Required = text_04_Required;
	}
	public boolean isText_05_IsActive() {
		return Text_05_IsActive;
	}
	public void setText_05_IsActive(boolean text_05_IsActive) {
		Text_05_IsActive = text_05_IsActive;
	}
	public String getText_05_Label() {
		return Text_05_Label;
	}
	public void setText_05_Label(String text_05_Label) {
		Text_05_Label = text_05_Label;
	}
	public int getText_05_Layout() {
		return Text_05_Layout;
	}
	public void setText_05_Layout(int text_05_Layout) {
		Text_05_Layout = text_05_Layout;
	}
	public boolean isText_05_Required() {
		return Text_05_Required;
	}
	public void setText_05_Required(boolean text_05_Required) {
		Text_05_Required = text_05_Required;
	}
	public boolean isText_06_IsActive() {
		return Text_06_IsActive;
	}
	public void setText_06_IsActive(boolean text_06_IsActive) {
		Text_06_IsActive = text_06_IsActive;
	}
	public String getText_06_Label() {
		return Text_06_Label;
	}
	public void setText_06_Label(String text_06_Label) {
		Text_06_Label = text_06_Label;
	}
	public int getText_06_Layout() {
		return Text_06_Layout;
	}
	public void setText_06_Layout(int text_06_Layout) {
		Text_06_Layout = text_06_Layout;
	}
	public boolean isText_06_Required() {
		return Text_06_Required;
	}
	public void setText_06_Required(boolean text_06_Required) {
		Text_06_Required = text_06_Required;
	}
	public boolean isText_07_IsActive() {
		return Text_07_IsActive;
	}
	public void setText_07_IsActive(boolean text_07_IsActive) {
		Text_07_IsActive = text_07_IsActive;
	}
	public String getText_07_Label() {
		return Text_07_Label;
	}
	public void setText_07_Label(String text_07_Label) {
		Text_07_Label = text_07_Label;
	}
	public int getText_07_Layout() {
		return Text_07_Layout;
	}
	public void setText_07_Layout(int text_07_Layout) {
		Text_07_Layout = text_07_Layout;
	}
	public boolean isText_07_Required() {
		return Text_07_Required;
	}
	public void setText_07_Required(boolean text_07_Required) {
		Text_07_Required = text_07_Required;
	}
	public boolean isText_08_IsActive() {
		return Text_08_IsActive;
	}
	public void setText_08_IsActive(boolean text_08_IsActive) {
		Text_08_IsActive = text_08_IsActive;
	}
	public String getText_08_Label() {
		return Text_08_Label;
	}
	public void setText_08_Label(String text_08_Label) {
		Text_08_Label = text_08_Label;
	}
	public int getText_08_Layout() {
		return Text_08_Layout;
	}
	public void setText_08_Layout(int text_08_Layout) {
		Text_08_Layout = text_08_Layout;
	}
	public boolean isText_08_Required() {
		return Text_08_Required;
	}
	public void setText_08_Required(boolean text_08_Required) {
		Text_08_Required = text_08_Required;
	}
	public boolean isText_09_IsActive() {
		return Text_09_IsActive;
	}
	public void setText_09_IsActive(boolean text_09_IsActive) {
		Text_09_IsActive = text_09_IsActive;
	}
	public String getText_09_Label() {
		return Text_09_Label;
	}
	public void setText_09_Label(String text_09_Label) {
		Text_09_Label = text_09_Label;
	}
	public int getText_09_Layout() {
		return Text_09_Layout;
	}
	public void setText_09_Layout(int text_09_Layout) {
		Text_09_Layout = text_09_Layout;
	}
	public boolean isText_09_Required() {
		return Text_09_Required;
	}
	public void setText_09_Required(boolean text_09_Required) {
		Text_09_Required = text_09_Required;
	}
	public boolean isText_10_IsActive() {
		return Text_10_IsActive;
	}
	public void setText_10_IsActive(boolean text_10_IsActive) {
		Text_10_IsActive = text_10_IsActive;
	}
	public String getText_10_Label() {
		return Text_10_Label;
	}
	public void setText_10_Label(String text_10_Label) {
		Text_10_Label = text_10_Label;
	}
	public int getText_10_Layout() {
		return Text_10_Layout;
	}
	public void setText_10_Layout(int text_10_Layout) {
		Text_10_Layout = text_10_Layout;
	}
	public boolean isText_10_Required() {
		return Text_10_Required;
	}
	public void setText_10_Required(boolean text_10_Required) {
		Text_10_Required = text_10_Required;
	}
	public boolean isArea_01_IsActive() {
		return Area_01_IsActive;
	}
	public void setArea_01_IsActive(boolean area_01_IsActive) {
		Area_01_IsActive = area_01_IsActive;
	}
	public boolean isCheck_01_IsActive() {
		return Check_01_IsActive;
	}
	public void setCheck_01_IsActive(boolean check_01_IsActive) {
		Check_01_IsActive = check_01_IsActive;
	}
	public String getCheck_01_Label() {
		return Check_01_Label;
	}
	public void setCheck_01_Label(String check_01_Label) {
		Check_01_Label = check_01_Label;
	}
	public int getCheck_01_Layout() {
		return Check_01_Layout;
	}
	public void setCheck_01_Layout(int check_01_Layout) {
		Check_01_Layout = check_01_Layout;
	}
	public boolean isCheck_02_IsActive() {
		return Check_02_IsActive;
	}
	public void setCheck_02_IsActive(boolean check_02_IsActive) {
		Check_02_IsActive = check_02_IsActive;
	}
	public String getCheck_02_Label() {
		return Check_02_Label;
	}
	public void setCheck_02_Label(String check_02_Label) {
		Check_02_Label = check_02_Label;
	}
	public int getCheck_02_Layout() {
		return Check_02_Layout;
	}
	public void setCheck_02_Layout(int check_02_Layout) {
		Check_02_Layout = check_02_Layout;
	}
	public boolean isCheck_03_IsActive() {
		return Check_03_IsActive;
	}
	public void setCheck_03_IsActive(boolean check_03_IsActive) {
		Check_03_IsActive = check_03_IsActive;
	}
	public String getCheck_03_Label() {
		return Check_03_Label;
	}
	public void setCheck_03_Label(String check_03_Label) {
		Check_03_Label = check_03_Label;
	}
	public int getCheck_03_Layout() {
		return Check_03_Layout;
	}
	public void setCheck_03_Layout(int check_03_Layout) {
		Check_03_Layout = check_03_Layout;
	}
	public boolean isCheck_04_IsActive() {
		return Check_04_IsActive;
	}
	public void setCheck_04_IsActive(boolean check_04_IsActive) {
		Check_04_IsActive = check_04_IsActive;
	}
	public String getCheck_04_Label() {
		return Check_04_Label;
	}
	public void setCheck_04_Label(String check_04_Label) {
		Check_04_Label = check_04_Label;
	}
	public int getCheck_04_Layout() {
		return Check_04_Layout;
	}
	public void setCheck_04_Layout(int check_04_Layout) {
		Check_04_Layout = check_04_Layout;
	}
	public boolean isCheck_05_IsActive() {
		return Check_05_IsActive;
	}
	public void setCheck_05_IsActive(boolean check_05_IsActive) {
		Check_05_IsActive = check_05_IsActive;
	}
	public String getCheck_05_Label() {
		return Check_05_Label;
	}
	public void setCheck_05_Label(String check_05_Label) {
		Check_05_Label = check_05_Label;
	}
	public int getCheck_05_Layout() {
		return Check_05_Layout;
	}
	public void setCheck_05_Layout(int check_05_Layout) {
		Check_05_Layout = check_05_Layout;
	}
	public boolean isCheck_06_IsActive() {
		return Check_06_IsActive;
	}
	public void setCheck_06_IsActive(boolean check_06_IsActive) {
		Check_06_IsActive = check_06_IsActive;
	}
	public String getCheck_06_Label() {
		return Check_06_Label;
	}
	public void setCheck_06_Label(String check_06_Label) {
		Check_06_Label = check_06_Label;
	}
	public int getCheck_06_Layout() {
		return Check_06_Layout;
	}
	public void setCheck_06_Layout(int check_06_Layout) {
		Check_06_Layout = check_06_Layout;
	}
	public boolean isCheck_07_IsActive() {
		return Check_07_IsActive;
	}
	public void setCheck_07_IsActive(boolean check_07_IsActive) {
		Check_07_IsActive = check_07_IsActive;
	}
	public String getCheck_07_Label() {
		return Check_07_Label;
	}
	public void setCheck_07_Label(String check_07_Label) {
		Check_07_Label = check_07_Label;
	}
	public int getCheck_07_Layout() {
		return Check_07_Layout;
	}
	public void setCheck_07_Layout(int check_07_Layout) {
		Check_07_Layout = check_07_Layout;
	}
	public boolean isCheck_08_IsActive() {
		return Check_08_IsActive;
	}
	public void setCheck_08_IsActive(boolean check_08_IsActive) {
		Check_08_IsActive = check_08_IsActive;
	}
	public String getCheck_08_Label() {
		return Check_08_Label;
	}
	public void setCheck_08_Label(String check_08_Label) {
		Check_08_Label = check_08_Label;
	}
	public int getCheck_08_Layout() {
		return Check_08_Layout;
	}
	public void setCheck_08_Layout(int check_08_Layout) {
		Check_08_Layout = check_08_Layout;
	}
	public boolean isCheck_09_IsActive() {
		return Check_09_IsActive;
	}
	public void setCheck_09_IsActive(boolean check_09_IsActive) {
		Check_09_IsActive = check_09_IsActive;
	}
	public String getCheck_09_Label() {
		return Check_09_Label;
	}
	public void setCheck_09_Label(String check_09_Label) {
		Check_09_Label = check_09_Label;
	}
	public int getCheck_09_Layout() {
		return Check_09_Layout;
	}
	public void setCheck_09_Layout(int check_09_Layout) {
		Check_09_Layout = check_09_Layout;
	}
	public boolean isCheck_10_IsActive() {
		return Check_10_IsActive;
	}
	public void setCheck_10_IsActive(boolean check_10_IsActive) {
		Check_10_IsActive = check_10_IsActive;
	}
	public String getCheck_10_Label() {
		return Check_10_Label;
	}
	public void setCheck_10_Label(String check_10_Label) {
		Check_10_Label = check_10_Label;
	}
	public int getCheck_10_Layout() {
		return Check_10_Layout;
	}
	public void setCheck_10_Layout(int check_10_Layout) {
		Check_10_Layout = check_10_Layout;
	}
	public boolean isDate_01_IsActive() {
		return Date_01_IsActive;
	}
	public void setDate_01_IsActive(boolean date_01_IsActive) {
		Date_01_IsActive = date_01_IsActive;
	}
	public String getDate_01_Label() {
		return Date_01_Label;
	}
	public void setDate_01_Label(String date_01_Label) {
		Date_01_Label = date_01_Label;
	}
	public int getDate_01_Layout() {
		return Date_01_Layout;
	}
	public void setDate_01_Layout(int date_01_Layout) {
		Date_01_Layout = date_01_Layout;
	}
	public boolean isDate_01_Required() {
		return Date_01_Required;
	}
	public void setDate_01_Required(boolean date_01_Required) {
		Date_01_Required = date_01_Required;
	}
	public boolean isDate_02_IsActive() {
		return Date_02_IsActive;
	}
	public void setDate_02_IsActive(boolean date_02_IsActive) {
		Date_02_IsActive = date_02_IsActive;
	}
	public String getDate_02_Label() {
		return Date_02_Label;
	}
	public void setDate_02_Label(String date_02_Label) {
		Date_02_Label = date_02_Label;
	}
	public int getDate_02_Layout() {
		return Date_02_Layout;
	}
	public void setDate_02_Layout(int date_02_Layout) {
		Date_02_Layout = date_02_Layout;
	}
	public boolean isDate_02_Required() {
		return Date_02_Required;
	}
	public void setDate_02_Required(boolean date_02_Required) {
		Date_02_Required = date_02_Required;
	}
	public boolean isDate_03_IsActive() {
		return Date_03_IsActive;
	}
	public void setDate_03_IsActive(boolean date_03_IsActive) {
		Date_03_IsActive = date_03_IsActive;
	}
	public String getDate_03_Label() {
		return Date_03_Label;
	}
	public void setDate_03_Label(String date_03_Label) {
		Date_03_Label = date_03_Label;
	}
	public int getDate_03_Layout() {
		return Date_03_Layout;
	}
	public void setDate_03_Layout(int date_03_Layout) {
		Date_03_Layout = date_03_Layout;
	}
	public boolean isDate_03_Required() {
		return Date_03_Required;
	}
	public void setDate_03_Required(boolean date_03_Required) {
		Date_03_Required = date_03_Required;
	}
	public boolean isDate_04_IsActive() {
		return Date_04_IsActive;
	}
	public void setDate_04_IsActive(boolean date_04_IsActive) {
		Date_04_IsActive = date_04_IsActive;
	}
	public String getDate_04_Label() {
		return Date_04_Label;
	}
	public void setDate_04_Label(String date_04_Label) {
		Date_04_Label = date_04_Label;
	}
	public int getDate_04_Layout() {
		return Date_04_Layout;
	}
	public void setDate_04_Layout(int date_04_Layout) {
		Date_04_Layout = date_04_Layout;
	}
	public boolean isDate_04_Required() {
		return Date_04_Required;
	}
	public void setDate_04_Required(boolean date_04_Required) {
		Date_04_Required = date_04_Required;
	}
	public boolean isDate_05_IsActive() {
		return Date_05_IsActive;
	}
	public void setDate_05_IsActive(boolean date_05_IsActive) {
		Date_05_IsActive = date_05_IsActive;
	}
	public String getDate_05_Label() {
		return Date_05_Label;
	}
	public void setDate_05_Label(String date_05_Label) {
		Date_05_Label = date_05_Label;
	}
	public int getDate_05_Layout() {
		return Date_05_Layout;
	}
	public void setDate_05_Layout(int date_05_Layout) {
		Date_05_Layout = date_05_Layout;
	}
	public boolean isDate_05_Required() {
		return Date_05_Required;
	}
	public void setDate_05_Required(boolean date_05_Required) {
		Date_05_Required = date_05_Required;
	}
	public boolean isDate_06_IsActive() {
		return Date_06_IsActive;
	}
	public void setDate_06_IsActive(boolean date_06_IsActive) {
		Date_06_IsActive = date_06_IsActive;
	}
	public String getDate_06_Label() {
		return Date_06_Label;
	}
	public void setDate_06_Label(String date_06_Label) {
		Date_06_Label = date_06_Label;
	}
	public int getDate_06_Layout() {
		return Date_06_Layout;
	}
	public void setDate_06_Layout(int date_06_Layout) {
		Date_06_Layout = date_06_Layout;
	}
	public boolean isDate_06_Required() {
		return Date_06_Required;
	}
	public void setDate_06_Required(boolean date_06_Required) {
		Date_06_Required = date_06_Required;
	}
	public boolean isDate_07_IsActive() {
		return Date_07_IsActive;
	}
	public void setDate_07_IsActive(boolean date_07_IsActive) {
		Date_07_IsActive = date_07_IsActive;
	}
	public String getDate_07_Label() {
		return Date_07_Label;
	}
	public void setDate_07_Label(String date_07_Label) {
		Date_07_Label = date_07_Label;
	}
	public int getDate_07_Layout() {
		return Date_07_Layout;
	}
	public void setDate_07_Layout(int date_07_Layout) {
		Date_07_Layout = date_07_Layout;
	}
	public boolean isDate_07_Required() {
		return Date_07_Required;
	}
	public void setDate_07_Required(boolean date_07_Required) {
		Date_07_Required = date_07_Required;
	}
	public boolean isDate_08_IsActive() {
		return Date_08_IsActive;
	}
	public void setDate_08_IsActive(boolean date_08_IsActive) {
		Date_08_IsActive = date_08_IsActive;
	}
	public String getDate_08_Label() {
		return Date_08_Label;
	}
	public void setDate_08_Label(String date_08_Label) {
		Date_08_Label = date_08_Label;
	}
	public int getDate_08_Layout() {
		return Date_08_Layout;
	}
	public void setDate_08_Layout(int date_08_Layout) {
		Date_08_Layout = date_08_Layout;
	}
	public boolean isDate_08_Required() {
		return Date_08_Required;
	}
	public void setDate_08_Required(boolean date_08_Required) {
		Date_08_Required = date_08_Required;
	}
	public boolean isDate_09_IsActive() {
		return Date_09_IsActive;
	}
	public void setDate_09_IsActive(boolean date_09_IsActive) {
		Date_09_IsActive = date_09_IsActive;
	}
	public String getDate_09_Label() {
		return Date_09_Label;
	}
	public void setDate_09_Label(String date_09_Label) {
		Date_09_Label = date_09_Label;
	}
	public int getDate_09_Layout() {
		return Date_09_Layout;
	}
	public void setDate_09_Layout(int date_09_Layout) {
		Date_09_Layout = date_09_Layout;
	}
	public boolean isDate_09_Required() {
		return Date_09_Required;
	}
	public void setDate_09_Required(boolean date_09_Required) {
		Date_09_Required = date_09_Required;
	}
	public boolean isDate_10_IsActive() {
		return Date_10_IsActive;
	}
	public void setDate_10_IsActive(boolean date_10_IsActive) {
		Date_10_IsActive = date_10_IsActive;
	}
	public String getDate_10_Label() {
		return Date_10_Label;
	}
	public void setDate_10_Label(String date_10_Label) {
		Date_10_Label = date_10_Label;
	}
	public int getDate_10_Layout() {
		return Date_10_Layout;
	}
	public void setDate_10_Layout(int date_10_Layout) {
		Date_10_Layout = date_10_Layout;
	}
	public boolean isDate_10_Required() {
		return Date_10_Required;
	}
	public void setDate_10_Required(boolean date_10_Required) {
		Date_10_Required = date_10_Required;
	}
	public boolean isList_01_IsActive() {
		return List_01_IsActive;
	}
	public void setList_01_IsActive(boolean list_01_IsActive) {
		List_01_IsActive = list_01_IsActive;
	}
	public String getList_01_Label() {
		return List_01_Label;
	}
	public void setList_01_Label(String list_01_Label) {
		List_01_Label = list_01_Label;
	}
	public int getList_01_Layout() {
		return List_01_Layout;
	}
	public void setList_01_Layout(int list_01_Layout) {
		List_01_Layout = list_01_Layout;
	}
	public String getList_01_ListValues() {
		return List_01_ListValues;
	}
	public void setList_01_ListValues(String list_01_ListValues) {
		List_01_ListValues = list_01_ListValues;
	}
	public boolean isList_01_Required() {
		return List_01_Required;
	}
	public void setList_01_Required(boolean list_01_Required) {
		List_01_Required = list_01_Required;
	}
	public boolean isList_02_IsActive() {
		return List_02_IsActive;
	}
	public void setList_02_IsActive(boolean list_02_IsActive) {
		List_02_IsActive = list_02_IsActive;
	}
	public String getList_02_Label() {
		return List_02_Label;
	}
	public void setList_02_Label(String list_02_Label) {
		List_02_Label = list_02_Label;
	}
	public int getList_02_Layout() {
		return List_02_Layout;
	}
	public void setList_02_Layout(int list_02_Layout) {
		List_02_Layout = list_02_Layout;
	}
	public String getList_02_ListValues() {
		return List_02_ListValues;
	}
	public void setList_02_ListValues(String list_02_ListValues) {
		List_02_ListValues = list_02_ListValues;
	}
	public boolean isList_02_Required() {
		return List_02_Required;
	}
	public void setList_02_Required(boolean list_02_Required) {
		List_02_Required = list_02_Required;
	}
	public boolean isList_03_IsActive() {
		return List_03_IsActive;
	}
	public void setList_03_IsActive(boolean list_03_IsActive) {
		List_03_IsActive = list_03_IsActive;
	}
	public String getList_03_Label() {
		return List_03_Label;
	}
	public void setList_03_Label(String list_03_Label) {
		List_03_Label = list_03_Label;
	}
	public int getList_03_Layout() {
		return List_03_Layout;
	}
	public void setList_03_Layout(int list_03_Layout) {
		List_03_Layout = list_03_Layout;
	}
	public String getList_03_ListValues() {
		return List_03_ListValues;
	}
	public void setList_03_ListValues(String list_03_ListValues) {
		List_03_ListValues = list_03_ListValues;
	}
	public boolean isList_03_Required() {
		return List_03_Required;
	}
	public void setList_03_Required(boolean list_03_Required) {
		List_03_Required = list_03_Required;
	}
	public boolean isList_04_IsActive() {
		return List_04_IsActive;
	}
	public void setList_04_IsActive(boolean list_04_IsActive) {
		List_04_IsActive = list_04_IsActive;
	}
	public String getList_04_Label() {
		return List_04_Label;
	}
	public void setList_04_Label(String list_04_Label) {
		List_04_Label = list_04_Label;
	}
	public int getList_04_Layout() {
		return List_04_Layout;
	}
	public void setList_04_Layout(int list_04_Layout) {
		List_04_Layout = list_04_Layout;
	}
	public String getList_04_ListValues() {
		return List_04_ListValues;
	}
	public void setList_04_ListValues(String list_04_ListValues) {
		List_04_ListValues = list_04_ListValues;
	}
	public boolean isList_04_Required() {
		return List_04_Required;
	}
	public void setList_04_Required(boolean list_04_Required) {
		List_04_Required = list_04_Required;
	}
	public boolean isList_05_IsActive() {
		return List_05_IsActive;
	}
	public void setList_05_IsActive(boolean list_05_IsActive) {
		List_05_IsActive = list_05_IsActive;
	}
	public String getList_05_Label() {
		return List_05_Label;
	}
	public void setList_05_Label(String list_05_Label) {
		List_05_Label = list_05_Label;
	}
	public int getList_05_Layout() {
		return List_05_Layout;
	}
	public void setList_05_Layout(int list_05_Layout) {
		List_05_Layout = list_05_Layout;
	}
	public String getList_05_ListValues() {
		return List_05_ListValues;
	}
	public void setList_05_ListValues(String list_05_ListValues) {
		List_05_ListValues = list_05_ListValues;
	}
	public boolean isList_05_Required() {
		return List_05_Required;
	}
	public void setList_05_Required(boolean list_05_Required) {
		List_05_Required = list_05_Required;
	}
	public boolean isList_06_IsActive() {
		return List_06_IsActive;
	}
	public void setList_06_IsActive(boolean list_06_IsActive) {
		List_06_IsActive = list_06_IsActive;
	}
	public String getList_06_Label() {
		return List_06_Label;
	}
	public void setList_06_Label(String list_06_Label) {
		List_06_Label = list_06_Label;
	}
	public int getList_06_Layout() {
		return List_06_Layout;
	}
	public void setList_06_Layout(int list_06_Layout) {
		List_06_Layout = list_06_Layout;
	}
	public String getList_06_ListValues() {
		return List_06_ListValues;
	}
	public void setList_06_ListValues(String list_06_ListValues) {
		List_06_ListValues = list_06_ListValues;
	}
	public boolean isList_06_Required() {
		return List_06_Required;
	}
	public void setList_06_Required(boolean list_06_Required) {
		List_06_Required = list_06_Required;
	}
	public boolean isList_07_IsActive() {
		return List_07_IsActive;
	}
	public void setList_07_IsActive(boolean list_07_IsActive) {
		List_07_IsActive = list_07_IsActive;
	}
	public String getList_07_Label() {
		return List_07_Label;
	}
	public void setList_07_Label(String list_07_Label) {
		List_07_Label = list_07_Label;
	}
	public int getList_07_Layout() {
		return List_07_Layout;
	}
	public void setList_07_Layout(int list_07_Layout) {
		List_07_Layout = list_07_Layout;
	}
	public String getList_07_ListValues() {
		return List_07_ListValues;
	}
	public void setList_07_ListValues(String list_07_ListValues) {
		List_07_ListValues = list_07_ListValues;
	}
	public boolean isList_07_Required() {
		return List_07_Required;
	}
	public void setList_07_Required(boolean list_07_Required) {
		List_07_Required = list_07_Required;
	}
	public boolean isList_08_IsActive() {
		return List_08_IsActive;
	}
	public void setList_08_IsActive(boolean list_08_IsActive) {
		List_08_IsActive = list_08_IsActive;
	}
	public String getList_08_Label() {
		return List_08_Label;
	}
	public void setList_08_Label(String list_08_Label) {
		List_08_Label = list_08_Label;
	}
	public int getList_08_Layout() {
		return List_08_Layout;
	}
	public void setList_08_Layout(int list_08_Layout) {
		List_08_Layout = list_08_Layout;
	}
	public String getList_08_ListValues() {
		return List_08_ListValues;
	}
	public void setList_08_ListValues(String list_08_ListValues) {
		List_08_ListValues = list_08_ListValues;
	}
	public boolean isList_08_Required() {
		return List_08_Required;
	}
	public void setList_08_Required(boolean list_08_Required) {
		List_08_Required = list_08_Required;
	}
	public boolean isList_09_IsActive() {
		return List_09_IsActive;
	}
	public void setList_09_IsActive(boolean list_09_IsActive) {
		List_09_IsActive = list_09_IsActive;
	}
	public String getList_09_Label() {
		return List_09_Label;
	}
	public void setList_09_Label(String list_09_Label) {
		List_09_Label = list_09_Label;
	}
	public int getList_09_Layout() {
		return List_09_Layout;
	}
	public void setList_09_Layout(int list_09_Layout) {
		List_09_Layout = list_09_Layout;
	}
	public String getList_09_ListValues() {
		return List_09_ListValues;
	}
	public void setList_09_ListValues(String list_09_ListValues) {
		List_09_ListValues = list_09_ListValues;
	}
	public boolean isList_09_Required() {
		return List_09_Required;
	}
	public void setList_09_Required(boolean list_09_Required) {
		List_09_Required = list_09_Required;
	}
	public boolean isList_10_IsActive() {
		return List_10_IsActive;
	}
	public void setList_10_IsActive(boolean list_10_IsActive) {
		List_10_IsActive = list_10_IsActive;
	}
	public String getList_10_Label() {
		return List_10_Label;
	}
	public void setList_10_Label(String list_10_Label) {
		List_10_Label = list_10_Label;
	}
	public int getList_10_Layout() {
		return List_10_Layout;
	}
	public void setList_10_Layout(int list_10_Layout) {
		List_10_Layout = list_10_Layout;
	}
	public String getList_10_ListValues() {
		return List_10_ListValues;
	}
	public void setList_10_ListValues(String list_10_ListValues) {
		List_10_ListValues = list_10_ListValues;
	}
	public boolean isList_10_Required() {
		return List_10_Required;
	}
	public void setList_10_Required(boolean list_10_Required) {
		List_10_Required = list_10_Required;
	}
	public boolean isNumber_01_IsActive() {
		return Number_01_IsActive;
	}
	public void setNumber_01_IsActive(boolean number_01_IsActive) {
		Number_01_IsActive = number_01_IsActive;
	}
	public String getNumber_01_Label() {
		return Number_01_Label;
	}
	public void setNumber_01_Label(String number_01_Label) {
		Number_01_Label = number_01_Label;
	}
	public int getNumber_01_Layout() {
		return Number_01_Layout;
	}
	public void setNumber_01_Layout(int number_01_Layout) {
		Number_01_Layout = number_01_Layout;
	}
	public boolean isNumber_01_Required() {
		return Number_01_Required;
	}
	public void setNumber_01_Required(boolean number_01_Required) {
		Number_01_Required = number_01_Required;
	}
	public boolean isNumber_02_IsActive() {
		return Number_02_IsActive;
	}
	public void setNumber_02_IsActive(boolean number_02_IsActive) {
		Number_02_IsActive = number_02_IsActive;
	}
	public String getNumber_02_Label() {
		return Number_02_Label;
	}
	public void setNumber_02_Label(String number_02_Label) {
		Number_02_Label = number_02_Label;
	}
	public int getNumber_02_Layout() {
		return Number_02_Layout;
	}
	public void setNumber_02_Layout(int number_02_Layout) {
		Number_02_Layout = number_02_Layout;
	}
	public boolean isNumber_02_Required() {
		return Number_02_Required;
	}
	public void setNumber_02_Required(boolean number_02_Required) {
		Number_02_Required = number_02_Required;
	}
	public boolean isNumber_03_IsActive() {
		return Number_03_IsActive;
	}
	public void setNumber_03_IsActive(boolean number_03_IsActive) {
		Number_03_IsActive = number_03_IsActive;
	}
	public String getNumber_03_Label() {
		return Number_03_Label;
	}
	public void setNumber_03_Label(String number_03_Label) {
		Number_03_Label = number_03_Label;
	}
	public int getNumber_03_Layout() {
		return Number_03_Layout;
	}
	public void setNumber_03_Layout(int number_03_Layout) {
		Number_03_Layout = number_03_Layout;
	}
	public boolean isNumber_03_Required() {
		return Number_03_Required;
	}
	public void setNumber_03_Required(boolean number_03_Required) {
		Number_03_Required = number_03_Required;
	}
	public boolean isNumber_04_IsActive() {
		return Number_04_IsActive;
	}
	public void setNumber_04_IsActive(boolean number_04_IsActive) {
		Number_04_IsActive = number_04_IsActive;
	}
	public String getNumber_04_Label() {
		return Number_04_Label;
	}
	public void setNumber_04_Label(String number_04_Label) {
		Number_04_Label = number_04_Label;
	}
	public int getNumber_04_Layout() {
		return Number_04_Layout;
	}
	public void setNumber_04_Layout(int number_04_Layout) {
		Number_04_Layout = number_04_Layout;
	}
	public boolean isNumber_04_Required() {
		return Number_04_Required;
	}
	public void setNumber_04_Required(boolean number_04_Required) {
		Number_04_Required = number_04_Required;
	}
	public boolean isNumber_05_IsActive() {
		return Number_05_IsActive;
	}
	public void setNumber_05_IsActive(boolean number_05_IsActive) {
		Number_05_IsActive = number_05_IsActive;
	}
	public String getNumber_05_Label() {
		return Number_05_Label;
	}
	public void setNumber_05_Label(String number_05_Label) {
		Number_05_Label = number_05_Label;
	}
	public int getNumber_05_Layout() {
		return Number_05_Layout;
	}
	public void setNumber_05_Layout(int number_05_Layout) {
		Number_05_Layout = number_05_Layout;
	}
	public boolean isNumber_05_Required() {
		return Number_05_Required;
	}
	public void setNumber_05_Required(boolean number_05_Required) {
		Number_05_Required = number_05_Required;
	}
	public boolean isNumber_06_IsActive() {
		return Number_06_IsActive;
	}
	public void setNumber_06_IsActive(boolean number_06_IsActive) {
		Number_06_IsActive = number_06_IsActive;
	}
	public String getNumber_06_Label() {
		return Number_06_Label;
	}
	public void setNumber_06_Label(String number_06_Label) {
		Number_06_Label = number_06_Label;
	}
	public int getNumber_06_Layout() {
		return Number_06_Layout;
	}
	public void setNumber_06_Layout(int number_06_Layout) {
		Number_06_Layout = number_06_Layout;
	}
	public boolean isNumber_06_Required() {
		return Number_06_Required;
	}
	public void setNumber_06_Required(boolean number_06_Required) {
		Number_06_Required = number_06_Required;
	}
	public boolean isNumber_07_IsActive() {
		return Number_07_IsActive;
	}
	public void setNumber_07_IsActive(boolean number_07_IsActive) {
		Number_07_IsActive = number_07_IsActive;
	}
	public String getNumber_07_Label() {
		return Number_07_Label;
	}
	public void setNumber_07_Label(String number_07_Label) {
		Number_07_Label = number_07_Label;
	}
	public int getNumber_07_Layout() {
		return Number_07_Layout;
	}
	public void setNumber_07_Layout(int number_07_Layout) {
		Number_07_Layout = number_07_Layout;
	}
	public boolean isNumber_07_Required() {
		return Number_07_Required;
	}
	public void setNumber_07_Required(boolean number_07_Required) {
		Number_07_Required = number_07_Required;
	}
	public boolean isNumber_08_IsActive() {
		return Number_08_IsActive;
	}
	public void setNumber_08_IsActive(boolean number_08_IsActive) {
		Number_08_IsActive = number_08_IsActive;
	}
	public String getNumber_08_Label() {
		return Number_08_Label;
	}
	public void setNumber_08_Label(String number_08_Label) {
		Number_08_Label = number_08_Label;
	}
	public int getNumber_08_Layout() {
		return Number_08_Layout;
	}
	public void setNumber_08_Layout(int number_08_Layout) {
		Number_08_Layout = number_08_Layout;
	}
	public boolean isNumber_08_Required() {
		return Number_08_Required;
	}
	public void setNumber_08_Required(boolean number_08_Required) {
		Number_08_Required = number_08_Required;
	}
	public boolean isNumber_09_IsActive() {
		return Number_09_IsActive;
	}
	public void setNumber_09_IsActive(boolean number_09_IsActive) {
		Number_09_IsActive = number_09_IsActive;
	}
	public String getNumber_09_Label() {
		return Number_09_Label;
	}
	public void setNumber_09_Label(String number_09_Label) {
		Number_09_Label = number_09_Label;
	}
	public int getNumber_09_Layout() {
		return Number_09_Layout;
	}
	public void setNumber_09_Layout(int number_09_Layout) {
		Number_09_Layout = number_09_Layout;
	}
	public boolean isNumber_09_Required() {
		return Number_09_Required;
	}
	public void setNumber_09_Required(boolean number_09_Required) {
		Number_09_Required = number_09_Required;
	}
	public boolean isNumber_10_IsActive() {
		return Number_10_IsActive;
	}
	public void setNumber_10_IsActive(boolean number_10_IsActive) {
		Number_10_IsActive = number_10_IsActive;
	}
	public String getNumber_10_Label() {
		return Number_10_Label;
	}
	public void setNumber_10_Label(String number_10_Label) {
		Number_10_Label = number_10_Label;
	}
	public int getNumber_10_Layout() {
		return Number_10_Layout;
	}
	public void setNumber_10_Layout(int number_10_Layout) {
		Number_10_Layout = number_10_Layout;
	}
	public boolean isNumber_10_Required() {
		return Number_10_Required;
	}
	public void setNumber_10_Required(boolean number_10_Required) {
		Number_10_Required = number_10_Required;
	}
	public String getArea_01_Label() {
		return Area_01_Label;
	}
	public void setArea_01_Label(String area_01_Label) {
		Area_01_Label = area_01_Label;
	}
	public boolean isArea_01_Required() {
		return Area_01_Required;
	}
	public void setArea_01_Required(boolean area_01_Required) {
		Area_01_Required = area_01_Required;
	}
	public boolean isArea_02_IsActive() {
		return Area_02_IsActive;
	}
	public void setArea_02_IsActive(boolean area_02_IsActive) {
		Area_02_IsActive = area_02_IsActive;
	}
	public String getArea_02_Label() {
		return Area_02_Label;
	}
	public void setArea_02_Label(String area_02_Label) {
		Area_02_Label = area_02_Label;
	}
	public boolean isArea_02_Required() {
		return Area_02_Required;
	}
	public void setArea_02_Required(boolean area_02_Required) {
		Area_02_Required = area_02_Required;
	}
	public boolean isArea_03_IsActive() {
		return Area_03_IsActive;
	}
	public void setArea_03_IsActive(boolean area_03_IsActive) {
		Area_03_IsActive = area_03_IsActive;
	}
	public String getArea_03_Label() {
		return Area_03_Label;
	}
	public void setArea_03_Label(String area_03_Label) {
		Area_03_Label = area_03_Label;
	}
	public boolean isArea_03_Required() {
		return Area_03_Required;
	}
	public void setArea_03_Required(boolean area_03_Required) {
		Area_03_Required = area_03_Required;
	}
	public boolean isArea_04_IsActive() {
		return Area_04_IsActive;
	}
	public void setArea_04_IsActive(boolean area_04_IsActive) {
		Area_04_IsActive = area_04_IsActive;
	}
	public String getArea_04_Label() {
		return Area_04_Label;
	}
	public void setArea_04_Label(String area_04_Label) {
		Area_04_Label = area_04_Label;
	}
	public boolean isArea_04_Required() {
		return Area_04_Required;
	}
	public void setArea_04_Required(boolean area_04_Required) {
		Area_04_Required = area_04_Required;
	}
	public boolean isArea_05_IsActive() {
		return Area_05_IsActive;
	}
	public void setArea_05_IsActive(boolean area_05_IsActive) {
		Area_05_IsActive = area_05_IsActive;
	}
	public String getArea_05_Label() {
		return Area_05_Label;
	}
	public void setArea_05_Label(String area_05_Label) {
		Area_05_Label = area_05_Label;
	}
	public boolean isArea_05_Required() {
		return Area_05_Required;
	}
	public void setArea_05_Required(boolean area_05_Required) {
		Area_05_Required = area_05_Required;
	}
	public boolean isArea_06_IsActive() {
		return Area_06_IsActive;
	}
	public void setArea_06_IsActive(boolean area_06_IsActive) {
		Area_06_IsActive = area_06_IsActive;
	}
	public String getArea_06_Label() {
		return Area_06_Label;
	}
	public void setArea_06_Label(String area_06_Label) {
		Area_06_Label = area_06_Label;
	}
	public boolean isArea_06_Required() {
		return Area_06_Required;
	}
	public void setArea_06_Required(boolean area_06_Required) {
		Area_06_Required = area_06_Required;
	}
	public boolean isArea_07_IsActive() {
		return Area_07_IsActive;
	}
	public void setArea_07_IsActive(boolean area_07_IsActive) {
		Area_07_IsActive = area_07_IsActive;
	}
	public String getArea_07_Label() {
		return Area_07_Label;
	}
	public void setArea_07_Label(String area_07_Label) {
		Area_07_Label = area_07_Label;
	}
	public boolean isArea_07_Required() {
		return Area_07_Required;
	}
	public void setArea_07_Required(boolean area_07_Required) {
		Area_07_Required = area_07_Required;
	}
	public boolean isArea_08_IsActive() {
		return Area_08_IsActive;
	}
	public void setArea_08_IsActive(boolean area_08_IsActive) {
		Area_08_IsActive = area_08_IsActive;
	}
	public String getArea_08_Label() {
		return Area_08_Label;
	}
	public void setArea_08_Label(String area_08_Label) {
		Area_08_Label = area_08_Label;
	}
	public boolean isArea_08_Required() {
		return Area_08_Required;
	}
	public void setArea_08_Required(boolean area_08_Required) {
		Area_08_Required = area_08_Required;
	}
	public boolean isArea_09_IsActive() {
		return Area_09_IsActive;
	}
	public void setArea_09_IsActive(boolean area_09_IsActive) {
		Area_09_IsActive = area_09_IsActive;
	}
	public String getArea_09_Label() {
		return Area_09_Label;
	}
	public void setArea_09_Label(String area_09_Label) {
		Area_09_Label = area_09_Label;
	}
	public boolean isArea_09_Required() {
		return Area_09_Required;
	}
	public void setArea_09_Required(boolean area_09_Required) {
		Area_09_Required = area_09_Required;
	}
	public boolean isArea_10_IsActive() {
		return Area_10_IsActive;
	}
	public void setArea_10_IsActive(boolean area_10_IsActive) {
		Area_10_IsActive = area_10_IsActive;
	}
	public String getArea_10_Label() {
		return Area_10_Label;
	}
	public void setArea_10_Label(String area_10_Label) {
		Area_10_Label = area_10_Label;
	}
	public boolean isArea_10_Required() {
		return Area_10_Required;
	}
	public void setArea_10_Required(boolean area_10_Required) {
		Area_10_Required = area_10_Required;
	}
	public int getComponentcnt() {
		return componentcnt;
	}
	public void setComponentcnt(int componentcnt) {
		this.componentcnt = componentcnt;
	}

}
