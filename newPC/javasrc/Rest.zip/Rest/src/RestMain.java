import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class RestMain {

	public static void main(String[] args) {

		HttpURLConnection connection = null;
		String SessionId = "";

		try {
			URL url = new URL("https://login.salesforce.com/services/Soap/u/30.0");
			//https://instance_name.salesforce.com/services/data/v35.0/

			connection = (HttpURLConnection) url.openConnection();

			connection.setDoOutput(true);
			connection.setInstanceFollowRedirects(false);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");
			connection.setRequestProperty("SOAPAction", "\"\"");
			connection.connect();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(connection.getOutputStream(), "utf-8"));
			writer.write("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
			writer.write("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:urn=\"urn:partner.soap.sforce.com\">");
			writer.write("<soapenv:Body>");
			writer.write("<urn:login>");
			writer.write("<urn:username>ita@mail.com</urn:username>");
			writer.write("<urn:password>xsw2#EDC</urn:password>");
			writer.write("</urn:login>");
			writer.write("</soapenv:Body>");
			writer.write("</soapenv:Envelope>");
			writer.close();

			if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
				;
				BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
				String line;
				while ((line = reader.readLine()) != null) {
//					System.out.println(line);
					SessionId = line.split("<sessionId>")[1].split("</sessionId>")[0];
				}
			} else {
				System.out.println(connection.getResponseCode());
				return;
			}

//			System.out.println(SessionId);
			getObjects.getObjectsList(SessionId);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			if (connection != null) {
				connection.disconnect();
			}
		}

	}

}
