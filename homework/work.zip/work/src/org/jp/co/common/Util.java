package org.jp.co.common;

import java.util.Iterator;
import java.util.Map;


public class Util {

	/*
	 * 型変換(String → int)
	 *
	 * POIの仕様上、数値はDouble型で取り出すため整数に変換
	 *
	 */
	public static int convertStringIngeger(String value){

		return (int) Double.parseDouble(value);

	}

	/*
	 * 型変換 (String → int)
	 *
	 * convertStringIngegerとの違いは
	 * 引数が""(空文字列の場合)に0を返却する
	 *
	 */
	public static int convertInteger(String value){

		if ( value.equals("") ){

			return 0;

		}else{

			return convertStringIngeger(value);

		}

	}

	/*
	 *
	 * エラー時のstacktraceから必要な情報を文字列に変換する
	 *
	 */
	public static String errorDisplay(Exception e){

		String error = e.getClass() + "\n";

		int cnt = 1;
		for ( StackTraceElement s : e.getStackTrace()){

			error += s.toString() + "\n";
			cnt++;

			//大量になると見辛いので10行目まで
			if ( cnt == 10 ) break;

		}

		return error;

	}

	/*
	 *
	 * Mapの中身を確認する
	 *
	 */
	public static void MapContenCheck(Map<String,String> map){

		Iterator<String> it = map.keySet().iterator();

		while( it.hasNext() ){

			String key = it.next();
			System.out.println(key + " : " + map.get(key) );

		}

	}

}
