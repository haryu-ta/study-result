package org.jp.co.common;

import java.util.LinkedHashMap;

public class ComBean {

	private String FileId = "";
	private String TableName_ja = "";
	private LinkedHashMap<String,String> tabledata;
	private LinkedHashMap<String,String> tabledefinedata;

	public String getFileId() {
		return FileId;
	}
	public void setFileId(String fileId) {
		FileId = fileId;
	}
	public String getTableName_ja() {
		return TableName_ja;
	}
	public void setTableName_ja(String tableName_ja) {
		TableName_ja = tableName_ja;
	}
	public LinkedHashMap<String, String> getTabledefinedata() {
		return tabledefinedata;
	}
	public void setTabledefinedata(LinkedHashMap<String, String> tabledefinedata) {
		this.tabledefinedata = tabledefinedata;
	}
	public LinkedHashMap<String, String> getTabledata() {
		return tabledata;
	}
	public void setTabledata(LinkedHashMap<String, String> tabledata) {
		this.tabledata = tabledata;
	}

}
