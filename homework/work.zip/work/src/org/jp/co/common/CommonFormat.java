package org.jp.co.common;

import java.awt.Color;
import java.awt.Font;

public class CommonFormat {

	//文字のフォント設定

	//共通のフォント
	public static Font font = new Font("MS ゴシック",Font.BOLD,15);

	//カラー

	//非活性時の背景色
	public static Color enablebackcolor = new Color(223,223,223);

	//非活性時の文字色
	public static Color enablemojicolor = new Color(85,85,85);


}
