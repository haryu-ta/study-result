package org.jp.co.common;

public class TableDefine {

	private String column_name;     //テーブル物理名
	private String column_type;    //データ型
	private int data_volume;        //データ精度
	private int primary_flg;        //主キーフラグ
	private boolean notnull_flg;    //NOT NULLフラグ
	private int index1;             //インデックス1
	private int index2;             //インデックス2
	private int index3;             //インデックス3
	private int index4;             //インデックス4
	private int index5;             //インデックス5
	private int index6;             //インデックス6
	private int index7;             //インデックス7
	private String column_name_ja;  //テーブル論理名

	public TableDefine(){

		//初期化
		column_name = "";
		column_type = "";
		data_volume = 0;
		primary_flg = 0;
		notnull_flg = false;
		index1 = 0;
		index2 = 0;
		index3 = 0;
		index4 = 0;
		index5 = 0;
		index6 = 0;
		index7 = 0;
		column_name_ja = "";

	}

	public String getColumn_name_ja() {
		return column_name_ja;
	}
	public void setColumn_name_ja(String table_name_ja) {
		this.column_name_ja = table_name_ja;
	}
	public String getColumn_name() {
		return column_name;
	}
	public void setColumn_name(String column_name) {
		this.column_name = column_name;
	}
	public String getColumn_type() {
		return column_type;
	}
	public void setColumn_type(String column_type) {
		this.column_type = column_type;
	}
	public int getData_volume() {
		return data_volume;
	}
	public void setData_volume(int data_volume) {
		this.data_volume = data_volume;
	}
	public int getPrimary_flg() {
		return primary_flg;
	}
	public void setPrimary_flg(int primary_flg) {
		this.primary_flg = primary_flg;
	}
	public boolean isNotnull_flg() {
		return notnull_flg;
	}
	public void setNotnull_flg(boolean notnull_flg) {
		this.notnull_flg = notnull_flg;
	}
	public int getIndex1() {
		return index1;
	}
	public void setIndex1(int index1) {
		this.index1 = index1;
	}
	public int getIndex2() {
		return index2;
	}
	public void setIndex2(int index2) {
		this.index2 = index2;
	}
	public int getIndex3() {
		return index3;
	}
	public void setIndex3(int index3) {
		this.index3 = index3;
	}
	public int getIndex4() {
		return index4;
	}
	public void setIndex4(int index4) {
		this.index4 = index4;
	}
	public int getIndex5() {
		return index5;
	}
	public void setIndex5(int index5) {
		this.index5 = index5;
	}
	public int getIndex6() {
		return index6;
	}
	public void setIndex6(int index6) {
		this.index6 = index6;
	}
	public int getIndex7() {
		return index7;
	}
	public void setIndex7(int index7) {
		this.index7 = index7;
	}

}
