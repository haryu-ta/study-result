package org.jp.co.common;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class POIUtil {

	//既存ブックの読込
	public static Workbook readFile(String filename) throws Exception{

		FileInputStream in = null;
		Workbook wb = null;

		try{

			//既存のワークブックを開く
			in = new FileInputStream(filename);

			//読込(マクロまでコピー可能)
			wb = WorkbookFactory.create(in);

		} finally {
				in.close();
		}

	    return wb;

	}

	//指定セルの値を取得
	public static String getValue(int rownumber,int columnnumber,Sheet sh ){

		try{

			Cell celldata = sh.getRow(rownumber).getCell(columnnumber);
			return getValue(celldata).toString();

		}catch(NullPointerException npe){

			return "";

		}

	}

	//
	private static Object getValue(Cell celldata){

		try{

			int datatype = celldata.getCellType();

			switch( datatype ){
			//文字列型
			case Cell.CELL_TYPE_STRING :

				return celldata.getStringCellValue();

			//数値型
			case Cell.CELL_TYPE_NUMERIC :

				//日付型
				if ( DateUtil.isCellDateFormatted(celldata)) {
					return celldata.getDateCellValue();

				} else {
					return celldata.getNumericCellValue();
				}

			//ブランク
			case Cell.CELL_TYPE_BLANK :

				return "";

			//数式
			case Cell.CELL_TYPE_FORMULA :

				return getValue(celldata.getSheet().getWorkbook().getCreationHelper().createFormulaEvaluator().evaluateInCell(celldata));

			//真偽型
			case Cell.CELL_TYPE_BOOLEAN :

				return celldata.getBooleanCellValue();

			default :

				return "";

			}

		}catch(Exception e){
			return "";
		}

	}

	/*
	 *
	 * 指定行を真下にコピーする
	 *
	 * sheet    : コピー対象シート
	 * rowno    : コピー対象行
	 * times    : コピー回数
	 *
	 */
	public static Sheet rowCopy(Sheet sheet, int rowno, int times){

		int x = sheet.getNumMergedRegions();
		int lrow = sheet.getLastRowNum();
		Row row = null, row2 = null;
		Cell cell = null, cell2 = null;
		CellStyle cellstyle = null;
		short height = 0;
		CellRangeAddress cra = null;

		//指定行以降は移動
		for ( int i = sheet.getLastRowNum(); rowno < i; i-- ) {

			row = sheet.getRow(i);
			height = row.getHeight();

			row2 = sheet.createRow(i + times);
			row2.setHeight(height);
			for(int j = 0; j < row.getLastCellNum(); j++){
				cell = row.getCell(j);
				if(cell != null){
					cell2 = row2.createCell(j);
					cellstyle = cell.getCellStyle();
					cell2.setCellStyle(cellstyle);
					switch(cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						cell2.setCellValue(cell.getRichStringCellValue());
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if(DateUtil.isCellDateFormatted(cell)) {
							cell2.setCellValue(cell.getDateCellValue());
						}else{
							cell2.setCellValue(cell.getNumericCellValue());
						}
						break;
					case Cell.CELL_TYPE_FORMULA:
						cell2.setCellFormula(cell.getCellFormula());
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						cell2.setCellValue(cell.getBooleanCellValue());
						break;
					}
				}
			}

			for(int a = 0; a < x; a++){
				cra = sheet.getMergedRegion(a);

				if ( cra.getFirstRow() == i && cra.getLastRow() == i ){

					sheet.addMergedRegion(new CellRangeAddress(i + times,i + times,cra.getFirstColumn(),cra.getLastColumn()));

				}

			}

		}

		//コピー対象行の情報
		row = sheet.getRow(rowno);
		height = row.getHeight();

		for(int i = 0; i <= times; i++){

			row2 = sheet.createRow(rowno +  i);
			row2.setHeight(height);
			for(int j = 0; j < row.getLastCellNum(); j++){
				cell = row.getCell(j);
				if(cell != null){
					cell2 = row2.createCell(j);
					cellstyle = cell.getCellStyle();
					cell2.setCellStyle(cellstyle);
					switch(cell.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						cell2.setCellValue(cell.getRichStringCellValue());
						break;
					case Cell.CELL_TYPE_NUMERIC:
						if(DateUtil.isCellDateFormatted(cell)) {
							cell2.setCellValue(cell.getDateCellValue());
						}else{
							cell2.setCellValue(cell.getNumericCellValue());
						}
						break;
					case Cell.CELL_TYPE_FORMULA:
						cell2.setCellFormula(cell.getCellFormula());
						break;
					case Cell.CELL_TYPE_BOOLEAN:
						cell2.setCellValue(cell.getBooleanCellValue());
						break;
					}
				}

			}

			for(int a = 0; a < x; a++){
				cra = sheet.getMergedRegion(a);
				if ( cra.getFirstRow() == rowno && cra.getLastRow() == rowno ){

					sheet.addMergedRegion(new CellRangeAddress(rowno + i + 1,rowno + i + 1,cra.getFirstColumn(),cra.getLastColumn()));

				}
			}

		}
		return sheet;
	}

	/*
	 * XSLSファイルを書き出します
	 *
	 * 第一引数 : 書出内容
	 * 第二引数 : 書出ファイルフルパス
	 * 第三引数 : 書出シート名
	 *
	 */
	public static void wirte(String[][] data, String path,String sheetname) throws IOException {

		Workbook wb = new XSSFWorkbook();
		Sheet sh = wb.createSheet(sheetname);
		Row row;
		Cell cell;

		//レコード数文繰返し
		for ( int xind = 0; xind < data.length; xind++ ){

			row = sh.createRow(xind);

			//項目数分ループ
			for ( int yind = 0; yind < data[xind].length;yind++ ){

				//値を設定
				cell = row.createCell(yind);
				cell.setCellValue(data[xind][yind]);

			}

		}

		//期待値データ作成
		FileOutputStream out = new FileOutputStream(path);
		wb.write(out);
		out.close();

	}
}
