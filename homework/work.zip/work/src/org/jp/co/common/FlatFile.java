package org.jp.co.common;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class FlatFile {

	public static void write(String[][] data, String filepath) throws IOException {

		StringBuilder content = new StringBuilder();

		//レコード数文繰返し
		for ( int xind = 1; xind < data.length; xind++ ){

			//項目数分ループ
			for ( int yind = 0; yind < data[xind].length;yind++ ){

				//値を設定
				content.append(data[xind][yind]);

			}

		}


		//期待値データ作成
		BufferedWriter out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filepath),"Shift_JIS"));
		out.write(content.toString());
		out.close();

	}

}
