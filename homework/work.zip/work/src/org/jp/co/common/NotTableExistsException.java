package org.jp.co.common;

public class NotTableExistsException extends Exception {

	private int code;
	private String table_name;

	public NotTableExistsException(int code,String message,String table_name){
		super(message);
		this.code = code;
		this.table_name = table_name;
	}

	public int getCode(){
		return code;
	}

	public String getTableName(){
		return table_name;
	}

}
