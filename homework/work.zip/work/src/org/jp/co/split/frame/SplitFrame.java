package org.jp.co.split.frame;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.jp.co.common.CommonFormat;
import org.jp.co.common.Util;
import org.jp.co.split.SplitExpectedFile;

public class SplitFrame extends JFrame {

	JTextField filename;
	JTextField filepath;
	JButton btn;

	public SplitFrame(String title) throws HeadlessException {

		super(title);

	}

	public void setComponent() {

		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100,100,400,210);
		getContentPane().setBackground(new Color(204,255,0));

		setFramePart();

		setVisible(true);

	}

	private void setFramePart() {

		//標準フォントの設定
//		Font font = new Font("MS ゴシック",Font.BOLD,15);

		filename = new JTextField();
		filename.setBounds(10, 30, 280, 50);
		filename.setFont(CommonFormat.font);
		filename.setBackground(CommonFormat.enablebackcolor);
		filename.setDisabledTextColor(CommonFormat.enablemojicolor);
		filename.setEnabled(false);

		filepath = new JTextField();

		JButton filechoice = new JButton("選択");
		filechoice.setBounds(300, 30, 75, 50);
		filechoice.setFont(CommonFormat.font);
		filechoice.addActionListener(new SelectFile());

		btn = new JButton("実行");
		btn.setBounds(100, 100, 200, 50);
		btn.setFont(CommonFormat.font);
		btn.addActionListener(new ExecuteMainShori());
		btn.setEnabled(false);

		add(filename);
		add(filechoice);
		add(btn);


	}

	class ExecuteMainShori implements ActionListener {

		public void actionPerformed(ActionEvent e) {

			try{
				SplitExpectedFile.split(filepath.getText(),filename.getText());
			}catch(Exception ex){

				JOptionPane.showMessageDialog(SplitFrame.this, Util.errorDisplay(ex));
				ex.printStackTrace();

			}

		}

	}

	class SelectFile implements ActionListener {

		public void actionPerformed(ActionEvent e) {

			FileDialog file = new FileDialog((java.awt.Frame) null,"ファイル選択");
//			file.setDirectory("C:\\Users\\enoch\\Desktop\\IF");
			file.setVisible(true);

			if (file.getFile() != null) {

				filename.setText(file.getFile());
				filepath.setText(file.getDirectory() + file.getFile());
				btn.setEnabled(true);

			}

		}

	}

}
