package org.jp.co.split;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.jp.co.common.POIUtil;
import org.jp.co.split.frame.SplitFrame;

/*
 *
 * 横持ちのExpectedファイルの分割を行う
 *
 */

public class SplitExpectedFile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		SplitFrame frame = new SplitFrame("分割ファイル");
		frame.setComponent();

	}

	public static void split(String filepath, String filename) throws Exception {


		Workbook wb = POIUtil.readFile(filepath);

		//ブックコピー
		FileOutputStream copybook = new FileOutputStream(filepath.replaceAll(filename, "") + "【backup】" + filename);
		wb.write(copybook);
		copybook.close();

		Sheet sh = wb.getSheetAt(0);
		int cnt = 0;

		LinkedHashSet<String> set = new LinkedHashSet<String>();       //全カラム(重複含まない)
		ArrayList<String> list = new ArrayList<String>();              //全カラム(重複含む)
		LinkedHashSet<String> multi = new LinkedHashSet<String>();     //重複するカラムのみ

		while ( !POIUtil.getValue(0, cnt, sh).equals("") ){

			//全カラム追加
			list.add(POIUtil.getValue(0, cnt, sh));

			//重複なし分追加
			if ( !set.add(POIUtil.getValue(0, cnt, sh)) ){

				multi.add(POIUtil.getValue(0, cnt, sh));

			}
			cnt++;

		}

		//繰返数
		int repeattime = (list.size() - set.size() + multi.size()) / multi.size();
		System.out.println(repeattime);

		String[][] data  = new String[sh.getLastRowNum() * repeattime + 1][set.size()]; //データ
		int ccnt;

		//ヘッダーのみ
		int colind = 0;
		for (String colmun : set ){

			data[0][colind++] = colmun;

		}

//		//列数文繰り返し
		for(int rcnt = 1;rcnt <= sh.getLastRowNum();rcnt++ ){

			ccnt = 0;

			for( String colname : set ){

				//共通項目
				if( !multi.contains(colname) ){

					//共通項目は一気にセット
					for ( int times = 1;times <= repeattime;times++ ){

						data[(rcnt - 1) * repeattime + times ][ccnt] = POIUtil.getValue(rcnt, ccnt, sh);

					}

				}else{

					for ( int times = 1;times <= repeattime;times++ ){

						data[(rcnt - 1) * repeattime + times ][ccnt] = POIUtil.getValue(rcnt, ccnt + multi.size() * (times - 1), sh).replaceAll(".0","");

					}

				}

				ccnt++;

			}

		}

		String sheetname = wb.getSheetName(0);
		POIUtil.wirte(data,filepath , sheetname);

	}

}
