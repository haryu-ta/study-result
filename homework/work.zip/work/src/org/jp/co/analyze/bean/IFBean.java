package org.jp.co.analyze.bean;

import org.jp.co.common.TableDefine;

public class IFBean extends TableDefine {

	private int startpos;
	private int bytesize;
	private String fileheadername;
	private String editmode;

	public IFBean(){
		startpos = 0;
		bytesize = 0;
	}

	public int getStartpos() {
		return startpos;
	}

	public void setStartpos(int startpos) {
		this.startpos = startpos;
	}

	public int getBytesize() {
		return bytesize;
	}

	public void setBytesize(int bytesize) {
		this.bytesize = bytesize;
	}

	public String getFileheadername() {
		return fileheadername;
	}

	public void setFileheadername(String fileheadername) {
		this.fileheadername = fileheadername;
	}

	public String getEditmode() {
		return editmode;
	}

	public void setEditmode(String editmode) {
		this.editmode = editmode;
	}


}
