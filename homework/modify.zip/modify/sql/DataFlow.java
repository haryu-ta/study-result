package org.jp.co.sql;

import org.jp.co.common.TableDefine;

public class DataFlow extends TableDefine {

	private String edit_method;

	public DataFlow(){

		super();
		edit_method = "";

	}

	public String getEdit_method() {
		return edit_method;
	}

	public void setEdit_method(String edit_method) {
		this.edit_method = edit_method;
	}



}
