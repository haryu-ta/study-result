package org.jp.co.sql;

import static org.jp.co.common.POIUtil.*;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.jp.co.common.NotTableExistsException;
import org.jp.co.common.Util;

public class CreateSQLFileMain extends JFrame implements ActionListener {

	//configファイルのパス
	private static String confpath = "conf/setting.cfg";

	private static String inbookpath = "";
	private static String infilename = "";
	private static String outfiledir = "";
	private static String defbookpath = "";
	private static String defbookname = "";
	private static String savedir = "";

	//処理判断文言
	private static String MERGEJUDGE;
	private static String CONDITIONJUDGE;
	private static String UPINJUDGE;

	//置換文字
	private static String REPCONDITION = "@condition@";
	private static String REPPRIMARY = "@parimary@";
	private static String REPINSERT = "@insert@";
	private static String REPINSERTCOL = "@insert2@";
	private static String REPUPDATE = "@update@";
	private static String REPUPDATE2 = "@update2@";

	//グローバルに使用するGUI部品
	JComboBox cmb;
	JFileChooser file;
	JTextField path ;

	/*
	 * メイン処理
	 *
	 * ★主な処理
	 * ①cfgファイルロード
	 * ②フレームの作成
	 *
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException{

		// ■□■□■□設定ファイル読込■□■□■□
		LoadConfig();

		//■□■□■□FRAME作成■□■□■□
		new CreateSQLFileMain();

	}

	/*
	 * コンストラクタ
	 *
	 * ★主な処理
	 * ① フレームの作成
	 */
	public CreateSQLFileMain() {

		super("SQLファイル作成");
		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100,100,400,250);
		getContentPane().setBackground(new Color(239,117,152));

		setComponent();

		setVisible(true);

	}

	/*
	 * フレーム中の部品配置
	 *
	 * ★主な処理
	 * ① コンボボックス表示用の文字列取得
	 * ② 各種GUIの配置
	 *
	 */
	private void setComponent() {

		//ComboBoxの作成
		cmb = new JComboBox(getCmblist());
		cmb.setBounds(3, 10, 380 , 50);
		cmb.setFont(new Font("MS ゴシック",Font.BOLD,10));
		cmb.setSelectedIndex(0);

		//Buttonの作成
		JButton btn = new JButton();
		btn.setText("SQL作成");
		btn.setBounds(125, 140, 150, 50);
		btn.addActionListener(this);

		//Labelの作成
		JLabel label = new JLabel("出力先 : ");
		label.setBounds(3, 74, 50, 50);

		//TextFieldの作成
		path = new JTextField(outfiledir);
		path.setBounds(65, 83, 240, 35);
		path.setEditable(false);

		//Buttonの作成
		JButton btn2 = new JButton();
		btn2.setBounds(310, 83, 70, 35);
		btn2.setText("選択");
		btn2.addActionListener(this);

		//Frame上に配置
		add(cmb);
		add(btn);
		add(label);
		add(path);
		add(btn2);

	}

	/*
	 * コンボボックス初期表示設定
	 *
	 * ★主な処理
	 * ① コンボボックスの初期表示用文字列取得
	 *
	 */
	private String[] getCmblist() {

		List<String> filelists = new ArrayList<String>();

		//指定ディレクトリ配下を検索
		File f1 = new File(inbookpath);
		for( File file : f1.listFiles() ){

			//ファイルのみコレクションに追加
			if ( file.isFile() && file.getName().startsWith("外部インターフェース") ){

				try {

					//データフロー②が存在しないブックはSQL作成対象外
					if ( readFile(inbookpath + File.separator + file.getName()).getSheet("データフロー②") != null) {

						filelists.add(file.getName());

					}

				} catch (Exception e) {

					e.printStackTrace();

				}

			}

		}

		//コレクションを文字列配列に変換して返却
		return (String[])filelists.toArray(new String[0]);
	}

	/*
	 * Form上のボタン押下時に動作する挙動を記載
	 *
	 * ★主な処理
	 * ①出力先選択ボタン押下時の処理
	 * ②制御ファイル作成ボタン押下時の処理
	 *
	 */
	public void actionPerformed( ActionEvent ae ){

		// ■□■□■□出力先選択ボタン押下時に実行■□■□■□
		if ( ae.getActionCommand().equals("選択") ){

			//ディレクトリ選択ダイアログを表示
			file = new JFileChooser(outfiledir);
			file.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

			int selected = file.showSaveDialog(this);
			if (selected == JFileChooser.APPROVE_OPTION){

				//選択されたディレクトリを出力先ラベルに設定
				path.setText(file.getSelectedFile().getAbsolutePath());

			}

			return;

		}

		// ■□■□■□SQL作成ボタン押下時に実行■□■□■□

		//横縦分解フラグ
		Boolean splitflg = false;
		//変数初期化
		Workbook wb = null;
		Workbook tabledefine = null;
		Sheet sh = null;
		Sheet tsh = null;
		Exception NotTableExistsException = null;

		SQLBean bean = new SQLBean();

		// ■□■□■□FORMから設定値取得■□■□■□
		//選択ファイル名取得
		infilename = (String) cmb.getSelectedItem();

		//ファイル保存先取得
		savedir = path.getText();

		try {

			// ■□■□■□IFファイル定義書の内容を取得■□■□■□
			//コンボボックスで指定されたファイル情報を取得
			wb = readFile(inbookpath + File.separator + infilename);

			// ★☆★☆『外部インターフェース仕様』シート★☆★☆
			getInterfaceSheet(bean,wb.getSheet("外部インターフェース仕様"));

			// ★☆★☆『データフロー②』シート★☆★☆
			getDataFlow(bean,wb.getSheet("データフロー②"));

			// ■□■□■□テーブル定義書の内容を取得■□■□■□
			tabledefine = readFile(defbookpath + File.separator + defbookname);

			// テーブル名でシートを検索
			tsh = searchSheet(tabledefine,bean.getTableName_ja());

			// テーブル名がテーブル定義に存在しない
			if ( tsh == null ){
				throw new NotTableExistsException(1,"テーブル定義書から該当のテーブル名のシートは見つかりません",bean.getTableName_ja());
			}

//			TableDefine column;

			// テーブル定義の内容をコレクションに追加
			LinkedHashMap<String,String> tdefine = new LinkedHashMap<String,String>();
			for ( int rcnt = 10; rcnt <= tsh.getLastRowNum() ; rcnt++ ){

				if ( !getValue(rcnt, 1, tsh).equals("") ){

					tdefine.put(getValue(rcnt, 1, tsh),getValue(rcnt, 6, tsh));

				}

			}
			bean.setTabledefinedata(tdefine);

			// ■□■□■□制御ファイルの内容を組立■□■□■□
			String sql = createsqlfile(bean);

			// ■□■□■□ファイル出力■□■□■□
			//書出準備
			OutputStreamWriter fout = new OutputStreamWriter(new FileOutputStream(savedir + File.separator + bean.getFileId() + ".sql"),"UTF-8");

			//ファイルへの出力
			fout.write(sql);

			//出力後処理
			fout.close();

			//終了メッセージ出力
			JOptionPane.showMessageDialog(this, "ファイルの出力に成功しました。\n" + savedir + File.separator + bean.getFileId() + ".sql");

		} catch ( NotTableExistsException ex){

			String Message = "エラーコード ： " + ex.getCode() + "\n";
			Message += "\n";
			Message += ex.getMessage() + "\nテーブル名 : " + ex.getTableName();
			JOptionPane.showMessageDialog(this, Message,"エラー",JOptionPane.ERROR_MESSAGE);
			return;

		} catch (Exception e) {

			JOptionPane.showMessageDialog(this, Util.errorDisplay(e),"エラー",JOptionPane.ERROR_MESSAGE);

		}finally{

			//不要なオブジェクト破棄

		}


	}

	/*
	 * 設定ファイルの読込
	 *
	 */
	private static void LoadConfig() throws FileNotFoundException, IOException{

		// ■□■□■□プロパティファイルの読込■□■□■□
		Properties prop = new Properties();

		prop.load(new InputStreamReader(new FileInputStream(confpath),"UTF-8"));

		// ■□■□■□変数への値設定■□■□■□
		//読込ファイル
		inbookpath = prop.getProperty("INFILE");
		defbookpath = prop.getProperty("TABLEDEFINEPATH");
		defbookname = prop.getProperty("TABLEDEFINENAME");
		outfiledir = prop.getProperty("OUTFILEDIR");

		MERGEJUDGE = prop.getProperty("MERGE_JUDGE");
		CONDITIONJUDGE = prop.getProperty("CONDITION_JUDGE");
		UPINJUDGE=prop.getProperty("UPINJUDGE");

	}

	/*
	 * 指定シート名のシートを検索する
	 *
	 */
	private static Sheet searchSheet(Workbook tabledefine,String tablename){

		for (int scnt = 0 ; scnt < tabledefine.getNumberOfSheets(); scnt++){

			if ( tabledefine.getSheetAt(scnt).getSheetName().equals(tablename) ){

				return tabledefine.getSheetAt(scnt);

			}
		}

		return null;

	}

	/*
	 * 外部インタフェースシートより情報取得
	 *
	 * ★主な処理
	 * 設定値の取得
	 *
	 */
	private static void getInterfaceSheet(SQLBean bean, Sheet sh){

		// ファイルID ( M2AHN049 )
		if ( getValue(7, 20, sh).equals("") ){
			bean.setFileId(getValue(25, 4, sh));
		}else{
			bean.setFileId(getValue(7, 20, sh));
		}
		// テーブル物理名
		bean.setTable_name(changeWorkTable(getValue(25, 4, sh),0));
		// ワークテーブル物理名(setする際に編集)
		bean.setWk_table_name(changeWorkTable(getValue(25, 4, sh),1));

	}


	/*
	 *
	 * テーブル名からワークテーブル名へ変換
	 *
	 * ★引数の説明
	 * tbl_kbn
	 * 0 : 正テーブル名を戻す
	 * 1 : ワークテーブル名を戻す
	 */
	private static String changeWorkTable(String tbl, int tbl_kbn) {

		//正テーブル
		if ( tbl_kbn == 0 ){

			//MVIEWの場合
			if ( tbl.startsWith("MV_") ){

				return tbl.replaceFirst("MV_", "");

			} else {

				return tbl;

			}

		//ワークテーブル
		}else{

			if ( tbl.startsWith("MV_") ) {

				return tbl;

			} else {

				return "WK_" + tbl;

			}

		}

	}

	/*
	 * データフロー②シートより情報取得
	 *
	 * ★主な処理
	 * 設定値の取得
	 *
	 */
	private static void getDataFlow(SQLBean bean, Sheet sh){

		//ワークテーブル論理名 ( リボ残高情報（確定Ⅱ）ワーク )
		bean.setWktable_name_ja(getValue(17, 4, sh));

		//テーブル論理名 ( リボ残高情報（確定Ⅱ） )
		bean.setTableName_ja(getValue(17, 27, sh));

		//データフローの内容をコレクションに追加
		LinkedHashMap<String,DataFlow> tabledata = new LinkedHashMap<String,DataFlow>();
		DataFlow df;
		String editmode="";
		for ( int rcnt = 20 ; rcnt <= sh.getLastRowNum() ; rcnt++ ){

			//カラム名が空の場合には追加しない
			if (! getValue(rcnt, 27, sh).equals("") ){

				df = new DataFlow();
				editmode = getValue(rcnt, 12, sh) + (getValue(rcnt, 37, sh).equals("") ? "" :  "," + getValue(rcnt, 37, sh));
				// キー → カラム論理名  値 → ファイルヘッダー名@編集仕様
				changeEditMethod(editmode,df);

				tabledata.put(getValue(rcnt, 27, sh), df);

			}

		}
		bean.setMap(tabledata);

		// 更新条件有無
		if ( getValue(8, 2, sh).contains(CONDITIONJUDGE) || getValue(9, 2, sh).contains(CONDITIONJUDGE) || getValue(10, 2, sh).contains(CONDITIONJUDGE) ){

			//条件有SQL
			bean.setConditionflg(true);

		}

		// 挿入・挿入更新区分
		if ( getValue(8, 2, sh).contains(MERGEJUDGE) || getValue(9, 2, sh).contains(MERGEJUDGE) || getValue(10, 2, sh).contains(MERGEJUDGE) ){

			if ( getValue(11,2,sh).contains(UPINJUDGE) || getValue(12,2,sh).contains(UPINJUDGE) || getValue(13,2,sh).contains(UPINJUDGE) ){

				//UPDATEINSERT
				bean.setShori_kbn("UPDATE/INSERT");

			}else{

				//MERGESQL
				bean.setShori_kbn("MERGE");

			}

		}


	}

	/*
	 *
	 * 編集仕様欄の内容でキーなのか、編集仕様なのかを判断
	 *
	 *
	 */
	private static void changeEditMethod(String value, DataFlow df) {

		if( value.equals("")){

			return;

		}else if ( value.startsWith("更新判断用キー") ){

			//主キーを設定
			df.setPrimary_flg(1);

		}

		if ( value.split(",").length == 2){

			//編集モードとして設定
			df.setEdit_method(value);

		}

	}

	private static String createsqlfile(SQLBean bean){

		StringBuilder sql = new StringBuilder();

		sql.append(createheader(bean));

		if ( bean.getShori_kbn().equals("MERGE") ){

			sql.append(createMergeSQL(bean));

		}else if( bean.getShori_kbn().equals("UPDATE/INSERT") ){

			sql.append(createUpdateSQL(bean));

		}else{

			sql.append(createInsertSQL(bean));

		}

		sql.append("\n");
		sql.append("commit;" + "\n");
		sql.append("EXIT 0;" + "\n");
		return sql.toString();

	}

	private static String createUpdateSQL(SQLBean bean) {

		StringBuilder upinssql = new StringBuilder();

		upinssql.append("--UPDATE" + "\n");
		upinssql.append("UPDATE " + bean.getTable_name() + " t1 SET" + "\n");
		upinssql.append("\t" + "(" + "\n");
		upinssql.append(REPUPDATE);
		upinssql.append("\t" + ")" + "\n");
		upinssql.append("= (SELECT" + "\n");
		upinssql.append(REPUPDATE2);
		upinssql.append("FROM " + bean.getWk_table_name() + " t2" + "\n");
		upinssql.append("\t" + "WHERE" + "\n");
		upinssql.append(REPPRIMARY);
		upinssql.append("\t" + ")" + "\n");
		upinssql.append("WHERE EXISTS ("+ "\n");
		upinssql.append("\t" + "SELECT 'X'" + "\n");
		upinssql.append("\t" + "FROM " + bean.getWk_table_name() + " t3" + "\n");
		upinssql.append(REPPRIMARY);
		upinssql.append(")" + "\n");
		upinssql.append(";" + "\n");
		upinssql.append("\n");
		upinssql.append("--INSERT" + "\n");
		upinssql.append("INSERT INTO " + bean.getTable_name() + "VALUES" + "\n");
		upinssql.append("SELECT" + "\n");
		upinssql.append(REPINSERT);
		upinssql.append("FROM " + bean.getWk_table_name() + "\n");
		upinssql.append("WHERE" + "\n");
		upinssql.append("\t" + "SEIQ_JSK_SEIQ_YM = (SELECT MAX(SEIQ_JSK_SEIQ_YM) FROM " + bean.getWk_table_name() + ")" + "\n");
		upinssql.append(";" + "\n");


		//データフロー②のカラム列分ループ処理
		Iterator<String> it = bean.getMap().keySet().iterator();
		String col;
		boolean primaryflg = false;
		String primarysql = "";
		String columnsql = "";

		while( it.hasNext() ){
			col = it.next();

			if ( bean.getMap().get(col).getPrimary_flg() != 0 ){

				if ( primaryflg ){

					primarysql += "\n";
					primarysql += "\t\t" + "AND ";

				}

				primarysql += "t1." + bean.getTabledefinedata().get(col) + " = " + "t2."  + bean.getTabledefinedata().get(col);
				primaryflg = true;

			}

			if ( bean.getMap().get(col).getEdit_method().contains("金額DECODE") ){
				columnsql += "\t\t" + " DECODE(" + bean.getTabledefinedata().get(col) + "_FUGO," +
						"'-',-1 * " + bean.getTabledefinedata().get(col) + "," + bean.getTabledefinedata().get(col)+ ")";
			}else{
				columnsql += "\t\t" + bean.getTabledefinedata().get(col);
			}

			if ( it.hasNext() ){

				columnsql += ",";

			}

			columnsql += "\n";

		}

//		String sql = insertsql.toString().replaceFirst(REPINSERTCOL,columnsql);
//		sql = sql.replaceFirst(REPPRIMARY,primarysql);
		return "";


	}

	/*
	 * ファイルヘッダーの組立
	 */
	private static String createheader(SQLBean bean){

		StringBuilder header = new StringBuilder();
		Calendar cal = Calendar.getInstance(Locale.JAPAN);
		int month = cal.get(Calendar.MONTH) + 1;

		header.append("--##################################################################" + "\n");
		header.append("--##" + "\n");
		header.append("--## テーブル名  : "+ bean.getTableName_ja() + "\n");
		header.append("--## SQL処理名   : "+ bean.getShori_kbn() + "\n");
		header.append("--## 作成日      : " +  cal.get(Calendar.YEAR) + "/" + Integer.toString(month) + "/" + cal.get(Calendar.DATE) + "\n");
		header.append("--## 作成者      : TIS\n");
		header.append("--##" + "\n");
		header.append("--##################################################################" + "\n");
		header.append("\n");
		header.append("WHENEVER SQLERROR EXIT 1 ROLLBACK");
		header.append("\n");
		header.append("\n");

		return header.toString();

	}

	private static String createInsertSQL(SQLBean bean){

		StringBuilder insertsql = new StringBuilder();

		insertsql.append("--INSERT" + "\n");
		insertsql.append("INSERT INTO " + bean.getTable_name() + "\n");
		insertsql.append("SELECT" + "\n");
		insertsql.append(REPINSERTCOL);
		insertsql.append("FROM " + bean.getWk_table_name() + " t1" + "\n");
		insertsql.append("WHERE NOT EXISTS" + "\n");
		insertsql.append("(" + "\n");
		insertsql.append("\t" + "SELECT 'X'" + "\n");
		insertsql.append("\t" + "FROM " + bean.getTable_name() + " t2" + "\n");
		insertsql.append("\t" + "WHERE " + "\n");
		insertsql.append("\t\t" + REPPRIMARY  + "\n");
		insertsql.append(")");

		//条件有の場合
		if ( bean.isConditionflg() ){

			insertsql.append("AND t1.UPDATE_DATE > (SELECT NVL(MAX(UPDATE_DATE),to_timestamp('20140101','YYYYMMDD')) FROM " + bean.getTable_name() + ")" + "\n");

		}

		insertsql.append(";" + "\n");

		//データフロー②のカラム列分ループ処理
		Iterator<String> it = bean.getMap().keySet().iterator();
		String col;
		boolean primaryflg = false;
		String primarysql = "";
		String columnsql = "";

		while( it.hasNext() ){
			col = it.next();

			if ( bean.getMap().get(col).getPrimary_flg() != 0 ){

				if ( primaryflg ){

					primarysql += "\n";
					primarysql += "\t\t" + "AND ";

				}

				primarysql += "t1." + bean.getTabledefinedata().get(col) + " = " + "t2."  + bean.getTabledefinedata().get(col);
				primaryflg = true;

			}

			if ( bean.getMap().get(col).getEdit_method().contains("金額DECODE") ){
				columnsql += "\t\t" + "DECODE(" + bean.getTabledefinedata().get(col) + "_FUGO,"  +
						"'-',-1 * " + bean.getTabledefinedata().get(col) + "," +  bean.getTabledefinedata().get(col) + ")";
			}else{
				columnsql += "\t\t" + bean.getTabledefinedata().get(col);
			}

			if ( it.hasNext() ){

				columnsql += ",";

			}

			columnsql += "\n";

		}

		String sql = insertsql.toString().replaceFirst(REPINSERTCOL,columnsql);
		sql = sql.replaceFirst(REPPRIMARY,primarysql);
		return sql;

	}

	private static String createMergeSQL(SQLBean bean){

		StringBuilder mergesql = new StringBuilder();

		mergesql.append("--MERGE" + "\n");
		mergesql.append("MERGE INTO " + bean.getTable_name() + " t1\n");
		mergesql.append("\t" + "USING ");

		//条件なしの場合
		if ( !bean.isConditionflg() ){

			mergesql.append(bean.getWk_table_name() + " t2");

		} else {

			mergesql.append("( SELECT * FROM " + bean.getWk_table_name() + " WHERE UPDATE_DATE > ( SELECT NVL(MAX(UPDATE_DATE),to_timestamp('20140101','YYYYMMDD')) FROM " + bean.getTable_name() + ") ) t2");

		}

		mergesql.append("\n");
		mergesql.append("\t" + "ON (" + "\n");
		mergesql.append("\t\t" + REPPRIMARY + "\n");
		mergesql.append("\t)" + "\n");
		mergesql.append("WHEN MATCHED THEN" + "\n");
		mergesql.append("\t" + "UPDATE SET" + "\n");
		mergesql.append(REPUPDATE + "\n");
		mergesql.append("WHEN NOT MATCHED THEN" + "\n");
		mergesql.append("\tINSERT(" + "\n");
		mergesql.append(REPINSERTCOL + "\n");
		mergesql.append("\t)\n");
		mergesql.append("\tVALUES\n");
		mergesql.append("\t(\n");
		mergesql.append(REPINSERT + "\n");
		mergesql.append("\t);\n");
		mergesql.append("\n");

		String primary = "";
		String updatesql = "";
		String insertcolumnsql = "";
		String insertsql = "";

		//データフロー②のカラム列分ループ処理
		Iterator<String> it = bean.getMap().keySet().iterator();
		String col;
		boolean primaryflg = false;
		boolean updateflg = false;
		boolean fistcolflg = false;

		while( it.hasNext() ){

			col = it.next();

			//主キー?
			if ( bean.getMap().get(col).getPrimary_flg() != 0 ){

				//2項目目以降の主キー
				if ( primaryflg ) {

					primary += "\n";
					primary += "\t\t" + "AND ";

				}

				primary += "t1." + bean.getTabledefinedata().get(col) + " = t2." + bean.getTabledefinedata().get(col);
				primaryflg = true;

			}else{

				if ( updateflg ){

					updatesql += "\n";

				}

				if ( bean.getMap().get(col).getEdit_method().contains("金額DECODE") ){
					updatesql += "\t\t" + "t1." + bean.getTabledefinedata().get(col) + " = " +
							"DECODE(t2." + bean.getTabledefinedata().get(col) + "_FUGO,"  +
							"'-',-1 * t2." + bean.getTabledefinedata().get(col) + ",t2." +  bean.getTabledefinedata().get(col)  + ")" + ",";
				}else{
					updatesql += "\t\t" + "t1." + bean.getTabledefinedata().get(col) + " = t2." + bean.getTabledefinedata().get(col) + ",";
				}
				updateflg = true;

			}

			if ( fistcolflg ) {

				insertcolumnsql += "\n";
				insertsql += "\n";

			}

			insertcolumnsql += "\t\t" + bean.getTabledefinedata().get(col) + ",";
			if ( bean.getMap().get(col).getEdit_method().contains("金額DECODE") ){
				insertsql += "\t\t" + "DECODE(t2." + bean.getTabledefinedata().get(col) + "_FUGO," +
						"'-',-1 * t2." + bean.getTabledefinedata().get(col) + ",t2." + bean.getTabledefinedata().get(col) + ")" + ",";
			}else{
				insertsql += "\t\tt2." + bean.getTabledefinedata().get(col) + ",";
			}
			fistcolflg = true;



		}

		String sql = mergesql.toString().replaceFirst(REPPRIMARY, primary);
		sql = sql.replaceFirst(REPUPDATE, updatesql.substring(0, updatesql.length() - 1));
		sql = sql.replaceFirst(REPINSERTCOL, insertcolumnsql.substring(0, insertcolumnsql.length() - 1));
		sql = sql.replaceFirst(REPINSERT, insertsql.substring(0, insertsql.length() - 1));

		return sql.toString();

	}

}
