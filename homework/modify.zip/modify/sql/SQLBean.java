package org.jp.co.sql;

import java.util.LinkedHashMap;

import org.jp.co.common.ComBean;

public class SQLBean extends ComBean{

	//ワークテーブル論理名
	private String wktable_name_ja = "";
	//カラム論理名と編集仕様と主キーフラグ
	private LinkedHashMap<String,DataFlow> map;
	//テーブル物理名
	private String table_name = "";
	//ワークテーブル物理名
	private String wk_table_name = "";
	//更新条件区分
	private boolean conditionflg = false;
	//挿入・更新区分
	private String shori_kbn = "INSERT";

	public String getWktable_name_ja() {
		return wktable_name_ja;
	}

	public void setWktable_name_ja(String wktable_name_ja) {
		this.wktable_name_ja = wktable_name_ja;
	}

	public LinkedHashMap<String,DataFlow> getMap() {
		return map;
	}

	public void setMap(LinkedHashMap<String,DataFlow> map) {
		this.map = map;
	}

	public String getTable_name() {
		return table_name;
	}

	public void setTable_name(String table_name) {
		this.table_name = table_name;
	}

	public String getWk_table_name() {
		return wk_table_name;
	}

	public void setWk_table_name(String wk_table_name) {
		this.wk_table_name = wk_table_name;
	}

	public boolean isConditionflg() {
		return conditionflg;
	}

	public void setConditionflg(boolean conditionflg) {
		this.conditionflg = conditionflg;
	}

	public String getShori_kbn() {
		return shori_kbn;
	}

	public void setShori_kbn(String shori_kbn) {
		this.shori_kbn = shori_kbn;
	}



}
