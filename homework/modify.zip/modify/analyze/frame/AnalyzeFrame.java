package org.jp.co.analyze.frame;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.apache.poi.ss.usermodel.Workbook;
import org.jp.co.analyze.AnalyzeMain;
import org.jp.co.analyze.bean.IFBean;
import org.jp.co.common.CommonFormat;
import org.jp.co.common.POIUtil;
import org.jp.co.common.TableDefine;


public class AnalyzeFrame extends JFrame {

	private static final String confpath = "conf/setting.cfg";

	JTextField datafilepath;
	JTextField formatfilepath;
	JTextField outputdir ;
	JButton btn;

	private static String TBLDEFINEPATH = "";

	public AnalyzeFrame(String title){
		super(title);
	}

	public void setComponent() {

		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100,100,400,350);
		getContentPane().setBackground(new Color(51,102,204));

		setFramePart();

		setVisible(true);

	}

	private void setFramePart() {


		JLabel label = new JLabel("①データファイル  (同フォルダにファイル出力)");
		label.setFont(CommonFormat.font);
		label.setForeground(new Color(255,255,102));
		label.setBounds(10, 10, 400, 50);

		datafilepath = new JTextField();
		datafilepath.setBounds(10, 50, 280, 50);
		datafilepath.setFont(CommonFormat.font);
		datafilepath.setBackground(CommonFormat.enablebackcolor);
		datafilepath.setDisabledTextColor(CommonFormat.enablemojicolor);
		datafilepath.setEnabled(false);

		JButton filechoice = new JButton("選択");
		filechoice.setBounds(300, 50, 75, 50);
		filechoice.setFont(CommonFormat.font);
		filechoice.addActionListener(new SelectDataFile());

		JLabel label2 = new JLabel("②IF定義ファイル");
		label2.setFont(CommonFormat.font);
		label2.setForeground(new Color(255,255,102));
		label2.setBounds(10, 100, 400, 50);

		formatfilepath = new JTextField();
		formatfilepath.setBounds(10, 140, 280, 50);
		formatfilepath.setFont(CommonFormat.font);
		formatfilepath.setBackground(CommonFormat.enablebackcolor);
		formatfilepath.setDisabledTextColor(CommonFormat.enablemojicolor);
		formatfilepath.setEnabled(false);

		//hidden項目
		outputdir = new JTextField();

		JButton filechoice2 = new JButton("選択2");
		filechoice2.setBounds(300, 140, 75, 50);
		filechoice2.setFont(CommonFormat.font);
		filechoice2.addActionListener(new SelectDataFile());

		btn = new JButton("分析");
		btn.setBounds(100, 230, 200, 50);
		btn.setFont(CommonFormat.font);
		btn.addActionListener(new ExecAnalyze());
		btn.setEnabled(false);

		add(label);
		add(datafilepath);
		add(filechoice);
		add(label2);
		add(formatfilepath);
		add(filechoice2);
		add(btn);

	}

	class SelectDataFile implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {

			FileDialog file = new FileDialog((java.awt.Frame) null,"ファイル選択");
			file.setVisible(true);

			if (file.getFile() != null) {

				if( e.getActionCommand().equals("選択") ){

					if( !file.getFile().endsWith(".dat") ){

						JOptionPane.showMessageDialog(null, "固定長のデータファイルを選択してください。");
						return;

					}

					datafilepath.setText(file.getDirectory() + File.separator + file.getFile() );
					outputdir.setText(file.getDirectory());

				}else{

					if( !file.getFile().startsWith("外部インターフェース") || !file.getFile().endsWith(".xls") ){

						JOptionPane.showMessageDialog(null, "外部インタフェース設計書を選択してください。");
						return;

					}

					formatfilepath.setText(file.getDirectory() + File.separator + file.getFile());

				}

				if ( !datafilepath.getText().equals("") && !formatfilepath.getText().equals("") ){

					btn.setEnabled(true);

				}else{

					btn.setEnabled(false);

				}

			}

		}

	}

	class ExecAnalyze implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {

			try {

				Workbook wb = POIUtil.readFile(formatfilepath.getText());

				//ファイル定義取得
				LinkedHashMap<String,IFBean> info = AnalyzeMain.ReadIF(wb);
				int recordlen = getRecordLen(info);

				//ファイルとテーブルとの紐つけを取得
				AnalyzeMain.ReadFlow(wb,info);

				//configファイル読み出し
				readConfig();

				//テーブル定義取得
				String tablename = POIUtil.getValue(25, 4, wb.getSheet("外部インターフェース仕様"));
				HashMap<String,TableDefine> tblinfo = AnalyzeMain.getTblDefile(TBLDEFINEPATH,tablename);

				//データを合成する
				info = AnalyzeMain.compoundData(info,tblinfo);

				//不要オブジェクトは破棄
				tblinfo = null;

				//データ分析
				String[][] data = AnalyzeMain.dataAnalyze(new BufferedReader(new InputStreamReader(new FileInputStream(datafilepath.getText()),"Shift_JIS")),info,recordlen);

				//書出し
				POIUtil.wirte(data, outputdir.getText() + File.separator + "expected.xlsx", "WK_" + tablename);

			} catch (Exception e1) {

				System.out.println(e1.getMessage());
				e1.printStackTrace();

			}

		}

		private int getRecordLen(LinkedHashMap<String, IFBean> info) {

			Iterator<String> it = info.keySet().iterator();
			String key = "";

			while(it.hasNext()){

				key = it.next();
				if( !it.hasNext() ){

					IFBean bean = info.get(key);
					return bean.getStartpos() + bean.getBytesize() - 1;

				}

			}

			return 0;

		}

		private void readConfig() throws UnsupportedEncodingException, FileNotFoundException, IOException {

			Properties prop = new Properties();
			prop.load(new InputStreamReader(new FileInputStream(confpath),"UTF-8"));

			TBLDEFINEPATH = prop.getProperty("TABLEDEFINEPATH") + File.separator + prop.getProperty("TABLEDEFINENAME");

		}

	}

}
