package org.jp.co.analyze;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.jp.co.analyze.bean.IFBean;
import org.jp.co.analyze.frame.AnalyzeFrame;
import org.jp.co.common.POIUtil;
import org.jp.co.common.TableDefine;
import org.jp.co.common.Util;

public class AnalyzeMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		AnalyzeFrame frame = new AnalyzeFrame("解析");
		frame.setComponent();

	}

	public static LinkedHashMap<String,IFBean> ReadIF(Workbook wb) throws Exception {

		Sheet sh = wb.getSheet("データレコード");

		IFBean bean;

		//ファイルヘッダー名をキー
		LinkedHashMap<String,IFBean> map = new LinkedHashMap<String,IFBean>();

		int rcnt = 7 ;

		while ( !POIUtil.getValue(rcnt, 1, sh).equals("") ){

			bean = new IFBean();

			bean.setFileheadername(POIUtil.getValue(rcnt, 1, sh));
			bean.setBytesize(Util.convertStringIngeger(POIUtil.getValue(rcnt, 21, sh)));
			bean.setStartpos(Util.convertStringIngeger(POIUtil.getValue(rcnt, 23, sh)));

			//キー重複の場合(Ｒ／Ａの場合なのでいったん消去して再設定←レコード長取得の関係で後勝ちにしたい)
			if ( map.containsKey(POIUtil.getValue(rcnt, 1, sh)) ){

				map.remove(POIUtil.getValue(rcnt, 1, sh));

			}
			map.put(POIUtil.getValue(rcnt, 1, sh), bean);
			rcnt++;

		}

		return map;

	}

	public static void ReadFlow(Workbook wb, LinkedHashMap<String, IFBean> info) throws Exception {

		IFBean bean;
		int repeattime = 0;
		String headername = "";

		Sheet sh = wb.getSheet("データフロー");

		int rcnt = 20;

		while ( !POIUtil.getValue(rcnt, 4, sh).equals("") || !POIUtil.getValue(rcnt, 27, sh).equals("") ){

			if ( !POIUtil.getValue(rcnt, 4, sh).equals("") ){

				//ファイルに対応する物理名あり
				if ( info.containsKey(POIUtil.getValue(rcnt, 4, sh)) ){

					bean = info.get(POIUtil.getValue(rcnt, 4, sh));
					bean.setColumn_name_ja(POIUtil.getValue(rcnt, 27, sh));

				//横持対応
				}else if( POIUtil.getValue(rcnt, 4, sh).contains("1～") ){

					//横持分取得
					repeattime = Util.convertStringIngeger(POIUtil.getValue(rcnt, 4, sh).split("1～")[1]);

					headername = POIUtil.getValue(rcnt, 4, sh).split("1～")[0];

					for(int index = 1;index <= repeattime;index++ ){

						if( info.containsKey(headername + index) ){

							bean = info.get(headername + index);
							bean.setColumn_name_ja(POIUtil.getValue(rcnt, 27, sh));

						}else{

							//おそらくの設計書不備のためException
							throw new Exception("ファイル項目名が不正です。 項目名 : " + POIUtil.getValue(rcnt, 4, sh) );

						}

					}

				//それ以外の場合
				}else{

					throw new Exception("ファイル項目名が不正です。(データフローとデータレコードシートで不一致) 項目名 : " + POIUtil.getValue(rcnt, 4, sh) );

				}

			}

			rcnt++;

		}

	}

	public static HashMap<String, TableDefine> getTblDefile(String tbldefinepath, String tablename) throws Exception {

		Workbook wb = POIUtil.readFile(tbldefinepath);
		Sheet sh = null;

		for ( int scnt = 0;scnt < wb.getNumberOfSheets(); scnt++ ){

			if ( POIUtil.getValue(4, 22, wb.getSheetAt(scnt)).equalsIgnoreCase("WK_" + tablename) ){

				sh = wb.getSheetAt(scnt);
				break;

			}else if( POIUtil.getValue(4, 22, wb.getSheetAt(scnt)).equalsIgnoreCase(tablename) ){

				sh = wb.getSheetAt(scnt);

			}

		}

		if( sh == null){

			throw new Exception("外部インタフェースに記載されたテーブル名がテーブル定義書に存在しない。");

		}

		//論理名をキーとしてカラム情報を格納
		HashMap<String,TableDefine> col = new HashMap<String,TableDefine>();
		TableDefine colinfo;

		//物理名と論理名の関連をMAPに定義
		for( int rcnt = 10;rcnt <= sh.getLastRowNum(); rcnt++ ){

			if( POIUtil.getValue(rcnt, 1, sh).equals("") ) break;
			colinfo = new TableDefine();
			colinfo.setColumn_name(POIUtil.getValue(rcnt, 6, sh));                              //物理名
			colinfo.setColumn_type(POIUtil.getValue(rcnt, 16, sh));                             //データ型
			colinfo.setData_volume(Util.convertInteger(POIUtil.getValue(rcnt, 19, sh)));        //データ精度
			col.put(POIUtil.getValue(rcnt, 1, sh),colinfo);

		}

		return col;

	}

	public static LinkedHashMap<String, IFBean> compoundData(LinkedHashMap<String, IFBean> info, HashMap<String, TableDefine> tblinfo) throws Exception {

		Iterator<String> it = info.keySet().iterator();

		//不要分を除いたファイル項目を詰めたコレクション
		LinkedHashMap<String, IFBean> data = new LinkedHashMap<String, IFBean>();

		IFBean bean;
		TableDefine tbl;

		while( it.hasNext() ){

			String key = it.next();

			if ( !info.get(key).getColumn_name_ja().equals("") ){

				//テーブル定義と名前が合致するもの
				if ( tblinfo.containsKey(info.get(key).getColumn_name_ja()) ){

					bean = info.get(key);
					tbl = tblinfo.get(info.get(key).getColumn_name_ja());
					bean.setColumn_name(tbl.getColumn_name());
					bean.setColumn_type(tbl.getColumn_type());
					bean.setData_volume(tbl.getData_volume());
					data.put(key, bean);

				//おそらく設計書ミスなのでException
				}else{

					throw new Exception("IF定義書とテーブル定義書のカラム名が一致していません。  カラム名 : " + key);

				}

			}

		}

		return data;

	}

	public static String[][] dataAnalyze(BufferedReader content, LinkedHashMap<String, IFBean> info,int recordlen) throws IOException {

		String key = "";

		//ArrayListに詰め替え
		Iterator<String> it = info.keySet().iterator();
		ArrayList<IFBean> infolist = new ArrayList<IFBean>();
		while ( it.hasNext() ){

			key = it.next();
			infolist.add(info.get(key));

		}

		ArrayList<String> data;
		ArrayList<String[]> list = new ArrayList<String[]>();

		//不要オブジェクト破棄
		info = null;

		//ファイル内容を取得
		String val = content.readLine();

		//ファイル内のデータ長取得
		int datalength = val.getBytes("Shift_JIS").length;

		data = new ArrayList<String>();

		//ヘッダー組立
		for ( IFBean col : infolist ){

			data.add(col.getColumn_name());

		}

		list.add(data.toArray(new String[0]));

		//レコード数分ループ
		for ( int indy = 1;indy <= datalength /  recordlen ; indy++ ){

			data = new ArrayList<String>();

			for ( int indx = 1;indx <= infolist.size() ; indx++  ){

				data.add(
					changeType(
						new String(val.getBytes("Shift_JIS")
						,infolist.get(indx - 1).getStartpos() + recordlen * (indy - 1) - 1
						,infolist.get(indx - 1).getBytesize())
						,infolist.get(indx - 1).getColumn_type(),infolist.get(indx - 1).getData_volume()
					)
				);

			}

			list.add(data.toArray(new String[0]));

		}

		return list.toArray(new String[0][0]);

	}

	private static String changeType(String content, String column_type, int data_volume) throws UnsupportedEncodingException {

		String result="";
		int mojibyte = 0;

		//前後スペースを除去
		content = StringUtils.stripToEmpty(content);

		if( column_type.equals("NVARCHAR2") || column_type.equals("VARCHAR2")){

			result = content;

		}else if( column_type.equals("NCHAR") || column_type.equals("CHAR") ){

			if ( column_type.equals("NCHAR") ){
				mojibyte = 0;
			}else{
				mojibyte = content.getBytes("Shift_JIS").length;
			}
			result = StringUtils.rightPad(content,data_volume - mojibyte);

		}else if( column_type.equals("NUMBER") ){

			if( content.equals("") ){

				result = "";

			}else{

				result = String.valueOf(Integer.parseInt(content));

			}

		}

		return result;
	}



}
