import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/*
 *
 * 自動作成シェル作成
 *
 */
public class createTransfersh {

	static String path = "//P2fsvt01/3520/DBS/ＫＤＤＩ情報系システム_部門間共有/90.参考資料/10.ORACLE/ph2.0/成果物/sh(Aiss配置)";
	static String cfgpath = "/setting";
	static final String ipadress = "10.2.6.2_";

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws Exception {

		//シェルテンプレート読み込み
		BufferedReader shtemp = readFile(path + cfgpath + File.separator + "filetransfer.sh","UTF-8");
		//置換文字列読み込み
		BufferedReader repstr = readFile(path + cfgpath + File.separator + "setting.cfg","Shift_JIS");
		//設定ファイル読み込み
		BufferedReader cfgtemp = readFile(path + cfgpath + File.separator + "tmplate.config","UTF-8");

		//sh内容
		StringBuilder sh = readContent(shtemp);
		//cfg内容
		StringBuilder cfg = readContent(cfgtemp);

		//置換文字
		ArrayList<String> repcommand = readSetting(repstr);

		shtemp.close();
		repstr.close();

		//日付取得
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy/MM/dd");

		String content;

		for ( String str : repcommand ){

			content = sh.toString().replaceAll("●", str.split("@")[0]);  //ジョブID
			content = content.replaceAll("▲", str.split("@")[1]);        //ファイルID
			content = content.replaceAll("★", str.split("@")[2]);        //ファイル名
			content = content.replaceAll("■",sdf1.format(new Date()) );  //日付

			//シェル作成
			writeFile(path + File.separator +  str.split("@")[0] + ".sh",content,"UTF-8");
			writeFile(path + "/conf" + File.separator + ipadress + str.split("@")[1] + ".config",cfg.toString(),"UTF-8");
			 content = "";

		}

	}

	private static void writeFile(String filepath, String content, String mojicode) throws IOException {

		BufferedWriter f1 = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filepath),mojicode));
		f1.write(content);
		f1.close();

	}

	private static StringBuilder readContent(BufferedReader shtemp) throws IOException {

		StringBuilder content = new StringBuilder();
		String command = "";
		while ( (command = shtemp.readLine()) != null ){

			content.append(command + "\n");

		}

		return content;

	}

	private static ArrayList<String> readSetting(BufferedReader repstr) throws IOException {

		String command = "";
		ArrayList<String> list = new ArrayList<String>();
		while( (command = repstr.readLine()) != null ){
			if( !command.startsWith("#") )list.add(command);
		}
		return list;

	}

	private static BufferedReader readFile(String filepath,String mojicode) throws UnsupportedEncodingException, FileNotFoundException{

		return  new BufferedReader(
				new InputStreamReader(
						new FileInputStream(filepath),mojicode)
				);

	}



}
