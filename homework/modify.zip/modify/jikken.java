import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;


public class jikken {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {

		//①commons-lang実験
//		for (int a = 0; a < 100 ;a++){
//			int cnt = RandomUtils.nextInt(0,101);
//			System.out.println(cnt);
//			System.out.println(RandomStringUtils.random(cnt ,DataList.kanji));
//		}
//		System.out.println(StringUtils.stripStart("000100","0").equals("") ? "0" : StringUtils.stripStart("000100","0"));

//		File f1 = new File("//P2fsvt01/3520/DBS/ＫＤＤＩ情報系システム_部門間共有/90.参考資料/10.ORACLE/ph2.0/単体テスト/制御ファイル");
//		for (File file:f1.listFiles()){
//			if (file.isFile())System.out.println(file.getName());
//		}

		//②バイト数取得確認
//		System.out.println("ﾌヘソタﾜハﾃﾊオキヘムラﾀﾋ      ".getBytes("Shift-JIS").length);
//		System.out.println("Ａ".getBytes("Shift-JIS").length);
////		System.out.println("ｱ".getBytes("Shift-JIS").length);
//		String val;

		//③ファイルよりバイト数カット
//		BufferedReader f1 = new BufferedReader(new FileReader(new File("C:\\Users\\tie027538\\Desktop\\M2AHN030.dat")));
//		while( ( val = f1.readLine()) != null){
//
//			System.out.println(new String(val.getBytes("Shift_JIS"),0,2,"Shift_JIS"));
//			System.out.println(new String(val.getBytes("Shift_JIS"),2,3,"Shift_JIS"));
//			System.out.println(new String(val.getBytes("Shift_JIS"),5,8,"Shift_JIS"));
//			System.out.println(new String(val.getBytes("Shift_JIS"),13,8,"Shift_JIS"));
//			System.out.println(new String(val.getBytes("Shift_JIS"),21,9,"Shift_JIS"));
//			System.out.println(new String(val.getBytes("Shift_JIS"),30,8,"Shift_JIS"));
//			System.out.println(new String(val.getBytes("Shift_JIS"),38,4,"Shift_JIS"));
//			System.out.println(new String(val.getBytes("Shift_JIS"),42,3,"Shift_JIS"));
//			System.out.println(new String(val.getBytes("Shift_JIS"),45,4,"Shift_JIS"));
//
//		}

//		//④文字列置換
//		String tempstr = "★ ファイル監視ネット\r\n★ ファイル監視\r\n★ ファイル転送ネット\r\n★ ファイル転送\r\n★ ファイル取込ネット\r\n★ ファイル取込\r\n★ 累積\r\n★ ファイルバックアップ\r\n★ ファイルクリーニング\r\n";
//		String val;
//		StringBuilder result = new StringBuilder();
//
//		BufferedReader f1 = new BufferedReader(new FileReader(new File("C:\\tool\\filelist")));
//		while( ( val = f1.readLine()) != null ){
//
//			result.append(tempstr.replaceAll("★", val));
//
//		}
//
//		System.out.println(result);

		//被置換対象文字列
		BufferedReader f1 = new BufferedReader(new InputStreamReader(new FileInputStream("C:\\tool\\list.txt"),"Shift_JIS"));

		ArrayList<String> list = new ArrayList<String>();
		String val = "";
		//被置換文字列
		while( ( val = f1.readLine()) != null ){

			list.add(val);

		}
		f1.close();

		//置換文字列
		BufferedReader f2 = new BufferedReader(new InputStreamReader(new FileInputStream("C:\\tool\\list2.txt"),"Shift_JIS"));

		ArrayList<String> list2 = new ArrayList<String>();
		String val2 = "";
		//置換文字列
		while( ( val2 = f2.readLine() ) != null ){

			list2.add(val2);

		}
		f2.close();

		for ( int c = 30; c <= 53 ;c++ ){
			for(String a : list ){
				System.out.println(a.replaceAll("■", String.valueOf(c)));
			}
			
		}
		
//		for( String b : list2 ){
//
//			for ( String a : list ){
//
//				System.out.println(a.replaceAll("●", b));
//
//			}
//
//		}

	}

}
