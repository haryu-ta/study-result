	DROP PROCEDURE IF EXISTS createFunction;

	DELIMITER //

	CREATE PROCEDURE createFunction()
	BEGIN

		-- �ϐ��錾
		DECLARE date_period INT;
		DECLARE record_cnt INT;

		SET record_cnt=0;
		SET date_period=100;

		-- ���[�v
		WHILE 1000 > record_cnt  DO

			-- INSERT��
			INSERT INTO TABLEA (COL1,COL2) VALUES ('1','2');
			
			SET record_cnt = record_cnt + 1;

		END WHILE;

	END

	//

	DELIMITER ;

	CALL createFunction();

	-- �v���V�[�W���폜
	DROP PROCEDURE createFunction;