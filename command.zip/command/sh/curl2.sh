#!/bin/sh

rm -f ./aaa.txt
curl --proxy XXX.XXX.XXX.XXX:8080 -s -o ./aaa.txt https://xxxx.hostname.com/nexus/service/rest/v1/repositories 

echo ""
echo "-----------------"
echo "★対象リポジトリ一覧"
cat aaa.txt | jq .[].name -r |  grep "maven-" 
echo "-----------------"
echo ""
echo ""

read -p "対象のリポジトリを選択してください : " repository

if [ -z ${repository} ];then
    echo "repositoryを指定してください。exit"
    exit
fi

# 対象のrepositoryが存在するか
count=`cat aaa.txt | grep "\"name\"" | grep ${repository} | wc -l`

if [ ${count} -ne 1 ];then
    echo "指定レポジトリが不正。exit"
    exit
fi

rm -f ./aaa.txt

curl --proxy XXX.XXX.XXX.XXX:8080 -s -o aaa.txt "https://xxxx.hostname.com/nexus/service/rest/v1/search/assets?repository=${repository}"

# 対象リポジトリ
func=`pwd | sed -e s@/work/gyomu/@@g | sed -e s@/target@@g`

echo ""
echo ""
echo "--------------------"
echo "ダウンロード対象機能"
echo "${func}"
echo "--------------------"
echo ""
echo ""

echo ""
echo ""
echo "------------------"
echo "ダウンロードファイル一覧(最新10件)"
cat aaa.txt  | jq -r '.items[].downloadUrl' | grep ${func} | egrep "*.jar$" | sort | tail -10
echo "------------------"
echo ""
echo ""
read -p "ダウンロードするファイルを選択してください: " fileurl

if [ -z ${fileurl} ];then
    echo "ファイルを指定してください。exit"
    exit
fi

count2=`cat aaa.txt | grep "\"downloadUrl\"" | grep "\"${fileurl}\"" | wc -l`

echo ${count2}

if [ ${count2} -ne 1 ];then
    echo "指定URLが不正。exit"
    exit
fi

rm -f ./aaa.txt

command=`echo ${fileurl} | sed -e 's/www./nexus./g'`
curl --proxy XXX.XXX.XXX.XXX:8080 -O ${command}

ls -l

echo "success"
