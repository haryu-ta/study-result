#!/bin/sh


# タグ名 (変更要)
tagprefix=xxxxxxxxxx


echo ""
echo "=========処理開始========"
echo ""
echo ""


# dockerファイル名
dockerfile=Dockerfile_xxx

# カレントディレクトリ名取得
path=`pwd`
curdir=`basename ${path}`


# jarファイル確認
if [ ! -f ./target/*.jar ]; then
  echo "ERROR : jarファイル存在せず"
  exit
fi


# dockerファイルが存在しない場合はエラー
if [ ! -f ${dockerfile} ]; then
  echo "ERROR : Dockerfile存在せず"
  exit
fi

# 必要な情報を取得
dockerinfo=`docker image ls | grep ${tagprefix}`

if [ ${?} -eq 0 ]; then
  repository=`echo ${dockerinfo} | awk -F ' ' '{print $1}'`
  tagname=`echo ${dockerinfo} | awk -F ' ' '{print $2}'`
  tagver=`echo ${tagname} | awk -F '-' '{print $3}' | sed -e s/v//g`
  newtagver=`expr ${tagver} + 1`
else
  repository="wsbkcpc0dr001f0:443/org1/sht"
  tagname=${tagprefix}-v0
  tagver=0
  newtagver=1
fi 
newtagname=`echo ${tagname} | sed -e s/-v${tagver}/-v${newtagver}/g`

# 情報表示
echo ""
echo "## 情報表示"
echo ■□■□■□■□■□■□■□■□■□■□■□■□
echo "対象 : ${curdir}"
echo "Repository : ${repository}"
echo "Old Tag : ${tagname}"
echo "New Tag : ${newtagname}"
echo ■□■□■□■□■□■□■□■□■□■□■□■□
echo ""
read -p "OK? (y/N): " yn
case "$yn" in [yY]*) ;; *) echo "abort." ; exit ;; esac

# Dockerイメージビルド
echo ""
echo "## Dockerイメージビルド"
cd ..
docker image build . -t ${repository}:${newtagname} -f ${curdir}/${dockerfile}

# DockerImageファイルの保存
echo ""
echo "## DockerImageファイルの保存"
docker save ${repository}:${newtagname} | gzip -c > /APL01/DATA/DOCKER/${curdir}.tar.gz

# 保存したDockerImageを指定フォルダに配置
#echo ""
#echo "## 保存したDockerImageを指定フォルダに配置"
#cp -p ${curdir}.tar.gz /APL01/DATA/DOCKER/.

# コピー先のファイル確認
if [ ! -f "/APL01/DATA/DOCKER/${curdir}.tar.gz" ]; then
  echo ""
  echo "ERROR : docker imageファイルコピーできず"
  exit
fi

# 元ファイル削除
#echo ""
#echo "## コピー前ファイル削除"
#rm -f ${curdir}.tar.gz

# Dockerイメージ削除
echo ""
echo "## Dockerイメージ削除"
docker image rm ${repository}:${tagname}
docker image rm ${repository}:${newtagname}

# Dockerレジストリサーバへのプッシュシェル実行
echo ""
echo "## Dockerレジストリサーバへのプッシュシェル実行"
/bin/bash /script/sht/bin/dbs_psh_docimg.sh ${curdir}.tar.gz,${newtagname}

# Dockerイメージのpull
echo ""
echo "## Dockerイメージのpull"
docker image pull ${repository}:${newtagname}

echo ""
echo ""
echo "-------------------結果情報-------------------"
echo ""
docker image ls
echo ""
echo "-------------------結果情報-------------------"

# pull確認
if [ `docker image ls | grep ${tagprefix} | wc -l` -eq 0  ]; then
  echo ""
  echo "ERROR : docker pull失敗"
  exit
fi

echo ""
echo ""
echo "★☆★☆ 処理正常終了 ★☆★☆"
echo ""

cd ${curdir}/target
rm -i *.jar
