#!/bin/sh

function checkURL (){
  str=`echo ${1} | grep "${2}"`
  if [ $? -ne 0 ]; then
    echo "URL不正"
    exit
  fi
}


## 処理ここから
if [ ${#} -ne 1 ]; then
  echo "引数不正"
  exit
fi

command=`echo ${1} | sed -e 's/www./nexus./g'`

checkURL ${command} https:
checkURL ${command} nexus
checkURL ${command} jar
checkURL ${command} repository
checkURL ${command} maven

echo " "
echo ""
echo "■□■□■□■□■□■□■□"
echo " URL : ${command} "
echo "■□■□■□■□■□■□■□"
read -p "OK? (y/N): " yn
case "$yn" in [yY]*) ;; *) echo "abort." ; exit ;; esac


curl --proxy XXX.XXX.XXX.XXX:8080 -O ${command}

if [ $? -ne 0 ]; then
  echo "異常終了"
  exit
fi 

ls -l

