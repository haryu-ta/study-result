#!/bin/bash

groupId="sg-xxxxxxxxxxxx"

# SecurityGroupの登録情報を返す
function dispInfo() {
    echo " "
    aws ec2 describe-security-groups --group-id ${groupId} --output table
    echo " "
    echo " "
}

# SecurityGroupの登録情報を消す
function deleteSG() {

    if [ -z ${1} ];then
        read -p "削除するIPアドレスを指定してください? (xxx.xxx.xxx.xxx): " ipadress
    
        # 入力されたIPチェック
        checkIPFormat ${ipadress}
        if [ ${?} -ne 0 ];then
            exit
        fi
    
        # 指定IPの登録確認
        checkRegistedIP ${ipadress}
    
        if [ ${?} -eq 0 ]; then
            echo "削除対象なし"
            exit
        fi
    else
        ipadress=${1}
    fi
    
    # 送信情報の組み立て
    json=$(cat << EOS
[{"IpProtocol": "tcp", "FromPort": 443, "ToPort": 443, "IpRanges": [{"CidrIp": "${ipadress}/32"}]}]
EOS
)
    
    # 削除処理
    echo " "
    echo "SG削除"
    aws ec2 revoke-security-group-ingress --group-id ${groupId} --ip-permissions "${json}"
    echo " "
    echo " "
}

# SecurityGroupの登録情報を追加
function registSG() {

    if [ -z ${1} ];then
        read -p "登録するIPアドレスを指定してください? (xxx.xxx.xxx.xxx): " ipadress
        
        # 入力されたIPチェック
        checkIPFormat ${ipadress}
        
        if [ ${?} -ne 0 ];then
            exit
        fi
        
        read -p "登録する備考を指定してください? ([社名]_[名前]): " description
        # 入力された備考チェック
        checkDescription ${description}
        
        if [ ${?} -ne 0 ];then
            exit
        fi
    else
        ipadress=${1}
        description=${2}
    fi
    
    # 送信情報の組み立て
    json=$(cat << EOS
[{"IpProtocol": "tcp", "FromPort": 443, "ToPort": 443, "IpRanges": [{"CidrIp": "${ipadress}/32","Description" : "${description}" }]}]
EOS
)
    # 登録処理
    echo " "
    echo "SG登録"
    aws ec2 authorize-security-group-ingress --group-id ${groupId} --ip-permissions "${json}"
    echo " "
    echo " "
}

# 指定したIPが登録されているかを確認
function checkRegistedIP(){
    result=`aws ec2 describe-security-groups --group-id ${groupId} --output table | grep "${1}/32" | wc -l`
    return ${result}
}

# 入力されたIPが正しいかを確認
function checkIPFormat(){
    if [ -z ${1} ];then
        echo "不正な値が指定されました。"
        return 2
    fi

    # どっと区切りで分解
    parts=(${1//./ })

    # 4個の数値
    if [ ${#parts[@]} -ne 4 ];then
        echo "不正な値が指定されました"
        return 2
    fi

    # 各桁ごとに分解
    for ip in "${parts[@]}"
    do
        if [ ${ip} -gt 256 -o ${ip} -lt 0 ];then
            echo "不正な値が指定されました"
            return 2
        fi
    done
    
    # グローバルIPは非許容
    if [ ${1} == "0.0.0.0" ];then
        echo "ブロードバンドIP非許容"
        return 2
    fi

    return 0
}

# 入力されたコメントが正しかを確認
function checkDescription(){
    if [ -z ${1} ];then
        echo "不正な値が指定されました。"
        return 2
    fi
}

function registAndDeleteSG(){
    read -p "削除・登録する備考を指定してください? ([社名]_[名前]): " description
    
    checkDescription ${description}
    
    if [ ${?} -ne 0 ];then
        exit
    fi

    result=`aws ec2 describe-security-groups --group-id ${groupId} --output table | grep "${description}" | wc -l`

    if [ ${result} -ne 1 ]; then
        echo " "
        echo "[${description}]で登録がないor複数あるため削除対象を絞れません"
        return 0
    fi

    newDescription=${description}

    read -p "登録するIPアドレスを指定してください? (xxx.xxx.xxx.xxx): " ipadress
    
    # 入力されたIPチェック
    checkIPFormat ${ipadress}
    
    if [ ${?} -ne 0 ];then
        exit
    fi
    
    newIpaddress=${ipadress}

    # 既存で登録されたIPアドレスを取得（削除のキーとする）
    registDescription=`aws ec2 describe-security-groups --group-id ${groupId} --output table | grep "${description}" | awk -F '|' '{print $5}' | sed -e 's@/32@@g'`

    echo " "
    # 削除処理
    deleteSG ${registDescription}
    # 登録処理
    echo " "
    registSG ${newIpaddress} ${newDescription}
}

# =============================== 本処理ここから ====================================

#echo "========================"
#echo "0: Redmine"
#echo "1: DBサーバ"
#echo "2: CrackProof"
#echo "9:終了"
#echo "========================"
#read -p "設定するSGを選択してください : " connect


#if [ ${connect} -eq 0 ];then
    #groupId="sg-xxxxxxxxxxx"
#elif [ ${connect} -eq 1 ];then
    #groupId=""
#else
    #echo "exit."
    #exit
#fi

# 登録情報表示
dispInfo

read -p "処理継続しますか? (y/N): " reply
case "${reply}" in [yY]*) ;; *) echo "exit." ; exit;; esac

reply=""


for line in `seq 1 100`
do
    echo " "
    echo "========================"
    echo "0:登録確認"
    echo "1:登録削除"
    echo "2:登録追加"
    echo "3:削除→登録"
    echo "9:終了"
    echo "========================"
    echo " "
    read -p "どの処理にしますか? : " reply

    if [ ${reply} -eq 0 ];then
        dispInfo
    elif [ ${reply} -eq 1 ];then
        deleteSG
    elif [ ${reply} -eq 2 ];then
        registSG
    elif [ ${reply} -eq 3 ];then
        registAndDeleteSG
    else
        echo "exit."
        exit
    fi

done