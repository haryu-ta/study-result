#!/bin/bash

for times in `seq 1 1000`
do

    ec2Id=""

    echo " "
    echo "========================"
    echo "★対象インスタンス"
    echo "1:Bastion"
    echo "2:ChatServer"
    echo "9:終了"
    echo "========================"
    echo " "
    read -p "どのインスタンスにしますか? : " reply

    if [ ${reply} -eq 1 ];then
        ec2Id="xxxxxxxxxxxxxxxxxxxxx"
    elif [ ${reply} -eq 2 ];then
        ec2Id="xxxxxxxxxxxxxxxxxxxxx"
    else
        echo "終了"
        exit
    fi

    echo " "
    echo "========================"
    echo "1:起動"
    echo "2:停止"
    echo "9:終了"
    echo "========================"
    echo " "
    read -p "どの処理にしますか? : " reply2

    if [ ${reply2} -eq 1 ];then
        execcommand="start"
    elif [ ${reply2} -eq 2 ];then
        execcommand="stop"
    else
        echo "終了"
        exit
    fi

    aws ec2 ${execcommand}-instances --instance-ids ${ec2Id}

done