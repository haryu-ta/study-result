package oracle.tools;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;

import oracle.CommonUtil;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.jp.co.common.POIUtil;

public class OracleMain {

	private static final String propertiesname = "oracle.tools.db";

	public static void main(String[] args) throws Exception {

		CreateDMLMain frame = new CreateDMLMain("SQL作成ツール");
		frame.setComponent();

	}

	public static void createSQL(String filedir,String outputdir) throws Exception{

		//置き換え要変数
		String tablename = "MBST101";
		//String filedir = "C:/Users/tie027538/Desktop/work";
		//String filename = "import_A.xls";
		//String outputdir = "C:/Users/tie027538/Desktop/work";

		//ファイル名
		String file = filedir;

		//指定ブック読込
		Workbook wb = POIUtil.readFile(file);
		//DB接続情報取得
		HashMap<String, String> map = CommonUtil.readConfig(propertiesname);
		Connection con = null;
		//DB接続
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection(
				"jdbc:oracle:thin:@" + map.get("SERVER") + ":" + map.get("PORT") + ":" + map.get("SID"),
				map.get("DBUSER"),
				map.get("PASSWORD"));
		//主キー情報取得
		DatabaseMetaData dbmd = con.getMetaData();

		//必要な変数の宣言
		ResultSet rs = null;
		ArrayList<String> pk;
		LinkedHashMap<String, String> cols;
		String[] inssql;
		String[] upsql;

		try{

			for (int scnt = 0; scnt < wb.getNumberOfSheets(); scnt++) {

				//シート名チェック
				if ( wb.getSheetName(scnt).startsWith("Sheet") ) continue;

				tablename = wb.getSheetName(scnt);

				//主キー情報取得
				rs = dbmd.getPrimaryKeys(map.get("SID"), map.get("DBUSER"), tablename);

				pk = new ArrayList<String>();
				while (rs.next()) {
					pk.add(rs.getString(4));
				}

				rs = null;

				//カラム情報取得
				cols = new LinkedHashMap<String, String>();
				rs = dbmd.getColumns(map.get("SID"), map.get("DBUSER"), tablename, "%");
				while (rs.next()) {
					//キー : 列名  / 値 : データタイプ
					cols.put(rs.getString(4), rs.getString(6));
				}

				inssql = createInsert(tablename,wb.getSheetAt(scnt),pk,cols);
				upsql = createUpdate(tablename,wb.getSheetAt(scnt),pk,cols);

				BufferedWriter outfile = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputdir + "/" + tablename.toUpperCase() + "_INSERT.sql" ),"Shift_JIS"));

				for( String sql : inssql){
					outfile.write(sql);
					outfile.write("\r\n");
				}

				outfile.close();
				outfile = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputdir + "/" + tablename.toUpperCase() + "_UPDATE.sql" ),"Shift_JIS"));

				for( String sql : upsql ){
					outfile.write(sql);
					outfile.write("\r\n");
				}

				outfile.close();

			}

			rs.close();
			con.close();

		}catch(Exception e){

			rs.close();
			con.close();
			throw e;

		}



	}

	private static String[] createUpdate(String tablename, Sheet ws, ArrayList<String> pk,
			LinkedHashMap<String, String> cols) throws Exception {

		String UPD1 = "UPDATE " + tablename + " \r\nSET\r\n ★ \r\n■;";
		String valuelist = "";
		String pklist = ""; //WHERE\r\n

		ArrayList<String> updsql = new ArrayList<String>();
		String val = "";
		int colno = 0;



		for( int rowno = 1 ; rowno < ws.getLastRowNum() ; rowno++ ){

			while( !POIUtil.getValue(0, colno, ws).equals("") ){

				//if ( colno != 0 ) valuelist += ",";

				//テーブル定義にない列名が使用されている場合
				if (  cols.get(POIUtil.getValue(0, colno, ws)) == null ){
					Exception e = new Exception("テーブル定義に存在しない列が定義さています");
					throw e;
				}

				//文字列
				if (cols.get(POIUtil.getValue(0, colno, ws)).equals("NCHAR")
						|| cols.get(POIUtil.getValue(0, colno, ws)).equals("CHAR") ||
						cols.get(POIUtil.getValue(0, colno, ws)).startsWith("NVARCHAR")
						|| cols.get(POIUtil.getValue(0, colno, ws)).startsWith("VARCHAR")) {

					val = "'" + POIUtil.getValue(rowno, colno, ws) + "'";

					//数値型
				} else if (cols.get(POIUtil.getValue(0, colno, ws)).equals("NUMBER")) {

					//値なしの場合
					if (POIUtil.getValue(0, colno, ws).equals("")) {

						val = "null";

						//値有り
					} else {

						val = POIUtil.getValue(rowno, colno, ws);

					}

					//日付型
				} else {

					val = "TO_TIMESTAMP('"
							+ POIUtil.getValue(rowno, colno, ws).replaceAll(" ", "").replaceAll(":", "")
									.replaceAll("-", "")
							+ "','YYYYMMDDHH24MISS')";

				}

				//主キー場合
				if (pk.contains(POIUtil.getValue(0, colno, ws))) {

					if ( !pklist.equals("") ) pklist += "\r\nAND ";

					pklist += "\t" + POIUtil.getValue(0, colno, ws) + " = " + val;

				} else {

					if ( !valuelist.equals("") ) valuelist += ",\r\n";
					valuelist += "\t" + POIUtil.getValue(0, colno, ws) + " = " + val;

				}

				colno++;

			}

			if ( pklist.equals("") ){
				updsql.add(UPD1.replace("★", valuelist).replace("■", "" ));
			}else{
				updsql.add(UPD1.replace("★", valuelist).replace("■", "WHERE\r\n" + pklist ));
			}
			valuelist = "";
			pklist = "";
			colno = 0;

		}

		return updsql.toArray(new String[0]);
	}

	//ファイルの値を使用したINSERT文作り
	private static String[] createInsert(String tablename,Sheet ws, ArrayList<String> pk, LinkedHashMap<String, String> cols) throws Exception {

		String INS1 = "INSERT INTO " + tablename + " (★) VALUES (■);";
		String valuelist = "";
		String collist = "";
		ArrayList<String> inssql = new ArrayList<String>();
		String val = "";
		int colno = 0;

		//カラム名組み立て
		Iterator<String> it = cols.keySet().iterator();
		while( it.hasNext() ){

			val = it.next();
			collist += val;

			if( it.hasNext() ) collist += ",";

		}

		//値部分頸縦
		for( int rowno = 1 ; rowno < ws.getLastRowNum() ; rowno++ ){

			while( !POIUtil.getValue(0, colno, ws).equals("") ){

				if ( colno != 0 ) valuelist += ",";

				//テーブル定義にない列名が使用されている場合
				if (  cols.get(POIUtil.getValue(0, colno, ws)) == null ){
					Exception e = new Exception("テーブル定義に存在しない列が定義さています");
					throw e;
				}

				//文字列
				if ( cols.get(POIUtil.getValue(0, colno, ws)).equals("NCHAR") || cols.get(POIUtil.getValue(0, colno, ws)).equals("CHAR") ||
						cols.get(POIUtil.getValue(0, colno, ws)).startsWith("NVARCHAR") || cols.get(POIUtil.getValue(0, colno, ws)).startsWith("VARCHAR")	){

					valuelist +=  "'" + POIUtil.getValue(rowno, colno, ws) + "'";

				//数値型
				}else if( cols.get(POIUtil.getValue(0, colno, ws)).equals("NUMBER") ){

					//値なしの場合
					if ( POIUtil.getValue(0, colno, ws).equals("") ){
						valuelist += "'null'";

					//値有り
					}else{

						valuelist +=   POIUtil.getValue(rowno, colno, ws);

					}

				//日付型
				}else{

					valuelist += "TO_TIMESTAMP('" + POIUtil.getValue(rowno, colno, ws).replaceAll(" ", "").replaceAll(":", "").replaceAll("-", "")
							+ "','YYYYMMDDHH24MISS')";

				}


				colno++;

			}

			inssql.add(INS1.replace("★", collist).replace("■", valuelist));
			valuelist = "";
			colno = 0;

		}
		return inssql.toArray(new String[0]);
	}

}
