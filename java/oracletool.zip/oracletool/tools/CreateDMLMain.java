package oracle.tools;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.jp.co.common.CommonFormat;

public class CreateDMLMain extends JFrame {

	JTextField datafilepath;
	JTextField outputfilepath;
	JTextField outputdir;
	JButton btn;

	public CreateDMLMain(String title){
		super(title);
	}

	public void setComponent() {

		getContentPane().setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100,100,400,330);
		getContentPane().setBackground(new Color(204,255,0));

		setFramePart();

		setVisible(true);

	}

	private void setFramePart(){

		JLabel label = new JLabel("①入力ファイル");
		label.setFont(CommonFormat.font);
		label.setForeground(new Color(0,0,255));
		label.setBounds(10, 10, 400, 50);

		datafilepath = new JTextField();
		datafilepath.setBounds(10, 50, 280, 50);
		datafilepath.setFont(CommonFormat.font);
		datafilepath.setBackground(CommonFormat.enablebackcolor);
		datafilepath.setDisabledTextColor(CommonFormat.enablemojicolor);
		datafilepath.setEnabled(false);

		JButton filechoice = new JButton("選択");
		filechoice.setBounds(300, 50, 75, 50);
		filechoice.setFont(CommonFormat.font);
		filechoice.addActionListener(new SelectDataFile());

		JLabel label2 = new JLabel("②ファイル出力先");
		label2.setFont(CommonFormat.font);
		label2.setForeground(new Color(0,0,255));
		label2.setBounds(10, 100, 400, 50);

		outputfilepath = new JTextField();
		outputfilepath.setBounds(10, 140, 280, 50);
		outputfilepath.setFont(CommonFormat.font);
		outputfilepath.setBackground(CommonFormat.enablebackcolor);
		outputfilepath.setDisabledTextColor(CommonFormat.enablemojicolor);
		outputfilepath.setEnabled(false);

//		//hidden項目
//		outputdir = new JTextField();

		JButton filechoice2 = new JButton("選択2");
		filechoice2.setBounds(300, 140, 75, 50);
		filechoice2.setFont(CommonFormat.font);
		filechoice2.addActionListener(new SelectOutDir());

		btn = new JButton("作成");
		btn.setBounds(100, 220, 200, 50);
		btn.setFont(CommonFormat.font);
		btn.addActionListener(new createSQL());
		//btn.setEnabled(false);

		add(label);
		add(datafilepath);
		add(filechoice);
		add(label2);
		add(filechoice2);
		add(outputfilepath);
		add(btn);

	}

	class SelectDataFile implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {

			FileDialog file = new FileDialog((java.awt.Frame) null,"ファイル選択");
			file.setVisible(true);

			if (file.getFile() != null) {

				if( e.getActionCommand().equals("選択") ){

					if( !file.getFile().endsWith(".xls") && !file.getFile().endsWith(".xlsx") ){

						JOptionPane.showMessageDialog(null, "EXCELファイルを選択してください");
						return;


					}

					datafilepath.setText(file.getDirectory()  + file.getFile() );

				}

			}

		}

	}

	class SelectOutDir implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {

			JFileChooser file = new JFileChooser();
			file.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

			int selected = file.showSaveDialog(CreateDMLMain.this);
			if (selected == JFileChooser.APPROVE_OPTION){

				//選択されたディレクトリを出力先ラベルに設定
				outputfilepath.setText(file.getSelectedFile().getAbsolutePath());

			}

			return;

		}

	}

	class createSQL implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {

			if( datafilepath.getText().equals("") ){

				JOptionPane.showMessageDialog(null, "データファイルを選択してください");
				return;

			}else if( outputfilepath.getText().equals("") ){

				JOptionPane.showMessageDialog(null, "出力先ディレクトリを指定してください");
				return;

			}

			try {

				OracleMain.createSQL(datafilepath.getText(),outputfilepath.getText());

			} catch (Exception e1) {


				JOptionPane.showMessageDialog(null, e1.getMessage());

			}

		}

	}

}
