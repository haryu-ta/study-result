# -*- coding: utf-8 -*-

from selenium import webdriver
import configparser

if __name__ == '__main__':

    inifile = configparser.SafeConfigParser()
    inifile.read("./setting.ini", "shift_jis")

    #ログイン情報
    userid = inifile.get("LOGININFO","USER")
    pw = inifile.get("LOGININFO","PASSWORD")
    #パス情報
    driverpath = inifile.get("URLINFO","DRIVERPATH")
    indexpage = inifile.get("URLINFO","URL")
    #フォーム情報
    username = inifile.get("FORMINFO","USERFORM")
    password = inifile.get("FORMINFO","PASSFORM")
    login = inifile.get("FORMINFO","LOGINFORM")

    browser = webdriver.Chrome(driverpath)
    browser.get(indexpage)
    browser.find_element_by_id(username).send_keys(userid)
    browser.find_element_by_id(password).send_keys(pw)
    browser.find_elements_by_name(login)[0].click()